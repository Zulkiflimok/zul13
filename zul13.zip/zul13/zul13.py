from TEAM_TERMUX import *
from liff.ttypes import LiffChatContext, LiffContext, LiffSquareChatContext, LiffNoneContext, LiffViewRequest
from akad.ttypes import Message
from akad.ttypes import ContentType as Type
from akad.ttypes import TalkException
from datetime import datetime, timedelta
from time import sleep
from bs4 import BeautifulSoup as bSoup
from bs4 import BeautifulSoup
from humanfriendly import format_timespan, format_size, format_number, format_length
from gtts import gTTS
from threading import Thread
from io import StringIO
from multiprocessing import Pool
from googletrans import Translator
from urllib.parse import urlencode
from Naked.toolshed.shell import execute_js
from wikiapi import WikiApi
from tmp.MySplit import *
from random import randint
from shutil import copyfile
from youtube_dl import YoutubeDL
import subprocess, youtube_dl, humanize, traceback
import subprocess as cmd
import platform
import requests, json
import time, random, sys, json, null, pafy, codecs, html5lib ,shutil ,threading, glob, re, base64, string, os, requests, six, ast, pytz, wikipedia, urllib, urllib.parse, atexit, asyncio, traceback
_session = requests.session()
try:
    import urllib.request as urllib2
except ImportError:
    import urllib2
#=========================================================
#f = open('token1.txt','r')
#token = f.read()

#cl = LINE("{}".format(str(token)))
#f.close()
client = LINE("ime@gmail.com","katasandi") #GANTI IMEL DAN KATA SANDI LINE MU DISINI
client.log("Auth Token : " + str(client.authToken))
client.log("Timeline Token : " + str(client.tl.channelAccessToken))
#====================================================================
waitOpen = codecs.open("Zul/wait.json","r","utf-8")
settingsOpen = codecs.open("Zul/temp.json","r","utf-8")
#===================================================================
imagesOpen = codecs.open("Zul/image.json","r","utf-8")
stickersOpen = codecs.open("Zul/sticker.json","r","utf-8")
stickerzOpen = codecs.open("Zul/stickerz.json","r","utf-8")
stickers1Open = codecs.open("Zul/sticker1.json","r","utf-8")
stickers2Open = codecs.open("Zul/sticker2.json","r","utf-8")
#=====================================================================
Settempopen = codecs.open("Zul/settemp.json","r","utf-8")
AMOpen = codecs.open("Zul/am.json","r","utf-8")
Onoffopen = codecs.open("Zul/on.json","r","utf-8")
balasopen = codecs.open("Zul/message.json","r","utf-8")
Banlist = {"blacklist": {},"ablack": False,"dblack": False}
#=====================================================================
clientProfile = client.getProfile()
clientSettings = client.getSettings()
clientPoll = OEPoll(client)
clientMID = client.getProfile().mid
#=====================================================================
admin = ["ganti mid kamu"] #ganti mid kamu
owner = ["ganti mid kamu"] #ganti mid kamu
creator = ["ganti mid kamu"] #ganti mid kamu
nodelserver = ["ganti mid kamu"] #ganti mid kamu
ZULKIFLI = list(admin) + list(creator)
moi = "akX5Lq6pYaQnZ9Re60rnHEngiQGRXOkGR9kAg2qKN6tbQyotmJV2X4cj7iLR4rx7"
ktp = client.getContact(clientMID).displayName

#=====================================================================
loop = asyncio.get_event_loop()
#admin =[clientMID]
botStart = time.time()
msg_image={}
msg_video={}
msg_sticker={}
msgdikirim = {}
msgditerima = {}
unsendchat = {}
msg_dict = {}
temp_flood = {}
groupName = {}
groupImage = {}
kuciyose = {}
protectname = []
wbanlist = []
protectinvite = []
protectkick = []
protectjoin = []
protectqr = []
protectantijs = []
#====================================================
wait = json.load(waitOpen)
settings = json.load(settingsOpen)
#====================================================
stickers1 = json.load(stickers1Open)
stickers2 = json.load(stickers2Open)
stickers = json.load(stickersOpen)
stickerz = json.load(stickerzOpen)
images = json.load(imagesOpen)
#====================================================
Settemp = json.load(Settempopen)
AM_SAKLAR = json.load(Onoffopen)
AM_backup = json.load(AMOpen)
AM_message = json.load(balasopen)
#&&&&&&&&

#====================================================
responsename = client.getProfile().displayName
mulai = time.time()
#====================================================
for js in nodelserver:
  try:
    client.findAndAddContactsByMid(js)
  except:pass

#=========[ SETTINGS TEMPLATE ]===============
temp_notif = {"temp":"TEAM TERMUX V 13"}
temp_size = {"ukuran":"micro"}
temp_background = {"warna":"#000000"}
temp_popup = {"pup":"line://nv/profilePopup/mid=u42880eb65b2da1eb8fd3b7a9caa4ccc3"}
#temp_chanel = {"link":"https://www.youtube.com/channel/UCqAk2EvmA86wthgifn2D_VA?view_as=subscriber"}
temp_creatore = {"pup":"line://nv/profilePopup/mid=u42880eb65b2da1eb8fd3b7a9caa4ccc3"}
#========[ MENU TEMPLATE ]=========
menu_img = {"img":"https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcRrJWOLGKLIuF3NB64QHgk5TalEB1qmp_ly-XimgoInPm6Mq6Rk"}
menu_text = {"warna":"#FFD700"}
menu_text_size = {"ukuran":"xs"}
menu_border = {"warna":"#FFD700"}
menu_background = {"warna":"#000000"}
#========[ OBJECT TEMP ]===========
object_temp = {"size":"micro"}
object_image = {"img":"https://media.istockphoto.com/photos/modern-futuristic-neon-lights-on-old-grunge-brick-wall-room-3d-picture-id1151380473?b=1&k=6&m=1151380473&s=170667a&w=0&h=lp3tNBKRY1JKffKg2qvKJasO9IMXvj6uCHd_JPNPVk4="}
object_icon = {"img":"https://i.ibb.co/KbfDFN1/1657636839741.jpg"}
object_label_utama = {"label":"𝑺 𝑬 𝑳 𝑭 𝑩 𝑶 𝑻"}
object_label_text_color = {"warna":"#ffffff"}
object_label_text_size = {"size":"xxs"}
object_text = {"warna":"#ffffff"}
object_text_size = {"size":"xxs"}
object_border_color = {"warna":"#FF7F00"}
object_background = {"warna":"#ffffff"}
#=======[ LABEL SETTINGS ]=========
label ={"label":"TEAM TERMUX V 13"}
label_text_coloor = {"warna":"#FFFFFF"}
label_text_size = {"ukuran":"xs"}
label_bg_color = {"warna":"#FF0000"}
label_background = {"warna":"#DC143C"}
#======[ FOOTER SETTINGS ]=========
foter_img = {"img":"https://i.ibb.co/KbfDFN1/1657636839741.jpg"}
foter_label = {"label":"TEAM TERMUX V 13"}
#===========[ SIDER TEMP ]==========
sider_img = {"img":"https://www.ecopetit.cat/wpic/mpic/130-1308664_dark-anime-wallpaper-phone.jpg"}
sider_border_color = {"warna":"#FFD700"}
sider_icon = {"img":""}
sider_text_color = {"warna":"#FFD700"}
sider_label_text = {"label":"TEAM TERMUX V 13"}
sider_text_object_color = {"warna":"#ffffff"}
sider_text_object_size = {"size":"xxx"}
#=============[ SIDER 2 TEMP ]=================
sider2_bg = {"warna":"#000000"}
sider2_img = {"img":"https://www.ecopetit.cat/wpic/mpic/130-1308664_dark-anime-wallpaper-phone.jpg"}
sider2_icon = {"img":"https://4.imimg.com/data4/IO/KU/MY-22180908/hikvision-dome-camera-1080p-500x500.png"}
sider2_garis = {"warna":"#40E0D0"}
sider2_text = {"text":"Terciduk"}
sider2_text_color = {"warna":"#ffffff"}
sider2_text_size = {"ukuran":"xxs"}
sider2_label_color = {"warna":"#800000"}
sider2_text_label_color = {"warna":"#ffffff"}
#=============[ BROADCATS TEMP ]
bc_bg = {"warna":"#000000"}
bc_text = {"warna":"#ffffff"}
bc_size = {"ukuran":"xxs"}
bc_border = {"warna":"#FF4500"}
bc_label_color = {"warna":"#800000"}
bc_label_text = {"warna":"#ffffff"}
bc_label_text_size = {"ukuran":"xs"}
api1 = "K2021liproAngrus"
api2 = "RrxMisu9KMsa-S"
apiKeyy = "RrxMisu9KMsa"
#===========================================================================================================
def backupData():
    try:
        backup = settings
        f = codecs.open('Zul/temp.json','w','utf-8')
        json.dump(backup, f, sort_keys=True, indent=4, ensure_ascii=False)
        backup = stickers
        f = codecs.open('Zul/sticker.json','w','utf-8')
        json.dump(backup, f, sort_keys=True, indent=4, ensure_ascii=False)
        backup = stickerz
        f = codecs.open('Zul/stickerz.json','w','utf-8')
        json.dump(backup, f, sort_keys=True, indent=4, ensure_ascii=False)
        backup = images
        f = codecs.open('Zul/image.json','w','utf-8')
        json.dump(backup, f, sort_keys=True, indent=4, ensure_ascii=False)
        backup = wait
        f = codecs.open('Zul/wait.json','w','utf-8')
        json.dump(backup, f, sort_keys=True, indent=4, ensure_ascii=False)
        backup = stickers1
        f = codecs.open('Zul/sticker1.json','w','utf-8')
        json.dump(backup, f, sort_keys=True, indent=4, ensure_ascii=False)
        backup = stickers2
        f = codecs.open('Zul/sticker2.json','w','utf-8')
        json.dump(backup, f, sort_keys=True, indent=4, ensure_ascii=False)
        backup = AM_backup
        f = codecs.open('Zul/am.json','w','utf-8')
        json.dump(backup, f, sort_keys=True, indent=4, ensure_ascii=False)
        backup = Settemp
        f = codecs.open('Zul/settemp.json','w','utf-8')
        json.dump(backup, f, sort_keys=True, indent=4, ensure_ascii=False)
        backup = AM_SAKLAR
        f = codecs.open('Zul/on.json','w','utf-8')
        json.dump(backup, f, sort_keys=True, indent=4, ensure_ascii=False)
        backup = AM_message
        f = codecs.open('Zul/message.json','w','utf-8')
        json.dump(backup, f, sort_keys=True, indent=4, ensure_ascii=False)
        return True
    except Exception as error:
        logError(error)
        return False

#========[ Def templet ]======================================================================



def sendTemplate(group, data):
    xyz = LiffChatContext(group)
    xyzz = LiffContext(chat=xyz)
    view = LiffViewRequest('1602687308-GXq4Vvk9', xyzz)
    token = client.liff.issueLiffView(view)
    url = 'https://api.line.me/message/v3/share'
    headers = {'Content-Type': 'application/json','Authorization': 'Bearer %s' % token.accessToken}
    data = {"messages":[data]}
    requests.post(url, headers=headers, data=json.dumps(data))

def sendTemplate(to, data):
    xyz = LiffChatContext(to)
    xyzz = LiffContext(chat=xyz)
    view = LiffViewRequest('1602687308-GXq4Vvk9', xyzz)
    token = client.liff.issueLiffView(view)
    url = 'https://api.line.me/message/v3/share'
    headers = {'Content-Type': 'application/json','Authorization': 'Bearer %s' % token.accessToken}
    data = {"messages":[data]}
    requests.post(url, headers=headers, data=json.dumps(data))

def sendCarousel(to, data):
    data = json.dumps(data)
    xyz = LiffChatContext(to)
    xyzz = LiffContext(chat=xyz)
    view = LiffViewRequest('1602687308-GXq4Vvk9', xyzz)
    token = client.liff.issueLiffView(view)
    url = 'https://api.line.me/message/v3/share'
    headers = {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer %s' % token.accessToken
    }
    return requests.post(url, data=data, headers=headers)

def sendCarousel(to,col):
    col = json.dumps(col)
    xyz = LiffChatContext(to)
    xyzz = LiffContext(chat=xyz)
    view = LiffViewRequest('1602687308-GXq4Vvk9', xyzz)
    token = client.issueLiffView(view)
    url = 'https://api.line.me/message/v3/share'
    headers = {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer %s' % token.accessToken
    }
    return requests.post(url, data=col, headers=headers)

#==============================================================================================
def vinfooter(to,love):
    data = {"type": "text","text": love,"sentBy": {"label": Settemp["footer"]["text"],"iconUrl":Settemp["footer"]["image"],"linkUrl": Settemp["footer"]["poppup"]}}
    sendTemplate(to, data)
    
def vin_gabut(to, text):
    am = client.getContact(clientMID)
    data = {"type":"flex","altText": "TEAM TERMUX V 13","contents":{"type": "carousel","contents": [{"type": "bubble","size": "micro","body": {"type": "box","layout": "vertical","contents": [{"type": "image","url": "https://raw.githubusercontent.com/Andika163/liff-/master/20201018_044358.png","size": "full","aspectMode": "cover", "aspectRatio": "35:9","gravity": "top"},{"type": "box","layout": "vertical","contents": [{"type": "image","url": "https://obs.line-scdn.net/{}".format(am.pictureStatus),"size": "full","aspectMode": "cover"}],"position": "absolute","width": "34px","height": "34px","cornerRadius": "100px","offsetTop": "4px","offsetStart": "8px","borderWidth": "1px","borderColor": "#48D1CC"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "TEAM TERMUX V 13","size": "xxs","color": "#ffffff"}],"position": "absolute","offsetTop": "25px","offsetStart": "43px","width": "60px"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": text,"size": "xs","color": "#ffffff"}],"position": "absolute","offsetTop": "11px","offsetStart": "47px","width": "90px"}],"paddingAll": "0px","backgroundColor": "#1E90FF","borderWidth": "1px","borderColor": "#ffffff","cornerRadius": "10px"}}]}}
    sendTemplate(to,data)
    
def vintemp(to, text):
    warna1 = ("#1AE501","#0108E5","#696969","#E50AE0","#E50F00","#DEE500","#47E1E5","#C82EF8")
    warnanya1 = random.choice(warna1)
    data = {
            "type": "flex",
            "altText": "TEAM TERMUX V 13",
            "contents":{
  "type": "bubble",
  "size": "micro",
  "body": {
    "type": "box",
    "layout": "vertical",
    "contents": [
      {
        "type": "box",
        "layout": "horizontal",
        "contents": [
          {
            "type": "text",
            "text":  text,
            "size": "xs",
            "color": "#FFFF00",
            "wrap": True,
            "weight": "regular",
            "offsetStart": "3px"
          }
        ],
        "margin": "xs",
        "spacing": "md",
        "backgroundColor": "#3333FF"
      },
      {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "text",
            "text": "TEAM TERMUX V 13",
            "align": "center",
            "size": "xs",
            "color": "#FFFF00"
          }
        ],
        "paddingAll": "2px",
        "backgroundColor": "#000033",
        "margin": "xs"
      }
    ],
    "paddingAll": "0px",
    "borderWidth": "2px",
    "borderColor": "#D7D8DD",
    "cornerRadius": "10px",
    "spacing": "xs"
  },
  "styles": {
    "body": {
      "backgroundColor": "#D7D8DD"
    }
  }
}
}
    sendTemplate(to, data)

def vintemp2(to, Zul):
	data = {"type": "flex","altText": "TEAM TERMUX V 13","contents": {"type": "carousel","contents": [{"type": "bubble","size": "kilo","body": {"type": "box","layout": "vertical","contents": [{"type": "box","layout": "vertical","contents": [{"type": "box","layout": "vertical","contents": [{"type": "box","layout": "vertical","contents": [{"type": "text","text": Zul,"wrap": True,"size": "xxs","align": "start","offsetStart": "3px"}],"width": "240px","offsetStart": "4px","backgroundColor": "#ffffff","borderWidth": "1px","cornerRadius": "5px","borderColor": "#00FF00"}],"offsetTop": "3px","paddingBottom": "5px"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": Settemp["call"]["labeltext"],"align": "center","size": "sm","color": "#00FF00"}],"action": {"type": "uri","label": "action","uri": Settemp["Notif"]["poppup"]}}],"borderWidth": "1px","borderColor": "#00FF00","width": "250px","cornerRadius": "5px","offsetStart": "3px","offsetTop": "4px","backgroundColor": "#000000"}],"paddingAll": "0px","borderWidth": "2px","borderColor": "#000000","cornerRadius": "10px","paddingBottom": "7px"},"styles": {"body": {"backgroundColor": "#00FF00"}}}]}}
	sendTemplate(to, data)

def achinkZul1(to, love):
    am = client.getContact(clientMID)
    tz = pytz.timezone("Asia/Jakarta")
    timeNow = datetime.now(tz=tz)
    timeHours = datetime.strftime(timeNow," (%H:%M)")
    data = {"type": "flex","altText": Settemp["Notif"]["tempnotif"],"contents": {"type": "carousel","contents": [{"type": "bubble","size": "micro","body": {"type": "box","layout": "vertical","contents": [{"type": "image","size": "full","aspectMode": "cover","aspectRatio": "2:3","gravity": "top","url": "https://obs.line-scdn.net/{}".format(am.pictureStatus)},{"type": "box","layout": "vertical","position": "absolute","contents": [{"type": "image","size": "full","aspectMode": "cover","aspectRatio": "2:3","gravity": "top","url": Settemp["menu"]["anim4"],"animated":True}]},{"type": "box","layout": "vertical","contents": [{"type": "box","layout": "horizontal","contents": [{"type": "box","layout": "vertical","contents": [{"type": "image","url": Settemp["menu"]["icon"],"aspectMode": "cover"}],"width": "20px","height": "20px"},{"type": "separator","color":Settemp["menu"]["Garis"]},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "𝑪 𝑶 𝑴 𝑴 𝑨 𝑵 𝑫","align": "center","size": "xs","color": Settemp["menu"]["Garis"],"offsetTop": "1px"}],"cornerRadius": "5px"},{"type": "separator","color": Settemp["menu"]["Garis"]},{"type": "box","layout": "vertical","contents": [{"type": "image","url": Settemp["menu"]["icon"],"aspectMode": "cover"}], "width": "20px","height": "20px"}]}],"position": "absolute","offsetTop": "3px","width": "150px","offsetStart": "3px","cornerRadius": "5px","borderWidth": "1px","borderColor":Settemp["menu"]["Garis"]},{"type": "box","layout": "vertical","contents": [{"type": "box","layout": "vertical","contents": [{"type": "box","layout": "vertical","contents": [{"type": "text","text": love,"color":Settemp["menu"]["Warnatext"],"size": "xxs","wrap": True,"offsetStart": "2px"}]}]}],"position": "absolute","offsetTop": "28px","width": "150px","offsetStart": "3px"},{"type": "box","layout": "vertical","contents": [{"type": "box","layout": "horizontal","contents": [{"type": "box","layout": "vertical","contents": [{"type": "image","url": "https://obs.line-scdn.net/{}".format(am.pictureStatus),"aspectMode": "cover","size": "full"}],"width": "33px","height": "33px"},{"type": "separator","color": Settemp["menu"]["Garis"]},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "{}".format(client.getProfile().displayName),"color": Settemp["menu"]["warnatextnikname"],"align": "center","offsetTop": "1px","size": "xxs"},{"type": "separator","color": Settemp["menu"]["Garis"]},{"type": "box","layout": "vertical","contents": [{"type": "text","text": Settemp["menu"]["labeltext"],"align": "center","size": "xs","color": "#48D1CC"}],"backgroundColor":Settemp["menu"]["warnalabel"]}]}],"backgroundColor": "#000000"}],"position": "absolute","offsetTop": "196px","width": "150px","offsetStart": "3px","borderWidth": "1px","borderColor":Settemp["menu"]["Garis"],"cornerRadius": "5px"}],"paddingAll": "0px","cornerRadius": "10px","action": {"type": "uri","label": "action","uri": Settemp["Notif"]["poppup"]},"borderWidth": "2px","borderColor": Settemp["menu"]["Garis"]},"styles": {"body": {"backgroundColor": Settemp["menu"]["Bg"]}}}]}}
    sendTemplate(to, data)

def achinkZul2(to, love, Zul):
    am = client.getContact(clientMID)
    tz = pytz.timezone("Asia/Jakarta")
    timeNow = datetime.now(tz=tz)
    timeHours = datetime.strftime(timeNow," (%H:%M)")
    data = {"type": "flex","altText": Settemp["Notif"]["tempnotif"],"contents": {"type": "carousel","contents": [{"type": "bubble","size": "micro","body": {"type": "box","layout": "vertical","contents": [{"type": "image","size": "full","aspectMode": "cover","aspectRatio": "2:3","gravity": "top","url": "https://obs.line-scdn.net/{}".format(am.pictureStatus)},{"type": "box","layout": "vertical","position": "absolute","contents": [{"type": "image","size": "full","aspectMode": "cover","aspectRatio": "2:3","gravity": "top","url": Settemp["menu"]["anim"],"animated":True}]},{"type": "box","layout": "vertical","contents": [{"type": "box","layout": "horizontal","contents": [{"type": "box","layout": "vertical","contents": [{"type": "image","url": Settemp["menu"]["icon"],"aspectMode": "cover"}],"width": "20px","height": "20px"},{"type": "separator","color":Settemp["menu"]["Garis"]},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "𝑪 𝑶 𝑴 𝑴 𝑨 𝑵 𝑫","align": "center","size": "xs","color": Settemp["menu"]["Garis"],"offsetTop": "1px"}],"cornerRadius": "5px"},{"type": "separator","color": Settemp["menu"]["Garis"]},{"type": "box","layout": "vertical","contents": [{"type": "image","url": Settemp["menu"]["icon"],"aspectMode": "cover"}],"width": "20px","height": "20px"}]}],"position": "absolute","offsetTop": "3px","width": "150px","offsetStart": "3px","cornerRadius": "5px","borderWidth": "1px","borderColor":Settemp["menu"]["Garis"]},{"type": "box","layout": "vertical","contents": [{"type": "box","layout": "vertical","contents": [{"type": "box","layout": "vertical","contents": [{"type": "text","text": love,"color":Settemp["menu"]["Warnatext"],"size": "xxs","wrap": True,"offsetStart": "2px"}]}]}],"position": "absolute","offsetTop": "28px","width": "150px","offsetStart": "3px"},{"type": "box","layout": "vertical","contents": [{"type": "box","layout": "horizontal","contents": [{"type": "box","layout": "vertical","contents": [{"type": "image","url": "https://obs.line-scdn.net/{}".format(am.pictureStatus),"aspectMode": "cover","size": "full"}],"width": "33px","height": "33px"},{"type": "separator", "color": Settemp["menu"]["Garis"]},{"type": "box","layout": "vertical","contents": [{ "type": "text","text": "{}".format(client.getProfile().displayName),"color": Settemp["menu"]["warnatextnikname"],"align": "center","offsetTop": "1px","size": "xxs"},{"type": "separator","color": Settemp["menu"]["Garis"]},{"type": "box","layout": "vertical","contents": [{"type": "text","text": Settemp["menu"]["labeltext"],"align": "center","size": "xs","color": "#48D1CC"}],"backgroundColor":Settemp["menu"]["warnalabel"]}]}],"backgroundColor": "#000000"}],"position": "absolute","offsetTop": "196px","width": "150px","offsetStart": "3px","borderWidth": "1px","borderColor":Settemp["menu"]["Garis"],"cornerRadius": "5px"}],"paddingAll": "0px","cornerRadius": "10px","action": {"type": "uri","label": "action","uri": Settemp["Notif"]["poppup"]},"borderWidth": "2px","borderColor": Settemp["menu"]["Garis"]},"styles": {"body": {"backgroundColor": Settemp["menu"]["Bg"]}}},{"type": "bubble","size": "micro","body": {"type": "box","layout": "vertical","contents": [{"type": "image","size": "full","aspectMode": "cover","aspectRatio": "2:3","gravity": "top","url": "https://obs.line-scdn.net/{}".format(am.pictureStatus)},{"type": "box","layout": "vertical","position": "absolute","contents": [{"type": "image","size": "full","aspectMode": "cover","aspectRatio": "2:3","gravity": "top","url": Settemp["menu"]["anim2"],"animated":True}]},{"type": "box","layout": "vertical","contents": [{"type": "box","layout": "horizontal","contents": [{"type": "box","layout": "vertical","contents": [{"type": "image","url": Settemp["menu"]["icon"],"aspectMode": "cover"}],"width": "20px","height": "20px"},{"type": "separator","color":Settemp["menu"]["Garis"]},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "𝑪 𝑶 𝑴 𝑴 𝑨 𝑵 𝑫","align": "center","size": "xs","color": Settemp["menu"]["Garis"],"offsetTop": "1px"}],"cornerRadius": "5px"},{"type": "separator","color": Settemp["menu"]["Garis"]},{"type": "box","layout": "vertical","contents": [{"type": "image","url": Settemp["menu"]["icon"],"aspectMode": "cover"}],"width": "20px","height": "20px"}]}],"position": "absolute","offsetTop": "3px","width": "150px","offsetStart": "3px","cornerRadius": "5px","borderWidth": "1px","borderColor":Settemp["menu"]["Garis"]},{"type": "box","layout": "vertical","contents": [{"type": "box","layout": "vertical","contents": [{"type": "box","layout": "vertical","contents": [{"type": "text","text": Zul,"color":Settemp["menu"]["Warnatext"],"size": "xxs","wrap": True,"offsetStart": "2px"}]}]}],"position": "absolute","offsetTop": "28px","width": "150px","offsetStart": "3px"},{"type": "box","layout": "vertical","contents": [{"type": "box","layout": "horizontal","contents": [{"type": "box","layout": "vertical","contents": [{"type": "image","url": "https://obs.line-scdn.net/{}".format(am.pictureStatus),"aspectMode": "cover","size": "full"}],"width": "33px","height": "33px"},{"type": "separator","color": Settemp["menu"]["Garis"]},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "{}".format(client.getProfile().displayName),"color": Settemp["menu"]["warnatextnikname"],"align": "center","offsetTop": "1px","size": "xxs"},{"type": "separator","color": Settemp["menu"]["Garis"]},{"type": "box","layout": "vertical","contents": [{"type": "text","text": Settemp["menu"]["labeltext"],"align": "center","size": "xs","color": "#48D1CC"}],"backgroundColor":Settemp["menu"]["warnalabel"]}]}],"backgroundColor": "#000000"}],"position": "absolute","offsetTop": "196px","width": "150px","offsetStart": "3px","borderWidth": "1px","borderColor":Settemp["menu"]["Garis"],"cornerRadius": "5px"}],"paddingAll": "0px","cornerRadius": "10px","action": {"type": "uri","label": "action","uri": Settemp["Notif"]["poppup"]},"borderWidth": "2px","borderColor": Settemp["menu"]["Garis"]},"styles": {"body": {"backgroundColor": Settemp["menu"]["Bg"]}}}]}}
    sendTemplate(to, data)

def achinkZul3(to, love, Zul, inces):
    am = client.getContact(clientMID)
    tz = pytz.timezone("Asia/Jakarta")
    timeNow = datetime.now(tz=tz)
    timeHours = datetime.strftime(timeNow," (%H:%M)")
    data = {"type": "flex","altText": Settemp["Notif"]["tempnotif"],"contents": {"type": "carousel","contents": [{"type": "bubble","size": "micro","body": {"type": "box","layout": "vertical","contents": [{"type": "image","size": "full","aspectMode": "cover","aspectRatio": "2:3","gravity": "top","url": Settemp["menu"]["image"]},{"type": "box","layout": "vertical","contents": [{"type": "box","layout": "horizontal","contents": [{"type": "box","layout": "vertical","contents": [{"type": "image","url": Settemp["menu"]["icon"],"aspectMode": "cover"}],"width": "20px","height": "20px"},{"type": "separator","color":Settemp["menu"]["Garis"]},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "𝑪 𝑶 𝑴 𝑴 𝑨 𝑵 𝑫","align": "center","size": "xs","color": Settemp["menu"]["Garis"],"offsetTop": "1px"}],"cornerRadius": "5px"},{"type": "separator","color": Settemp["menu"]["Garis"]},{"type": "box","layout": "vertical","contents": [{"type": "image","url": Settemp["menu"]["icon"],"aspectMode": "cover"}],"width": "20px","height": "20px"}]}],"position": "absolute","offsetTop": "3px","width": "150px","offsetStart": "3px","cornerRadius": "5px","borderWidth": "1px","borderColor":Settemp["menu"]["Garis"]},{"type": "box","layout": "vertical","contents": [{"type": "box","layout": "vertical","contents": [{"type": "box","layout": "vertical","contents": [{"type": "text","text": love,"color":Settemp["menu"]["Warnatext"],"size": "xxs","wrap": True,"offsetStart": "2px"}]}]}],"position": "absolute","offsetTop": "28px","width": "150px","offsetStart": "3px"},{"type": "box","layout": "vertical","contents": [{"type": "box","layout": "horizontal","contents": [{"type": "box","layout": "vertical","contents": [{"type": "image","url": "https://obs.line-scdn.net/{}".format(am.pictureStatus),"aspectMode": "cover","size": "full"}],"width": "33px","height": "33px"},{"type": "separator", "color": Settemp["menu"]["Garis"]},{"type": "box","layout": "vertical","contents": [{ "type": "text","text": "{}".format(client.getProfile().displayName),"color": Settemp["menu"]["warnatextnikname"],"align": "center","offsetTop": "1px","size": "xxs"},{"type": "separator","color": Settemp["menu"]["Garis"]},{"type": "box","layout": "vertical","contents": [{"type": "text","text": Settemp["menu"]["labeltext"],"align": "center","size": "xs","color": "#48D1CC"}],"backgroundColor":Settemp["menu"]["warnalabel"]}]}],"backgroundColor": "#000000"}],"position": "absolute","offsetTop": "196px","width": "150px","offsetStart": "3px","borderWidth": "1px","borderColor":Settemp["menu"]["Garis"],"cornerRadius": "5px"}],"paddingAll": "0px","cornerRadius": "10px","action": {"type": "uri","label": "action","uri": Settemp["Notif"]["poppup"]},"borderWidth": "2px","borderColor": Settemp["menu"]["Garis"]},"styles": {"body": {"backgroundColor": Settemp["menu"]["Bg"]}}},{"type": "bubble","size": "micro","body": {"type": "box","layout": "vertical","contents": [{"type": "image","size": "full","aspectMode": "cover","aspectRatio": "2:3","gravity": "top","url": Settemp["menu"]["image"]},{"type": "box","layout": "vertical","contents": [{"type": "box","layout": "horizontal","contents": [{"type": "box","layout": "vertical","contents": [{"type": "image","url": Settemp["menu"]["icon"],"aspectMode": "cover"}],"width": "20px","height": "20px"},{"type": "separator","color":Settemp["menu"]["Garis"]},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "𝑪 𝑶 𝑴 𝑴 𝑨 𝑵 𝑫","align": "center","size": "xs","color": Settemp["menu"]["Garis"],"offsetTop": "1px"}],"cornerRadius": "5px"},{"type": "separator","color": Settemp["menu"]["Garis"]},{"type": "box","layout": "vertical","contents": [{"type": "image","url": Settemp["menu"]["icon"],"aspectMode": "cover"}],"width": "20px","height": "20px"}]}],"position": "absolute","offsetTop": "3px","width": "150px","offsetStart": "3px","cornerRadius": "5px","borderWidth": "1px","borderColor":Settemp["menu"]["Garis"]},{"type": "box","layout": "vertical","contents": [{"type": "box","layout": "vertical","contents": [{"type": "box","layout": "vertical","contents": [{"type": "text","text": Zul,"color":Settemp["menu"]["Warnatext"],"size": "xxs","wrap": True,"offsetStart": "2px"}]}]}],"position": "absolute","offsetTop": "28px","width": "150px","offsetStart": "3px"},{"type": "box","layout": "vertical","contents": [{"type": "box","layout": "horizontal","contents": [{"type": "box","layout": "vertical","contents": [{"type": "image","url": "https://obs.line-scdn.net/{}".format(am.pictureStatus),"aspectMode": "cover","size": "full"}],"width": "33px","height": "33px"},{"type": "separator","color": Settemp["menu"]["Garis"]},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "{}".format(client.getProfile().displayName),"color": Settemp["menu"]["warnatextnikname"],"align": "center","offsetTop": "1px","size": "xxs"},{"type": "separator","color": Settemp["menu"]["Garis"]},{"type": "box","layout": "vertical","contents": [{"type": "text","text": Settemp["menu"]["labeltext"],"align": "center","size": "xs","color": "#48D1CC"}],"backgroundColor":Settemp["menu"]["warnalabel"]}]}],"backgroundColor": "#000000"}],"position": "absolute","offsetTop": "196px","width": "150px","offsetStart": "3px","borderWidth": "1px","borderColor":Settemp["menu"]["Garis"],"cornerRadius": "5px"}],"paddingAll": "0px","cornerRadius": "10px","action": {"type": "uri","label": "action","uri": Settemp["Notif"]["poppup"]},"borderWidth": "2px","borderColor": Settemp["menu"]["Garis"]},"styles": {"body": {"backgroundColor": Settemp["menu"]["Bg"]}}},{"type": "bubble","size": "micro","body": {"type": "box","layout": "vertical","contents": [{"type": "image","size": "full","aspectMode": "cover","aspectRatio": "2:3","gravity": "top","url": Settemp["menu"]["image"]},{"type": "box","layout": "vertical","contents": [{"type": "box","layout": "horizontal","contents": [{"type": "box","layout": "vertical","contents": [{"type": "image","url": Settemp["menu"]["icon"],"aspectMode": "cover"}],"width": "20px","height": "20px"},{"type": "separator","color":Settemp["menu"]["Garis"]},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "𝑪 𝑶 𝑴 𝑴 𝑨 𝑵 𝑫","align": "center","size": "xs","color": Settemp["menu"]["Garis"],"offsetTop": "1px"}],"cornerRadius": "5px"},{"type": "separator","color": Settemp["menu"]["Garis"]},{"type": "box","layout": "vertical","contents": [{"type": "image","url": Settemp["menu"]["icon"],"aspectMode": "cover"}],"width": "20px","height": "20px"}]}],"position": "absolute","offsetTop": "3px","width": "150px","offsetStart": "3px","cornerRadius": "5px","borderWidth": "1px","borderColor":Settemp["menu"]["Garis"]},{"type": "box","layout": "vertical","contents": [{"type": "box","layout": "vertical","contents": [{"type": "box","layout": "vertical","contents": [{"type": "text","text": inces,"color":Settemp["menu"]["Warnatext"],"size": "xxs","wrap": True,"offsetStart": "2px"}]}]}],"position": "absolute","offsetTop": "28px","width": "150px","offsetStart": "3px"},{"type": "box","layout": "vertical","contents": [{"type": "box","layout": "horizontal","contents": [{"type": "box","layout": "vertical","contents": [{"type": "image","url": "https://obs.line-scdn.net/{}".format(am.pictureStatus),"aspectMode": "cover","size": "full"}],"width": "33px","height": "33px"},{"type": "separator", "color": Settemp["menu"]["Garis"]},{"type": "box","layout": "vertical","contents": [{ "type": "text","text": "{}".format(client.getProfile().displayName),"color": Settemp["menu"]["warnatextnikname"],"align": "center","offsetTop": "1px","size": "xxs"},{"type": "separator","color": Settemp["menu"]["Garis"]},{"type": "box","layout": "vertical","contents": [{"type": "text","text": Settemp["menu"]["labeltext"],"align": "center","size": "xs","color": "#48D1CC"}],"backgroundColor":Settemp["menu"]["warnalabel"]}]}],"backgroundColor": "#000000"}],"position": "absolute","offsetTop": "196px","width": "150px","offsetStart": "3px","borderWidth": "1px","borderColor":Settemp["menu"]["Garis"],"cornerRadius": "5px"}],"paddingAll": "0px","cornerRadius": "10px","action": {"type": "uri","label": "action","uri": Settemp["Notif"]["poppup"]},"borderWidth": "2px","borderColor": Settemp["menu"]["Garis"]},"styles": {"body": {"backgroundColor": Settemp["menu"]["Bg"]}}}]}}
    sendTemplate(to, data)
    #data = {"type": "flex","altText": Settemp["Notif"]["tempnotif"],"contents": {"type": "carousel","contents": [{"type": "bubble","size": "micro","body": {"type": "box","layout": "vertical","contents": [{"type": "image","size": "full","aspectMode": "cover","aspectRatio": "2:3","gravity": "top","url": "https://obs.line-scdn.net/{}".format(am.pictureStatus)},{"type": "box","layout": "vertical","contents": [{"type": "image","size": "full","aspectMode": "cover","aspectRatio": "2:3","gravity": "top","url": "https://obs.line-scdn.net/{}".format(am.pictureStatus)},{"type": "box","layout": "vertical","position": "absolute","contents": [{"type": "image","size": "full","aspectMode": "cover","aspectRatio": "2:3","gravity": "top","url": Settemp["menu"]["anim"],"animated":True}]},{"type": "box","layout": "vertical","contents": [{"type": "box","layout": "horizontal","contents": [{"type": "box","layout": "vertical","contents": [{"type": "image","url": Settemp["menu"]["icon"],"aspectMode": "cover"}],"width": "20px","height": "20px"},{"type": "separator","color":Settemp["menu"]["Garis"]},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "𝑪 𝑶 𝑴 𝑴 𝑨 𝑵 𝑫","align": "center","size": "xs","color": Settemp["menu"]["Garis"],"offsetTop": "1px"}],"cornerRadius": "5px"},{"type": "separator","color": Settemp["menu"]["Garis"]},{"type": "box","layout": "vertical","contents": [{"type": "image","url": Settemp["menu"]["icon"],"aspectMode": "cover"}],"width": "20px","height": "20px"}]}],"position": "absolute","offsetTop": "3px","width": "150px","offsetStart": "3px","cornerRadius": "5px","borderWidth": "1px","borderColor":Settemp["menu"]["Garis"]},{"type": "box","layout": "vertical","contents": [{"type": "box","layout": "vertical","contents": [{"type": "box","layout": "vertical","contents": [{"type": "text","text": love,"color":Settemp["menu"]["Warnatext"],"size": "xxs","wrap": True,"offsetStart": "2px"}]}]}],"position": "absolute","offsetTop": "28px","width": "150px","offsetStart": "3px"},{"type": "box","layout": "vertical","contents": [{"type": "box","layout": "horizontal","contents": [{"type": "box","layout": "vertical","contents": [{"type": "image","url": "https://obs.line-scdn.net/{}".format(am.pictureStatus),"aspectMode": "cover","size": "full"}],"width": "33px","height": "33px"},{"type": "separator", "color": Settemp["menu"]["Garis"]},{"type": "box","layout": "vertical","contents": [{ "type": "text","text": "{}".format(client.getProfile().displayName),"color": Settemp["menu"]["warnatextnikname"],"align": "center","offsetTop": "1px","size": "xxs"},{"type": "separator","color": Settemp["menu"]["Garis"]},{"type": "box","layout": "vertical","contents": [{"type": "text","text": Settemp["menu"]["labeltext"],"align": "center","size": "xs","color": "#48D1CC"}],"backgroundColor":Settemp["menu"]["warnalabel"]}]}],"backgroundColor": "#000000"}],"position": "absolute","offsetTop": "196px","width": "150px","offsetStart": "3px","borderWidth": "1px","borderColor":Settemp["menu"]["Garis"],"cornerRadius": "5px"}],"paddingAll": "0px","cornerRadius": "10px","action": {"type": "uri","label": "action","uri": Settemp["Notif"]["poppup"]},"borderWidth": "2px","borderColor": Settemp["menu"]["Garis"]},"styles": {"body": {"backgroundColor": Settemp["menu"]["Bg"]}}}, {"type": "bubble","size": "micro","body": {"type": "box","layout": "vertical","contents": [{"type": "image","size": "full","aspectMode": "cover","aspectRatio": "2:3","gravity": "top","url": "https://obs.line-scdn.net/{}".format(am.pictureStatus)},{"type": "box","layout": "vertical","position": "absolute","contents": [{"type": "image","size": "full","aspectMode": "cover","aspectRatio": "2:3","gravity": "top","url": Settemp["menu"]["anim2"],"animated":True}]},{"type": "box","layout": "vertical","contents": [{"type": "box","layout": "horizontal","contents": [{"type": "box","layout": "vertical","contents": [{"type": "image","url": Settemp["menu"]["icon"],"aspectMode": "cover"}],"width": "20px","height": "20px"},{"type": "separator","color":Settemp["menu"]["Garis"]},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "𝑪 𝑶 𝑴 𝑴 𝑨 𝑵 𝑫","align": "center","size": "xs","color": Settemp["menu"]["Garis"],"offsetTop": "1px"}],"cornerRadius": "5px"},{"type": "separator","color": Settemp["menu"]["Garis"]},{"type": "box","layout": "vertical","contents": [{"type": "image","url": Settemp["menu"]["icon"],"aspectMode": "cover"}],"width": "20px","height": "20px"}]}],"position": "absolute","offsetTop": "3px","width": "150px","offsetStart": "3px","cornerRadius": "5px","borderWidth": "1px","borderColor":Settemp["menu"]["Garis"]},{"type": "box","layout": "vertical","contents": [{"type": "box","layout": "vertical","contents": [{"type": "box","layout": "vertical","contents": [{"type": "text","text": Zul,"color":Settemp["menu"]["Warnatext"],"size": "xxs","wrap": True,"offsetStart": "2px"}]}]}],"position": "absolute","offsetTop": "28px","width": "150px","offsetStart": "3px"},{"type": "box","layout": "vertical","contents": [{"type": "box","layout": "horizontal","contents": [{"type": "box","layout": "vertical","contents": [{"type": "image","url": "https://obs.line-scdn.net/{}".format(am.pictureStatus),"aspectMode": "cover","size": "full"}],"width": "33px","height": "33px"},{"type": "separator","color": Settemp["menu"]["Garis"]},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "{}".format(client.getProfile().displayName),"color": Settemp["menu"]["warnatextnikname"],"align": "center","offsetTop": "1px","size": "xxs"},{"type": "separator","color": Settemp["menu"]["Garis"]},{"type": "box","layout": "vertical","contents": [{"type": "text","text": Settemp["menu"]["labeltext"],"align": "center","size": "xs","color": "#48D1CC"}],"backgroundColor":Settemp["menu"]["warnalabel"]}]}],"backgroundColor": "#000000"}],"position": "absolute","offsetTop": "196px","width": "150px","offsetStart": "3px","borderWidth": "1px","borderColor":Settemp["menu"]["Garis"],"cornerRadius": "5px"}],"paddingAll": "0px","cornerRadius": "10px","action": {"type": "uri","label": "action","uri": Settemp["Notif"]["poppup"]},"borderWidth": "2px","borderColor": Settemp["menu"]["Garis"]},"styles": {"body": {"backgroundColor": Settemp["menu"]["Bg"]}}},{"type": "bubble","size": "micro","body": {"type": "box","layout": "vertical","contents": [{"type": "image","size": "full","aspectMode": "cover","aspectRatio": "2:3","gravity": "top","url": "https://obs.line-scdn.net/{}".format(am.pictureStatus)},{"type": "box","layout": "vertical","position": "absolute","contents": [{"type": "image","size": "full","aspectMode": "cover","aspectRatio": "2:3","gravity": "top","url": Settemp["menu"]["anim3"],"animated":True}]},{"type": "box","layout": "vertical","contents": [{"type": "box","layout": "horizontal","contents": [{"type": "box","layout": "vertical","contents": [{"type": "image","url": Settemp["menu"]["icon"],"aspectMode": "cover"}],"width": "20px","height": "20px"},{"type": "separator","color":Settemp["menu"]["Garis"]},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "𝑪 𝑶 𝑴 𝑴 𝑨 𝑵 𝑫","align": "center","size": "xs","color": Settemp["menu"]["Garis"],"offsetTop": "1px"}],"cornerRadius": "5px"},{"type": "separator","color": Settemp["menu"]["Garis"]},{"type": "box","layout": "vertical","contents": [{"type": "image","url": Settemp["menu"]["icon"],"aspectMode": "cover"}],"width": "20px","height": "20px"}]}],"position": "absolute","offsetTop": "3px","width": "150px","offsetStart": "3px","cornerRadius": "5px","borderWidth": "1px","borderColor":Settemp["menu"]["Garis"]},{"type": "box","layout": "vertical","contents": [{"type": "box","layout": "vertical","contents": [{"type": "box","layout": "vertical","contents": [{"type": "text","text": inces,"color":Settemp["menu"]["Warnatext"],"size": "xxs","wrap": True,"offsetStart": "2px"}]}]}],"position": "absolute","offsetTop": "28px","width": "150px","offsetStart": "3px"},{"type": "box","layout": "vertical","contents": [{"type": "box","layout": "horizontal","contents": [{"type": "box","layout": "vertical","contents": [{"type": "image","url": "https://obs.line-scdn.net/{}".format(am.pictureStatus),"aspectMode": "cover","size": "full"}],"width": "33px","height": "33px"},{"type": "separator", "color": Settemp["menu"]["Garis"]},{"type": "box","layout": "vertical","contents": [{ "type": "text","text": "{}".format(client.getProfile().displayName),"color": Settemp["menu"]["warnatextnikname"],"align": "center","offsetTop": "1px","size": "xxs"},{"type": "separator","color": Settemp["menu"]["Garis"]},{"type": "box","layout": "vertical","contents": [{"type": "text","text": Settemp["menu"]["labeltext"],"align": "center","size": "xs","color": "#48D1CC"}],"backgroundColor":Settemp["menu"]["warnalabel"]}]}],"backgroundColor": "#000000"}],"position": "absolute","offsetTop": "196px","width": "150px","offsetStart": "3px","borderWidth": "1px","borderColor":Settemp["menu"]["Garis"],"cornerRadius": "5px"}],"paddingAll": "0px","cornerRadius": "10px","action": {"type": "uri","label": "action","uri": Settemp["Notif"]["poppup"]},"borderWidth": "2px","borderColor": Settemp["menu"]["Garis"]},"styles": {"body": {"backgroundColor": Settemp["menu"]["Bg"]}}}]}}
    #sendTemplate(to, data)

def achinkZul4(to, love, Zul, inces, achink):
    am = client.getContact(clientMID)
    tz = pytz.timezone("Asia/Jakarta")
    timeNow = datetime.now(tz=tz)
    timeHours = datetime.strftime(timeNow," (%H:%M)")
    data = {"type": "flex","altText": Settemp["Notif"]["tempnotif"],"contents": {"type": "carousel","contents": [{"type": "bubble","size": "micro","body": {"type": "box","layout": "vertical","contents": [{"type": "image","size": "full","aspectMode": "cover","aspectRatio": "2:3","gravity": "top","url": "https://obs.line-scdn.net/{}".format(am.pictureStatus)},{"type": "box","layout": "vertical","position": "absolute","contents": [{"type": "image","size": "full","aspectMode": "cover","aspectRatio": "2:3","gravity": "top","url": Settemp["menu"]["anim3"],"animated":True}]},{"type": "box","layout": "vertical","contents": [{"type": "box","layout": "horizontal","contents": [{"type": "box","layout": "vertical","contents": [{"type": "image","url": Settemp["menu"]["icon"],"aspectMode": "cover"}],"width": "20px","height": "20px"},{"type": "separator","color":Settemp["menu"]["Garis"]},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "𝑪 𝑶 𝑴 𝑴 𝑨 𝑵 𝑫","align": "center","size": "xs","color": Settemp["menu"]["Garis"],"offsetTop": "1px"}],"cornerRadius": "5px"},{"type": "separator","color": Settemp["menu"]["Garis"]},{"type": "box","layout": "vertical","contents": [{"type": "image","url": Settemp["menu"]["icon"],"aspectMode": "cover"}],"width": "20px","height": "20px"}]}],"position": "absolute","offsetTop": "3px","width": "150px","offsetStart": "3px","cornerRadius": "5px","borderWidth": "1px","borderColor":Settemp["menu"]["Garis"]},{"type": "box","layout": "vertical","contents": [{"type": "box","layout": "vertical","contents": [{"type": "box","layout": "vertical","contents": [{"type": "text","text": love,"color":Settemp["menu"]["Warnatext"],"size": "xxs","wrap": True,"offsetStart": "2px"}]}]}],"position": "absolute","offsetTop": "28px","width": "150px","offsetStart": "3px"},{"type": "box","layout": "vertical","contents": [{"type": "box","layout": "horizontal","contents": [{"type": "box","layout": "vertical","contents": [{"type": "image","url": "https://obs.line-scdn.net/{}".format(am.pictureStatus),"aspectMode": "cover","size": "full"}],"width": "33px","height": "33px"},{"type": "separator", "color": Settemp["menu"]["Garis"]},{"type": "box","layout": "vertical","contents": [{ "type": "text","text": "{}".format(client.getProfile().displayName),"color": Settemp["menu"]["warnatextnikname"],"align": "center","offsetTop": "1px","size": "xxs"},{"type": "separator","color": Settemp["menu"]["Garis"]},{"type": "box","layout": "vertical","contents": [{"type": "text","text": Settemp["menu"]["labeltext"],"align": "center","size": "xs","color": "#48D1CC"}],"backgroundColor":Settemp["menu"]["warnalabel"]}]}],"backgroundColor": "#000000"}],"position": "absolute","offsetTop": "196px","width": "150px","offsetStart": "3px","borderWidth": "1px","borderColor":Settemp["menu"]["Garis"],"cornerRadius": "5px"}],"paddingAll": "0px","cornerRadius": "10px","action": {"type": "uri","label": "action","uri": Settemp["Notif"]["poppup"]},"borderWidth": "2px","borderColor": Settemp["menu"]["Garis"]},"styles": {"body": {"backgroundColor": Settemp["menu"]["Bg"]}}},{"type": "bubble","size": "micro","body": {"type": "box","layout": "vertical","contents": [{"type": "image","size": "full","aspectMode": "cover","aspectRatio": "2:3","gravity": "top","url": "https://obs.line-scdn.net/{}".format(am.pictureStatus)},{"type": "box","layout": "vertical","position": "absolute","contents": [{"type": "image","size": "full","aspectMode": "cover","aspectRatio": "2:3","gravity": "top","url": Settemp["menu"]["anim4"],"animated":True}]},{"type": "box","layout": "vertical","contents": [{"type": "box","layout": "horizontal","contents": [{"type": "box","layout": "vertical","contents": [{"type": "image","url": Settemp["menu"]["icon"],"aspectMode": "cover"}],"width": "20px","height": "20px"},{"type": "separator","color":Settemp["menu"]["Garis"]},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "𝑪 𝑶 𝑴 𝑴 𝑨 𝑵 𝑫","align": "center","size": "xs","color": Settemp["menu"]["Garis"],"offsetTop": "1px"}],"cornerRadius": "5px"},{"type": "separator","color": Settemp["menu"]["Garis"]},{"type": "box","layout": "vertical","contents": [{"type": "image","url": Settemp["menu"]["icon"],"aspectMode": "cover"}],"width": "20px","height": "20px"}]}],"position": "absolute","offsetTop": "3px","width": "150px","offsetStart": "3px","cornerRadius": "5px","borderWidth": "1px","borderColor":Settemp["menu"]["Garis"]},{"type": "box","layout": "vertical","contents": [{"type": "box","layout": "vertical","contents": [{"type": "box","layout": "vertical","contents": [{"type": "text","text": Zul,"color":Settemp["menu"]["Warnatext"],"size": "xxs","wrap": True,"offsetStart": "2px"}]}]}],"position": "absolute","offsetTop": "28px","width": "150px","offsetStart": "3px"},{"type": "box","layout": "vertical","contents": [{"type": "box","layout": "horizontal","contents": [{"type": "box","layout": "vertical","contents": [{"type": "image","url": "https://obs.line-scdn.net/{}".format(am.pictureStatus),"aspectMode": "cover","size": "full"}],"width": "33px","height": "33px"},{"type": "separator","color": Settemp["menu"]["Garis"]},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "{}".format(client.getProfile().displayName),"color": Settemp["menu"]["warnatextnikname"],"align": "center","offsetTop": "1px","size": "xxs"},{"type": "separator","color": Settemp["menu"]["Garis"]},{"type": "box","layout": "vertical","contents": [{"type": "text","text": Settemp["menu"]["labeltext"],"align": "center","size": "xs","color": "#48D1CC"}],"backgroundColor":Settemp["menu"]["warnalabel"]}]}],"backgroundColor": "#000000"}],"position": "absolute","offsetTop": "196px","width": "150px","offsetStart": "3px","borderWidth": "1px","borderColor":Settemp["menu"]["Garis"],"cornerRadius": "5px"}],"paddingAll": "0px","cornerRadius": "10px","action": {"type": "uri","label": "action","uri": Settemp["Notif"]["poppup"]},"borderWidth": "2px","borderColor": Settemp["menu"]["Garis"]},"styles": {"body": {"backgroundColor": Settemp["menu"]["Bg"]}}},{"type": "bubble","size": "micro","body": {"type": "box","layout": "vertical","contents": [{"type": "image","size": "full","aspectMode": "cover","aspectRatio": "2:3","gravity": "top","url": "https://obs.line-scdn.net/{}".format(am.pictureStatus)},{"type": "box","layout": "vertical","position": "absolute","contents": [{"type": "image","size": "full","aspectMode": "cover","aspectRatio": "2:3","gravity": "top","url": Settemp["menu"]["anim4"],"animated":True}]},{"type": "box","layout": "vertical","contents": [{"type": "box","layout": "horizontal","contents": [{"type": "box","layout": "vertical","contents": [{"type": "image","url": Settemp["menu"]["icon"],"aspectMode": "cover"}],"width": "20px","height": "20px"},{"type": "separator","color":Settemp["menu"]["Garis"]},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "𝑪 𝑶 𝑴 𝑴 𝑨 𝑵 𝑫","align": "center","size": "xs","color": Settemp["menu"]["Garis"],"offsetTop": "1px"}],"cornerRadius": "5px"},{"type": "separator","color": Settemp["menu"]["Garis"]},{"type": "box","layout": "vertical","contents": [{"type": "image","url": Settemp["menu"]["icon"],"aspectMode": "cover"}],"width": "20px","height": "20px"}]}],"position": "absolute","offsetTop": "3px","width": "150px","offsetStart": "3px","cornerRadius": "5px","borderWidth": "1px","borderColor":Settemp["menu"]["Garis"]},{"type": "box","layout": "vertical","contents": [{"type": "box","layout": "vertical","contents": [{"type": "box","layout": "vertical","contents": [{"type": "text","text": inces,"color":Settemp["menu"]["Warnatext"],"size": "xxs","wrap": True,"offsetStart": "2px"}]}]}],"position": "absolute","offsetTop": "28px","width": "150px","offsetStart": "3px"},{"type": "box","layout": "vertical","contents": [{"type": "box","layout": "horizontal","contents": [{"type": "box","layout": "vertical","contents": [{"type": "image","url": "https://obs.line-scdn.net/{}".format(am.pictureStatus),"aspectMode": "cover","size": "full"}],"width": "33px","height": "33px"},{"type": "separator", "color": Settemp["menu"]["Garis"]},{"type": "box","layout": "vertical","contents": [{ "type": "text","text": "{}".format(client.getProfile().displayName),"color": Settemp["menu"]["warnatextnikname"],"align": "center","offsetTop": "1px","size": "xxs"},{"type": "separator","color": Settemp["menu"]["Garis"]},{"type": "box","layout": "vertical","contents": [{"type": "text","text": Settemp["menu"]["labeltext"],"align": "center","size": "xs","color": "#48D1CC"}],"backgroundColor":Settemp["menu"]["warnalabel"]}]}],"backgroundColor": "#000000"}],"position": "absolute","offsetTop": "196px","width": "150px","offsetStart": "3px","borderWidth": "1px","borderColor":Settemp["menu"]["Garis"],"cornerRadius": "5px"}],"paddingAll": "0px","cornerRadius": "10px","action": {"type": "uri","label": "action","uri": Settemp["Notif"]["poppup"]},"borderWidth": "2px","borderColor": Settemp["menu"]["Garis"]},"styles": {"body": {"backgroundColor": Settemp["menu"]["Bg"]}}},{"type": "bubble","size": "micro","body": {"type": "box","layout": "vertical","contents": [{"type": "image","size": "full","aspectMode": "cover","aspectRatio": "2:3","gravity": "top","url": "https://obs.line-scdn.net/{}".format(am.pictureStatus)},{"type": "box","layout": "vertical","position": "absolute","contents": [{"type": "image","size": "full","aspectMode": "cover","aspectRatio": "2:3","gravity": "top","url": Settemp["menu"]["anim"],"animated":True}]},{"type": "box","layout": "vertical","contents": [{"type": "box","layout": "horizontal","contents": [{"type": "box","layout": "vertical","contents": [{"type": "image","url": Settemp["menu"]["icon"],"aspectMode": "cover"}],"width": "20px","height": "20px"},{"type": "separator","color":Settemp["menu"]["Garis"]},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "𝑪 𝑶 𝑴 𝑴 𝑨 𝑵 𝑫","align": "center","size": "xs","color": Settemp["menu"]["Garis"],"offsetTop": "1px"}],"cornerRadius": "5px"},{"type": "separator","color": Settemp["menu"]["Garis"]},{"type": "box","layout": "vertical","contents": [{"type": "image","url": Settemp["menu"]["icon"],"aspectMode": "cover"}],"width": "20px","height": "20px"}]}],"position": "absolute","offsetTop": "3px","width": "150px","offsetStart": "3px","cornerRadius": "5px","borderWidth": "1px","borderColor":Settemp["menu"]["Garis"]},{"type": "box","layout": "vertical","contents": [{"type": "box","layout": "vertical","contents": [{"type": "box","layout": "vertical","contents": [{"type": "text","text": achink,"color":Settemp["menu"]["Warnatext"],"size": "xxs","wrap": True,"offsetStart": "2px"}]}]}],"position": "absolute","offsetTop": "28px","width": "150px","offsetStart": "3px"},{"type": "box","layout": "vertical","contents": [{"type": "box","layout": "horizontal","contents": [{"type": "box","layout": "vertical","contents": [{"type": "image","url": "https://obs.line-scdn.net/{}".format(am.pictureStatus),"aspectMode": "cover","size": "full"}],"width": "33px","height": "33px"},{"type": "separator", "color": Settemp["menu"]["Garis"]},{"type": "box","layout": "vertical","contents": [{ "type": "text","text": "{}".format(client.getProfile().displayName),"color": Settemp["menu"]["warnatextnikname"],"align": "center","offsetTop": "1px","size": "xxs"},{"type": "separator","color": Settemp["menu"]["Garis"]},{"type": "box","layout": "vertical","contents": [{"type": "text","text": Settemp["menu"]["labeltext"],"align": "center","size": "xs","color": "#48D1CC"}],"backgroundColor":Settemp["menu"]["warnalabel"]}]}],"backgroundColor": "#000000"}],"position": "absolute","offsetTop": "196px","width": "150px","offsetStart": "3px","borderWidth": "1px","borderColor":Settemp["menu"]["Garis"],"cornerRadius": "5px"}],"paddingAll": "0px","cornerRadius": "10px","action": {"type": "uri","label": "action","uri": Settemp["Notif"]["poppup"]},"borderWidth": "2px","borderColor": Settemp["menu"]["Garis"]},"styles": {"body": {"backgroundColor": Settemp["menu"]["Bg"]}}}]}}
    sendTemplate(to, data)

def achinkZul5(to, love, Zul, inces, achink, maulana):
    am = client.getContact(clientMID)
    tz = pytz.timezone("Asia/Jakarta")
    timeNow = datetime.now(tz=tz)
    timeHours = datetime.strftime(timeNow," (%H:%M)")
    data = {"type": "flex","altText": Settemp["Notif"]["tempnotif"],"contents": {"type": "carousel","contents": [{"type": "bubble","size": "micro","body": {"type": "box","layout": "vertical","contents": [{"type": "image","size": "full","aspectMode": "cover","aspectRatio": "2:3","gravity": "top","url": "https://obs.line-scdn.net/{}".format(am.pictureStatus)},{"type": "box","layout": "vertical","position": "absolute","contents": [{"type": "image","size": "full","aspectMode": "cover","aspectRatio": "2:3","gravity": "top","url": Settemp["menu"]["anim"],"animated":True}]},{"type": "box","layout": "vertical","contents": [{"type": "box","layout": "horizontal","contents": [{"type": "box","layout": "vertical","contents": [{"type": "image","url": Settemp["menu"]["icon"],"aspectMode": "cover"}],"width": "20px","height": "20px"},{"type": "separator","color":Settemp["menu"]["Garis"]},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "𝑪 𝑶 𝑴 𝑴 𝑨 𝑵 𝑫","align": "center","size": "xs","color": Settemp["menu"]["Garis"],"offsetTop": "1px"}],"cornerRadius": "5px"},{"type": "separator","color": Settemp["menu"]["Garis"]},{"type": "box","layout": "vertical","contents": [{"type": "image","url": Settemp["menu"]["icon"],"aspectMode": "cover"}],"width": "20px","height": "20px"}]}],"position": "absolute","offsetTop": "3px","width": "150px","offsetStart": "3px","cornerRadius": "5px","borderWidth": "1px","borderColor":Settemp["menu"]["Garis"]},{"type": "box","layout": "vertical","contents": [{"type": "box","layout": "vertical","contents": [{"type": "box","layout": "vertical","contents": [{"type": "text","text": love,"color":Settemp["menu"]["Warnatext"],"size": "xxs","wrap": True,"offsetStart": "2px"}]}]}],"position": "absolute","offsetTop": "28px","width": "150px","offsetStart": "3px"},{"type": "box","layout": "vertical","contents": [{"type": "box","layout": "horizontal","contents": [{"type": "box","layout": "vertical","contents": [{"type": "image","url": "https://obs.line-scdn.net/{}".format(am.pictureStatus),"aspectMode": "cover","size": "full"}],"width": "33px","height": "33px"},{"type": "separator", "color": Settemp["menu"]["Garis"]},{"type": "box","layout": "vertical","contents": [{ "type": "text","text": "{}".format(client.getProfile().displayName),"color": Settemp["menu"]["warnatextnikname"],"align": "center","offsetTop": "1px","size": "xxs"},{"type": "separator","color": Settemp["menu"]["Garis"]},{"type": "box","layout": "vertical","contents": [{"type": "text","text": Settemp["menu"]["labeltext"],"align": "center","size": "xs","color": "#48D1CC"}],"backgroundColor":Settemp["menu"]["warnalabel"]}]}],"backgroundColor": "#000000"}],"position": "absolute","offsetTop": "196px","width": "150px","offsetStart": "3px","borderWidth": "1px","borderColor":Settemp["menu"]["Garis"],"cornerRadius": "5px"}],"paddingAll": "0px","cornerRadius": "10px","action": {"type": "uri","label": "action","uri": Settemp["Notif"]["poppup"]},"borderWidth": "2px","borderColor": Settemp["menu"]["Garis"]},"styles": {"body": {"backgroundColor": Settemp["menu"]["Bg"]}}},{"type": "bubble","size": "micro","body": {"type": "box","layout": "vertical","contents": [{"type": "image","size": "full","aspectMode": "cover","aspectRatio": "2:3","gravity": "top","url": "https://obs.line-scdn.net/{}".format(am.pictureStatus)},{"type": "box","layout": "vertical","contents": [{"type": "box","layout": "horizontal","contents": [{"type": "box","layout": "vertical","contents": [{"type": "image","url": Settemp["menu"]["icon"],"aspectMode": "cover"}],"width": "20px","height": "20px"},{"type": "separator","color":Settemp["menu"]["Garis"]},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "𝑪 𝑶 𝑴 𝑴 𝑨 𝑵 𝑫","align": "center","size": "xs","color": Settemp["menu"]["Garis"],"offsetTop": "1px"}],"cornerRadius": "5px"},{"type": "separator","color": Settemp["menu"]["Garis"]},{"type": "box","layout": "vertical","contents": [{"type": "image","url": Settemp["menu"]["icon"],"aspectMode": "cover"}],"width": "20px","height": "20px"}]}],"position": "absolute","offsetTop": "3px","width": "150px","offsetStart": "3px","cornerRadius": "5px","borderWidth": "1px","borderColor":Settemp["menu"]["Garis"]},{"type": "box","layout": "vertical","contents": [{"type": "box","layout": "vertical","contents": [{"type": "box","layout": "vertical","contents": [{"type": "text","text": Zul,"color":Settemp["menu"]["Warnatext"],"size": "xxs","wrap": True,"offsetStart": "2px"}]}]}],"position": "absolute","offsetTop": "28px","width": "150px","offsetStart": "3px"},{"type": "box","layout": "vertical","contents": [{"type": "box","layout": "horizontal","contents": [{"type": "box","layout": "vertical","contents": [{"type": "image","url": "https://obs.line-scdn.net/{}".format(am.pictureStatus),"aspectMode": "cover","size": "full"}],"width": "33px","height": "33px"},{"type": "separator","color": Settemp["menu"]["Garis"]},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "{}".format(client.getProfile().displayName),"color": Settemp["menu"]["warnatextnikname"],"align": "center","offsetTop": "1px","size": "xxs"},{"type": "separator","color": Settemp["menu"]["Garis"]},{"type": "box","layout": "vertical","contents": [{"type": "text","text": Settemp["menu"]["labeltext"],"align": "center","size": "xs","color": "#48D1CC"}],"backgroundColor":Settemp["menu"]["warnalabel"]}]}],"backgroundColor": "#000000"}],"position": "absolute","offsetTop": "196px","width": "150px","offsetStart": "3px","borderWidth": "1px","borderColor":Settemp["menu"]["Garis"],"cornerRadius": "5px"}],"paddingAll": "0px","cornerRadius": "10px","action": {"type": "uri","label": "action","uri": Settemp["Notif"]["poppup"]},"borderWidth": "2px","borderColor": Settemp["menu"]["Garis"]},"styles": {"body": {"backgroundColor": Settemp["menu"]["Bg"]}}},{"type": "bubble","size": "micro","body": {"type": "box","layout": "vertical","contents": [{"type": "image","size": "full","aspectMode": "cover","aspectRatio": "2:3","gravity": "top","url": "https://obs.line-scdn.net/{}".format(am.pictureStatus)},{"type": "box","layout": "vertical","position": "absolute","contents": [{"type": "image","size": "full","aspectMode": "cover","aspectRatio": "2:3","gravity": "top","url": Settemp["menu"]["anim2"],"animated":True}]},{"type": "box","layout": "vertical","contents": [{"type": "box","layout": "horizontal","contents": [{"type": "box","layout": "vertical","contents": [{"type": "image","url": Settemp["menu"]["icon"],"aspectMode": "cover"}],"width": "20px","height": "20px"},{"type": "separator","color":Settemp["menu"]["Garis"]},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "𝑪 𝑶 𝑴 𝑴 𝑨 𝑵 𝑫","align": "center","size": "xs","color": Settemp["menu"]["Garis"],"offsetTop": "1px"}],"cornerRadius": "5px"},{"type": "separator","color": Settemp["menu"]["Garis"]},{"type": "box","layout": "vertical","contents": [{"type": "image","url": Settemp["menu"]["icon"],"aspectMode": "cover"}],"width": "20px","height": "20px"}]}],"position": "absolute","offsetTop": "3px","width": "150px","offsetStart": "3px","cornerRadius": "5px","borderWidth": "1px","borderColor":Settemp["menu"]["Garis"]},{"type": "box","layout": "vertical","contents": [{"type": "box","layout": "vertical","contents": [{"type": "box","layout": "vertical","contents": [{"type": "text","text": inces,"color":Settemp["menu"]["Warnatext"],"size": "xxs","wrap": True,"offsetStart": "2px"}]}]}],"position": "absolute","offsetTop": "28px","width": "150px","offsetStart": "3px"},{"type": "box","layout": "vertical","contents": [{"type": "box","layout": "horizontal","contents": [{"type": "box","layout": "vertical","contents": [{"type": "image","url": "https://obs.line-scdn.net/{}".format(am.pictureStatus),"aspectMode": "cover","size": "full"}],"width": "33px","height": "33px"},{"type": "separator", "color": Settemp["menu"]["Garis"]},{"type": "box","layout": "vertical","contents": [{ "type": "text","text": "{}".format(client.getProfile().displayName),"color": Settemp["menu"]["warnatextnikname"],"align": "center","offsetTop": "1px","size": "xxs"},{"type": "separator","color": Settemp["menu"]["Garis"]},{"type": "box","layout": "vertical","contents": [{"type": "text","text": Settemp["menu"]["labeltext"],"align": "center","size": "xs","color": "#48D1CC"}],"backgroundColor":Settemp["menu"]["warnalabel"]}]}],"backgroundColor": "#000000"}],"position": "absolute","offsetTop": "196px","width": "150px","offsetStart": "3px","borderWidth": "1px","borderColor":Settemp["menu"]["Garis"],"cornerRadius": "5px"}],"paddingAll": "0px","cornerRadius": "10px","action": {"type": "uri","label": "action","uri": Settemp["Notif"]["poppup"]},"borderWidth": "2px","borderColor": Settemp["menu"]["Garis"]},"styles": {"body": {"backgroundColor": Settemp["menu"]["Bg"]}}},{"type": "bubble","size": "micro","body": {"type": "box","layout": "vertical","contents": [{"type": "image","size": "full","aspectMode": "cover","aspectRatio": "2:3","gravity": "top","url": "https://obs.line-scdn.net/{}".format(am.pictureStatus)},{"type": "box","layout": "vertical","position": "absolute","contents": [{"type": "image","size": "full","aspectMode": "cover","aspectRatio": "2:3","gravity": "top","url": Settemp["menu"]["anim3"],"animated":True}]},{"type": "box","layout": "vertical","contents": [{"type": "box","layout": "horizontal","contents": [{"type": "box","layout": "vertical","contents": [{"type": "image","url": Settemp["menu"]["icon"],"aspectMode": "cover"}],"width": "20px","height": "20px"},{"type": "separator","color":Settemp["menu"]["Garis"]},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "𝑪 𝑶 𝑴 𝑴 𝑨 𝑵 𝑫","align": "center","size": "xs","color": Settemp["menu"]["Garis"],"offsetTop": "1px"}],"cornerRadius": "5px"},{"type": "separator","color": Settemp["menu"]["Garis"]},{"type": "box","layout": "vertical","contents": [{"type": "image","url": Settemp["menu"]["icon"],"aspectMode": "cover"}],"width": "20px","height": "20px"}]}],"position": "absolute","offsetTop": "3px","width": "150px","offsetStart": "3px","cornerRadius": "5px","borderWidth": "1px","borderColor":Settemp["menu"]["Garis"]},{"type": "box","layout": "vertical","contents": [{"type": "box","layout": "vertical","contents": [{"type": "box","layout": "vertical","contents": [{"type": "text","text": achink,"color":Settemp["menu"]["Warnatext"],"size": "xxs","wrap": True,"offsetStart": "2px"}]}]}],"position": "absolute","offsetTop": "28px","width": "150px","offsetStart": "3px"},{"type": "box","layout": "vertical","contents": [{"type": "box","layout": "horizontal","contents": [{"type": "box","layout": "vertical","contents": [{"type": "image","url": "https://obs.line-scdn.net/{}".format(am.pictureStatus),"aspectMode": "cover","size": "full"}],"width": "33px","height": "33px"},{"type": "separator", "color": Settemp["menu"]["Garis"]},{"type": "box","layout": "vertical","contents": [{ "type": "text","text": "{}".format(client.getProfile().displayName),"color": Settemp["menu"]["warnatextnikname"],"align": "center","offsetTop": "1px","size": "xxs"},{"type": "separator","color": Settemp["menu"]["Garis"]},{"type": "box","layout": "vertical","contents": [{"type": "text","text": Settemp["menu"]["labeltext"],"align": "center","size": "xs","color": "#48D1CC"}],"backgroundColor":Settemp["menu"]["warnalabel"]}]}],"backgroundColor": "#000000"}],"position": "absolute","offsetTop": "196px","width": "150px","offsetStart": "3px","borderWidth": "1px","borderColor":Settemp["menu"]["Garis"],"cornerRadius": "5px"}],"paddingAll": "0px","cornerRadius": "10px","action": {"type": "uri","label": "action","uri": Settemp["Notif"]["poppup"]},"borderWidth": "2px","borderColor": Settemp["menu"]["Garis"]},"styles": {"body": {"backgroundColor": Settemp["menu"]["Bg"]}}},{"type": "bubble","size": "micro","body": {"type": "box","layout": "vertical","contents": [{"type": "image","size": "full","aspectMode": "cover","aspectRatio": "2:3","gravity": "top","url": "https://obs.line-scdn.net/{}".format(am.pictureStatus)},{"type": "box","layout": "vertical","contents": [{"type": "box","layout": "horizontal","contents": [{"type": "box","layout": "vertical","contents": [{"type": "image","url": Settemp["menu"]["icon"],"aspectMode": "cover"}],"width": "20px","height": "20px"},{"type": "separator","color":Settemp["menu"]["Garis"]},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "C O M M A N D","align": "center","size": "xs","color": Settemp["menu"]["Garis"],"offsetTop": "1px"}],"cornerRadius": "5px"},{"type": "separator","color": Settemp["menu"]["Garis"]},{"type": "box","layout": "vertical","contents": [{"type": "image","url": Settemp["menu"]["icon"],"aspectMode": "cover"}],"width": "20px","height": "20px"}]}],"position": "absolute","offsetTop": "3px","width": "150px","offsetStart": "3px","cornerRadius": "5px","borderWidth": "1px","borderColor":Settemp["menu"]["Garis"]},{"type": "box","layout": "vertical","contents": [{"type": "box","layout": "vertical","contents": [{"type": "box","layout": "vertical","contents": [{"type": "text","text": maulana,"color":Settemp["menu"]["Warnatext"],"size": "xxs","wrap": True,"offsetStart": "2px"}]}]}],"position": "absolute","offsetTop": "28px","width": "150px","offsetStart": "3px"},{"type": "box","layout": "vertical","contents": [{"type": "box","layout": "horizontal","contents": [{"type": "box","layout": "vertical","contents": [{"type": "image","url": "https://obs.line-scdn.net/{}".format(am.pictureStatus),"aspectMode": "cover","size": "full"}],"width": "33px","height": "33px"},{"type": "separator", "color": Settemp["menu"]["Garis"]},{"type": "box","layout": "vertical","contents": [{ "type": "text","text": "{}".format(client.getProfile().displayName),"color": Settemp["menu"]["warnatextnikname"],"align": "center","offsetTop": "1px","size": "xxs"},{"type": "separator","color": Settemp["menu"]["Garis"]},{"type": "box","layout": "vertical","contents": [{"type": "text","text": Settemp["menu"]["labeltext"],"align": "center","size": "xs","color": "#48D1CC"}],"backgroundColor":Settemp["menu"]["warnalabel"]}]}],"backgroundColor": "#000000"}],"position": "absolute","offsetTop": "196px","width": "150px","offsetStart": "3px","borderWidth": "1px","borderColor":Settemp["menu"]["Garis"],"cornerRadius": "5px"}],"paddingAll": "0px","cornerRadius": "10px","action": {"type": "uri","label": "action","uri": Settemp["Notif"]["poppup"]},"borderWidth": "2px","borderColor": Settemp["menu"]["Garis"]},"styles": {"body": {"backgroundColor": Settemp["menu"]["Bg"]}}}]}}
    sendTemplate(to, data)
#===============[ SAKLAR SETTINGS ]====================================================================
saklar_media = {"smuledonwload1": False,"smuledonwload2": False,"tiktokdonwload": False,"yt_donwload": True,"timelinedonwload": False}
#=====================================================================================================#
am_sider5 = {"ngintip":{}}
am_sider4 = {"ngintip":{}}
am_sider3 = {"ngintip":{}}
am_sider2 = {"ngintip":{},"text":"Absen dulu kak..!"}
AM_Zul = {"ngintip":{}}
cctv = {"cyduk":{},"point":{},"sidermem":{}}
nissa = {"addTikel2": {"name": "","status": False},}
anyun = {"addTikel": {"name": "","status": False},}
chatbot = {"admin": [],"botMute": [],"botOff": [],}
tes = {"Message": {},"msg": {},}
tes2 = {"Message2": {},"msg2": {},}
peler = { "receivercount": 0,"sendcount": 0}
read = { "readMember": {},"readPoint": {}}
hoho = {"savefile": False,"namefile": "",}
ProfileMe = {"myProfile": {"coverId": "","pictureStatus": "","statusMessage": ""},"PictureMe": "","NameMe": "",}
#=====================================================================
#=====================================================================
with open("Zul/temp.json", "r", encoding="utf_8_sig") as f:
    anu = json.loads(f.read())
    anu.update(settings)
    settings = anu
with open("Zul/wait.json", "r", encoding="utf_8_sig") as f:
    itu = json.loads(f.read())
    itu.update(wait)
    wait = itu





#=====================================================================
#======================[ JS ]===============================================
def executeCmd(msg, text, txt, cmd, msg_id, receiver, sender, to, setKey):
    if cmd.startswith('ex\n'):
      if sender in admin:
        try:
            sep = text.split('\n')
            ryn = text.replace(sep[0] + '\n','')
            f = open('exec.txt', 'w')
            sys.stdout = f
            print(' ')
            exec(ryn)
            print('\n%s' % str(datetime.now()))
            f.close()
            sys.stdout = sys.__stdout__
            with open('exec.txt','r') as r:
                txt = r.read()
            client.sendMessage(to, txt)
        except Exception as e:
            pass
      else:
        client.sendMessage(to, 'Apalo !')
    elif cmd.startswith('exc\n'):
      if sender in clientMid:
        sep = text.split('\n')
        ryn = text.replace(sep[0] + '\n','')
        if 'print' in ryn:
          ryn = ryn.replace('print(','client.sendExecMessage(to,')
          exec(ryn)
        else:
          exec(ryn)
      else:
        client.sendMessage(to, 'Apalo !')
def failOverAPI():
    try:
        result = requests.get("https://api.boteater.xyz",timeout=0.5)
        if result.status_code == 200:
            return "https://api.boteater.xyz"
        else:
            return "https://api.boteater.us"
    except:
        return "https://api.boteater.us"



def sendSticker(to, version, packageId, stickerId):
    contentMetadata = {'STKVER': version,'STKPKGID': packageId,'STKID': stickerId}
    client.sendMessage(to, '', contentMetadata, 7)

def footerimg(to,s,wait,j=''):
    try:
        if j == '':
            data = {"messages": [{"type": "image","originalContentUrl": s,"previewImageUrl": s,"sentBy":{"label":"{}".format(client.getContact(clientMID).displayName),"iconUrl":"https://obs.line-scdn.net/{}".format(client.getContact(clientMID).pictureStatus),"linkUrl":"line://ti/p/~linux.1"}}]}
        else:
            data = {"messages": [{"type": "image","originalContentUrl": s,"previewImageUrl": s,"animated":True,"extension":"gif","sentBy":{"label":"{}".format(client.getContact(clientMID).displayName),"iconUrl":"https://obs.line-scdn.net/{}".format(client.getContact(clientMID).pictureStatus),"linkUrl":"line://ti/p/~linux.1"}}]}
        sendCarousel(to,data)
    except Exception as e:
        print(e)
def footervideo(to,s,wait,j=''):
    try:
        if j == '':
            data = {"messages": [{"type": "video","originalContentUrl": s,"previewImageUrl": s}]}
        else:
            data = {"messages": [{"type": "video","originalContentUrl": s,"previewImageUrl": s}]}
        sendCarousel(to,data)
    except Exception as e:
        print(e)
# BATAS SUCI =====================================================================
def restartBot():
    print ("[ INFO ] BOT RESETTED")
    backupData()
    python = sys.executable
    os.execl(python, python, *sys.argv) 
#=====================================================
def runtime(secs):
    mins, secs = divmod(secs,60)
    hours, mins = divmod(mins,60)
    days, hours = divmod(hours, 24)
    return '%02d d %02d h %02d m %02d s' % (days, hours, mins, secs)
#=====================================================
def ClonerV2(to):
    try:
        contact = client.getContact(to)
        profile = client.profile
        profileName = client.profile
        profileStatus = client.profile
        profileName.displayName = contact.displayName
        profileStatus.statusMessage = contact.statusMessage
        client.updateProfile(profileName)
        client.updateProfile(profileStatus)
        profile.pictureStatus = client.downloadFileURL('http://dl.profile.line-cdn.net/{}'.format(contact.pictureStatus, 'path'))
        if client.getProfileCoverId(to) is not None:
            client.updateProfileCoverById(client.getProfileCoverId(to))
        client.updateProfilePicture(profile.pictureStatus)
        print("Success Clone Profile {}".format(contact.displayName))
        return client.updateProfile(profile)
        if contact.videoProfile == None:
            return "Get Video Profile"
        path2 = "http://dl.profile.line-cdn.net/" + profile.pictureStatus
        client.updateProfilePicture(path2, 'vp')
    except Exception as error:
        print(error)
#=====================================================
def cekmentions(to,wait,cmd):
    try:
        if to in wait['ROM']:
          moneys = {}
          for a in wait['ROM'][to].items():
            moneys[a[0]] = [a[1]['msg.id'],a[1]['waktu'],a[1]['metadata'],a[1]['text']] if a[1] is not None else idnya
          sort = sorted(moneys)
          sort.reverse()
          sort = sort[0:]
          msgas = ' 「 Mention Me 」'
          if cmd == "mentionme":
            try:
                if to in wait['ROM']:
                  h = []
                  no = 0
                  for m in sort:
                    h.append(m)
                    no+=1
                    msgas+= '\n{}. @!{}x'.format(no,len(moneys[m][0]))
                  client.sendMention(to, msgas,' 「 Mention Me 」\n', h)
            except:
                  try:
                      msgas = 'Sorry @!In {} nothink get a mention'.format(client.getGroup(to).name)
                      client.sendMention(to, msgas,' 「 Mention Me 」\n', [client.getProfile().mid])
                  except:
                      msgas = 'Sorry @!In Chat @!nothink get a mention'
                      client.sendMention(to, msgas,' 「 Mention Me 」\n', [client.getProfile().mid,to])

          if cmd.startswith('cek mention '):
            if len(cmd.split(" ")) == 3:
              asd = sort[int(cmd.split(" ")[2])-1]
              nol = 0
              msgas+= '\n - @! {}x Mention'.format(len(moneys[asd][0]))
              h = [asd]
              has = ''
              anu = -1
              numb = 0
              try:
                  for kntl in moneys[asd][0]:
                      anu += 1
                      numb += 1
                      has+= '\n{}. line://nv/chatMsg?chatId={}&messageId={} {}\n'.format(numb,to,kntl,humanize.naturaltime(datetime.fromtimestamp(moneys[asd][1][anu]/1000)))
                  for kucing in range(len(moneys[asd][3])):
                      nol+=1
                      if moneys[asd][3][kucing].count('@!') >= 21:
                        if nol == 1:msgas+= '\n{}. {}\nJust Tagall Or Spam Tag > 20 Tag'.format(nol,humanize.naturaltime(datetime.fromtimestamp(moneys[asd][1][kucing]/1000)))
                        else:msgas+= '\n\n{}. {}\nJust Tagall Or Spam Tag > 20 Tag'.format(nol,humanize.naturaltime(datetime.fromtimestamp(moneys[asd][1][kucing]/1000)))
                      else:
                          for hhh in eval(moneys[asd][2][kucing]['MENTION'])["MENTIONEES"]:
                              h.append(hhh['M'])
                          if nol == 1:msgas+= '\n{}. Text: {}'.format(nol,moneys[asd][3][kucing])
                          else:msgas+= '\n{}. Text: {}'.format(nol,moneys[asd][3][kucing])
                      dd = len(msgas.split('@!'))
                      k = dd//20
                      no=0
                      for a in range(k+1):
                          gg = ''
                          for b in msgas.split('@!')[a*20 : (a+1)*20]:
                              no+=1
                              if a == 0:
                                  if no == len(msgas.split('@!')):gg+= b
                                  else:gg+= b+'@!'
                              else:
                                  if no == a+100:gg+= b.replace('\n','')+'@!'
                                  else:
                                      if no == len(msgas.split('@!')):gg+= b
                                      else:gg+= b+'@!'
                          client.sendMention(to, gg+'\nLink: \n'+has,' 「 Mention Me 」\n', h[a*20 : (a+1)*20])
              except Exception as e:client.sendMessage(to,'ERROR {}'.format(e))
        else:
            try:
                msgas = 'Sorry @!In {} nothing get a mention'.format(client.getGroup(to).name)
                client.sendMention(to, msgas,' 「 Mention Me 」\n', [client.getProfile().mid])
            except:
                msgas = 'Sorry @!In Chat @!nothing get a mention'
                client.sendMention(to, msgas,' 「 Mention Me 」\n', [client.getProfile().mid,to])
    except Exception as error:
        logError(error)
        print(error)    
#=====================================================
def sendMentionV2(to, text="", mids=[], name="", url="", iconlink=""):
    arrData = ""
    arr = []
    mention = "@aLvi "
    if mids == []:
        raise Exception("Invalid mids")
    if "@!" in text:
        if text.count("@!") != len(mids):
            raise Exception("Invalid mids")
        texts = text.split("@!")
        textx = ""
        for mid in mids:
            textx += str(texts[mids.index(mid)])
            slen = len(textx)
            elen = len(textx) + 9
            arrData = {'S':str(slen), 'E':str(elen - 4), 'M':mid}
            arr.append(arrData)
            textx += mention
        textx += str(texts[len(mids)])
    else:
        textx = ""
        slen = len(textx)
        elen = len(textx) + 9
        arrData = {'S':str(slen), 'E':str(elen - 4), 'M':mids[0]}
        arr.append(arrData)
        textx += mention + str(text)
    client.sendMessage(to, textx, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)

def sendMention(to, mid, firstmessage='', lastmessage=''):
    try:
        arrData = ""
        text = "%s " %(str(firstmessage))
        arr = []
        mention = "@aLvino_baiha "
        slen = str(len(text))
        elen = str(len(text) + len(mention) - 1)
        arrData = {'S':slen, 'E':elen, 'M':mid}
        arr.append(arrData)
        text += mention + str(lastmessage)
        try:
            client.sendMessage(to, text, {'MSG_SENDER_NAME': client.getContact(mid).displayName,'MSG_SENDER_ICON': "http://dl.profile.line-cdn.net/" + client.getContact(mid).pictureStatus,'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
        except Exception as e:
            client.sendMessage(to, text, {'MSG_SENDER_NAME': client.getContact("u8048a08e0de46f2312d0158652e939f6").displayName,'MSG_SENDER_ICON': 'http://dl.profile.line-cdn.net/' + client.getContact("u8048a08e0de46f2312d0158652e939f6").pictureStatus,'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
    except Exception as error:
        print(error)
def sendMention2(to, mid, firstmessage='', lastmessage=''):
    try:
        arrData = ""
        text = "%s " %(str(firstmessage))
        arr = []
        mention = "@aLvino_baiha "
        slen = str(len(text))
        elen = str(len(text) + len(mention) - 1)
        arrData = {'S':slen, 'E':elen, 'M':mid}
        arr.append(arrData)
        text += mention + str(lastmessage)
        try:
            client.sendMessage(to, text, {'MSG_SENDER_NAME': client.getContact(mid).displayName,'MSG_SENDER_ICON': "http://dl.profile.line-cdn.net/" + client.getContact(mid).pictureStatus,'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
        except Exception as e:
            client.sendMessage(to, text, {'MSG_SENDER_NAME': client.getContact(mid).displayName,'MSG_SENDER_ICON': 'http://dl.profile.line-cdn.net/' + client.getContact(mid).pictureStatus,'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
    except Exception as error:
        print(error)
#=====================================================
def youtubeMp3(to, link):
    subprocess.getoutput('youtube-dl --extract-audio --audio-format mp3 --output video.mp3 {}'.format(link))
    try:
        client.sendAudio(to, 'video.mp3')
        time.sleep(2)
        os.remove('video.mp3')
    except Exception as e:
        client.sendMessage(to, "Error")

def fileYtMp4(to, link):
    subprocess.getoutput('youtube-dl --format mp4 --output FileYoutube.mp4 {}'.format(link))
    try:
        client.sendFile(to, "FileYoutube.mp4")
        time.sleep(2)
        os.remove('FileYoutube.mp4')
    except Exception as e:
        client.sendMessage(to, ' 「 ERROR 」')
    
def fileYtMp3(to, link):
    subprocess.getoutput('youtube-dl --extract-audio --audio-format mp3 --output FileYoutube.mp3 {}'.format(link))
    try:
        client.sendFile(to, 'FileYoutube.mp3')
        time.sleep(2)
        os.remove('FileYoutube.mp3')
    except Exception as e:
        client.sendMessage(to, ' 「 ERROR 」')
#=====================================================
def mentions(to, text="", mids=[]):
    arrData = ""
    arr = []
    mention = "@aLvino_baiha  "
    if mids == []:
        raise Exception("Invalid mids")
    if "@!" in text:
        if text.count("@!") != len(mids):
            raise Exception("Invalid mids")
        texts = text.split("@!")
        textx = ""
        for mid in mids:
            textx += str(texts[mids.index(mid)])
            slen = len(textx)
            elen = len(textx) + 15
            arrData = {'S':str(slen), 'E':str(elen - 4), 'M':mid}
            arr.append(arrData)
            textx += mention
        textx += str(texts[len(mids)])
    else:
        textx = ""
        slen = len(textx)
        elen = len(textx) + 15
        arrData = {'S':str(slen), 'E':str(elen - 4), 'M':mids[0]}
        arr.append(arrData)
        textx += mention + str(text)
    client.sendMessage(to, textx, {'AGENT_NAME':'LINE OFFICIAL', 'AGENT_LINK': 'line://ti/p/~{}'.format(client.getProfile().userid), 'AGENT_ICON': "http://dl.profile.line-cdn.net/" + client.getContact.picturePath, 'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
#=====================================================================
def load():
    global images
    global stickers
    global stickerz
    with open("Zul/image.json","r") as fp:
        images = json.load(fp)
    with open("Zul/sticker.json","r") as fp:
        stickers = json.load(fp)
    with open("Zul/stickerz.json","r") as fp:
        stickerz = json.load(fp)
def sendStickers(to, sver, spkg, sid):
    contentMetadata = {
        'STKVER': sver,
        'STKPKGID': spkg,
        'STKID': sid
    }
    client.sendMessage(to, '', contentMetadata, 7)
def sendSticker(to, mid, sver, spkg, sid):
    contentMetadata = {
        'MSG_SENDER_NAME': client.getContact(mid).displayName,
        'MSG_SENDER_ICON': 'http://dl.profile.line-cdn.net/' + client.getContact(mid).pictureStatus,
        'STKVER': sver,
        'STKPKGID': spkg,
        'STKID': sid
    }
    client.sendMessage(to, '', contentMetadata, 7)
def sendImage(to, path, name="image"):
    try:
        if settings["server"] == "VPS":
            client.sendImageWithURL(to, str(path))
    except Exception as error:
        logError(error)
#=====================================================================
#=====================================================================
def changeVideoAndPictureProfile(pict, vids):
    try:
        files = {'file': open(vids, 'rb')}
        obs_params = client.genOBSParams({'oid': clientMID, 'ver': '2.0', 'type': 'video', 'cat': 'vp.mp4'})
        data = {'params': obs_params}
        r_vp = client.server.postContent('{}/talk/vp/upload.nhn'.format(str(client.server.LINE_OBS_DOMAIN)), data=data, files=files)
        if r_vp.status_code != 201:
            return "Failed update profile"
        client.updateProfilePicture(pict, 'vp')
        return "Success update profile"
    except Exception as e:
        raise Exception("Error change video and picture profile {}".format(str(e)))
        os.remove("FadhilvanHalen.mp4")

def changeProfileVideo(to):
    if settings['changeProfileVideo']['picture'] == None:
        return client.sendMessage(to, "Foto tidak ditemukan")
    elif settings['changeProfileVideo']['video'] == None:
        return client.sendMessage(to, "Video tidak ditemukan")
    else:
        path = settings['changeProfileVideo']['video']
        files = {'file': open(path, 'rb')}
        obs_params = client.genOBSParams({'oid': client.getProfile().mid, 'ver': '2.0', 'type': 'video', 'cat': 'vp.mp4'})
        data = {'params': obs_params}
        r_vp = client.server.postContent('{}/talk/vp/upload.nhn'.format(str(client.server.LINE_OBS_DOMAIN)), data=data, files=files)
        if r_vp.status_code != 201:
            return client.sendMessage(to, "Gagal update profile")
        path_p = settings['changeProfileVideo']['picture']
        settings['changeProfileVideo']['status'] = False
        client.updateProfilePicture(path_p, 'vp')

def backProfileVideo():
    path = settings['changeProfileVideo']['video']
    files = {'file': open(path, 'rb')}
    obs_params = client.genOBSParams({'oid': client.getProfile().mid, 'ver': '2.0', 'type': 'video', 'cat': 'vp.mp4'})
    data = {'params': obs_params }
    r_vp = client.server.postContent('{}/talk/vp/upload.nhn'.format(str(client.server.LINE_OBS_DOMAIN)), data=data, files=files)
    if r_vp.status_code != 201:
        return client.sendMessage(to, "Failed")
    path_p = settings['changeProfileVideo']['picture']
    client.updateProfilePicture(path_p, 'vp')

def cytmp4(to,url):
    import pafy
    vid = pafy.new(url,basic=False)
    result = vid.streams[-1]
    return result.url
    links = cytmp4(anunya);links = 'https://'+client.google_url_shorten(links)

def pendekin(to,url):
    req_url = 'https://www.googleapis.com/urlshortener/v1/url?key=AIzaSyAzrJV41pMMDFUVPU0wRLtxlbEU-UkHMcI'
    payload = {'longUrl': url}
    headers = {'content-type': 'application/json'}
    r = requests.post(req_url, data=json.dumps(payload), headers=headers)
    resp = json.loads(r.text)
    return resp['id']

def cloneProfile(mid):
    contact = client.getContact(mid)
    if contact.videoProfile == None:
        client.cloneContactProfile(mid)
    else:
        profile = client.getProfile()
        profile.displayName, profile.statusMessage = contact.displayName, contact.statusMessage
        client.updateProfile(profile)
        pict = client.downloadFileURL('http://dl.profile.line-cdn.net/' + contact.pictureStatus, saveAs="tmp/pict.bin")
        vids = client.downloadFileURL( 'http://dl.profile.line-cdn.net/' + contact.pictureStatus + '/vp', saveAs="tmp/video.bin")
        changeVideoAndPictureProfile(pict, vids)
    coverId = client.getProfileDetail(mid)['result']['objectId']
    client.updateProfileCoverById(coverId)

def backupProfile():
    profile = client.getContact(clientMID)
    settings['myProfile']['displayName'] = profile.displayName
    settings['myProfile']['pictureStatus'] = profile.pictureStatus
    settings['myProfile']['statusMessage'] = profile.statusMessage
    settings['myProfile']['videoProfile'] = profile.videoProfile
    coverId = client.getProfileDetail()['result']['objectId']
    settings['myProfile']['coverId'] = str(coverId)

def restoreProfile():
    profile = client.getProfile()
    profile.displayName = settings['myProfile']['displayName']
    profile.statusMessage = settings['myProfile']['statusMessage']
    if settings['myProfile']['videoProfile'] == None:
        profile.pictureStatus = settings['myProfile']['pictureStatus']
        client.updateProfileAttribute(8, profile.pictureStatus)
        client.updateProfile(profile)
    else:
        client.updateProfile(profile)
        pict = client.downloadFileURL('http://dl.profile.line-cdn.net/' + settings['myProfile']['pictureStatus'], saveAs="tmp/pict.bin")
        vids = client.downloadFileURL( 'http://dl.profile.line-cdn.net/' + settings['myProfile']['pictureStatus'] + '/vp', saveAs="tmp/video.bin")
        changeVideoAndPictureProfile(pict, vids)
    coverId = settings['myProfile']['coverId']
    client.updateProfileCoverById(coverId)
def speedtest(secs):
    mins, secs = divmod(secs,60)
    hours, mins = divmod(mins,60)
    days, hours = divmod(hours,24)
    weaks, days = divmod(days,7)
    if days == 0:
        return '%02d' % (secs)
    elif days > 0 and weaks == 0:
        return '%02d' %(secs)
    elif days > 0 and weaks > 0:
        return '%02d' %(secs)

def change(url):
	import base64
	return base64.b64encode(url.encode()).decode()
	
def tagdia(to, text="",ps='', mids=[]):
        arrData = ""
        arr = []
        mention = "@aLvino_baiha "
        if mids == []:
            raise Exception("Invalid mids")
        if "@!" in text:
            if text.count("@!") != len(mids):
                raise Exception("Invalid mids")
            texts = text.split("@!")
            textx = ''
            h = ''
            for mid in range(len(mids)):
                h+= str(texts[mid].encode('unicode-escape'))
                textx += str(texts[mid])
                if h != textx:slen = len(textx)+h.count('U0');elen = len(textx)+h.count('U0') + 13
                else:slen = len(textx);elen = len(textx) + 13
                arrData = {'S':str(slen), 'E':str(elen), 'M':mids[mid]}
                arr.append(arrData)
                textx += mention
            textx += str(texts[len(mids)])
        else:
            textx = ''
            slen = len(textx)
            elen = len(textx) + 18
            arrData = {'S':str(slen), 'E':str(elen - 4), 'M':mids[0]}
            arr.append(arrData)
            textx += mention + str(text)
        client.sendMessage(to, textx, {'MSG_SENDER_NAME': client.getContact(ps).displayName,'MSG_SENDER_ICON': "http://dl.profile.line-cdn.net/" + client.getContact(ps).pictureStatus,'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
#=====================================================================
#=====================================================================
def youtubeMp4(to, link):
    subprocess.getoutput('youtube-dl --format mp4 --output video.mp4 {}'.format(link))
    try:
        client.sendVideo(to, "video.mp4")
        time.sleep(2)
        os.remove('video.mp4')
    except Exception as e:
        client.sendMessage(to, "Error")

def autoresponuy(to,msg,wait):
    to = msg.to
    if msg.to not in wait["GROUP"]['AR']['AP']:
        return
    if msg.to in wait["GROUP"]['AR']['S']:
        client.sendMessage(msg.to,text=None,contentMetadata=wait["GROUP"]['AR']['S'][msg.to]['Sticker'], contentType=7)
    if(wait["GROUP"]['AR']['P'][msg.to] in [""," ","\n",None]):
        return
    if '@!' not in wait["GROUP"]['AR']['P'][msg.to]:
        wait["GROUP"]['AR']['P'][msg.to] = '@!'+wait["GROUP"]['AR']['P'][msg.to]
    nama = client.getGroup(msg.to).name
    sd = client.waktunjir()
    client.sendMention(msg.to,wait["GROUP"]['AR']['P'][msg.to].replace('greeting',sd).replace(';',nama),'',[msg._from]*wait["GROUP"]['AR']['P'][msg.to].count('@!'))

def anulurk(to, wait):
    moneys = {}
    for a in wait["setTime"][to].items():
        moneys[a[1]] = [a[0]] if a[1] is not None else idnya
    sort = sorted(moneys)
    sort = sort[0:]
    k = len(sort)//100
    for a in range(k+1):
        if a == 0:no= a;msgas = '╭「 Lurkers 」─'
        else:no = a*100;msgas = '├「 Lurkers 」─'
        h = []
        for i in sort[a*100 : (a+1)*100]:
            h.append(moneys[i][0])
            no+=1
            a = '{}'.format(humanize.naturaltime(datetime.fromtimestamp(i/1000)))
            if no == len(sort):msgas+='\n│{}. @!\n╰    「 {} 」'.format(no,a)
            else:msgas+='\n│{}. @!\n│    「 {} 」'.format(no,a)
        mentions(to, msgas, h)
#=====================================================================
def bcTemplate3(friend, data):
    xyz = LiffChatContext(friend)
    xyzz = LiffContext(chat=xyz)
    view = LiffViewRequest('1602687308-GXq4Vvk9', xyzz)
    token = client.liff.issueLiffView(view)
    url = 'https://api.line.me/message/v3/share'
    headers = {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer %s' % token.accessToken
    }
    data = {"messages":[data]}
    requests.post(url, headers=headers, data=json.dumps(data))
#=====================================================================
def bcTemplate2(friend, data):
    xyz = LiffChatContext(friend)
    xyzz = LiffContext(chat=xyz)
    view = LiffViewRequest('1602687308-GXq4Vvk9', xyzz)
    token = client.liff.issueLiffView(view)
    url = 'https://api.line.me/message/v3/share'
    headers = {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer %s' % token.accessToken
    }
    data = {"messages":[data]}
    requests.post(url, headers=headers, data=json.dumps(data))
#=====================================================================
def bcTemplate(gr, data):
    xyz = LiffChatContext(gr)
    xyzz = LiffContext(chat=xyz)
    view = LiffViewRequest('1602687308-GXq4Vvk9', xyzz)
    token = client.liff.issueLiffView(view)
    url = 'https://api.line.me/message/v3/share'
    headers = {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer %s' % token.accessToken
    }
    data = {"messages":[data]}
    requests.post(url, headers=headers, data=json.dumps(data))
#=====================================================================

def am_status(to):
    am = client.getContact(clientMID)
    tz = pytz.timezone("Asia/Jakarta")
    timeNow = datetime.now(tz=tz)
    timeHours = datetime.strftime(timeNow," (%H:%M)")
    if AM_SAKLAR["autoblock"] == True:txt = "☑️ ᴀᴜᴛᴏʙʟᴏᴄᴋ ᴏɴ\n"
    else:txt = "❎ ᴀᴜᴛᴏʙʟᴏᴄᴋ ᴏғғ\n"
    if AM_SAKLAR["autojoin"] == True:txt += "☑️ ᴀᴜᴛᴏᴊᴏɪɴ ᴏɴ\n"
    else:txt += "❎ ᴀᴜᴛᴏᴊᴏɪɴ ᴏғғ\n"
    if AM_SAKLAR["autoleave"] == True:txt += "☑️ ᴀᴜᴛᴏʟᴇᴀᴠᴇ ᴏɴ\n"
    else:txt += "❎ ᴀᴜᴛᴏʟᴇᴀᴠᴇ ᴏғғ\n"
    if AM_SAKLAR["detect_tl"] == True:txt += "☑️ ᴀᴜᴛᴏʟɪᴋᴇ ᴏɴ\n"
    else:txt += "❎ ᴀᴜᴛᴏʟɪᴋᴇ ᴏғғ\n"
    if AM_SAKLAR["rwelcome"] == True:txt += "☑️ respon welcome ᴏɴ\n"
    else:txt += "❎ respon welcome ᴏғғ\n"
    if AM_SAKLAR["rleave"] == True:txt += "☑️ respon leave ᴏɴ\n"
    else:txt += "❎ respon leave ᴏғғ\n"
    if AM_SAKLAR["detect_tag"] == True:txt += "☑️ ʀᴇsᴘᴏɴ ᴛᴀɢ ᴏɴ\n"
    else:txt += "❎ ʀᴇsᴘᴏɴ ᴛᴀɢ ᴏғғ\n"
    if AM_SAKLAR["detect_tag_poto"] == True:txt += "☑️ ʀᴇsᴘᴏɴ ᴛᴀɢ ᴘᴏᴛᴏ ᴏɴ\n"
    else:txt += "❎ ʀᴇsᴘᴏɴ ᴛᴀɢ ᴘᴏᴛᴏ ᴏғғ\n"
    if AM_SAKLAR["detect_tag_text"] == True:txt += "☑️ ʀᴇsᴘᴏɴ ᴛᴀɢ ᴛᴇxᴛ ᴏɴ\n"
    else:txt += "❎ ʀᴇsᴘᴏɴ ᴛᴀɢ ᴛᴇxᴛ ᴏғғ\n"
    if AM_SAKLAR["detect_tag_kick"] == True:Zul = "☑️ ʀᴇsᴘᴏɴ ᴛᴀɢ ᴋɪᴄᴋ ᴏɴ\n"
    else:Zul = "❎ ʀᴇsᴘᴏɴ ᴛᴀɢ ᴋɪᴄᴋ ᴏғғ\n"
    if AM_SAKLAR["mode_publik"] == True:Zul += "☑️ ᴍᴏᴅᴇ ᴘᴜʙʟɪᴋ ᴏɴ\n"
    else:Zul += "❎ ᴍᴏᴅᴇ ᴘᴜʙʟɪᴋ ᴏғғ\n"
    if AM_SAKLAR["detect_contact"] == True:Zul += "☑️ ᴅᴇᴛᴇᴄᴛ ᴄᴏɴᴛᴀᴄᴛ ᴏɴ\n"
    else:Zul += "❎ ᴅᴇᴛᴇᴄᴛ ᴄᴏɴᴛᴀᴄᴛ ᴏғғ\n"
    if AM_SAKLAR["detect_sticker"] == True:Zul += "☑️ ᴅᴇᴛᴇᴄᴛ sᴛɪᴄᴋᴇʀ ᴏɴ\n"
    else:Zul += "❎ ᴅᴇᴛᴇᴄᴛ sᴛɪᴄᴋᴇʀ ᴏғғ\n"
    if AM_SAKLAR["detect_id_sticker"] == True:Zul += "☑️ ᴅᴇᴛᴇᴄᴛ ɪᴅ sᴛɪᴄᴋᴇʀ ᴏɴ\n"
    else:Zul += "❎ ᴅᴇᴛᴇᴄᴛ ɪᴅ sᴛɪᴄᴋᴇʀ ᴏғғ\n"
#..........    if AM_SAKLAR["detect_video"] == True:Zul += "☑️ ᴅᴇᴛᴇᴄᴛ ᴠɪᴅᴇᴏ ᴏɴ\n"
#..........    else:Zul += "❎ ᴅᴇᴛᴇᴄᴛ ᴠɪᴅᴇᴏ ᴏғғ\n"
#..........   if AM_SAKLAR["detect_audio"] == True:Zul += "☑️ ᴅᴇᴛᴇᴄᴛ ᴀᴜᴅɪᴏ ᴏɴ\n"
#..........    else:Zul += "❎ ᴅᴇᴛᴇᴄᴛ ᴀᴜᴅɪᴏ ᴏғғ\n"
    if AM_SAKLAR["detect_call"] == True:Zul += "☑️ ᴅᴇᴛᴇᴄᴛ ᴄᴀʟʟ ᴏɴ\n"
    else:Zul += "❎ ᴅᴇᴛᴇᴄᴛ ᴄᴀʟʟ ᴏғғ\n"
    if AM_SAKLAR["detect_templete"] == True:Zul += "☑️ ᴅᴇᴛᴇᴄᴛ ᴛᴇᴍᴘʟᴀᴛᴇ ᴏɴ\n"
    else:Zul += "❎ ᴅᴇᴛᴇᴄᴛ ᴛᴇᴍᴘʟᴀᴛᴇ ᴏғғ\n"
    if AM_SAKLAR["bigsticker"] == True:am = "☑️ ʙɪɢsᴛɪᴄᴋᴇʀ ᴏɴ\n"
    else:am = "❎ ʙɪɢsᴛɪᴄᴋᴇʀ ᴏғғ\n"
    if settings["autoRead"] == True:am += "☑️ ᴀᴜᴛᴏʀᴇᴀᴅ ᴘᴇsᴀɴ ᴏɴ\n"
    else:am += "❎ ᴀᴜᴛᴏʀᴇᴀᴅ ᴘᴇsᴀɴ ᴏғғ\n"
    if settings["autoRead1"] == True:am += "☑️ ᴀᴜᴛᴏʀᴇᴀᴅ ɢʀᴏᴜᴘ ᴏɴ\n"
    else:am += "❎ ᴀᴜᴛᴏʀᴇᴀᴅ ɢʀᴏᴜᴘ ᴏғғ\n"
#........    if AM_SAKLAR["detect_smule"] == True:am += "☑️ Detect smule ᴏɴ\n"
 #........   else:am += "❎ Detect smule ᴏғғ\n"
    data = {
    "type": "flex",
    "altText": temp_notif["temp"],
    "contents": {
    "type": "carousel",
    "contents": [
    {
    "type": "bubble",
    "size": "micro",
    "body": {
    "type": "box",
    "layout": "vertical",
    "contents": [
    {
    "type": "text",
    "text": "𝑶𝑵/𝑶𝑭𝑭",
    "size": "xs",
    "color": "#ffffff",
    "align": "center"
    },
    {
    "type": "separator",
    "color": "#00CED1"
    },
    {
    "type": "box",
    "layout": "horizontal",
    "contents": [
    {
    "type": "box",
    "layout": "vertical",
    "contents": [
    {
    "type": "text",
    "text": datetime.strftime(timeNow,'%H:%M:%S'),
    "size": "xxs",
    "color": "#ffffff",
    "align": "center"
    }
    ]
    },
    {
    "type": "separator",
    "color": "#00CED1"
    },
    {
    "type": "box",
    "layout": "vertical",
    "contents": [
    {
    "type": "text",
    "text": datetime.strftime(timeNow,'%d-%m-%Y'),
    "size": "xxs",
    "color": "#ffffff",
    "align": "center"
    }
    ]
    }
    ],
    "backgroundColor": "#008080"
    },
    {
    "type": "separator",
    "color": "#00CED1"
    },
    {
    "type": "box",
    "layout": "vertical",
    "contents": [
    {
    "type": "image",
    "url": "https://i.ibb.co/KbfDFN1/1657636839741.jpg",
    "size": "full",
    "aspectRatio": "2:2",
    "aspectMode": "cover"
    }
    ],
    "backgroundColor": "#F5F5F5"
    },
    {
    "type": "separator",
    "color": "#00CED1"
    },
    {
    "type": "box",
    "layout": "vertical",
    "contents": [
    {
    "type": "text",
    "text": "TEAM TERMUX V 13",
    "size": "sm",
    "color": "#FFFFFF",
    "align": "center"
    }
    ],
    "backgroundColor": "#800000",
    "action": {
    "type": "uri",
    "label": "action",
    "uri": "line://nv/profilePopup/mid=u42880eb65b2da1eb8fd3b7a9caa4ccc3"
    }
    },
    {
    "type": "box",
    "layout": "vertical",
    "contents": [
    {
    "type": "text",
    "text": txt,
    "size": "xs",
    "color": "#ffffff",
    "wrap": True
    }
    ],
    "position": "absolute",
    "offsetTop": "35px",
    "width": "150px",
    "offsetStart": "3px",
    "height": "150px"
    }
    ],
    "paddingAll": "0px",
    "backgroundColor": "#800000",
    "borderWidth": "2px",
    "borderColor": "#00CED1",
    "cornerRadius": "10px"
    }
    },
    {
    "type": "bubble",
    "size": "micro",
    "body": {
    "type": "box",
    "layout": "vertical",
    "contents": [
    {
    "type": "text",
    "text": "𝑶𝑵/𝑶𝑭𝑭",
    "size": "xs",
    "color": "#ffffff",
    "align": "center"
    },
    {
    "type": "separator",
    "color": "#00CED1"
    },
    {
    "type": "box",
    "layout": "horizontal",
    "contents": [
    {
    "type": "box",
    "layout": "vertical",
    "contents": [
    {
    "type": "text",
    "text": datetime.strftime(timeNow,'%H:%M:%S'),
    "size": "xxs",
    "color": "#ffffff",
    "align": "center"
    }
    ]
    },
    {
    "type": "separator",
    "color": "#00CED1"
    },
    {
    "type": "box",
    "layout": "vertical",
    "contents": [
    {
    "type": "text",
    "text": datetime.strftime(timeNow,'%d-%m-%Y'),
    "size": "xxs",
    "color": "#ffffff",
    "align": "center"
    }
    ]
    }
    ],
    "backgroundColor": "#008080"
    },
    {
    "type": "separator",
    "color": "#00CED1"
    },
    {
    "type": "box",
    "layout": "vertical",
    "contents": [
    {
    "type": "image",
    "url": "https://i.ibb.co/KbfDFN1/1657636839741.jpg",
    "size": "full",
    "aspectRatio": "2:2",
    "aspectMode": "cover"
    }
    ],
    "backgroundColor": "#F5F5F5"
    },
    {
    "type": "separator",
    "color": "#00CED1"
    },
    {
    "type": "box",
    "layout": "vertical",
    "contents": [
    {
    "type": "text",
    "text": "TEAM TERMUX V 13",
    "size": "sm",
    "color": "#FFFFFF",
    "align": "center"
    }
    ],
    "backgroundColor": "#800000",
    "action": {
    "type": "uri",
    "label": "action",
    "uri": "line://nv/profilePopup/mid=u42880eb65b2da1eb8fd3b7a9caa4ccc3"
    }
    },
    {
    "type": "box",
    "layout": "vertical",
    "contents": [
    {
    "type": "text",
    "text": Zul,
    "size": "xs",
    "color": "#ffffff",
    "wrap": True
    }
    ],
    "position": "absolute",
    "offsetTop": "35px",
    "width": "150px",
    "offsetStart": "3px",
    "height": "150px"
    }
    ],
    "paddingAll": "0px",
    "backgroundColor": "#800000",
    "borderWidth": "2px",
    "borderColor": "#00CED1",
    "cornerRadius": "10px"
    }
    },
    {
    "type": "bubble",
    "size": "micro",
    "body": {
    "type": "box",
    "layout": "vertical",
    "contents": [
    {
    "type": "text",
    "text": "𝑶𝑵/𝑶𝑭𝑭",
    "size": "xs",
    "color": "#ffffff",
    "align": "center"
    },
    {
    "type": "separator",
    "color": "#00CED1"
    },
    {
    "type": "box",
    "layout": "horizontal",
    "contents": [
    {
    "type": "box",
    "layout": "vertical",
    "contents": [
    {
    "type": "text",
    "text": datetime.strftime(timeNow,'%H:%M:%S'),
    "size": "xxs",
    "color": "#ffffff",
    "align": "center"
    }
    ]
    },
    {
    "type": "separator",
    "color": "#00CED1"
    },
    {
    "type": "box",
    "layout": "vertical",
    "contents": [
    {
    "type": "text",
    "text": datetime.strftime(timeNow,'%d-%m-%Y'),
    "size": "xxs",
    "color": "#ffffff",
    "align": "center"
    }
    ]
    }
    ],
    "backgroundColor": "#008080"
    },
    {
    "type": "separator",
    "color": "#00CED1"
    },
    {
    "type": "box",
    "layout": "vertical",
    "contents": [
    {
    "type": "image",
    "url": "https://i.ibb.co/KbfDFN1/1657636839741.jpg",
    "size": "full",
    "aspectRatio": "2:2",
    "aspectMode": "cover"
    }
    ],
    "backgroundColor": "#F5F5F5"
    },
    {
    "type": "separator",
    "color": "#00CED1"
    },
    {
    "type": "box",
    "layout": "vertical",
    "contents": [
    {
    "type": "text",
    "text": "TEAM TERMUX V 13",
    "size": "sm",
    "color": "#FFFFFF",
    "align": "center"
    }
    ],
    "backgroundColor": "#800000",
    "action": {
    "type": "uri",
    "label": "action",
    "uri": "line://nv/profilePopup/mid=u42880eb65b2da1eb8fd3b7a9caa4ccc3"
    }
    },
    {
    "type": "box",
    "layout": "vertical",
    "contents": [
    {
    "type": "text",
    "text": am,
    "size": "xs",
    "color": "#ffffff",
    "wrap": True
    }
    ],
    "position": "absolute",
    "offsetTop": "35px",
    "width": "150px",
    "offsetStart": "3px",
    "height": "150px"
    }
    ],
    "paddingAll": "0px",
    "backgroundColor": "#800000",
    "borderWidth": "2px",
    "borderColor": "#00CED1",
    "cornerRadius": "10px"
    }
    }
    ]
    }
    }
    sendTemplate(to, data)
    
def am_page1(to, love):
    am = client.getContact(clientMID)
    tz = pytz.timezone("Asia/Jakarta")
    timeNow = datetime.now(tz=tz)
    timeHours = datetime.strftime(timeNow," (%H:%M)")
    data = {
    "type": "flex",
    "altText": temp_notif["temp"],
    "contents": {
    "type": "carousel",
    "contents": [
    {
    "type": "bubble",
    "size": "micro",
    "body": {
    "type": "box",
    "layout": "vertical",
    "contents": [
    {
    "type": "image",
    "url": menu_img["img"],
    "size": "full",
    "aspectMode": "cover",
    "aspectRatio": "2:3",
    "gravity": "top"
    },
    {
    "type": "box",
    "layout": "horizontal",
    "contents": [
    {
    "type": "box",
    "layout": "vertical",
    "contents": [
    {
    "type": "image",
    "url": "https://obs.line-scdn.net/{}".format(am.pictureStatus),
    "size": "full",
    "aspectMode": "cover"
    }
    ],
    "width": "33px",
    "height": "33px"
    },
    {
    "type": "separator",
    "color": menu_border["warna"]
    },
    {
    "type": "box",
    "layout": "vertical",
    "contents": [
    {
    "type": "text",
    "text": "{}".format(client.getProfile().displayName),
    "size": "xxs",
    "color": label_text_coloor["warna"],
    "align": "center"
    },
    {
    "type": "separator",
    "color": menu_border["warna"]
    },
    {
    "type": "box",
    "layout": "vertical",
    "contents": [
    {
    "type": "text",
    "text": label["label"],
    "size": label_text_size["ukuran"],
    "color": label_text_coloor["warna"],
    "align": "center"
    }
    ],
    "backgroundColor": label_bg_color["warna"]
    }
    ]
    }
    ],
    "position": "absolute",
    "cornerRadius": "4px",
    "offsetTop": "198px",
    "backgroundColor": "#000000",
    "offsetStart": "4px",
    "width": "150px",
    "borderWidth": "1px",
    "borderColor": menu_border["warna"]
    },
    {
    "type": "box",
    "layout": "vertical",
    "contents": [
    {
    "type": "text",
    "text": love,
    "size": menu_text_size["ukuran"],
    "color": menu_text["warna"],
    "wrap": True
    }
    ],
    "position": "absolute",
    "height": "150px",
    "offsetTop": "30px",
    "offsetStart": "5px"
    },
    {
    "type": "box",
    "layout": "horizontal",
    "contents": [
    {
    "type": "box",
    "layout": "vertical",
    "contents": [
    {
    "type": "image",
    "url": object_icon["img"],
    "size": "full",
    }
    ],
    "width": "20px",
    "height": "20px"
    },
    {
    "type": "separator",
    "color": menu_border["warna"]
    },
    {
    "type": "box",
    "layout": "vertical",
    "contents": [
    {
    "type": "text",
    "text": "𝑴 𝑬 𝑵 𝑼  𝑺 𝑬 𝑳 𝑭",
    "size": "xs",
    "color": label_text_coloor["warna"],
    "align": "center",
    "offsetTop": "1px"
    }
    ]
    },
    {
    "type": "separator",
    "color": menu_border["warna"]
    },
    {
    "type": "box",
    "layout": "vertical",
    "contents": [
    {
    "type": "image",
    "url": object_icon["img"],
    "size": "full"
    }
    ],
    "width": "20px",
    "height": "20px"
    }
    ],
    "position": "absolute",
    "offsetTop": "4px",
    "width": "150px",
    "borderWidth": "1px",
    "borderColor": menu_border["warna"],
    "cornerRadius": "5px",
    "offsetStart": "4px"
    }
    ],
    "paddingAll": "0px",
    "borderWidth": "1px",
    "borderColor": menu_border["warna"],
    "cornerRadius": "10px"
    }
    }
    ]
    }
    }
    sendTemplate(to, data)
def am_page2(to, love, achink):
    am = client.getContact(clientMID)
    tz = pytz.timezone("Asia/Jakarta")
    timeNow = datetime.now(tz=tz)
    timeHours = datetime.strftime(timeNow," (%H:%M)")
    data = {
    "type": "flex",
    "altText": temp_notif["temp"],
    "contents": {
    "type": "carousel",
    "contents": [
    {
    "type": "bubble",
    "size": "micro",
    "body": {
    "type": "box",
    "layout": "vertical",
    "contents": [
    {
    "type": "image",
    "url": menu_img["img"],
    "size": "full",
    "aspectMode": "cover",
    "aspectRatio": "2:3",
    "gravity": "top"
    },
    {
    "type": "box",
    "layout": "horizontal",
    "contents": [
    {
    "type": "box",
    "layout": "vertical",
    "contents": [
    {
    "type": "image",
    "url": "https://obs.line-scdn.net/{}".format(am.pictureStatus),
    "size": "full",
    "aspectMode": "cover"
    }
    ],
    "width": "33px",
    "height": "33px"
    },
    {
    "type": "separator",
    "color": menu_border["warna"]
    },
    {
    "type": "box",
    "layout": "vertical",
    "contents": [
    {
    "type": "text",
    "text": "{}".format(client.getProfile().displayName),
    "size": "xxs",
    "color": label_text_coloor["warna"],
    "align": "center"
    },
    {
    "type": "separator",
    "color": menu_border["warna"]
    },
    {
    "type": "box",
    "layout": "vertical",
    "contents": [
    {
    "type": "text",
    "text": label["label"],
    "size": label_text_size["ukuran"],
    "color": label_text_coloor["warna"],
    "align": "center"
    }
    ],
    "backgroundColor": label_bg_color["warna"]
    }
    ]
    }
    ],
    "position": "absolute",
    "cornerRadius": "4px",
    "offsetTop": "198px",
    "backgroundColor": "#000000",
    "offsetStart": "4px",
    "width": "150px",
    "borderWidth": "1px",
    "borderColor": menu_border["warna"]
    },
    {
    "type": "box",
    "layout": "vertical",
    "contents": [
    {
    "type": "text",
    "text": love,
    "size": menu_text_size["ukuran"],
    "color": menu_text["warna"],
    "wrap": True
    }
    ],
    "position": "absolute",
    "height": "150px",
    "offsetTop": "30px",
    "offsetStart": "5px"
    },
    {
    "type": "box",
    "layout": "horizontal",
    "contents": [
    {
    "type": "box",
    "layout": "vertical",
    "contents": [
    {
    "type": "image",
    "url": object_icon["img"],
    "size": "full",
    }
    ],
    "width": "20px",
    "height": "20px"
    },
    {
    "type": "separator",
    "color": menu_border["warna"]
    },
    {
    "type": "box",
    "layout": "vertical",
    "contents": [
    {
    "type": "text",
    "text": "𝑴 𝑬 𝑵 𝑼  𝑺 𝑬 𝑳 𝑭",
    "size": "xs",
    "color": label_text_coloor["warna"],
    "align": "center",
    "offsetTop": "1px"
    }
    ]
    },
    {
    "type": "separator",
    "color": menu_border["warna"]
    },
    {
    "type": "box",
    "layout": "vertical",
    "contents": [
    {
    "type": "image",
    "url": object_icon["img"],
    "size": "full"
    }
    ],
    "width": "20px",
    "height": "20px"
    }
    ],
    "position": "absolute",
    "offsetTop": "4px",
    "width": "150px",
    "borderWidth": "1px",
    "borderColor": menu_border["warna"],
    "cornerRadius": "5px",
    "offsetStart": "4px"
    }
    ],
    "paddingAll": "0px",
    "borderWidth": "1px",
    "borderColor": menu_border["warna"],
    "cornerRadius": "10px"
    }
    },
    {
    "type": "bubble",
    "size": "micro",
    "body": {
    "type": "box",
    "layout": "vertical",
    "contents": [
    {
    "type": "image",
    "url": menu_img["img"],
    "size": "full",
    "aspectMode": "cover",
    "aspectRatio": "2:3",
    "gravity": "top"
    },
    {
    "type": "box",
    "layout": "horizontal",
    "contents": [
    {
    "type": "box",
    "layout": "vertical",
    "contents": [
    {
    "type": "image",
    "url": "https://obs.line-scdn.net/{}".format(am.pictureStatus),
    "size": "full",
    "aspectMode": "cover"
    }
    ],
    "width": "33px",
    "height": "33px"
    },
    {
    "type": "separator",
    "color": menu_border["warna"]
    },
    {
    "type": "box",
    "layout": "vertical",
    "contents": [
    {
    "type": "text",
    "text": "{}".format(client.getProfile().displayName),
    "size": "xxs",
    "color": label_text_coloor["warna"],
    "align": "center"
    },
    {
    "type": "separator",
    "color": menu_border["warna"]
    },
    {
    "type": "box",
    "layout": "vertical",
    "contents": [
    {
    "type": "text",
    "text": label["label"],
    "size": label_text_size["ukuran"],
    "color": label_text_coloor["warna"],
    "align": "center"
    }
    ],
    "backgroundColor": label_bg_color["warna"]
    }
    ]
    }
    ],
    "position": "absolute",
    "cornerRadius": "4px",
    "offsetTop": "198px",
    "backgroundColor": "#000000",
    "offsetStart": "4px",
    "width": "150px",
    "borderWidth": "1px",
    "borderColor": menu_border["warna"]
    },
    {
    "type": "box",
    "layout": "vertical",
    "contents": [
    {
    "type": "text",
    "text": achink,
    "size": menu_text_size["ukuran"],
    "color": menu_text["warna"],
    "wrap": True
    }
    ],
    "position": "absolute",
    "height": "150px",
    "offsetTop": "30px",
    "offsetStart": "5px"
    },
    {
    "type": "box",
    "layout": "horizontal",
    "contents": [
    {
    "type": "box",
    "layout": "vertical",
    "contents": [
    {
    "type": "image",
    "url": object_icon["img"],
    "size": "full",
    }
    ],
    "width": "20px",
    "height": "20px"
    },
    {
    "type": "separator",
    "color": menu_border["warna"]
    },
    {
    "type": "box",
    "layout": "vertical",
    "contents": [
    {
    "type": "text",
    "text": "𝑴 𝑬 𝑵 𝑼  𝑺 𝑬 𝑳 𝑭",
    "size": "xs",
    "color": label_text_coloor["warna"],
    "align": "center",
    "offsetTop": "1px"
    }
    ]
    },
    {
    "type": "separator",
    "color": menu_border["warna"]
    },
    {
    "type": "box",
    "layout": "vertical",
    "contents": [
    {
    "type": "image",
    "url": object_icon["img"],
    "size": "full"
    }
    ],
    "width": "20px",
    "height": "20px"
    }
    ],
    "position": "absolute",
    "offsetTop": "4px",
    "width": "150px",
    "borderWidth": "1px",
    "borderColor": menu_border["warna"],
    "cornerRadius": "5px",
    "offsetStart": "4px"
    }
    ],
    "paddingAll": "0px",
    "borderWidth": "1px",
    "borderColor": menu_border["warna"],
    "cornerRadius": "10px"
    }
    }
    ]
    }
    }
    sendTemplate(to, data)
def am_page3(to, love, achink, Zul):
    am = client.getContact(clientMID)
    tz = pytz.timezone("Asia/Jakarta")
    timeNow = datetime.now(tz=tz)
    timeHours = datetime.strftime(timeNow," (%H:%M)")
    data = {
    "type": "flex",
    "altText": temp_notif["temp"],
    "contents": {
    "type": "carousel",
    "contents": [
    {
    "type": "bubble",
    "size": "micro",
    "body": {
    "type": "box",
    "layout": "vertical",
    "contents": [
    {
    "type": "image",
    "url": menu_img["img"],
    "size": "full",
    "aspectMode": "cover",
    "aspectRatio": "2:3",
    "gravity": "top"
    },
    {
    "type": "box",
    "layout": "horizontal",
    "contents": [
    {
    "type": "box",
    "layout": "vertical",
    "contents": [
    {
    "type": "image",
    "url": "https://obs.line-scdn.net/{}".format(am.pictureStatus),
    "size": "full",
    "aspectMode": "cover"
    }
    ],
    "width": "33px",
    "height": "33px"
    },
    {
    "type": "separator",
    "color": menu_border["warna"]
    },
    {
    "type": "box",
    "layout": "vertical",
    "contents": [
    {
    "type": "text",
    "text": "{}".format(client.getProfile().displayName),
    "size": "xxs",
    "color": label_text_coloor["warna"],
    "align": "center"
    },
    {
    "type": "separator",
    "color": menu_border["warna"]
    },
    {
    "type": "box",
    "layout": "vertical",
    "contents": [
    {
    "type": "text",
    "text": label["label"],
    "size": label_text_size["ukuran"],
    "color": label_text_coloor["warna"],
    "align": "center"
    }
    ],
    "backgroundColor": label_bg_color["warna"]
    }
    ]
    }
    ],
    "position": "absolute",
    "cornerRadius": "4px",
    "offsetTop": "198px",
    "backgroundColor": "#000000",
    "offsetStart": "4px",
    "width": "150px",
    "borderWidth": "1px",
    "borderColor": menu_border["warna"]
    },
    {
    "type": "box",
    "layout": "vertical",
    "contents": [
    {
    "type": "text",
    "text": love,
    "size": menu_text_size["ukuran"],
    "color": menu_text["warna"],
    "wrap": True
    }
    ],
    "position": "absolute",
    "height": "150px",
    "offsetTop": "30px",
    "offsetStart": "5px"
    },
    {
    "type": "box",
    "layout": "horizontal",
    "contents": [
    {
    "type": "box",
    "layout": "vertical",
    "contents": [
    {
    "type": "image",
    "url": object_icon["img"],
    "size": "full",
    }
    ],
    "width": "20px",
    "height": "20px"
    },
    {
    "type": "separator",
    "color": menu_border["warna"]
    },
    {
    "type": "box",
    "layout": "vertical",
    "contents": [
    {
    "type": "text",
    "text": "𝑴 𝑬 𝑵 𝑼  𝑺 𝑬 𝑳 ??",
    "size": "xs",
    "color": label_text_coloor["warna"],
    "align": "center",
    "offsetTop": "1px"
    }
    ]
    },
    {
    "type": "separator",
    "color": menu_border["warna"]
    },
    {
    "type": "box",
    "layout": "vertical",
    "contents": [
    {
    "type": "image",
    "url": object_icon["img"],
    "size": "full"
    }
    ],
    "width": "20px",
    "height": "20px"
    }
    ],
    "position": "absolute",
    "offsetTop": "4px",
    "width": "150px",
    "borderWidth": "1px",
    "borderColor": menu_border["warna"],
    "cornerRadius": "5px",
    "offsetStart": "4px"
    }
    ],
    "paddingAll": "0px",
    "borderWidth": "1px",
    "borderColor": menu_border["warna"],
    "cornerRadius": "10px"
    }
    },
    {
    "type": "bubble",
    "size": "micro",
    "body": {
    "type": "box",
    "layout": "vertical",
    "contents": [
    {
    "type": "image",
    "url": menu_img["img"],
    "size": "full",
    "aspectMode": "cover",
    "aspectRatio": "2:3",
    "gravity": "top"
    },
    {
    "type": "box",
    "layout": "horizontal",
    "contents": [
    {
    "type": "box",
    "layout": "vertical",
    "contents": [
    {
    "type": "image",
    "url": "https://obs.line-scdn.net/{}".format(am.pictureStatus),
    "size": "full",
    "aspectMode": "cover"
    }
    ],
    "width": "33px",
    "height": "33px"
    },
    {
    "type": "separator",
    "color": menu_border["warna"]
    },
    {
    "type": "box",
    "layout": "vertical",
    "contents": [
    {
    "type": "text",
    "text": "{}".format(client.getProfile().displayName),
    "size": "xxs",
    "color": label_text_coloor["warna"],
    "align": "center"
    },
    {
    "type": "separator",
    "color": menu_border["warna"]
    },
    {
    "type": "box",
    "layout": "vertical",
    "contents": [
    {
    "type": "text",
    "text": label["label"],
    "size": label_text_size["ukuran"],
    "color": label_text_coloor["warna"],
    "align": "center"
    }
    ],
    "backgroundColor": label_bg_color["warna"]
    }
    ]
    }
    ],
    "position": "absolute",
    "cornerRadius": "4px",
    "offsetTop": "198px",
    "backgroundColor": "#000000",
    "offsetStart": "4px",
    "width": "150px",
    "borderWidth": "1px",
    "borderColor": menu_border["warna"]
    },
    {
    "type": "box",
    "layout": "vertical",
    "contents": [
    {
    "type": "text",
    "text": achink,
    "size": menu_text_size["ukuran"],
    "color": menu_text["warna"],
    "wrap": True
    }
    ],
    "position": "absolute",
    "height": "150px",
    "offsetTop": "30px",
    "offsetStart": "5px"
    },
    {
    "type": "box",
    "layout": "horizontal",
    "contents": [
    {
    "type": "box",
    "layout": "vertical",
    "contents": [
    {
    "type": "image",
    "url": object_icon["img"],
    "size": "full",
    }
    ],
    "width": "20px",
    "height": "20px"
    },
    {
    "type": "separator",
    "color": menu_border["warna"]
    },
    {
    "type": "box",
    "layout": "vertical",
    "contents": [
    {
    "type": "text",
    "text": "MENU SELF",
    "size": "xs",
    "color": label_text_coloor["warna"],
    "align": "center",
    "offsetTop": "1px"
    }
    ]
    },
    {
    "type": "separator",
    "color": menu_border["warna"]
    },
    {
    "type": "box",
    "layout": "vertical",
    "contents": [
    {
    "type": "image",
    "url": object_icon["img"],
    "size": "full"
    }
    ],
    "width": "20px",
    "height": "20px"
    }
    ],
    "position": "absolute",
    "offsetTop": "4px",
    "width": "150px",
    "borderWidth": "1px",
    "borderColor": menu_border["warna"],
    "cornerRadius": "5px",
    "offsetStart": "4px"
    }
    ],
    "paddingAll": "0px",
    "borderWidth": "1px",
    "borderColor": menu_border["warna"],
    "cornerRadius": "10px"
    }
    },
    {
    "type": "bubble",
    "size": "micro",
    "body": {
    "type": "box",
    "layout": "vertical",
    "contents": [
    {
    "type": "image",
    "url": menu_img["img"],
    "size": "full",
    "aspectMode": "cover",
    "aspectRatio": "2:3",
    "gravity": "top"
    },
    {
    "type": "box",
    "layout": "horizontal",
    "contents": [
    {
    "type": "box",
    "layout": "vertical",
    "contents": [
    {
    "type": "image",
    "url": "https://obs.line-scdn.net/{}".format(am.pictureStatus),
    "size": "full",
    "aspectMode": "cover"
    }
    ],
    "width": "33px",
    "height": "33px"
    },
    {
    "type": "separator",
    "color": menu_border["warna"]
    },
    {
    "type": "box",
    "layout": "vertical",
    "contents": [
    {
    "type": "text",
    "text": "{}".format(client.getProfile().displayName),
    "size": "xxs",
    "color": label_text_coloor["warna"],
    "align": "center"
    },
    {
    "type": "separator",
    "color": menu_border["warna"]
    },
    {
    "type": "box",
    "layout": "vertical",
    "contents": [
    {
    "type": "text",
    "text": label["label"],
    "size": label_text_size["ukuran"],
    "color": label_text_coloor["warna"],
    "align": "center"
    }
    ],
    "backgroundColor": label_bg_color["warna"]
    }
    ]
    }
    ],
    "position": "absolute",
    "cornerRadius": "4px",
    "offsetTop": "198px",
    "backgroundColor": "#000000",
    "offsetStart": "4px",
    "width": "150px",
    "borderWidth": "1px",
    "borderColor": menu_border["warna"]
    },
    {
    "type": "box",
    "layout": "vertical",
    "contents": [
    {
    "type": "text",
    "text": Zul,
    "size": menu_text_size["ukuran"],
    "color": menu_text["warna"],
    "wrap": True
    }
    ],
    "position": "absolute",
    "height": "150px",
    "offsetTop": "30px",
    "offsetStart": "5px"
    },
    {
    "type": "box",
    "layout": "horizontal",
    "contents": [
    {
    "type": "box",
    "layout": "vertical",
    "contents": [
    {
    "type": "image",
    "url": object_icon["img"],
    "size": "full",
    }
    ],
    "width": "20px",
    "height": "20px"
    },
    {
    "type": "separator",
    "color": menu_border["warna"]
    },
    {
    "type": "box",
    "layout": "vertical",
    "contents": [
    {
    "type": "text",
    "text": "𝑴 𝑬 𝑵 𝑼  𝑺 𝑬 𝑳 𝑭",
    "size": "xs",
    "color": label_text_coloor["warna"],
    "align": "center",
    "offsetTop": "1px"
    }
    ]
    },
    {
    "type": "separator",
    "color": menu_border["warna"]
    },
    {
    "type": "box",
    "layout": "vertical",
    "contents": [
    {
    "type": "image",
    "url": object_icon["img"],
    "size": "full"
    }
    ],
    "width": "20px",
    "height": "20px"
    }
    ],
    "position": "absolute",
    "offsetTop": "4px",
    "width": "150px",
    "borderWidth": "1px",
    "borderColor": menu_border["warna"],
    "cornerRadius": "5px",
    "offsetStart": "4px"
    }
    ],
    "paddingAll": "0px",
    "borderWidth": "1px",
    "borderColor": menu_border["warna"],
    "cornerRadius": "10px"
    }
    }
    ]
    }
    }
    sendTemplate(to, data)
def am_page4(to, love, achink, Zul, inces):
    am = client.getContact(clientMID)
    tz = pytz.timezone("Asia/Jakarta")
    timeNow = datetime.now(tz=tz)
    timeHours = datetime.strftime(timeNow," (%H:%M)")
    data = {
    "type": "flex",
    "altText": temp_notif["temp"],
    "contents": {
    "type": "carousel",
    "contents": [
    {
    "type": "bubble",
    "size": "micro",
    "body": {
    "type": "box",
    "layout": "vertical",
    "contents": [
    {
    "type": "image",
    "url": menu_img["img"],
    "size": "full",
    "aspectMode": "cover",
    "aspectRatio": "2:3",
    "gravity": "top"
    },
    {
    "type": "box",
    "layout": "horizontal",
    "contents": [
    {
    "type": "box",
    "layout": "vertical",
    "contents": [
    {
    "type": "image",
    "url": "https://obs.line-scdn.net/{}".format(am.pictureStatus),
    "size": "full",
    "aspectMode": "cover"
    }
    ],
    "width": "33px",
    "height": "33px"
    },
    {
    "type": "separator",
    "color": menu_border["warna"]
    },
    {
    "type": "box",
    "layout": "vertical",
    "contents": [
    {
    "type": "text",
    "text": "{}".format(client.getProfile().displayName),
    "size": "xxs",
    "color": label_text_coloor["warna"],
    "align": "center"
    },
    {
    "type": "separator",
    "color": menu_border["warna"]
    },
    {
    "type": "box",
    "layout": "vertical",
    "contents": [
    {
    "type": "text",
    "text": label["label"],
    "size": label_text_size["ukuran"],
    "color": label_text_coloor["warna"],
    "align": "center"
    }
    ],
    "backgroundColor": label_bg_color["warna"]
    }
    ]
    }
    ],
    "position": "absolute",
    "cornerRadius": "4px",
    "offsetTop": "198px",
    "backgroundColor": "#000000",
    "offsetStart": "4px",
    "width": "150px",
    "borderWidth": "1px",
    "borderColor": menu_border["warna"]
    },
    {
    "type": "box",
    "layout": "vertical",
    "contents": [
    {
    "type": "text",
    "text": love,
    "size": menu_text_size["ukuran"],
    "color": menu_text["warna"],
    "wrap": True
    }
    ],
    "position": "absolute",
    "height": "150px",
    "offsetTop": "30px",
    "offsetStart": "5px"
    },
    {
    "type": "box",
    "layout": "horizontal",
    "contents": [
    {
    "type": "box",
    "layout": "vertical",
    "contents": [
    {
    "type": "image",
    "url": object_icon["img"],
    "size": "full",
    }
    ],
    "width": "20px",
    "height": "20px"
    },
    {
    "type": "separator",
    "color": menu_border["warna"]
    },
    {
    "type": "box",
    "layout": "vertical",
    "contents": [
    {
    "type": "text",
    "text": "𝑴 𝑬 𝑵 𝑼  𝑺 𝑬 𝑳 𝑭",
    "size": "xs",
    "color": label_text_coloor["warna"],
    "align": "center",
    "offsetTop": "1px"
    }
    ]
    },
    {
    "type": "separator",
    "color": menu_border["warna"]
    },
    {
    "type": "box",
    "layout": "vertical",
    "contents": [
    {
    "type": "image",
    "url": object_icon["img"],
    "size": "full"
    }
    ],
    "width": "20px",
    "height": "20px"
    }
    ],
    "position": "absolute",
    "offsetTop": "4px",
    "width": "150px",
    "borderWidth": "1px",
    "borderColor": menu_border["warna"],
    "cornerRadius": "5px",
    "offsetStart": "4px"
    }
    ],
    "paddingAll": "0px",
    "borderWidth": "1px",
    "borderColor": menu_border["warna"],
    "cornerRadius": "10px"
    }
    },
    {
    "type": "bubble",
    "size": "micro",
    "body": {
    "type": "box",
    "layout": "vertical",
    "contents": [
    {
    "type": "image",
    "url": menu_img["img"],
    "size": "full",
    "aspectMode": "cover",
    "aspectRatio": "2:3",
    "gravity": "top"
    },
    {
    "type": "box",
    "layout": "horizontal",
    "contents": [
    {
    "type": "box",
    "layout": "vertical",
    "contents": [
    {
    "type": "image",
    "url": "https://obs.line-scdn.net/{}".format(am.pictureStatus),
    "size": "full",
    "aspectMode": "cover"
    }
    ],
    "width": "33px",
    "height": "33px"
    },
    {
    "type": "separator",
    "color": menu_border["warna"]
    },
    {
    "type": "box",
    "layout": "vertical",
    "contents": [
    {
    "type": "text",
    "text": "{}".format(client.getProfile().displayName),
    "size": "xxs",
    "color": label_text_coloor["warna"],
    "align": "center"
    },
    {
    "type": "separator",
    "color": menu_border["warna"]
    },
    {
    "type": "box",
    "layout": "vertical",
    "contents": [
    {
    "type": "text",
    "text": label["label"],
    "size": label_text_size["ukuran"],
    "color": label_text_coloor["warna"],
    "align": "center"
    }
    ],
    "backgroundColor": label_bg_color["warna"]
    }
    ]
    }
    ],
    "position": "absolute",
    "cornerRadius": "4px",
    "offsetTop": "198px",
    "backgroundColor": "#000000",
    "offsetStart": "4px",
    "width": "150px",
    "borderWidth": "1px",
    "borderColor": menu_border["warna"]
    },
    {
    "type": "box",
    "layout": "vertical",
    "contents": [
    {
    "type": "text",
    "text": achink,
    "size": menu_text_size["ukuran"],
    "color": menu_text["warna"],
    "wrap": True
    }
    ],
    "position": "absolute",
    "height": "150px",
    "offsetTop": "30px",
    "offsetStart": "5px"
    },
    {
    "type": "box",
    "layout": "horizontal",
    "contents": [
    {
    "type": "box",
    "layout": "vertical",
    "contents": [
    {
    "type": "image",
    "url": object_icon["img"],
    "size": "full",
    }
    ],
    "width": "20px",
    "height": "20px"
    },
    {
    "type": "separator",
    "color": menu_border["warna"]
    },
    {
    "type": "box",
    "layout": "vertical",
    "contents": [
    {
    "type": "text",
    "text": "𝑴 𝑬 𝑵 𝑼  𝑺 𝑬 𝑳 𝑭",
    "size": "xs",
    "color": label_text_coloor["warna"],
    "align": "center",
    "offsetTop": "1px"
    }
    ]
    },
    {
    "type": "separator",
    "color": menu_border["warna"]
    },
    {
    "type": "box",
    "layout": "vertical",
    "contents": [
    {
    "type": "image",
    "url": object_icon["img"],
    "size": "full"
    }
    ],
    "width": "20px",
    "height": "20px"
    }
    ],
    "position": "absolute",
    "offsetTop": "4px",
    "width": "150px",
    "borderWidth": "1px",
    "borderColor": menu_border["warna"],
    "cornerRadius": "5px",
    "offsetStart": "4px"
    }
    ],
    "paddingAll": "0px",
    "borderWidth": "1px",
    "borderColor": menu_border["warna"],
    "cornerRadius": "10px"
    }
    },
    {
    "type": "bubble",
    "size": "micro",
    "body": {
    "type": "box",
    "layout": "vertical",
    "contents": [
    {
    "type": "image",
    "url": menu_img["img"],
    "size": "full",
    "aspectMode": "cover",
    "aspectRatio": "2:3",
    "gravity": "top"
    },
    {
    "type": "box",
    "layout": "horizontal",
    "contents": [
    {
    "type": "box",
    "layout": "vertical",
    "contents": [
    {
    "type": "image",
    "url": "https://obs.line-scdn.net/{}".format(am.pictureStatus),
    "size": "full",
    "aspectMode": "cover"
    }
    ],
    "width": "33px",
    "height": "33px"
    },
    {
    "type": "separator",
    "color": menu_border["warna"]
    },
    {
    "type": "box",
    "layout": "vertical",
    "contents": [
    {
    "type": "text",
    "text": "{}".format(client.getProfile().displayName),
    "size": "xxs",
    "color": label_text_coloor["warna"],
    "align": "center"
    },
    {
    "type": "separator",
    "color": menu_border["warna"]
    },
    {
    "type": "box",
    "layout": "vertical",
    "contents": [
    {
    "type": "text",
    "text": label["label"],
    "size": label_text_size["ukuran"],
    "color": label_text_coloor["warna"],
    "align": "center"
    }
    ],
    "backgroundColor": label_bg_color["warna"]
    }
    ]
    }
    ],
    "position": "absolute",
    "cornerRadius": "4px",
    "offsetTop": "198px",
    "backgroundColor": "#000000",
    "offsetStart": "4px",
    "width": "150px",
    "borderWidth": "1px",
    "borderColor": menu_border["warna"]
    },
    {
    "type": "box",
    "layout": "vertical",
    "contents": [
    {
    "type": "text",
    "text": Zul,
    "size": menu_text_size["ukuran"],
    "color": menu_text["warna"],
    "wrap": True
    }
    ],
    "position": "absolute",
    "height": "150px",
    "offsetTop": "30px",
    "offsetStart": "5px"
    },
    {
    "type": "box",
    "layout": "horizontal",
    "contents": [
    {
    "type": "box",
    "layout": "vertical",
    "contents": [
    {
    "type": "image",
    "url": object_icon["img"],
    "size": "full",
    }
    ],
    "width": "20px",
    "height": "20px"
    },
    {
    "type": "separator",
    "color": menu_border["warna"]
    },
    {
    "type": "box",
    "layout": "vertical",
    "contents": [
    {
    "type": "text",
    "text": "𝑴 𝑬 𝑵 𝑼  𝑺 𝑬 𝑳 𝑭",
    "size": "xs",
    "color": label_text_coloor["warna"],
    "align": "center",
    "offsetTop": "1px"
    }
    ]
    },
    {
    "type": "separator",
    "color": menu_border["warna"]
    },
    {
    "type": "box",
    "layout": "vertical",
    "contents": [
    {
    "type": "image",
    "url": object_icon["img"],
    "size": "full"
    }
    ],
    "width": "20px",
    "height": "20px"
    }
    ],
    "position": "absolute",
    "offsetTop": "4px",
    "width": "150px",
    "borderWidth": "1px",
    "borderColor": menu_border["warna"],
    "cornerRadius": "5px",
    "offsetStart": "4px"
    }
    ],
    "paddingAll": "0px",
    "borderWidth": "1px",
    "borderColor": menu_border["warna"],
    "cornerRadius": "10px"
    }
    },
    {
    "type": "bubble",
    "size": "micro",
    "body": {
    "type": "box",
    "layout": "vertical",
    "contents": [
    {
    "type": "image",
    "url": menu_img["img"],
    "size": "full",
    "aspectMode": "cover",
    "aspectRatio": "2:3",
    "gravity": "top"
    },
    {
    "type": "box",
    "layout": "horizontal",
    "contents": [
    {
    "type": "box",
    "layout": "vertical",
    "contents": [
    {
    "type": "image",
    "url": "https://obs.line-scdn.net/{}".format(am.pictureStatus),
    "size": "full",
    "aspectMode": "cover"
    }
    ],
    "width": "33px",
    "height": "33px"
    },
    {
    "type": "separator",
    "color": menu_border["warna"]
    },
    {
    "type": "box",
    "layout": "vertical",
    "contents": [
    {
    "type": "text",
    "text": "{}".format(client.getProfile().displayName),
    "size": "xxs",
    "color": label_text_coloor["warna"],
    "align": "center"
    },
    {
    "type": "separator",
    "color": menu_border["warna"]
    },
    {
    "type": "box",
    "layout": "vertical",
    "contents": [
    {
    "type": "text",
    "text": label["label"],
    "size": label_text_size["ukuran"],
    "color": label_text_coloor["warna"],
    "align": "center"
    }
    ],
    "backgroundColor": label_bg_color["warna"]
    }
    ]
    }
    ],
    "position": "absolute",
    "cornerRadius": "4px",
    "offsetTop": "198px",
    "backgroundColor": "#000000",
    "offsetStart": "4px",
    "width": "150px",
    "borderWidth": "1px",
    "borderColor": menu_border["warna"]
    },
    {
    "type": "box",
    "layout": "vertical",
    "contents": [
    {
    "type": "text",
    "text": inces,
    "size": menu_text_size["ukuran"],
    "color": menu_text["warna"],
    "wrap": True
    }
    ],
    "position": "absolute",
    "height": "150px",
    "offsetTop": "30px",
    "offsetStart": "5px"
    },
    {
    "type": "box",
    "layout": "horizontal",
    "contents": [
    {
    "type": "box",
    "layout": "vertical",
    "contents": [
    {
    "type": "image",
    "url": object_icon["img"],
    "size": "full",
    }
    ],
    "width": "20px",
    "height": "20px"
    },
    {
    "type": "separator",
    "color": menu_border["warna"]
    },
    {
    "type": "box",
    "layout": "vertical",
    "contents": [
    {
    "type": "text",
    "text": "𝑴 𝑬 𝑵 𝑼  𝑺 𝑬 𝑳 𝑭",
    "size": "xs",
    "color": label_text_coloor["warna"],
    "align": "center",
    "offsetTop": "1px"
    }
    ]
    },
    {
    "type": "separator",
    "color": menu_border["warna"]
    },
    {
    "type": "box",
    "layout": "vertical",
    "contents": [
    {
    "type": "image",
    "url": object_icon["img"],
    "size": "full"
    }
    ],
    "width": "20px",
    "height": "20px"
    }
    ],
    "position": "absolute",
    "offsetTop": "4px",
    "width": "150px",
    "borderWidth": "1px",
    "borderColor": menu_border["warna"],
    "cornerRadius": "5px",
    "offsetStart": "4px"
    }
    ],
    "paddingAll": "0px",
    "borderWidth": "1px",
    "borderColor": menu_border["warna"],
    "cornerRadius": "10px"
    }
    }
    ]
    }
    }
    sendTemplate(to, data)
def am_page5(to, love, achink, Zul, inces, kecil):
    am = client.getContact(clientMID)
    tz = pytz.timezone("Asia/Jakarta")
    timeNow = datetime.now(tz=tz)
    timeHours = datetime.strftime(timeNow," (%H:%M)")
    data = {
    "type": "flex",
    "altText": temp_notif["temp"],
    "contents": {
    "type": "carousel",
    "contents": [
    {
    "type": "bubble",
    "size": "micro",
    "body": {
    "type": "box",
    "layout": "vertical",
    "contents": [
    {
    "type": "image",
    "url": menu_img["img"],
    "size": "full",
    "aspectMode": "cover",
    "aspectRatio": "2:3",
    "gravity": "top"
    },
    {
    "type": "box",
    "layout": "horizontal",
    "contents": [
    {
    "type": "box",
    "layout": "vertical",
    "contents": [
    {
    "type": "image",
    "url": "https://obs.line-scdn.net/{}".format(am.pictureStatus),
    "size": "full",
    "aspectMode": "cover"
    }
    ],
    "width": "33px",
    "height": "33px"
    },
    {
    "type": "separator",
    "color": menu_border["warna"]
    },
    {
    "type": "box",
    "layout": "vertical",
    "contents": [
    {
    "type": "text",
    "text": "{}".format(client.getProfile().displayName),
    "size": "xxs",
    "color": label_text_coloor["warna"],
    "align": "center"
    },
    {
    "type": "separator",
    "color": menu_border["warna"]
    },
    {
    "type": "box",
    "layout": "vertical",
    "contents": [
    {
    "type": "text",
    "text": label["label"],
    "size": label_text_size["ukuran"],
    "color": label_text_coloor["warna"],
    "align": "center"
    }
    ],
    "backgroundColor": label_bg_color["warna"]
    }
    ]
    }
    ],
    "position": "absolute",
    "cornerRadius": "4px",
    "offsetTop": "198px",
    "backgroundColor": "#000000",
    "offsetStart": "4px",
    "width": "150px",
    "borderWidth": "1px",
    "borderColor": menu_border["warna"]
    },
    {
    "type": "box",
    "layout": "vertical",
    "contents": [
    {
    "type": "text",
    "text": love,
    "size": menu_text_size["ukuran"],
    "color": menu_text["warna"],
    "wrap": True
    }
    ],
    "position": "absolute",
    "height": "150px",
    "offsetTop": "30px",
    "offsetStart": "5px"
    },
    {
    "type": "box",
    "layout": "horizontal",
    "contents": [
    {
    "type": "box",
    "layout": "vertical",
    "contents": [
    {
    "type": "image",
    "url": object_icon["img"],
    "size": "full",
    }
    ],
    "width": "20px",
    "height": "20px"
    },
    {
    "type": "separator",
    "color": menu_border["warna"]
    },
    {
    "type": "box",
    "layout": "vertical",
    "contents": [
    {
    "type": "text",
    "text": "𝑴 𝑬 𝑵 𝑼  𝑺 𝑬 𝑳 𝑭",
    "size": "xs",
    "color": label_text_coloor["warna"],
    "align": "center",
    "offsetTop": "1px"
    }
    ]
    },
    {
    "type": "separator",
    "color": menu_border["warna"]
    },
    {
    "type": "box",
    "layout": "vertical",
    "contents": [
    {
    "type": "image",
    "url": object_icon["img"],
    "size": "full"
    }
    ],
    "width": "20px",
    "height": "20px"
    }
    ],
    "position": "absolute",
    "offsetTop": "4px",
    "width": "150px",
    "borderWidth": "1px",
    "borderColor": menu_border["warna"],
    "cornerRadius": "5px",
    "offsetStart": "4px"
    }
    ],
    "paddingAll": "0px",
    "borderWidth": "1px",
    "borderColor": menu_border["warna"],
    "cornerRadius": "10px"
    }
    },
    {
    "type": "bubble",
    "size": "micro",
    "body": {
    "type": "box",
    "layout": "vertical",
    "contents": [
    {
    "type": "image",
    "url": menu_img["img"],
    "size": "full",
    "aspectMode": "cover",
    "aspectRatio": "2:3",
    "gravity": "top"
    },
    {
    "type": "box",
    "layout": "horizontal",
    "contents": [
    {
    "type": "box",
    "layout": "vertical",
    "contents": [
    {
    "type": "image",
    "url": "https://obs.line-scdn.net/{}".format(am.pictureStatus),
    "size": "full",
    "aspectMode": "cover"
    }
    ],
    "width": "33px",
    "height": "33px"
    },
    {
    "type": "separator",
    "color": menu_border["warna"]
    },
    {
    "type": "box",
    "layout": "vertical",
    "contents": [
    {
    "type": "text",
    "text": "{}".format(client.getProfile().displayName),
    "size": "xxs",
    "color": label_text_coloor["warna"],
    "align": "center"
    },
    {
    "type": "separator",
    "color": menu_border["warna"]
    },
    {
    "type": "box",
    "layout": "vertical",
    "contents": [
    {
    "type": "text",
    "text": label["label"],
    "size": label_text_size["ukuran"],
    "color": label_text_coloor["warna"],
    "align": "center"
    }
    ],
    "backgroundColor": label_bg_color["warna"]
    }
    ]
    }
    ],
    "position": "absolute",
    "cornerRadius": "4px",
    "offsetTop": "198px",
    "backgroundColor": "#000000",
    "offsetStart": "4px",
    "width": "150px",
    "borderWidth": "1px",
    "borderColor": menu_border["warna"]
    },
    {
    "type": "box",
    "layout": "vertical",
    "contents": [
    {
    "type": "text",
    "text": achink,
    "size": menu_text_size["ukuran"],
    "color": menu_text["warna"],
    "wrap": True
    }
    ],
    "position": "absolute",
    "height": "150px",
    "offsetTop": "30px",
    "offsetStart": "5px"
    },
    {
    "type": "box",
    "layout": "horizontal",
    "contents": [
    {
    "type": "box",
    "layout": "vertical",
    "contents": [
    {
    "type": "image",
    "url": object_icon["img"],
    "size": "full",
    }
    ],
    "width": "20px",
    "height": "20px"
    },
    {
    "type": "separator",
    "color": menu_border["warna"]
    },
    {
    "type": "box",
    "layout": "vertical",
    "contents": [
    {
    "type": "text",
    "text": "𝑴 𝑬 𝑵 𝑼  𝑺 𝑬 𝑳 𝑭",
    "size": "xs",
    "color": label_text_coloor["warna"],
    "align": "center",
    "offsetTop": "1px"
    }
    ]
    },
    {
    "type": "separator",
    "color": menu_border["warna"]
    },
    {
    "type": "box",
    "layout": "vertical",
    "contents": [
    {
    "type": "image",
    "url": object_icon["img"],
    "size": "full"
    }
    ],
    "width": "20px",
    "height": "20px"
    }
    ],
    "position": "absolute",
    "offsetTop": "4px",
    "width": "150px",
    "borderWidth": "1px",
    "borderColor": menu_border["warna"],
    "cornerRadius": "5px",
    "offsetStart": "4px"
    }
    ],
    "paddingAll": "0px",
    "borderWidth": "1px",
    "borderColor": menu_border["warna"],
    "cornerRadius": "10px"
    }
    },
    {
    "type": "bubble",
    "size": "micro",
    "body": {
    "type": "box",
    "layout": "vertical",
    "contents": [
    {
    "type": "image",
    "url": menu_img["img"],
    "size": "full",
    "aspectMode": "cover",
    "aspectRatio": "2:3",
    "gravity": "top"
    },
    {
    "type": "box",
    "layout": "horizontal",
    "contents": [
    {
    "type": "box",
    "layout": "vertical",
    "contents": [
    {
    "type": "image",
    "url": "https://obs.line-scdn.net/{}".format(am.pictureStatus),
    "size": "full",
    "aspectMode": "cover"
    }
    ],
    "width": "33px",
    "height": "33px"
    },
    {
    "type": "separator",
    "color": menu_border["warna"]
    },
    {
    "type": "box",
    "layout": "vertical",
    "contents": [
    {
    "type": "text",
    "text": "{}".format(client.getProfile().displayName),
    "size": "xxs",
    "color": label_text_coloor["warna"],
    "align": "center"
    },
    {
    "type": "separator",
    "color": menu_border["warna"]
    },
    {
    "type": "box",
    "layout": "vertical",
    "contents": [
    {
    "type": "text",
    "text": label["label"],
    "size": label_text_size["ukuran"],
    "color": label_text_coloor["warna"],
    "align": "center"
    }
    ],
    "backgroundColor": label_bg_color["warna"]
    }
    ]
    }
    ],
    "position": "absolute",
    "cornerRadius": "4px",
    "offsetTop": "198px",
    "backgroundColor": "#000000",
    "offsetStart": "4px",
    "width": "150px",
    "borderWidth": "1px",
    "borderColor": menu_border["warna"]
    },
    {
    "type": "box",
    "layout": "vertical",
    "contents": [
    {
    "type": "text",
    "text": Zul,
    "size": menu_text_size["ukuran"],
    "color": menu_text["warna"],
    "wrap": True
    }
    ],
    "position": "absolute",
    "height": "150px",
    "offsetTop": "30px",
    "offsetStart": "5px"
    },
    {
    "type": "box",
    "layout": "horizontal",
    "contents": [
    {
    "type": "box",
    "layout": "vertical",
    "contents": [
    {
    "type": "image",
    "url": object_icon["img"],
    "size": "full",
    }
    ],
    "width": "20px",
    "height": "20px"
    },
    {
    "type": "separator",
    "color": menu_border["warna"]
    },
    {
    "type": "box",
    "layout": "vertical",
    "contents": [
    {
    "type": "text",
    "text": "𝑴 𝑬 𝑵 𝑼  𝑺 𝑬 𝑳 𝑭",
    "size": "xs",
    "color": label_text_coloor["warna"],
    "align": "center",
    "offsetTop": "1px"
    }
    ]
    },
    {
    "type": "separator",
    "color": menu_border["warna"]
    },
    {
    "type": "box",
    "layout": "vertical",
    "contents": [
    {
    "type": "image",
    "url": object_icon["img"],
    "size": "full"
    }
    ],
    "width": "20px",
    "height": "20px"
    }
    ],
    "position": "absolute",
    "offsetTop": "4px",
    "width": "150px",
    "borderWidth": "1px",
    "borderColor": menu_border["warna"],
    "cornerRadius": "5px",
    "offsetStart": "4px"
    }
    ],
    "paddingAll": "0px",
    "borderWidth": "1px",
    "borderColor": menu_border["warna"],
    "cornerRadius": "10px"
    }
    },
    {
    "type": "bubble",
    "size": "micro",
    "body": {
    "type": "box",
    "layout": "vertical",
    "contents": [
    {
    "type": "image",
    "url": menu_img["img"],
    "size": "full",
    "aspectMode": "cover",
    "aspectRatio": "2:3",
    "gravity": "top"
    },
    {
    "type": "box",
    "layout": "horizontal",
    "contents": [
    {
    "type": "box",
    "layout": "vertical",
    "contents": [
    {
    "type": "image",
    "url": "https://obs.line-scdn.net/{}".format(am.pictureStatus),
    "size": "full",
    "aspectMode": "cover"
    }
    ],
    "width": "33px",
    "height": "33px"
    },
    {
    "type": "separator",
    "color": menu_border["warna"]
    },
    {
    "type": "box",
    "layout": "vertical",
    "contents": [
    {
    "type": "text",
    "text": "{}".format(client.getProfile().displayName),
    "size": "xxs",
    "color": label_text_coloor["warna"],
    "align": "center"
    },
    {
    "type": "separator",
    "color": menu_border["warna"]
    },
    {
    "type": "box",
    "layout": "vertical",
    "contents": [
    {
    "type": "text",
    "text": label["label"],
    "size": label_text_size["ukuran"],
    "color": label_text_coloor["warna"],
    "align": "center"
    }
    ],
    "backgroundColor": label_bg_color["warna"]
    }
    ]
    }
    ],
    "position": "absolute",
    "cornerRadius": "4px",
    "offsetTop": "198px",
    "backgroundColor": "#000000",
    "offsetStart": "4px",
    "width": "150px",
    "borderWidth": "1px",
    "borderColor": menu_border["warna"]
    },
    {
    "type": "box",
    "layout": "vertical",
    "contents": [
    {
    "type": "text",
    "text": inces,
    "size": menu_text_size["ukuran"],
    "color": menu_text["warna"],
    "wrap": True
    }
    ],
    "position": "absolute",
    "height": "150px",
    "offsetTop": "30px",
    "offsetStart": "5px"
    },
    {
    "type": "box",
    "layout": "horizontal",
    "contents": [
    {
    "type": "box",
    "layout": "vertical",
    "contents": [
    {
    "type": "image",
    "url": object_icon["img"],
    "size": "full",
    }
    ],
    "width": "20px",
    "height": "20px"
    },
    {
    "type": "separator",
    "color": menu_border["warna"]
    },
    {
    "type": "box",
    "layout": "vertical",
    "contents": [
    {
    "type": "text",
    "text": "𝑴 𝑬 𝑵 𝑼  𝑺 𝑬 𝑳 𝑭",
    "size": "xs",
    "color": label_text_coloor["warna"],
    "align": "center",
    "offsetTop": "1px"
    }
    ]
    },
    {
    "type": "separator",
    "color": menu_border["warna"]
    },
    {
    "type": "box",
    "layout": "vertical",
    "contents": [
    {
    "type": "image",
    "url": object_icon["img"],
    "size": "full"
    }
    ],
    "width": "20px",
    "height": "20px"
    }
    ],
    "position": "absolute",
    "offsetTop": "4px",
    "width": "150px",
    "borderWidth": "1px",
    "borderColor": menu_border["warna"],
    "cornerRadius": "5px",
    "offsetStart": "4px"
    }
    ],
    "paddingAll": "0px",
    "borderWidth": "1px",
    "borderColor": menu_border["warna"],
    "cornerRadius": "10px"
    }
    },
    {
    "type": "bubble",
    "size": "micro",
    "body": {
    "type": "box",
    "layout": "vertical",
    "contents": [
    {
    "type": "image",
    "url": menu_img["img"],
    "size": "full",
    "aspectMode": "cover",
    "aspectRatio": "2:3",
    "gravity": "top"
    },
    {
    "type": "box",
    "layout": "horizontal",
    "contents": [
    {
    "type": "box",
    "layout": "vertical",
    "contents": [
    {
    "type": "image",
    "url": "https://obs.line-scdn.net/{}".format(am.pictureStatus),
    "size": "full",
    "aspectMode": "cover"
    }
    ],
    "width": "33px",
    "height": "33px"
    },
    {
    "type": "separator",
    "color": menu_border["warna"]
    },
    {
    "type": "box",
    "layout": "vertical",
    "contents": [
    {
    "type": "text",
    "text": "{}".format(client.getProfile().displayName),
    "size": "xxs",
    "color": label_text_coloor["warna"],
    "align": "center"
    },
    {
    "type": "separator",
    "color": menu_border["warna"]
    },
    {
    "type": "box",
    "layout": "vertical",
    "contents": [
    {
    "type": "text",
    "text": label["label"],
    "size": label_text_size["ukuran"],
    "color": label_text_coloor["warna"],
    "align": "center"
    }
    ],
    "backgroundColor": label_bg_color["warna"]
    }
    ]
    }
    ],
    "position": "absolute",
    "cornerRadius": "4px",
    "offsetTop": "198px",
    "backgroundColor": "#000000",
    "offsetStart": "4px",
    "width": "150px",
    "borderWidth": "1px",
    "borderColor": menu_border["warna"]
    },
    {
    "type": "box",
    "layout": "vertical",
    "contents": [
    {
    "type": "text",
    "text": kecil,
    "size": menu_text_size["ukuran"],
    "color": menu_text["warna"],
    "wrap": True
    }
    ],
    "position": "absolute",
    "height": "150px",
    "offsetTop": "30px",
    "offsetStart": "5px"
    },
    {
    "type": "box",
    "layout": "horizontal",
    "contents": [
    {
    "type": "box",
    "layout": "vertical",
    "contents": [
    {
    "type": "image",
    "url": object_icon["img"],
    "size": "full",
    }
    ],
    "width": "20px",
    "height": "20px"
    },
    {
    "type": "separator",
    "color": menu_border["warna"]
    },
    {
    "type": "box",
    "layout": "vertical",
    "contents": [
    {
    "type": "text",
    "text": "𝑴 𝑬 𝑵 𝑼  𝑺 𝑬 𝑳 𝑭",
    "size": "xs",
    "color": label_text_coloor["warna"],
    "align": "center",
    "offsetTop": "1px"
    }
    ]
    },
    {
    "type": "separator",
    "color": menu_border["warna"]
    },
    {
    "type": "box",
    "layout": "vertical",
    "contents": [
    {
    "type": "image",
    "url": object_icon["img"],
    "size": "full"
    }
    ],
    "width": "20px",
    "height": "20px"
    }
    ],
    "position": "absolute",
    "offsetTop": "4px",
    "width": "150px",
    "borderWidth": "1px",
    "borderColor": menu_border["warna"],
    "cornerRadius": "5px",
    "offsetStart": "4px"
    }
    ],
    "paddingAll": "0px",
    "borderWidth": "1px",
    "borderColor": menu_border["warna"],
    "cornerRadius": "10px"
    }
    }
    ]
    }
    }
    sendTemplate(to, data)
def Zul_send(to, love):
    am = client.getContact(clientMID)
    tz = pytz.timezone("Asia/Jakarta")
    timeNow = datetime.now(tz=tz)
    timeHours = datetime.strftime(timeNow," (%H:%M)")
    data = {
    "type": "flex",
    "altText": temp_notif["temp"],
    "contents": {
    "type": "carousel",
    "contents": [
    {
    "type": "bubble",
    "size": "micro",
    "body": {
    "type": "box",
    "layout": "vertical",
    "contents": [
    {
    "type": "box",
    "layout": "vertical",
    "contents": [
    {
    "type": "image",
    "url": "https://s2.bukalapak.com/img/2305646003/w-1000/Bendera_Merah_Putih_120x180.png",
    "size": "xxl",
    "aspectMode": "cover"
    }
    ],
    "width": "160px",
    "height": "25px"
    },
    {
    "type": "separator",
    "color": "#48D1CC"
    },
    {
    "type": "box",
    "layout": "horizontal",
    "contents": [
    {
    "type": "box",
    "layout": "vertical",
    "contents": [
    {
    "type": "text",
    "text": datetime.strftime(timeNow,'%H:%M:%S'),
    "size": "xxs",
    "color": "#ffffff",
    "align": "center"
    }
    ]
    },
    {
    "type": "separator",
    "color": "#48D1CC"
    },
    {
    "type": "box",
    "layout": "vertical",
    "contents": [
    {
    "type": "text",
    "text": datetime.strftime(timeNow,'%d-%m-%Y'),
    "size": "xxs",
    "color": "#ffffff",
    "align": "center"
    }
    ]
    }
    ],
    "backgroundColor": "#5F9EA0"
    },
    {
    "type": "separator",
    "color": "#48D1CC"
    },
    {
    "type": "box",
    "layout": "vertical",
    "contents": [
    {
    "type": "text",
    "text": love,
    "size": "xs",
    "wrap": True,
    "offsetStart": "5px",
    "color": "#48D1CC"
    }
    ],
    "backgroundColor": "#FFFAF0"
    },
    {
    "type": "separator",
    "color": "#48D1CC"
    },
    {
    "type": "box",
    "layout": "vertical",
    "contents": [
    {
    "type": "text",
    "text": "TEAM TERMUX V 13",
    "size": "sm",
    "color": "#FFFFFF",
    "align": "center"
    }
    ],
    "backgroundColor": "#5F9EA0",
    "action": {
    "type": "uri",
    "label": "action",
    "uri": "line://nv/profilePopup/mid=u42880eb65b2da1eb8fd3b7a9caa4ccc3"
    }
    },
    {
    "type": "box",
    "layout": "vertical",
    "contents": [
    {
    "type": "text",
    "text": "𝑰 𝑵 𝑫 𝑶 𝑵 𝑬 𝑺 𝑰 𝑨",
    "align": "center",
    "color": "#008000"
    }
    ],
    "position": "absolute",
    "width": "150px",
    "offsetStart": "3px",
    "offsetTop": "3px"
    }
    ],
    "paddingAll": "0px",
    "backgroundColor": "#DC143C",
    "borderWidth": "2px",
    "borderColor": "#48D1CC",
    "cornerRadius": "10px"
    }
    }
    ]
    }
    }
    sendTemplate(to, data)

def siderMembers(to, mid):
    try:
        arrData = ""
        textx = "".format(str(len(mid)))
        arr = []
        no = 1
        num = 2
        for i in mid:
            mention = "@x\n"
            slen = str(len(textx))
            elen = str(len(textx) + len(mention) - 1)
            arrData = {'S':slen, 'E':elen, 'M':i}
            arr.append(arrData)
            textx += mention+Am["sidertext"]
            if no < len(mid):
                no += 1
                textx += "%i. " % (num)
                num=(num+1)
            else:
                try:
                    no = "\n╚══[ {} ]".format(str(client.getGroup(to).name))
                except:
                    no = "\n╚══[ Success ]"
#        client.sendMessage(to, textx, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
    except Exception as error:
        client.sendMessage(to, "[ INFO ] Error :\n" + str(error))
#================================================
def logError(text):
    client.log("ERROR 404 !\n" + str(text))
    tz = pytz.timezone("Asia/Jakarta")
    timeNow = datetime.now(tz=tz)
    timeHours = datetime.strftime(timeNow,"(%H:%M)")
    day = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday","Friday", "Saturday"]
    hari = ["Minggu", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu"]
    bulan = ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"]
    inihari = datetime.now(tz=tz)
    hr = inihari.strftime('%A')
    bln = inihari.strftime('%m')
    for i in range(len(day)):
        if hr == day[i]: hasil = hari[i]
    for k in range(0, len(bulan)):
        if bln == str(k): bln = bulan[k-1]
    time = hasil + ", " + inihari.strftime('%d') + " - " + bln + " - " + inihari.strftime('%Y') + " | " + inihari.strftime('%H:%M:%S')
    with open("errorLog.txt","a") as error:
        error.write("\n[%s] %s" % (str(time), text))

def cloneProfile(mid):
    contact = client.getContact(mid)
    if contact.videoProfile == None:
        client.cloneContactProfile(mid)
    else:
        profile = client.getProfile()
        profile.displayName, profile.statusMessage = contact.displayName, contact.statusMessage
        client.updateProfile(profile)
        pict = client.downloadFileURL('http://dl.profile.line-cdn.net/' + contact.pictureStatus, saveAs="tmp/pict.bin")
        vids = client.downloadFileURL( 'http://dl.profile.line-cdn.net/' + contact.pictureStatus + '/vp', saveAs="tmp/video.bin")
        changeVideoAndPictureProfile(pict, vids)
    coverId = client.getProfileDetail(mid)['result']['objectId']
    client.updateProfileCoverById(coverId)

def backupProfile():
    profile = client.getContact(clientMID)
    settings['myProfile']['displayName'] = profile.displayName
    settings['myProfile']['pictureStatus'] = profile.pictureStatus
    settings['myProfile']['statusMessage'] = profile.statusMessage
    settings['myProfile']['videoProfile'] = profile.videoProfile
    coverId = client.getProfileDetail()['result']['objectId']
    settings['myProfile']['coverId'] = str(coverId)

def restoreProfile():
    profile = client.getProfile()
    profile.displayName = settings['myProfile']['displayName']
    profile.statusMessage = settings['myProfile']['statusMessage']
    if settings['myProfile']['videoProfile'] == None:
        profile.pictureStatus = settings['myProfile']['pictureStatus']
        client.updateProfileAttribute(8, profile.pictureStatus)
        client.updateProfile(profile)
    else:
        client.updateProfile(profile)
        pict = client.downloadFileURL('http://dl.profile.line-cdn.net/' + settings['myProfile']['pictureStatus'], saveAs="tmp/pict.bin")
        vids = client.downloadFileURL( 'http://dl.profile.line-cdn.net/' + settings['myProfile']['pictureStatus'] + '/vp', saveAs="tmp/video.bin")
        changeVideoAndPictureProfile(pict, vids)
    coverId = settings['myProfile']['coverId']
    client.updateProfileCoverById(coverId)
#======================================================
def command(text):
    pesan = text.lower()
    if settings["setKey"] == True:
        if pesan.startswith(settings["keyCommand"]):
            cmd = pesan.replace(settings["keyCommand"],"")
        else:
            cmd = "Undefined command"
    else:
        cmd = text.lower()
    return cmd
    
def sendPhone(to, mid):
    a = client.getContact(mid)
    contentMetadata = {
        'vCard': 'BEGIN:VCARD\r\nVERSION:3.0\r\nPRODID:ANDROID 8.13.3 Android OS 4.4.4\r\nFN:\\'+a.displayName+'\nTEL;TYPE=mobile:'+a.statusMessage+'\r\nN:?;\\,\r\nEND:VCARD\r\n',
        'displayName': a.displayName
    }
    client.sendMessage(to, '', contentMetadata, 13)

def NoteCreate(to,pesan,msg):
    h = []
    s = []
    if pesan == 'mentionnote':
        sakui = client.getProfile()
        group = client.getGroup(msg.to);nama = [contact.mid+'||//{}'.format(contact.displayName) for contact in group.members];nama.remove(sakui.mid+'||//{}'.format(sakui.displayName))
        data = nama
        k = len(data)//20
        for aa in range(k+1):
            nos = 0
            if aa == 0:dd = '╭「 Mention Note 」─';no=aa
            else:dd = '├「 Mention Note 」─';no=aa*20
            msgas = dd
            for i in data[aa*20 : (aa+1)*20]:
                no+=1
                if no == len(data):msgas+='\n╰{}. @'.format(no)
                else:msgas+='\n│{}. @'.format(no)
            msgas = msgas
            for i in data[aa*20 : (aa+1)*20]:
                gg = []
                dd = ''
                for ss in msgas:
                    if ss == '@':
                        dd += str(ss)
                        gg.append(dd.index('@'))
                        dd = dd.replace('@',' ')
                    else:
                        dd += str(ss)
                s.append({'type': "RECALL", 'start': gg[nos], 'end': gg[nos]+1, 'mid': str(i.split('||//')[0])})
                nos +=1
            h = client.createPostGroup(msgas,msg.to,holdingTime=None,textMeta=s)
    else:
        pesan = pesan.replace('create note ','')
        if msg.contentMetadata is not None and 'MENTION' in msg.contentMetadata:
            mention = ast.literal_eval(msg.contentMetadata['MENTION'])
            mentionees = mention['MENTIONEES']
            no = 0
            for mention in mentionees:
                ask = no
                nama = str(client.getContact(mention["M"]).displayName)
                h.append(str(pesan.replace('create note @{}'.format(nama),'')))
                for b in h:
                    pesan = str(b)
                gg = []
                dd = ''
                for ss in pesan:
                    if ss == '@':
                        dd += str(ss)
                        gg.append(dd.index('@'))
                        dd = dd.replace('@',' ')
                    else:
                        dd += str(ss)
                s.append({'type': "RECALL", 'start': gg[no], 'end': gg[no]+1, 'mid': str(mention["M"])})
                no +=1
        h = client.createPostGroup(pesan,to,holdingTime=None,textMeta=s)
def albumNamaGrup(to,wait,pesan):
    ha = client.getGroupAlbum(to)
    if pesan == 'get album':
        a = [a['title'] for a in ha['result']['items']];c=[a['photoCount'] for a in ha['result']['items']]
        b = '╭「 Album Group 」'
        no=0
        for i in range(len(a)):
            no+=1
            if no == len(a):b+= '\n╰{}. {} | {}'.format(no,a[i],c[i])
            else:b+= '\n│{}. {} | {}'.format(no,a[i],c[i])
        client.sendMessage(to,"{}".format(b))
    if pesan.startswith('get album '):
        try:
            a = pesan.split(' ')
            selection = MySplit(a[3],range(1,len(ha['result']['items'])+1))
            print(selection)
            for i in selection.parse():
                try:
                    b = random.randint(0,999)
                    s = client.getImageGroupAlbum(to,ha['result']['items'][int(a[2])-1]['id'], ha['result']['items'][int(a[2])-1]['recentPhotos'][i-1]['oid'], returnAs='path', saveAs='{}.png'.format(b))
                    print(s)
                    client.sendImage(to,'{}.png'.format(b))
                    os.remove('{}.png'.format(b))
                except:continue
        except Exception as e:print(e)
    else:
        a = pesan.split(' ')
        if len(a) == 5:
            wait["Images"]['anu']=ha['result']['items'][int(a[3])-1]['id']
            wait['ChangeGDP'] = True
            client.sendMessage(to," 「 Album 」\nSend a Picture for add to album")
#=====================================================================
#=====================================================================
def removeCmd(cmd, text):
	key = settings["keyCommand"]
	if settings["setKey"] == False: key = ''
	rmv = len(key + cmd) + 1
	return text[rmv:]
#=====================================================================
def cytmp4(url):
    import pafy
    vid = pafy.new(url,basic=False)
    result = vid.streams[-1]
    return result.url

def cytmp3(url):
    import pafy
    vid = pafy.new(url,basic=False)
    result = vid.audiostreams[-1]
    return result.url
#=====================================================================
def virus():
    am = """
    ❌.👁️.★.★.★.👁️.❌.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.👿.👿.👿
    ❌.👁️.★.★.★.👁️.❌.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.☆.👿.👿.👿.
    ❌.👁️.★.★.★.👁️.❌.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.☆.👿.👿.👿.
    ❌.👁️.★.★.★.👁️.❌.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.☆.👿.👿.👿.
"""
    return am
#=====================================================================
def viruspm():
    am1 = """Assalamualaikum
 
 
               🌟
             */•|
         */•    |   
        *(.•__)    
          (💟) 
          (💟)  
          (💟)  
          (💟)     
    /|    (💟)      
  /#|    (💟)      /\    
(🌟(  . (💟),_/🌟|     
 \💀(  .(💟). 💀 /        
  \🌟)&__.  🌟(             
   )💀& __   💀 \
  /🌟&&___   🌟\
 (💀(&&&__    💀|
  \ 🌟 💕💕  🌟 /
     "+,_💀💀_,+"                  
😝😝😝😝😝😝😝😝














































    ?.???.?.?.?.???.?.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.??.??.??
    ?.???.?.?.?.???.?.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.?.??.??.??.
    ?.???.?.?.?.???.?.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.?.??.??.??.
    ?.???.?.?.?.???.?.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.?.??.??.??.Assalamualaikum













































    ?.???.?.?.?.???.?.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0…
"""
    return am1
#=====================================================================
def kibar():
    helpMessage8 = """
    ━━━━━🔰━━━━━━🔰━━━━━━━
          🔰━━━━━━🔰━━━━━━━🔰
         ╔╦╦╦═╦╗╔═╦═╦══╦═╗
         ║║║║═╣║║╔╣║║║║║═╣
         ║║║║═╣╚╣╚╣║║║║║═╣
         ╚══╩═╩═╩═╩═╩╩╩╩═╝
         🔰 ━━━━━━🔰━━━━━━━🔰
━━━𝑾𝑬 𝑪𝑶𝑴𝑬 𝑻𝑶 𝑪𝑳𝑬𝑨𝑵 𝒀𝑶𝑼𝑹 𝑹𝑶𝑶𝑴━━━
━━━━𝑷𝑶𝑹𝑵𝑶𝑮𝑹𝑨𝑷𝒀 𝑨𝒏𝒅 𝑮𝑨𝑴𝑳𝑰𝑵𝑮━━━━
╭━━━━━🔰━━━━━━🔰━━━━━━━
╰╮┏━┳┳┳┓  ┏┳┳┳┳┳┓  ┏┳┳┳┳┳┓
┏┻╋━╋┻┻┫  ┣┻┻┻┻┻┫  ┣┻┻┻┻┻┫
┃HALLO▪┃ ◾KAMI DATANG LAGI   ▪┃
┗ⓞ━━━ⓞ┻━┻ⓞ━━ⓞ┻━┻ⓞ━━ⓞ╯
UNTUK MENGGUSUR ROOM KALIAN
.        (҂`_´)
         <,︻╦̵̵̿╤━ ҉     ~  •
█۞███████]▄▄▄▄▄▄▄▄▄▄▃ ●●●
▂▄▅█████████▅▄▃▂…
[███████████████████]
◥⊙▲⊙▲⊙▲⊙▲⊙▲⊙▲⊙
╔═╦═╗══╗═╦╗══╗══╗══╗═╗
║║║║║║║╝║║║╔═╣╔═╣║║╝╬║
║║║║║║║╗║║║╚╗║╚╗║║║╗╗╣
╚╩═╩╝══╝╩═╝══╝══╝══╝╩╝
━━━━━━━━━━━━━━━━━━━━━━━
.        (҂`_´)
         <,︻╦̵̵̿╤━ ҉     ~  •
█۞███████]▄▄▄▄▄▄▄▄▄▄▃ ●●●
▂▄▅█████████▅▄▃▂…
[███████████████████]
◥⊙▲⊙▲⊙▲⊙▲⊙▲⊙▲⊙
╔═╦═╗══╗═╦╗══╗══╗══╗═╗
║║║║║║║╝║║║╔═╣╔═╣║║╝╬║
║║║║║║║╗║║║╚╗║╚╗║║║╗╗╣
╚╩═╩╝══╝╩═╝══╝══╝══╝╩╝
━━━━━━━━━━━━━━━━━━━━━━━
   ▂ ▄ ▅ ▆ ▇ █ 𝙖𝙨𝙨𝙖𝙨𝙞𝙣𝙩 𝙨𝙦𝙪𝙖𝙙 █ ▇ ▆ ▅ ▄ ▂ 
             𝑾𝑬 𝑪𝑶𝑴𝑬 𝑻𝑶 𝑪𝑳𝑬𝑨𝑵 𝒀𝑶𝑼𝑹 𝑹𝑶𝑶𝑴
                 𝑷𝑶𝑹𝑵𝑶𝑮𝑹𝑨𝑷𝒀 𝑨𝒏𝒅 𝑮𝑨𝑴𝑳𝑰𝑵𝑮
━━━━━━━━━━━━━━━━━━━━━━━
           ━━━━━━━━━━━━━━━━━
			╔══╗╔═╗╔══╗╔═╦═╗
		    ╚╗╔╝║╦╝║╔╗║║║║║║
		       ║║   ║╩╗║╠╣║║║║║║
			   ╚╝   ╚═╝╚╝╚╝╚╩═╩╝
			━━━━━━━━━━━━━━━━━
━━━━━━━━━━━━━━━━━━━━
   ▂ ▄ ▅ ▆ ▇ █𝙖𝙨𝙨𝙖𝙨𝙞𝙣𝙩 𝙨𝙦𝙪𝙖𝙙█ ▇ ▆ ▅ ▄ ▂ 
            ............/´¯/).......... (\¯`\.....
            ........../….//............\\\...\......
            ........./….//...............\\\...\......
            ......./´¯/..../´¯\......../¯ `\....¯ `\.....
            .././.../..../..../.|_.._|.\....\....\....\. .
            (.(....(....(..../.)..)..(..(. \....)....)....).)
            .\…………….\/…/….\....\/……………./
            ..\…………….. /……..\……………..…/
            ….\…………..(………...)……………../
━━━━━━━━━━━━━━━━━━━━━
   ▂ ▄ ▅ ▆ ▇ █ 𝙖𝙨𝙨𝙖𝙨𝙞𝙣𝙩 𝙨𝙦𝙪𝙖𝙙 █ ▇ ▆ ▅ ▄ ▂ 
             𝑾𝑬 𝑪𝑶𝑴𝑬 𝑻𝑶 𝑪𝑳𝑬𝑨𝑵 𝒀𝑶𝑼𝑹 𝑹𝑶𝑶𝑴
                 𝑷𝑶𝑹𝑵𝑶𝑮𝑹𝑨𝑷𝒀 𝑨𝒏𝒅 𝑮𝑨𝑴𝑳𝑰𝑵𝑮
            ━━━━━━━━━━━━━━━━━
            ━━━━━━━━━━━━━━━━━

            ............/´¯/).......... (\¯`\.....
            ........../….//............\\\...\......
            ........./….//...............\\\...\......
            ......./´¯/..../´¯\......../¯ `\....¯ `\.....
            .././.../..../..../.|_.._|.\....\....\....\. .
            (.(....(....(..../.)..)..(..(. \....)....)....).)
            .\…………….\/…/….\....\/……………./
            ..\…………….. /……..\……………..…/
            ….\…………..(………...)……………../
			━━━━━━━━━━━━━━━━━
   ▂ ▄ ▅ ▆ ▇ █ 𝙖𝙨𝙨𝙖𝙨𝙞𝙣𝙩 𝙨𝙦𝙪𝙖𝙙 █ ▇ ▆ ▅ ▄ ▂ 
             𝑾𝑬 𝑪𝑶𝑴𝑬 𝑻𝑶 𝑪𝑳𝑬𝑨𝑵 𝒀𝑶𝑼𝑹 ??𝑶𝑶𝑴
                 𝑷𝑶𝑹𝑵𝑶𝑮𝑹𝑨𝑷𝒀 𝑨??𝒅 𝑮𝑨𝑴𝑳𝑰𝑵𝑮
             ━━━━━━━━━━━━━━━━━
   ▂ ▄ ▅ ▆ ▇ █𝙖𝙨𝙨𝙖𝙨𝙞𝙣𝙩 𝙨𝙦𝙪𝙖𝙙█ ▇ ▆ ▅ ▄ ▂ 
🔰 🔰 🔰 🔰 ┏━┳┳┳━┳┳┓🔰 🔰 🔰 🔰
?? 🔰 🔰 🔰 ┃━┫┃┃┏┫━┫┏┓🔰 🔰 🔰 🔰
🔰 🔰 🔰 🔰 ┃┏┫┃┃┗┫┃┃┃┃🔰 🔰 🔰 🔰
🔰 🔰 🔰 🔰 ┗┛┗━┻━┻┻┛┃┃🔰 🔰 🔰 🔰
🔰 🔰 🔰 🔰 ┏┳┳━┳┳┳┓┏┫┣┳┓🔰 🔰 🔰 
🔰 🔰 🔰 🔰 ┃┃┃┃┃┃┃┃┣┻┫┃┃🔰 🔰 🔰 
🔰 🔰 🔰 🔰 ┣┓┃┃┃┃┣┫┃┏┻┻┫🔰 🔰 🔰 
🔰 🔰 🔰 🔰 ┗━┻━┻━┻┫   🔰 🔰 🔰 🔰
   ▂ ▄ ▅ ▆ ▇ █𝙖𝙨𝙨𝙖𝙨𝙞𝙣𝙩 𝙨𝙦𝙪𝙖𝙙█ ▇ ▆ ▅ ▄ ▂ 
━━━━━━━━━━━━━━━━━━━━━━━━━ """
    return helpMessage8
#=====================================================================
#async def clientBot(op):
def clientBot(op):
    global time
    global ast
    global groupParam
    ajsMid = AM_backup["antijs"]
    Bots = [clientMID,ajsMid]
    try:
        if settings["restartPoint"] != None:
            client.sendMessage(settings["restartPoint"], 'Activated♪')
            settings["restartPoint"] = None
        if op.type == 0:
            return
    #================================================================================

        if op.type == 5:
            print ("[ 5 ]  ADA YANG NGE ADD")
            if AM_SAKLAR["autoadd"] == True:
            	am = AM_message["autoaddmessage"]
            	client.sendMessage(op.param1, am)

        if op.type in [15,128]:
            if AM_SAKLAR["rleave"] == True:
                contact = client.getContact(op.param2)
                ginfo = client.getGroup(op.param1)
                cover = client.getProfileCoverURL(op.param2)
                aa = client.getContact(clientMID)
                tz = pytz.timezone("Asia/Jakarta")
                timeNow = datetime.now(tz=tz)
                timeHours = datetime.strftime(timeNow," (%H:%M)")
                name = contact.displayName
                pp = contact.pictureStatus
                e = AM_message["leave"]
                data = {"type": "flex","altText": "TEAM TERMUX V 13","contents":{"type": "carousel","contents": [{"type": "bubble","size": "micro","body": {"type": "box","layout": "vertical","contents": [{"type": "box","layout": "vertical","contents": [{"type": "text","text": "𝑮𝑶𝑶𝑫𝑩𝒀𝑬","size": "xs","color": "#00FF00","align": "center"}],"backgroundColor": "#000000"},{"type": "separator","color": "#A52A2A"},{"type": "box","layout": "vertical","contents": [{"type": "image","url": cover,"size": "full","aspectMode": "cover"}]},{"type": "separator","color": "#A52A2A"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": name,"size": "xs","color": "#00FF00","align": "center"}],"backgroundColor": "#000000"},{"type": "separator","color": "#A52A2A"},{"type": "box","layout": "vertical","contents": [{"type": "box","layout": "vertical","contents": [{"type": "text","text": e,"color": "#00FF00","size": "xxs","wrap": True,"align": "center"}],"backgroundColor": "#A52A2A"}]},{"type": "separator","color": "#A52A2A"},{"type": "box","layout": "horizontal","contents": [{"type": "box","layout": "vertical","contents": [{"type": "text","text": datetime.strftime(timeNow,'%H:%M:%S'),"size": "xs","color": "#00FF00","align": "center"}]},{"type": "separator","color": "#A52A2A"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": datetime.strftime(timeNow,'%d-%m-%Y'),"size": "xs","color": "#00FF00","align": "center"}]}],"backgroundColor": "#000000"},{"type": "box","layout": "vertical","contents": [{"type": "image","url": "https://profile.line-scdn.net/" + str(pp),"size": "full","aspectMode": "cover"}],"position": "absolute","offsetTop": "122px","width": "50px","height": "50px","cornerRadius": "100px","borderColor": "#00FF00","borderWidth": "1px","offsetStart": "5px"}],"paddingAll": "0px","backgroundColor": "#A52A2A","borderWidth": "1px","borderColor": "#A52A2A","cornerRadius": "10px"}}]}}
                sendTemplate(op.param1, data)
        if op.type == 5:
            print ("[ 5 ] NOTIFIED AUTO BLOCK CONTACT")
            if AM_SAKLAR["autoblock"] == True:
                am = AM_message["block"]
                client.blockContact(op.param1)
                client.sendMessage(op.param1, am)
                data={"type":"flex",
              "altText":"TEAM TERMUX V 13",
              "contents":
              {
              "type": "bubble",
              "size": "kilo",
              "body": {
              "type": "box",
              "layout": "vertical",
              "contents": [
              {
              "type": "text",
              "text": "\"THANKS FOR ADD ME\"",
              "weight": "bold",
              "color": "#FF0000",
              "size": "lg",
              "align": "center"
              },
              {
              "type": "separator",
              "margin": "xs",
              "color": "#FFD700"
              },
              {
              "type": "box",
              "layout": "vertical",
              "margin": "xs",
              "spacing": "xs",
              "contents": [
              {
              "type": "box",
              "layout": "horizontal",
              "contents": [
              {
              "type": "text",
              "text": AM_message["block"],
              "size": "xs",
              "color": "#00FFFF",
              "flex": 0,
              "wrap": True,
              "style": "normal"
              }
              ]
              },
              {
              "type": "separator",
              "margin": "xs",
              "color": "#FFD700"
              },
              {
              "type": "box",
              "layout": "horizontal",
              "margin": "xs",
              "contents": [
              {
              "type": "text",
              "text": "𝑼𝑺𝑬𝑹 𝑺𝑩",
              "size": "xxs",
              "color": "#FFFFFF"
              },
              {
              "type": "text",
              "text": "Klick",
              "size": "xs",
              "color": "#00FF00",
              "align": "end",
              "action": {
              "type": "uri",
              "label": "action",
              "uri": "line://nv/profilePopup/mid=u42880eb65b2da1eb8fd3b7a9caa4ccc3"
              }
              }
              ],
              "spacing": "xs"
              },
              {
              "type": "box",
              "layout": "horizontal",
              "contents": [
              {
              "type": "text",
              "text": "𝑶 𝑭 𝑭 𝑰 𝑪 𝑰 𝑨 𝑳",
              "size": "xxs",
              "color": "#FFFFFF"
              },
              {
              "type": "text",
              "text": "Klick",
              "size": "xs",
              "color": "#00FF00",
              "align": "end",
              "action": {
              "type": "uri",
              "label": "action",
              "uri": "line://nv/profilePopup/mid=u42880eb65b2da1eb8fd3b7a9caa4ccc3"
              }
              }
              ],
              "margin": "xs",
              "spacing": "xs"
              },
              {
              "type": "box",
              "layout": "horizontal",
              "contents": [
              {
              "type": "text",
              "text": "𝑩𝑶𝑻𝑺 𝑪𝑯𝑨𝑻",
              "size": "xxs",
              "color": "#FFFFFF"
              },
              {
              "type": "text",
              "text": "Klick",
              "size": "xs",
              "color": "#00FF00",
              "align": "end",
              "action": {
              "type": "uri",
              "label": "action",
              "uri": "line://nv/profilePopup/mid=u42880eb65b2da1eb8fd3b7a9caa4ccc3"
              }
              }
              ],
              "spacing": "xs",
              "margin": "xs"
              },
              {
              "type": "box",
              "layout": "horizontal",
              "contents": [
              {
              "type": "text",
              "text": "𝒀 𝑶 𝑼 𝑻 𝑼 𝑩 𝙀",
              "size": "xxs",
              "color": "#FFFFFF"
              },
              {
              "type": "text",
              "text": "Klick",
              "size": "xs",
              "color": "#00FF00",
              "align": "end",
              "action": {
              "type": "uri",
              "label": "action",
              "uri": "https://i.ibb.co/KbfDFN1/1657636839741.jpg"
              }
              }
              ],
              "spacing": "xs",
              "margin": "xs"
              },
              {
              "type": "box",
              "layout": "horizontal",
              "contents": [
              {
              "type": "text",
              "text": "𝑺𝑻𝑨𝑭𝑭 𝑳𝑶𝑮𝑰𝑵",
              "size": "xs",
              "color": "#FFFFFF",
              "align": "center"
              }
              ],
              "backgroundColor": "#964B00",
              "borderWidth": "1px",
              "borderColor": "#FFD700",
              "cornerRadius": "5px",
              "spacing": "xs",
              "margin": "xs"
              },
              {
              "type": "box",
              "layout": "horizontal",
              "contents": [
              {
              "type": "text",
              "text": "Zul",
              "size": "xs",
              "color": "#FF7F00"
              },
              {
              "type": "text",
              "text": "𝑨𝒅𝒅 𝑭𝒐𝒓 𝑳𝒐𝒈𝒊𝒏",
              "align": "end",
              "size": "xs",
              "color": "#FF0000",
              "action": {
              "type": "uri",
              "label": "action",
              "uri": "line://nv/profilePopup/mid=u42880eb65b2da1eb8fd3b7a9caa4ccc3"
              }
              }
              ]
              },
              {
              "type": "box",
              "layout": "horizontal",
              "contents": [
              {
              "type": "text",
              "text": "𝑲𝑯𝑨𝒁𝑼𝑴𝑰",
              "size": "xs",
              "color": "#FF7F00"
              },
              {
              "type": "text",
              "text": "Add for login",
              "size": "xs",
              "align": "end",
              "color": "#FF0000",
              "action": {
              "type": "uri",
              "label": "action",
              "uri": "line://nv/profilePopup/mid=u42880eb65b2da1eb8fd3b7a9caa4ccc3"
              }
              }
              ]
              }
              ]
              },
              {
              "type": "separator",
              "margin": "xs",
              "color": "#FFD700"
              },
              {
              "type": "box",
              "layout": "horizontal",
              "margin": "md",
              "contents": [
              {
              "type": "text",
              "text": "𝑪𝑹𝑬𝑨𝑻𝑶𝑹",
              "size": "xs",
              "color": "#ffffff",
              "flex": 0,
              "offsetTop": "1px",
              "align": "start"
              },
              {
              "type": "text",
              "text": "𝑰𝑵𝑻𝑰𝑨𝑳𝑺~𝑨",
              "color": "#ffffff",
              "size": "xs",
              "align": "end",
              "offsetTop": "1px",
              "action": {
              "type": "uri",
              "label": "action",
              "uri": "line://nv/profilePopup/mid=u42880eb65b2da1eb8fd3b7a9caa4ccc3"
              }
              }
              ]
              }
              ],
              "borderWidth": "2px",
              "cornerRadius": "10px",
              "borderColor": "#FFD700",
              "backgroundColor": "#000000"
              },
              "styles": {
              "footer": {
              "separator": True
              }
              }
              }
              }
            sendTemplate(op.param1, data)
            print ("[ 5 ] AUTO BLOCK")
    #================================================================================
        if op.type == 13 or op.type == 124:
            if clientMID in op.param3:
                if AM_SAKLAR["autoleave"] == True:
                    if op.param2 not in creator and op.param2 not in AM["wl"]:
                        client.acceptGroupInvitation(op.param1)
                        ginfo = client.getGroup(op.param1)
                        client.sendMessage(op.param1,"Maaf Autoleave kak ಠ_ಠ")
                        client.leaveGroup(op.param1)
                    else:
                        client.acceptGroupInvitation(op.param1)
            if AM_SAKLAR["autojoin"] == True:
              if op.param2 not in Banlist["blacklist"]:
                  client.acceptGroupInvitation(op.param1)
#===========================[PROTECT INVITE AMBOTLINE]================================================================

        if op.type == 17 or op.type == 130:
          if op.param2 in Banlist["blacklist"]:
              try:
                  client.kickoutFromGroup(op.param1,[op.param2])
              except:pass
        if op.type == 32 or op.type == 126:
            if op.param3 in AM_backup["wl"]:
                if op.param2 not in creator and op.param2 not in AM_backup['wl'] and op.param2 not in AM_backup['antijs']:
                    Banlist["blacklist"][op.param2] = True
                    client.kickoutFromGroup(op.param1,[op.param2])
                    try:
                        client.inviteIntoGroup(op.param1, [op.param3])
                    except:
                        client.findAndAddContactsByMid(op.param3)
                        client.inviteIntoGroup(op.param1, [op.param3])
            if op.param3 in creator:
                if op.param2 not in creator and op.param2 not in AM_backup['wl'] and op.param2 not in AM_backup['antijs']:
                    Banlist["blacklist"][op.param2] = True
                    client.kickoutFromGroup(op.param1,[op.param2])
                    try:
                        client.inviteIntoGroup(op.param1, [op.param3])
                    except:
                        client.findAndAddContactsByMid(op.param3)
                        client.inviteIntoGroup(op.param1, [op.param3])
            if op.param3 in AM_backup["antijs"]:
                if op.param2 not in creator and op.param2 not in AM_backup['wl'] and op.param2 not in AM_backup['antijs']:
                    Banlist["blacklist"][op.param2] = True
                    client.kickoutFromGroup(op.param1,[op.param2])
                    try:
                        client.inviteIntoGroup(op.param1, [op.param3])
                    except:
                        client.findAndAddContactsByMid(op.param3)
                        client.inviteIntoGroup(op.param1, [op.param3])
        if op.type == 19 or op.type == 133:
            if clientMID in op.param3:
                Banlist["blacklist"][op.param2] = True
                if op.param2 in creator or op.param2 in AM_backup['wl'] or op.param2 in AM_backup['antijs']:
                    del Banlist["blacklist"][op.param2]
        if op.type == 19 or op.type == 133:
            if op.param3 in AM_backup["wl"]:
                if op.param2 not in creator and op.param2 not in AM_backup['wl'] and op.param2 not in AM_backup['antijs']:
                    Banlist["blacklist"][op.param2] = True
                    client.kickoutFromGroup(op.param1,[op.param2])
                    try:
                        client.inviteIntoGroup(op.param1, [op.param3])
                    except:
                        client.findAndAddContactsByMid(op.param3)
                        client.inviteIntoGroup(op.param1, [op.param3])
            if op.param3 in creator:
                if op.param2 not in creator and op.param2 not in AM_backup['wl'] and op.param2 not in AM_backup['antijs']:
                    Banlist["blacklist"][op.param2] = True
                    client.kickoutFromGroup(op.param1,[op.param2])
                    try:
                        client.inviteIntoGroup(op.param1, [op.param3])
                    except:
                        client.findAndAddContactsByMid(op.param3)
                        client.inviteIntoGroup(op.param1, [op.param3])
            if op.param3 in AM_backup['antijs']:
                if op.param2 not in creator and op.param2 not in AM_backup['wl'] and op.param2 not in AM_backup['antijs']:
                    Banlist["blacklist"][op.param2] = True
                    client.kickoutFromGroup(op.param1,[op.param2])
                    try:
                        client.inviteIntoGroup(op.param1, [op.param3])
                    except:
                        client.findAndAddContactsByMid(op.param3)
                        client.inviteIntoGroup(op.param1, [op.param3])
        if op.type == 13 or op.type == 124:
            if op.param3 in creator or op.param3 in AM_backup["wl"] or op.param3 in AM_backup['antijs']:pass
            else:
                inv1 = op.param3.replace('\x1e',',')
                inv2 = inv1.split(',')
                for i in inv2:
                  if i in Banlist["blacklist"]:
                    try:
                        client.cancelGroupInvitation(op.param1,[i])
                    except:
                        pass
                    try:
                        if op.param2 not in creator and op.param2 not in AM_backup["wl"] and op.param2 not in AM_backup['antijs']:
                            client.kickoutFromGroup(op.param1,[op.param2])
                            Banlist["blacklist"][op.param2] = True
                    except:
                        pass
            if op.param2 not in Banlist["blacklist"]:pass
            else:
                inv1 = op.param3.replace('\x1e',',')
                inv2 = inv1.split(',')
                for i in inv2:
                    Banlist["blacklist"][i] = True
                    try:
                        client.cancelGroupInvitation(op.param1,[i])
                    except:pass
                    try:
                        client.kickoutFromGroup(op.param1,[op.param2])
                    except:
                        pass
#========================================================================================================
        if op.type == 17 or op.type == 130:
          if AM_SAKLAR["rwelcome"] == True:
            if op.param2 in clientMID:
                return
            ginfo = client.getGroup(op.param1)
            contact = client.getContact(op.param2)
            cover = client.getProfileCoverURL(op.param2)
            aa = client.getContact(clientMID)
            tz = pytz.timezone("Asia/Jakarta")
            timeNow = datetime.now(tz=tz)
            timeHours = datetime.strftime(timeNow," (%H:%M)")
            name = contact.displayName
            pp = contact.pictureStatus
            e = AM_message["welcome"]
            data = {"type": "flex","altText": "TEAM TERMUX V 13","contents":{"type": "carousel","contents": [{"type": "bubble","size": "micro","body": {"type": "box","layout": "vertical","contents": [{"type": "box","layout": "vertical","contents": [{"type": "text","text": "𝑾𝑬𝑳𝑪𝑶𝑴𝑬","size": "xs","color": "#00FF00","align": "center"}],"backgroundColor": "#000000"},{"type": "separator","color": "#00FF00"},{"type": "box","layout": "vertical","contents": [{"type": "image","url": cover,"size": "full","aspectMode": "cover"}]},{"type": "separator","color": "#00FF00"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": name,"size": "xs","color": "#00FF00","align": "center"}],"backgroundColor": "#000000"},{"type": "separator","color": "#00FF00"},{"type": "box","layout": "vertical","contents": [{"type": "box","layout": "vertical","contents": [{"type": "text","text": e,"color": "#000000","size": "xxs","wrap": True,"align": "center"}],"backgroundColor": "#00FF00"}]},{"type": "separator","color": "#00FF00"},{"type": "box","layout": "horizontal","contents": [{"type": "box","layout": "vertical","contents": [{"type": "text","text": datetime.strftime(timeNow,'%H:%M:%S'),"size": "xs","color": "#00FF00","align": "center"}]},{"type": "separator","color": "#00FF00"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": datetime.strftime(timeNow,'%d-%m-%Y'),"size": "xs","color": "#00FF00","align": "center"}]}],"backgroundColor": "#000000"},{"type": "box","layout": "vertical","contents": [{"type": "image","url": "https://profile.line-scdn.net/" + str(pp),"size": "full","aspectMode": "cover"}],"position": "absolute","offsetTop": "122px","width": "50px","height": "50px","cornerRadius": "100px","borderColor": "#00FF00","borderWidth": "1px","offsetStart": "5px"}],"paddingAll": "0px","backgroundColor": "#00FF00","borderWidth": "1px","borderColor": "#00FF00","cornerRadius": "10px"}}]}}
            sendTemplate(op.param1, data)
            time.sleep(1)

#==================================={BATAS OP.TYPE PROTECT}================================================================
        if op.type in [22,24]:
            client.leaveRoom(op.param1)

        if op.type in [25, 26]:
            if op.type == 25: print ("[ 25 ] SEND MESSAGE")
            else: print ("[ 26 ] RECEIVE MESSAGE")
            msg = op.message
            text = str(msg.text)
            msg_id = msg.id
            receiver = msg.to
            sender = msg._from
            to = msg.to
            cmd = command(text)
            isValid = True
            setKey = settings["keyCommand"].title()
            if settings["setKey"] == False: setKey = ''
            if isValid != False:
                if msg.toType == 0 and sender != clientMID: to = sender
                else: to = receiver
                if msg.contentType == 16:
                    if msg.toType in [2,1,0]:
                        print ("AutoLikeCommat")
                        try:
                            if AM_SAKLAR["detect_tl"] == True:
                                purl = msg.contentMetadata["postEndUrl"].split('userMid=')[1].split('&postId=')
                                if purl[1] not in wait['postId']:
                                    client.likePost(purl[0], purl[1], random.choice([1001,1002,1003,1004,1005]))
                                    contact = client.getContact(sender)
                                    am = client.getContact(clientMID)
                                    group = client.getGroup(to)
                                    path = "http://dl.profile.line-cdn.net/" + group.pictureStatus
                                    tz = pytz.timezone("Asia/Jakarta")
                                    timeNow = datetime.now(tz=tz)
                                    Zul = AM_message["info"]
                                    data = {"type":"flex","altText": "TEAM TERMUX V 13","contents":{
  "type": "carousel",
  "contents": [
    {
      "type": "bubble",
      "size": "micro",
      "body": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "url": "https://i.ytimg.com/vi/qfS84lQbkw8/maxresdefault.jpg",
            "size": "full",
            "aspectMode": "cover",
            "aspectRatio": "20:9",
            "gravity": "top"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url":"https://obs.line-scdn.net/{}".format(am.pictureStatus),
                "aspectMode": "cover",
                "size": "full"
              }
            ],
            "position": "absolute",
            "width": "39px",
            "height": "39px",
            "cornerRadius": "100px",
            "offsetTop": "2px",
            "offsetStart": "4px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://obs.line-scdn.net/{}".format(contact.pictureStatus),
                "aspectMode": "cover",
                "size": "full"
              }
            ],
            "width": "30px",
            "position": "absolute",
            "height": "30px",
            "offsetTop": "41px",
            "cornerRadius": "100px",
            "offsetStart": "124px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://raw.githubusercontent.com/Andika163/liff-/master/20201008_073145.png",
                "size": "full",
                "aspectRatio": "20:9",
                "aspectMode": "cover"
              }
            ],
            "position": "absolute",
            "width": "160px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "𝑫𝒐𝒏𝒆 𝑳𝒊𝒌𝒆",
                "size": "xs"
              }
            ],
            "position": "absolute",
            "offsetTop": "32px",
            "offsetStart": "55px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "TEAM TERMUX V 13",
                "size": "xxs",
                "color": "#ffffff",
                "align": "center",
                "offsetTop": "1px"
              }
            ],
            "position": "absolute",
            "offsetTop": "53px",
            "offsetStart": "21px",
            "width": "97px"
          }
        ],
        "paddingAll": "0px",
        "borderWidth": "1px",
        "borderColor": "#ffffff",
        "cornerRadius": "10px"
      }
    }
  ]
}}
                                    sendTemplate(to,data)
                                if AM_SAKLAR["detect_tl"] == True:
                                    client.createComment(purl[0], purl[1], AM_message["setcoment"])  
                                    wait['postId'].append(purl[1])
                                else:pass
                        except Exception as e:
                                if AM_SAKLAR["detect_tl"] == True:
                                    purl = msg.contentMetadata['postEndUrl'].split('homeId=')[1].split('&postId=')
                                    if purl[1] not in wait['postId']:
                                        client.likePost(msg._from, purl[1], random.choice([1001,1002,1003,1004,1005]))
                                        contact = client.getContact(sender)
                                        am = client.getContact(clientMID)
                                        group = client.getGroup(to)
                                        path = "http://dl.profile.line-cdn.net/" + group.pictureStatus
                                        tz = pytz.timezone("Asia/Jakarta")
                                        timeNow = datetime.now(tz=tz)
                                        Zul = AM_message["info"]
                                        data = {"type":"flex","altText": "TEAM TERMUX V 13","contents":{
  "type": "carousel",
  "contents": [
    {
      "type": "bubble",
      "size": "micro",
      "body": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "url": "https://i.ytimg.com/vi/qfS84lQbkw8/maxresdefault.jpg",
            "size": "full",
            "aspectMode": "cover",
            "aspectRatio": "20:9",
            "gravity": "top"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url":"https://obs.line-scdn.net/{}".format(am.pictureStatus),
                "aspectMode": "cover",
                "size": "full"
              }
            ],
            "position": "absolute",
            "width": "39px",
            "height": "39px",
            "cornerRadius": "100px",
            "offsetTop": "2px",
            "offsetStart": "4px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://obs.line-scdn.net/{}".format(contact.pictureStatus),
                "aspectMode": "cover",
                "size": "full"
              }
            ],
            "width": "30px",
            "position": "absolute",
            "height": "30px",
            "offsetTop": "41px",
            "cornerRadius": "100px",
            "offsetStart": "124px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://raw.githubusercontent.com/Andika163/liff-/master/20201008_073145.png",
                "size": "full",
                "aspectRatio": "20:9",
                "aspectMode": "cover"
              }
            ],
            "position": "absolute",
            "width": "160px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "𝑫𝒐𝒏𝒆 𝑳𝒊𝒌𝒆",
                "size": "xs"
              }
            ],
            "position": "absolute",
            "offsetTop": "32px",
            "offsetStart": "55px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "TEAM TERMUX V 13",
                "size": "xxs",
                "color": "#ffffff",
                "align": "center",
                "offsetTop": "1px"
              }
            ],
            "position": "absolute",
            "offsetTop": "53px",
            "offsetStart": "21px",
            "width": "97px"
          }
        ],
        "paddingAll": "0px",
        "borderWidth": "1px",
        "borderColor": "#ffffff",
        "cornerRadius": "10px"
      }
    }
  ]
}}
                                        sendTemplate(to,data)
                                    if AM_SAKLAR["detect_tl"] == True:
                                        client.createComment(msg._from, purl[1], AM_message["setcoment"])
                                        wait['postId'].append(purl[1])
                                    else:pass
#=====================================================================
#======================={ADD WL}=============================================
        if op.type == 25 or op.type == 26:
            msg = op.message
            if msg.contentType == 13:
               if msg._from in clientMID:
                  if AM_SAKLAR["addwl"] == True:
                    if msg.contentMetadata["mid"] in AM_backup["wl"]:
                        vinfooter(to,"𝑨𝒍𝒓𝒆𝒂𝒅𝒚 𝒊𝒏 𝒘𝒉𝒊𝒕𝒆𝒍𝒊𝒔𝒕....")
                    else:
                        AM_backup["wl"][msg.contentMetadata["mid"]] = True
                        backupData()
                        vinfooter(to,"𝑺𝒖𝒄𝒄𝒆𝒔 𝒂𝒅𝒅 𝒕𝒐 𝒘𝒉𝒊𝒕𝒆𝒍𝒊𝒔𝒕....")
                  if AM_SAKLAR["delwl"] == True:
                    if msg.contentMetadata["mid"] in AM_backup["wl"]:
                        del AM_backup["wl"][msg.contentMetadata["mid"]]
                        backupData()
                        vinfooter(to,"𝑺𝒖𝒄𝒄𝒆𝒔 𝒓𝒆𝒎𝒐𝒗𝒆 𝒕𝒐 𝒘𝒉𝒊𝒕𝒆𝒍𝒊𝒔𝒕....")
                    else:
                        vinfooter(to,"𝑪𝒐𝒏𝒕𝒂𝒄𝒕 𝑵𝒐𝒕 𝒊𝒏 𝑳𝒊𝒔𝒕...")
                  if Banlist["ablack"] == True:
                    if msg.contentMetadata["mid"] in Banlist["blacklist"]:
                        vinfooter(to,"𝑨𝒍𝒓𝒆𝒂𝒅𝒚 𝒊𝒏 𝑩𝒍𝒂𝒄𝒌𝒍𝒊𝒔𝒕....")
                    else:
                        Banlist["blacklist"][msg.contentMetadata["mid"]] = True
                        vinfooter(to,"𝑺𝒖𝒄𝒄𝒆𝒔 𝒂𝒅𝒅 𝒕𝒐 𝑩𝒍𝒂𝒄𝒌𝒍𝒊𝒔𝒕....")
                  if Banlist["dblack"] == True:
                    if msg.contentMetadata["mid"] in Banlist["blacklist"]:
                        del Banlist["blacklist"][msg.contentMetadata["mid"]]
                        vinfooter(to,"𝑺𝒖𝒄𝒄𝒆𝒔 𝒓??𝒎𝒐𝒗𝒆 𝒕𝒐 𝑩𝒍𝒂𝒄𝒌𝒍𝒊𝒔𝒕....")
                    else:
                        vinfooter(to,"𝑪𝒐𝒏𝒕𝒂𝒄𝒕 𝑵𝒐𝒕 𝒊𝒏 𝑳𝒊𝒔𝒕...")
#=======================[INVITE VIA CONTACT]==================================
        if op.type == 26:
            msg = op.message
            if msg.contentType == 13:
                if AM_SAKLAR["inviting"] == True:
                    inviting = msg.contentMetadata["mid"]
                    if inviting in Banlist["blacklist"]:
                        vinfooter(to, "𝑪𝒂𝒏'𝒕 𝒊𝒏𝒗𝒊𝒕𝒆𝒅 𝒃𝒂𝒏𝒍𝒊𝒔𝒕...")
                        AM_SAKLAR["inviting"] = False
                    else:
                         client.findAndAddContactsByMid(msg.contentMetadata["mid"])
                         client.inviteIntoGroup(msg.to, [inviting])
                         jp = client.getContact(inviting).displayName
                         vinfooter(to," 𝑺𝒖𝒄𝒄𝒆𝒔 𝒃𝒂𝒏𝒍𝒊𝒔𝒕... "+jp)
                         AM_SAKLAR["inviting"] = False
#=============================================================================
        if op.type == 26:
          print ("[ 26 ] RECEIVE MESSAGE")
          msg = op.message
          text = str(msg.text)
          msg_id = msg.id
          receiver = msg.to
          sender = msg._from
          to = msg.to
          cmd = command(text)
          isValid = True
          setKey = settings["keyCommand"].title()
          if settings["setKey"] == False: setKey = ''
          if isValid != False:
              if msg.toType == 0 and sender != clientMID: to = sender
              else: to = receiver
              if msg.contentType == 6:
                try:
                    contact = client.getContact(sender)
                    if msg.toType == 2:
                        anu = client.getGroup(to)
                        if msg.contentMetadata['GC_EVT_TYPE'] == 'S' and msg.contentMetadata['GC_MEDIA_TYPE'] == 'LIVE':
                            anu = msg.contentMetadata={'GC_EVT_TYPE': 'S', 'GC_CHAT_MID': to, 'RESULT': 'INFO', 'SKIP_BADGE_COUNT': 'false', 'GC_IGNORE_ON_FAILBACK': 'false', 'TYPE': 'G', 'DURATION': '0', 'GC_MEDIA_TYPE': 'VIDEO', 'VERSION': 'X', 'CAUSE': '16'}
                except Exception as e:
                    client.sendMessage(to, str(e))

        if op.type == 26:
            print ("[ 26 ] RECEIVE MESSAGE")
            msg = op.message
            text = str(msg.text)
            msg_id = msg.id
            receiver = msg.to
            sender = msg._from
            cmd = command(text)
            setKey = settings["keyCommand"].title()
            if settings["setKey"] == False: setKey = ""
            isValid = True
            if isValid != False:
                if msg.toType == 0 and sender != clientMID: to = sender
                else: to = receiver
                if msg.toType == 0 and settings["autoReply"] and sender != clientMID:
                    contact = client.getContact(sender)
                    if contact.attributes != 32 and "[ auto reply ]" not in text.lower():
                        msgSticker = settings["messageSticker"]["listSticker"]["replySticker"]
                        if msgSticker != None:
                            sid = msgSticker["STKID"]
                            spkg = msgSticker["STKPKGID"]
                            sver = msgSticker["STKVER"]
                            sendSticker(to, sver, spkg, sid)
                        if "@!" in settings["replyPesan"]:
                            msg_ = settings["replyPesan"].split("@!")
                            sendMention(to, sender, "「Sleep Mode」\n" + msg_[0], msg_[1])
                        sendMention(to, sender, "「Sleep Mode」\nHalo", settings["replyPesan"])

        if op.type == 26:
            print ("[ 26 ] RECEIVE MESSAGE")
            msg = op.message
            text = str(msg.text)
            msg_id = msg.id
            receiver = msg.to
            sender = msg._from
            to = msg.to
            cmd = command(text)
            isValid = True
            setKey = settings["keyCommand"].title()
            if settings["setKey"] == False: setKey = ''
            if isValid != False:
                if msg.toType == 0 and sender != clientMID: to = sender
                else: to = receiver
                if msg.contentType == 0 and sender not in clientMID:
                    if msg.contentMetadata is not None and 'MENTION' in msg.contentMetadata:
                        mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                        mentionees = mention['MENTIONEES']
                        for mention in mentionees:
                            if clientMID in mention["M"]:
                                if to not in wait['ROM']:
                                    wait['ROM'][to] = {}
                                if msg._from not in wait['ROM'][to]:
                                    wait['ROM'][to][msg._from] = {}
                                if 'msg.id' not in wait['ROM'][to][msg._from]:
                                    wait['ROM'][to][msg._from]['msg.id'] = []
                                if 'waktu' not in wait['ROM'][to][msg._from]:
                                    wait['ROM'][to][msg._from]['waktu'] = []
                                wait['ROM'][to][msg._from]['msg.id'].append(msg.id)
                                wait['ROM'][to][msg._from]['waktu'].append(msg.createdTime)
                                autoresponuy(to,msg,wait)
                                break
                if msg._from not in clientMID:
                  if AM_SAKLAR["talkban"] == True:
                    if msg._from in AM_backup["Talkblacklist"]:
                        client.sendMention(to, "Sorry  @!:)","",[msg._from])
                        client.kickoutFromGroup(msg.to, [msg._from])

                if msg.contentMetadata is not None and 'MENTION' in msg.contentMetadata:
                    if AM_SAKLAR["detect_tag_kick"] == True:
                        name = re.findall(r'@(\w+)', msg.text)
                        mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                        mentionees = mention['MENTIONEES']
                        for mention in mentionees:
                            if clientMID in mention["M"]:
                               client.sendMention(to, "𝑫𝒐𝒏𝒆 𝑻𝒂𝒈 𝑴𝒆 𝑩𝒓𝒐𝒕𝒉𝒆𝒓@!:)","",[msg._from])
                               client.kickoutFromGroup(msg.to, [msg._from])
                               break
                               
                if msg.contentMetadata is not None and 'MENTION' in msg.contentMetadata:
                    if AM_SAKLAR["detect_tag_poto"] == True:
                        name = re.findall(r'@(\w+)', msg.text)
                        mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                        mentionees = mention['MENTIONEES']
                        for mention in mentionees:
                            if clientMID in mention["M"]:                       
                                contact = client.getContact(sender)
                                img = "https://obs.line-scdn.net/{}".format(contact.pictureStatus),
                                data = {"type": "flex","altText": "TEAM TERMUX V 13","contents": {"type": "carousel","contents": [{"type": "bubble","size": "kilo","body": {"type": "box","layout": "vertical","contents": [{"type": "image","url": "https://obs.line-scdn.net/{}".format(contact.pictureStatus),"size": "full","aspectMode": "cover","aspectRatio": "2:3","gravity": "top"},{"type": "box","layout": "vertical","contents": [ {"type": "text","text": "\"𝑴𝒐𝒅𝒆𝒍 𝑫𝒖𝒎𝒂𝒚\"","size": "sm", "color": "#000000","style": "normal","align": "center"},{"type": "text","text": "{}".format(contact.displayName),"color": "#000000","align": "center","size": "xs"}],"position": "absolute","cornerRadius": "5px","offsetTop": "340px","width": "150px","borderWidth": "1px"},{"type": "box","layout": "vertical","contents": [{"type": "image","url": "https://upload.wikimedia.org/wikipedia/id/thumb/e/e5/SCTV_Logo.png/800px-SCTV_Logo.png","size": "xs","offsetBottom": "10px","offsetEnd": "2px"}],"position": "absolute","offsetStart": "200px"}],"paddingAll": "0px","action": {"type": "uri","label": "action","uri": "line://app/1602687308-GXq4Vvk9?type=image&img={}".format(str(img))}}}]}}
                                sendTemplate(to, data)
                                
                if msg.contentMetadata is not None and 'MENTION' in msg.contentMetadata:
                    if AM_SAKLAR["detect_tag_text"] == True:
                        name = re.findall(r'@(\w+)', msg.text)
                        mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                        mentionees = mention['MENTIONEES']
                        for mention in mentionees:
                            if clientMID in mention["M"]:                       
                                contact = client.getContact(sender)
                                name = contact.displayName
                                am = "{}\n".format(contact.displayName)
                                am += AM_message["restext"]
                                msg.text = am
                                vinfooter(to, msg.text)
                                
                if msg.contentMetadata is not None and 'MENTION' in msg.contentMetadata:
                    if AM_SAKLAR["detect_tag"] == True:
                        name = re.findall(r'@(\w+)', msg.text)
                        mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                        mentionees = mention['MENTIONEES']
                        for mention in mentionees:
                            if clientMID in mention["M"]:                       
                                contact = client.getContact(sender)
                                tz = pytz.timezone("Asia/Jakarta")
                                timeNow = datetime.now(tz=tz)
                                LINKFOTO = "https://os.line.naver.jp/os/p/" + sender
                                LINKVIDEO = "https://os.line.naver.jp/os/p/" + sender + "/vp"
                                res = AM_message["tag"]
                                data = {"type": "flex","altText": "TEAM TERMUX V 13.","contents": {"type": "carousel","contents": [{"type": "bubble","size": "micro","body": {"type": "box","layout": "vertical","contents": [{"type": "box","layout": "vertical","contents": [{"type": "text","text": "𝑹𝑬𝑺𝑷𝑶𝑵 𝑻𝑨𝑮","size": "xs","color": "#FFFFFF","align": "center"}],"backgroundColor": "#FF0000"},{"type": "separator","color": "#FFFF00"},{"type": "box","layout": "vertical","contents": [{"type": "image","url": "https://obs.line-scdn.net/{}".format(contact.pictureStatus),"size": "full","aspectMode": "cover"}]},{"type": "separator","color": "#FFFF00"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "{}".format(contact.displayName),"size": "xs","color": "#ffffff","align": "center"}],"backgroundColor": "#008B8B"},{"type": "separator","color": "#FFFF00"},{"type": "box","layout": "vertical","contents": [{"type": "box","layout": "vertical","contents": [{"type": "text","text": "{}".format(res),"color": "#ffffff","size": "xxs","wrap": True,"align": "center"}],"backgroundColor": "#FF0000"}]},{"type": "separator","color": "#FFFF00"},{"type": "box","layout": "horizontal","contents": [{"type": "box","layout": "vertical","contents": [{"type": "text","text": datetime.strftime(timeNow,'%H:%M:%S'),"size": "xs","color": "#000000","align": "center"}]},{"type": "separator","color": "#00FFFF"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": datetime.strftime(timeNow,'%d-%m-%Y'),"size": "xs","color": "#000000","align": "center"}]}],"backgroundColor": "#FF0000"}],"paddingAll": "0px","backgroundColor": "#FF0000","borderWidth": "1px","borderColor": "#FFFF00","cornerRadius": "10px"}}]}}
                                sendTemplate(to, data)

                if msg.contentType in [0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21]:
                    if msg.toType == 0:
                        if settings["autoRead"] == True:
                            client.sendChatChecked(to, msg_id)

                    if msg.toType == 2:
                        if settings["autoRead1"] == True:
                            client.sendChatChecked(to, msg_id)

                if msg.text:
                    if msg.text.lower().lstrip().rstrip() in wbanlist:
                        if msg.text not in clientMID:
                            try:
                                client.kickoutFromGroup(msg.to,[sender])
                            except Exception as e:
                                 print(e)

                if msg.contentType == 0: # Content type is text
                  if '/ti/g/' in text and AM_SAKLAR['tiket'] == True:
                      regex = re.compile('(?:line\:\/|line\.me\/R)\/ti\/g\/([a-zA-Z0-9_-]+)?')
                      links = regex.findall(text)
                      tickets = []
                      gids = client.getGroupIdsJoined()
                      for link in links:
                          if link not in tickets:
                            tickets.append(link)
                      for ticket in tickets:
                        try:
                            group = client.findGroupByTicket(ticket)
                        except:
                            continue
                        if group.id in gids:
                            vinfooter(to, 'Otw to group ' + group.name)
                            continue
                        client.acceptGroupInvitationByTicket(group.id, ticket)


                if msg.contentType == 0:
                  if AM_SAKLAR["detect_smule"] == True:
                        vinfooter(to, "「 Detect Smule 」\n\n" + AM_message["smule"])

                elif msg.contentType == 13:
                  if AM_SAKLAR['detect_contact'] == True:
                    mid = msg.contentMetadata['mid']
                    try:
                        contact = client.getContact(mid)
                    except:
                        return client.sendMessage(to, 'Failed get details contact with mid ' + mid)
                    res = '「 Details Contact 」'
                    res += '\n◌ MID : ' + mid
                    res += '\n◌ Display Name : ' + str(contact.displayName)
                    if contact.displayNameOverridden: res += '\n◌ Display Name Overridden : ' + str(contact.displayNameOverridden)
                    res += '\n◌ Status Message : ' + str(contact.statusMessage)
                    if contact.pictureStatus:
                      client.sendImageWithURL(to, 'http://dl.profile.line-cdn.net/' + contact.pictureStatus)
                    cover = client.getProfileCoverURL(mid)
                    client.sendImageWithURL(to, str(cover))
                    vinfooter(to, res)

                if msg.contentType == 1:
                  if msg.toType == 2 and msg._from not in clientMID:
                    ps = msg._from
                    if AM_SAKLAR["detect_gambar"] == True:
                      contact = client.getContact(msg._from)
                      xname = contact.displayName
                      xlen = str(len(xname)+1)
                      msg.contentType = 0
                      answ = "@"+xname+" What picture is that..?"
                      msg.text = answ
                      msg.contentMetadata ={'MENTION':'{"MENTIONEES":[{"S":"0","E":'+json.dumps(xlen)+',"M":'+json.dumps(msg._from)+'}]}','EMTVER':'4'}
                      client.sendMessage(receiver,msg.text,msg.contentMetadata)

                if msg.contentType == 3:
                  if msg.toType == 2 and msg._from not in clientMID:
                    ps = msg._from
                    if AM_SAKLAR["detect_audio"] == True:
                      contact = client.getContact(msg._from)
                      xname = contact.displayName
                      xlen = str(len(xname)+1)
                      msg.contentType = 0
                      answ = "@"+xname+" what audio it is..?"
                      msg.text = answ
                      msg.contentMetadata ={'MENTION':'{"MENTIONEES":[{"S":"0","E":'+json.dumps(xlen)+',"M":'+json.dumps(msg._from)+'}]}','EMTVER':'4'}
                      client.sendMessage(receiver,msg.text,msg.contentMetadata)

                if msg.contentType == 2:
                  if msg.toType == 2 and msg._from not in clientMID:
                    ps = msg._from
                    if AM_SAKLAR["detect_video"] == True:
                      contact = client.getContact(msg._from)
                      xname = contact.displayName
                      xlen = str(len(xname)+1)
                      msg.contentType = 0
                      answ = "@"+xname+" what video it is..?"
                      msg.text = answ
                      msg.contentMetadata ={'MENTION':'{"MENTIONEES":[{"S":"0","E":'+json.dumps(xlen)+',"M":'+json.dumps(msg._from)+'}]}','EMTVER':'4'}
                      client.sendMessage(receiver,msg.text,msg.contentMetadata)

                if msg.contentType == 7:
                  if msg.toType == 2 and msg._from not in clientMID:
                    ps = msg._from
                    if AM_SAKLAR["detect_sticker"] == True:
                      contact = client.getContact(msg._from)
                      xname = contact.displayName
                      xlen = str(len(xname)+1)
                      msg.contentType = 0
                      answ = "@"+xname+" Stickernya keren Gift me Dong...!"
                      msg.text = answ
                      msg.contentMetadata ={'MENTION':'{"MENTIONEES":[{"S":"0","E":'+json.dumps(xlen)+',"M":'+json.dumps(msg._from)+'}]}','EMTVER':'4'}
                      client.sendMessage(receiver,msg.text,msg.contentMetadata)

                if msg.contentType == 7:
                  if AM_SAKLAR["detect_id_sticker"] == True:
                    msg.contentType = 0
                    vinfooter(msg.to,"⌜Cek Id Sticker⌟\n◌ STKID :" + msg.contentMetadata["STKID"] + "\n◌ STKPKGID : " + msg.contentMetadata["STKPKGID"] + "\n◌ STKVER : " + msg.contentMetadata["STKVER"]+ "\n◌ line://shop/detail/" + msg.contentMetadata["STKPKGID"])

                if msg.contentType == 6:
                    if msg.toType == 2 and msg._from not in clientMID:
                        ps = msg._from
                        if AM_SAKLAR["detect_call"] == True:
                            b = msg.contentMetadata['GC_EVT_TYPE']
                            c = msg.contentMetadata["GC_MEDIA_TYPE"]
                            tz = pytz.timezone("Asia/Jakarta")
                            timeNow = datetime.now(tz=tz)
                            contact = client.getContact(sender)
                            if c == "VIDEO" and b == "S":
                                data = {"type": "flex","altText": "TEAM TERMUX V 13","contents": {"type": "bubble","size": "kilo","body": {"type": "box","layout": "vertical","contents": [{"type": "image","url": Settemp["call"]["image"],"size": "full","aspectMode": "cover","aspectRatio": "6:2","gravity": "center"},{"type": "box","layout": "vertical","contents": [{"type": "box","layout": "vertical","contents": [{"type": "box","layout": "vertical","contents": [{"type": "text","text": "TYPE {} CALL".format(c),"color": Settemp["call"]["warnatext"],"size": "xs","align": "center"}]},{"type": "separator","color": Settemp["call"]["garis"]},{"type": "box","layout": "horizontal","contents": [{"type": "box","layout": "vertical","contents": [{"type": "text","text": "VideoCall : Staters","size": "xs","color": Settemp["call"]["warnatext"],"offsetStart": "5px"},{"type": "separator","color": Settemp["call"]["garis"]},{"type": "text","text": "Host Name : {}".format(contact.displayName),"size": "xs","color": Settemp["call"]["warnatext"],"offsetStart": "5px"},{"type": "separator","color": Settemp["call"]["garis"]},{"type": "box","layout": "horizontal","contents": [{"type": "box","layout": "vertical","contents": [{"type": "text","text": "Data time :","color": Settemp["call"]["warnatext"],"size": "xs","offsetStart": "5px","offsetTop": "2px"}]},{"type": "separator","color": Settemp["call"]["garis"]},{"type": "box","layout": "vertical","contents": [{"type": "text","text": datetime.strftime(timeNow,'%H:%M:%S'),"size": "xs","color": Settemp["call"]["warnatext"],"align": "center","offsetTop": "2px"}]},{"type": "separator","color": Settemp["call"]["garis"]},{"type": "box","layout": "vertical","contents": [{"type": "text","text": datetime.strftime(timeNow,'%d-%m-%Y'),"size": "xs","color": Settemp["call"]["warnatext"],"align": "center","offsetTop": "2px"}]}]}]},{"type": "separator","color": Settemp["call"]["garis"]},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "ZULKIFLI","size": "xs","color": "#ffffff","align": "center"},{"type": "separator","color": Settemp["call"]["garis"]},{"type": "box","layout": "vertical","contents": [{"type": "image","url": "https://obs.line-scdn.net/{}".format(contact.pictureStatus),"size": "full","aspectMode": "cover"}],"width": "37px","height": "37px"}],"width": "37px"}]}]}],"position": "absolute","width": "250px","offsetStart": "4px","offsetTop": "5px","cornerRadius": "5px","borderWidth": "1px","borderColor": Settemp["call"]["garis"]},{"type": "box","layout": "vertical","contents": [{"type": "text","text": Settemp["call"]["labeltext"],"align": "center","color": "#ffffff","size": "sm"}],"backgroundColor": Settemp["call"]["warnalabel"]}],"paddingAll": "0px","borderWidth": "1px","borderColor": Settemp["call"]["garis"],"cornerRadius": "10px"}}}
                                sendTemplate(to, data)
                            if c == "AUDIO" and b == "S":
                                data = {"type": "flex","altText": "TEAM TERMUX V 13","contents": {"type": "bubble","size": "kilo","body": {"type": "box", "layout": "vertical","contents": [ {"type": "image","url": Settemp["call"]["image"],"size": "full","aspectMode": "cover","aspectRatio": "6:2","gravity": "center"},{"type": "box","layout": "vertical","contents": [{"type": "box","layout": "vertical","contents": [{"type": "box","layout": "vertical","contents": [{"type": "text","text": "TYPE {} CALL".format(c),"color": Settemp["call"]["warnatext"],"size": "xs","align": "center"}]},{"type": "separator","color": Settemp["call"]["garis"]},{"type": "box","layout": "horizontal","contents": [{"type": "box","layout": "vertical","contents": [{"type": "text", "text": "GroupCall : Staters","size": "xs","color": Settemp["call"]["warnatext"],"offsetStart": "5px"},{"type": "separator","color": Settemp["call"]["garis"]},{"type": "text","text": "Host Name : {}".format(contact.displayName),"size": "xs","color": Settemp["call"]["warnatext"],"offsetStart": "5px"},{"type": "separator","color": Settemp["call"]["garis"]},{"type": "box","layout": "horizontal","contents": [{"type": "box","layout": "vertical","contents": [{"type": "text","text": "Data time :","color": Settemp["call"]["warnatext"],"size": "xs","offsetStart": "5px","offsetTop": "2px"}]},{"type": "separator","color": Settemp["call"]["garis"]},{"type": "box","layout": "vertical","contents": [{"type": "text","text": datetime.strftime(timeNow,'%H:%M:%S'),"size": "xs","color": Settemp["call"]["warnatext"],"align": "center","offsetTop": "2px"}]},{"type": "separator","color": Settemp["call"]["garis"]},{ "type": "box","layout": "vertical","contents": [{"type": "text","text": datetime.strftime(timeNow,'%d-%m-%Y'),"size": "xs","color": Settemp["call"]["warnatext"],"align": "center","offsetTop": "2px"}]}]}]},{"type": "separator","color": Settemp["call"]["garis"]},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "ZULKIFLI","size": "xs","color": Settemp["call"]["warnatext"],"align": "center"},{"type": "separator","color": Settemp["call"]["garis"]},{"type": "box","layout": "vertical","contents": [{"type": "image","url": "https://obs.line-scdn.net/{}".format(contact.pictureStatus),"size": "full","aspectMode": "cover"}],"width": "37px","height": "37px"}],"width": "37px"}]}]}],"position": "absolute","width": "250px","offsetStart": "4px","offsetTop": "5px","cornerRadius": "5px","borderWidth": "1px","borderColor": Settemp["call"]["garis"]},{"type": "box","layout": "vertical","contents": [{"type": "text","text": Settemp["call"]["labeltext"],"align": "center","color": Settemp["call"]["warnatext"],"size": "sm"}],"backgroundColor": Settemp["call"]["warnalabel"]}],"paddingAll": "0px","borderWidth": "1px","borderColor": Settemp["call"]["garis"],"cornerRadius": "10px"}}}
                                sendTemplate(to, data)
                            if c == "LIVE" and b == "S":
                                data = {"type": "flex","altText": "TEAM TERMUX V 13","contents": {"type": "bubble","size": "kilo","body": {"type": "box","layout": "vertical","contents": [{"type": "image","url": Settemp["call"]["image"],"size": "full","aspectMode": "cover","aspectRatio": "6:2","gravity": "center"},{"type": "box","layout": "vertical","contents": [{"type": "box","layout": "vertical","contents": [{"type": "box","layout": "vertical","contents": [{ "type": "text","text": "TYPE {} SHOW".format(c),"color": Settemp["call"]["warnatext"],"size": "xs","align": "center"}]},{"type": "separator","color": Settemp["call"]["garis"]},{"type": "box","layout": "horizontal","contents": [{"type": "box","layout": "vertical","contents": [{"type": "text","text": "Live Show : Staters","size": "xs","color": Settemp["call"]["warnatext"],"offsetStart": "5px"},{"type": "separator","color": Settemp["call"]["garis"] },{"type": "text","text": "Host Name : {}".format(contact.displayName),"size": "xs","color": Settemp["call"]["warnatext"],"offsetStart": "5px"},{"type": "separator","color": Settemp["call"]["garis"]},{"type": "box","layout": "horizontal","contents": [{"type": "box","layout": "vertical","contents": [{ "type": "text","text": "Data time :","color": Settemp["call"]["warnatext"],"size": "xs","offsetStart": "5px","offsetTop": "2px"}]},{"type": "separator","color": Settemp["call"]["garis"]},{"type": "box","layout": "vertical","contents": [{"type": "text","text": datetime.strftime(timeNow,'%H:%M:%S'),"size": "xs","color": Settemp["call"]["warnatext"],"align": "center","offsetTop": "2px"}]},{"type": "separator","color": Settemp["call"]["garis"]},{"type": "box","layout": "vertical","contents": [{ "type": "text","text": datetime.strftime(timeNow,'%d-%m-%Y'),"size": "xs","color": Settemp["call"]["warnatext"],"align": "center","offsetTop": "2px"}]}]}]},{"type": "separator","color": Settemp["call"]["garis"]},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "ZULKIFLI","size": "xs","color": Settemp["call"]["warnatext"],"align": "center"}, {"type": "separator","color": Settemp["call"]["garis"]},{"type": "box","layout": "vertical","contents": [{"type": "image","url": "https://obs.line-scdn.net/{}".format(contact.pictureStatus),"size": "full","aspectMode": "cover"}],"width": "37px","height": "37px"}],"width": "37px"}]}]}],"position": "absolute","width": "250px","offsetStart": "4px","offsetTop": "5px","cornerRadius": "5px","borderWidth": "1px","borderColor": Settemp["call"]["garis"]},{"type": "box","layout": "vertical","contents": [{"type": "text","text": Settemp["call"]["labeltext"], "align": "center","color": Settemp["call"]["warnatext"],"size": "sm"}],"backgroundColor": Settemp["call"]["warnalabel"]}],"paddingAll": "0px","borderWidth": "1px","borderColor": Settemp["call"]["garis"],"cornerRadius": "10px" }}}
                                sendTemplate(to, data)
                            else:
                                mills = int(msg.contentMetadata["DURATION"])
                                seconds = (mills/1000)%60
                                if c == "VIDEO" and b == "E":
                                    data = {"type": "flex","altText": "TEAM TERMUX V 13","contents": {"type": "bubble","size": "kilo","body": {"type": "box","layout": "vertical","contents": [{"type": "image","url": Settemp["call"]["image"],"size": "full","aspectMode": "cover","aspectRatio": "6:2","gravity": "center"},{"type": "box","layout": "vertical","contents": [{"type": "box","layout": "vertical","contents": [{"type": "box","layout": "vertical","contents": [{"type": "text","text": "TYPE {} CALL".format(c),"color": Settemp["call"]["warnatext"],"size": "xs","align": "center"}]},{"type": "separator","color": Settemp["call"]["garis"]},{"type": "box","layout": "horizontal","contents": [{"type": "box","layout": "vertical","contents": [{"type": "text","text": "Video Call : End up","size": "xs","color": Settemp["call"]["warnatext"],"offsetStart": "5px"},{ "type": "separator","color": Settemp["call"]["garis"]},{"type": "text","text": "Host Name : {}".format(contact.displayName),"size": "xs","color": Settemp["call"]["warnatext"],"offsetStart": "5px"},{"type": "separator","color": Settemp["call"]["garis"]},{"type": "box","layout": "horizontal","contents": [{"type": "box","layout": "vertical","contents": [{"type": "text","text": "Data time :","color": Settemp["call"]["warnatext"],"size": "xs","offsetStart": "5px","offsetTop": "2px"}]},{"type": "separator","color": Settemp["call"]["garis"]},{"type": "box","layout": "vertical","contents": [{"type": "text","text": datetime.strftime(timeNow,'%H:%M:%S'),"size": "xs","color": Settemp["call"]["warnatext"],"align": "center","offsetTop": "2px"}]},{"type": "separator","color": Settemp["call"]["garis"]},{"type": "box","layout": "vertical","contents": [{"type": "text","text": datetime.strftime(timeNow,'%d-%m-%Y'),"size": "xs","color": Settemp["call"]["warnatext"],"align": "center","offsetTop": "2px"}]}]}]},{"type": "separator", "color": Settemp["call"]["garis"]},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "ZULKIFLI","size": "xs","color": Settemp["call"]["warnatext"],"align": "center"},{"type": "separator","color": Settemp["call"]["garis"]},{"type": "box","layout": "vertical","contents": [{"type": "image","url": "https://obs.line-scdn.net/{}".format(contact.pictureStatus),"size": "full","aspectMode": "cover"}],"width": "37px","height": "37px"}],"width": "37px"}]}]}],"position": "absolute","width": "250px","offsetStart": "4px","offsetTop": "5px","cornerRadius": "5px","borderWidth": "1px","borderColor": Settemp["call"]["garis"]},{ "type": "box","layout": "vertical","contents": [{"type": "text","text": Settemp["call"]["labeltext"],"align": "center","color": Settemp["call"]["warnatext"],"size": "sm"}],"backgroundColor": Settemp["call"]["warnalabel"]}],"paddingAll": "0px","borderWidth": "1px","borderColor": Settemp["call"]["garis"],"cornerRadius": "10px"}}}
                                    sendTemplate(to, data)
                                if c == "AUDIO" and b == "E":
                                    data = {"type": "flex","altText": "TEAM TERMUX V 13","contents": {"type": "bubble","size": "kilo","body": {"type": "box","layout": "vertical","contents": [{"type": "image","url": Settemp["call"]["image"],"size": "full","aspectMode": "cover","aspectRatio": "6:2","gravity": "center"},{"type": "box", "layout": "vertical","contents": [{"type": "box","layout": "vertical","contents": [{"type": "box","layout": "vertical","contents": [{"type": "text","text": "TYPE {} CALL".format(c),"color": Settemp["call"]["warnatext"],"size": "xs","align": "center"}]},{"type": "separator","color": Settemp["call"]["garis"]},{"type": "box","layout": "horizontal","contents": [{"type": "box","layout": "vertical","contents": [{"type": "text","text": "Group Call : End up","size": "xs", "color": Settemp["call"]["warnatext"],"offsetStart": "5px"},{"type": "separator","color": Settemp["call"]["garis"]},{"type": "text","text": "Host Name : {}".format(contact.displayName),"size": "xs","color": Settemp["call"]["warnatext"],"offsetStart": "5px"},{"type": "separator","color": "#00FFFF"},{"type": "box","layout": "horizontal","contents": [{"type": "box","layout": "vertical","contents": [{"type": "text","text": "Data time :","color": Settemp["call"]["warnatext"],"size": "xs","offsetStart": "5px","offsetTop": "2px"}]},{"type": "separator","color": Settemp["call"]["garis"]},{"type": "box","layout": "vertical","contents": [{"type": "text","text": datetime.strftime(timeNow,'%H:%M:%S'),"size": "xs","color": Settemp["call"]["warnatext"],"align": "center","offsetTop": "2px"}]},{"type": "separator","color": Settemp["call"]["garis"]},{"type": "box","layout": "vertical","contents": [{"type": "text","text": datetime.strftime(timeNow,'%d-%m-%Y'),"size": "xs","color": Settemp["call"]["warnatext"],"align": "center","offsetTop": "2px"}]}]}]}, {"type": "separator","color": Settemp["call"]["garis"]},{"type": "box","layout": "vertical", "contents": [{"type": "text","text": "ZULKIFLI","size": "xs","color": Settemp["call"]["warnatext"],"align": "center"},{"type": "separator","color": Settemp["call"]["garis"]},{"type": "box","layout": "vertical","contents": [{"type": "image","url": "https://obs.line-scdn.net/{}".format(contact.pictureStatus), "size": "full","aspectMode": "cover"}],"width": "37px","height": "37px"}],"width": "37px"}]}]}],"position": "absolute","width": "250px","offsetStart": "4px", "offsetTop": "5px","cornerRadius": "5px","borderWidth": "1px","borderColor": Settemp["call"]["garis"]},{"type": "box","layout": "vertical","contents": [{"type": "text","text": Settemp["call"]["labeltext"],"align": "center","color": Settemp["call"]["warnatext"],"size": "sm"}],"backgroundColor": Settemp["call"]["warnalabel"]}],"paddingAll": "0px","borderWidth": "1px","borderColor": Settemp["call"]["garis"],"cornerRadius": "10px"}}}
                                    sendTemplate(to, data)
                                if c == "LIVE" and b == "E":
                                    data = {"type": "flex","altText": "TEAM TERMUX V 13","contents": {"type": "bubble","size": "kilo","body": {"type": "box","layout": "vertical","contents": [{"type": "image","url": Settemp["call"]["image"], "size": "full","aspectMode": "cover","aspectRatio": "6:2","gravity": "center"},{"type": "box","layout": "vertical","contents": [{"type": "box","layout": "vertical","contents": [{"type": "box","layout": "vertical","contents": [{"type": "text","text": "TYPE {} SHOW".format(c),"color": Settemp["call"]["warnatext"],"size": "xs","align": "center"}]},{"type": "separator","color": Settemp["call"]["garis"]},{"type": "box","layout": "horizontal","contents": [{"type": "box","layout": "vertical","contents": [{"type": "text","text": "Live Show : End up","size": "xs","color": Settemp["call"]["warnatext"],"offsetStart": "5px"},{"type": "separator","color": Settemp["call"]["garis"]},{"type": "text","text": "Host Name : {}".format(contact.displayName),"size": "xs","color": Settemp["call"]["warnatext"],"offsetStart": "5px"},{"type": "separator","color": Settemp["call"]["garis"]},{"type": "box","layout": "horizontal","contents": [{"type": "box","layout": "vertical","contents": [ {"type": "text","text": "Data time :","color": Settemp["call"]["warnatext"],"size": "xs","offsetStart": "5px","offsetTop": "2px"}]},{"type": "separator","color": Settemp["call"]["garis"]},{"type": "box","layout": "vertical","contents": [{"type": "text","text": datetime.strftime(timeNow,'%H:%M:%S'),"size": "xs","color": Settemp["call"]["warnatext"],"align": "center","offsetTop": "2px"}]},{"type": "separator","color": Settemp["call"]["garis"]},{"type": "box","layout": "vertical","contents": [{"type": "text","text": datetime.strftime(timeNow,'%d-%m-%Y'),"size": "xs","color": Settemp["call"]["warnatext"],"align": "center","offsetTop": "2px"}]}]}]},{"type": "separator","color": Settemp["call"]["garis"]},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "ZULKIFLI","size": "xs","color": Settemp["call"]["warnatext"],"align": "center"},{"type": "separator","color": Settemp["call"]["garis"]},{"type": "box","layout": "vertical","contents": [{"type": "image","url": "https://obs.line-scdn.net/{}".format(contact.pictureStatus),"size": "full","aspectMode": "cover"}],"width": "37px","height": "37px"}],"width": "37px"}]}]}],"position": "absolute","width": "250px","offsetStart": "4px","offsetTop": "5px","cornerRadius": "5px","borderWidth": "1px","borderColor": Settemp["call"]["garis"]},{"type": "box","layout": "vertical","contents": [{"type": "text","text": Settemp["call"]["labeltext"],"align": "center","color": Settemp["call"]["warnatext"],"size": "sm"}],"backgroundColor": Settemp["call"]["warnalabel"]}],"paddingAll": "0px","borderWidth": "1px","borderColor": Settemp["call"]["garis"],"cornerRadius": "10px"}}}
                                    sendTemplate(to, data)

                    
                for image in images:
                  if AM_SAKLAR["mode_publik"] == True:
                    if text.lower() == image:
                        client.generateReplyMessage(msg.id)
                        client.sendReplyImage(msg.id, to, images[image])

                for sticker in stickers:
                  if AM_SAKLAR["mode_publik"] == True:
                    if text.lower() == sticker:
                        sid = stickers[sticker]["STKID"]
                        spkg = stickers[sticker]["STKPKGID"]
                        sver = stickers[sticker]["STKVER"]
                        try:
                            sendSticker(to, msg._from, sver, spkg, sid)
                        except Exception as e:
                            sendSticker2(to, msg._from, sver, spkg, sid)

                for sticker in stickers2:
                  if AM_SAKLAR["bigsticker"] == True:
                    try:
                        if text.lower() == sticker:
                            sid = stickers2[sticker]["STKID"]
                            spkg = stickers2[sticker]["STKPKGID"]
                            sver = stickers2[sticker]["STKVER"]
                            a = client.shop.getProduct(packageID=int(spkg), language='ID', country='ID')
                            if a.hasAnimation == True:data = {"type": "template","altText": "{}TEAM TERMUX V 13".format(client.getProfile().displayName),"template": {"type": "image_carousel","columns": [{"imageUrl": "https://stickershop.line-scdn.net/stickershop/v1/sticker/{}/IOS/sticker_animation@2x.png".format(sid),"size": "full","action": {"type": "uri","uri": "line://nv/profilePopup/mid=u42880eb65b2da1eb8fd3b7a9caa4ccc3"}}]}}
                            else:data = {"type": "template","altText": "{}TEAM TERMUX V 13".format(client.getProfile().displayName),"template": {"type": "image_carousel","columns": [{"imageUrl": "https://stickershop.line-scdn.net/stickershop/v1/sticker/{}/android/sticker@2x.png".format(sid),"size": "full","action": {"type": "uri","uri": "line://nv/profilePopup/mid=u42880eb65b2da1eb8fd3b7a9caa4ccc3"}}]}}
                            sendTemplate(to,data)
                    except Exception as e:
                        print(e)

                for sticker in stickers1:
                  if AM_SAKLAR["bigsticker"] == True:
                    if text.lower() == sticker:
                        sid = stickers1[sticker]["STKID"]
                        data = {"type": "template","altText": "TEAM TERMUX V 13","baseSize": {"height": 1040,"width": 1040},"template": {"type": "image_carousel","columns": [{"imageUrl": "https://stickershop.line-scdn.net/stickershop/v1/sticker/{}/IOS/sticker@2x.png".format(sid),"action": {"type": "uri","uri": "line://nv/profilePopup/mid=u42880eb65b2da1eb8fd3b7a9caa4ccc3","area": {"x": 520,"y": 0,"width": 520,"height": 1040}}}]}}
                        sendTemplate(to, data)
                        
#☵☵☵☵☵☵☵☵☵☵☵☵[ Mode Public ]☵☵☵☵☵☵☵☵☵☵☵☵☵
                        
        if op.type == 25 or op.type == 26:
            msg = op.message
            text = msg.text
            msg_id = msg.id
            receiver = msg.to
            sender = msg._from
            if msg.toType == 0 or msg.toType == 1 or msg.toType == 2:
                if msg.toType == 0:
                    if sender != client.profile.mid:
                        to = sender
                    else:
                        to = receiver
                elif msg.toType == 1:
                    to = receiver
                elif msg.toType == 2:
                    to = receiver
            if msg.contentType == 0:
                if text is None:
                    return

            #=========[ Cmd media Admin/public ]

                elif text.lower() == "mid" or text.lower() == "mid":
                  if msg._from in clientMID:
                    try:
                      vinfooter(to,"{}".format(msg._from))
                    except Exception as e:
                      vinfooter(to, str(e))

                elif cmd.startswith("media"):
                    if msg._from in clientMID:
                      try:
                          ret_ ="◉ joox judul\n"
                          ret_ +="◉ ytsearch judul\n"
                          ret_ +="◉ youtube judul\n"
                          ret_ +="◉ img judul\n"
                          ret_ +="◉ ceksuhu kota\n"
                          ret_ +="◉ infoloker kota\n"
                          ret_ +="◉ jadwaltv channel\n"
      #                    ret_ +="◉ dadjoke\n"
                          ret_ +="◉ zodiac text\n"
                          ret_ +="◉ cekip text\n"
                          ret_ +="◉ vin1 text\n"
                          ret_ +="◉ vin2 text\n"
                          ret_ +="◉ smule 1 on off\n"    
                          ret_ +="◉ smule 2 on off\n"
                          rett_ ="◉ tiktok on off\n"
                          rett_ +="◉ timeline on off\n"
                          rett_ +="◉ donwloadyt on off\n"
                          rett_ +="◉ smuleid idnya\n"
                          rett_ +="◉ lirik judul\n"
                          rett_ +="◉ icak\n"
                          rett_ +="◉ artiname namanya\n"
                          rett_ +="◉ sifatname namanya\n"
                          rett_ +="◉ nekopoipage num\n"
                          rett_ +="◉ wikipedia text\n"
                          rett_ +="◉ xxx text\n"
                          rett_ +="◉ hentai text\n"
                          achinkZul2(to, ret_, rett_)
                      except Exception as e:
                          vinfooter(to, str(e))

                elif "addwl " in cmd:
                            if msg._from in creator:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                  if target in AM_backup["wl"]:
                                    vintemp(to,"「 𝑨𝒅𝒅 𝑾𝒉𝒊𝒕𝒆𝒍𝒊𝒔𝒕 」\n\n𝑨𝒍𝒓𝒆𝒂𝒅𝒚 ??𝒏 𝒕𝒉𝒆 𝒍𝒊𝒔𝒕...")
                                  else:
                                      try:
                                          AM_backup["wl"][target] = True
                                          backupData()
                                          vintemp(to,"「 𝑨𝒅𝒅 𝑾𝒉𝒊𝒕𝒆𝒍𝒊𝒔𝒕 」\n\n𝑺𝒖𝒄𝒄𝒆𝒔 𝒂𝒅𝒅 𝒕𝒐 𝑾𝒉𝒊𝒕𝒆𝒍𝒊𝒔𝒕...")
                                      except:
                                          pass

                elif "delbl " in cmd:
                            if msg._from in creator:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                  if target not in Banlist["blacklist"]:
                                      vintemp(to,"「 𝑩𝒍𝒂𝒄𝒌𝒍𝒊𝒔𝒕 」\n\n𝑵𝒐𝒕𝒊𝒏𝒈 𝑩𝒍𝒂𝒄𝒌𝒍𝒊𝒔𝒕...")
                                  else:
                                      try:
                                          del Banlist["blacklist"][target]
                                          backupData()
                                          vintemp(to,"「 𝑩𝒍𝒂𝒄𝒌𝒍𝒊𝒔𝒕 」\n\n𝑺𝒖𝒄𝒄𝒆𝒔 𝒅𝒆𝒍𝒍𝒆𝒕 𝑩𝒍𝒂𝒄𝒌𝒍𝒊𝒔𝒕...")
                                      except:
                                          pass

                elif cmd == "wl" or text.lower() == 'wlist':
                            if msg._from in creator:
                              if AM_backup["wl"] == {}:
                                vintemp(to,"「 𝑾𝒉𝒊𝒕𝒆𝒍𝒊𝒔𝒕 」\n\n𝑵𝒐𝒕𝒊𝒏𝒈 𝑾𝒉𝒊𝒕𝒆𝒍𝒊𝒔𝒕....")
                              else:
                                num = 1
                                mc = "「 𝑾𝒉𝒊𝒕𝒆𝒍𝒊𝒔𝒕 」\n"
                                for me in AM_backup["wl"]:
                                    mc += "\n %i.  %s" % (num, client.getContact(me).displayName)
                                    num = (num+1)
                                mc += "\n\n𝑻𝒐𝒕𝒂𝒍 %i 𝑾𝒉𝒊𝒕𝒆𝒍𝒊𝒔𝒕" % len(AM_backup["wl"])
                                vintemp(to,"{}".format(str(mc)))

                elif cmd == "clearwl" or text.lower() == 'clear wl':
                            if msg._from in creator:
                              ang = client.getContacts(AM_backup["wl"])
                              mc = "%i 𝑾𝒉𝒊𝒕𝒆𝒍𝒊𝒔𝒕 " % len(ang)
                              vintemp(to,"𝑪𝒍𝒆𝒂𝒓 {}".format(str(mc)))
                              AM_backup["wl"] = {}

                elif "https://www.smule.com/" in text.lower():
                    if saklar_media["smuledonwload1"] == True:
                        try:
                            regex = r'http[s]?://(?:[a-zA-Z]|[0-9]|[$-_@.&+]|[!*\(\),]|(?:%[0-9a-fA-F][0-9a-fA-F]))+'
                            links = re.findall(regex, text)
                            n_links = []
                            for l in links:
                                if l not in n_links:
                                    n_links.append(l)
                            for ticket_id in n_links:
                                ve = requests.get("https://api.vhtear.com/getsmule?link={}&apikey=K2021liproAngrus".format(str(ticket_id)))
                                h = json.loads(ve.text)
                                if h["result"]['Type'] == 'audio':
                                    vintemp2(to, '◤ 𝑻𝒚𝒑𝒆 𝑹𝒆𝒄𝒐𝒓𝒅 𝑨𝒖𝒅𝒊𝒐 𝑺𝒎𝒖𝒍𝒆◢\n\n𝑻𝒊𝒕𝒕𝒍𝒆 ➽' +h["result"]["title"])
                                    client.sendAudioWithURL(to, h['result']['url'])
                                else:
                                    vintemp2(to, '◢ 𝑻𝒚𝒑𝒆 𝑹𝒆𝒄𝒐𝒓𝒅 𝑽𝒊𝒅𝒆𝒐 𝑺𝒎𝒖𝒍𝒆 ◢\n\n𝑻𝒊𝒕𝒕𝒍𝒆 ➽' +h["result"]["title"])
                                    client.sendVideoWithURL(to, h['result']['url'])
                        except Exception as e:
                                vin_gabut(to,"Done Like..!!!")
                        #=======[ New cmd ]
                    if saklar_media["smuledonwload2"] == True:
                        try:
                            regex = r'http[s]?://(?:[a-zA-Z]|[0-9]|[$-_@.&+]|[!*\(\),]|(?:%[0-9a-fA-F][0-9a-fA-F]))+'
                            links = re.findall(regex, text)
                            contact = client.getContact(sender)
                            n_links = []
                            for l in links:
                                if l not in n_links:
                                    n_links.append(l)
                            for ticket_id in n_links:
                                apiKey = apiKeyy
                                tz = pytz.timezone("Asia/Jakarta")
                                timeNow = datetime.now(tz=tz)
                                headers = {"apiKey": apiKey}
                                Zulget = requests.get("https://api.be-team.me/smule?url="+ticket_id,headers=headers)
                                h = json.loads(Zulget.text)
                                if h["result"]["type"] == "video":
                                    data = {"type":"flex","altText": "TEAM TERMUX V 13","contents":{"type": "bubble","size": "kilo","body": {"type": "box","layout": "vertical","contents": [{"type": "box","layout": "vertical","contents": [{"type": "box","layout": "horizontal","contents": [{"type": "box","layout": "vertical","contents": [{"type": "text","text": "{}".format(h["result"]["message"]),"size": "xxs"}] },{"type": "box","layout": "vertical","contents": [{ "type": "image","url": "https://img2.pngdownload.id/20180423/dze/kisspng-dots-computer-icons-button-encapsulated-postscript-dot-material-5add88a1f29574.9109267215244678739936.jpg","size": "full","aspectMode": "cover"}],"width": "10px","height": "10px"}]},{"type": "separator"},{"type": "box","layout": "horizontal", "contents": [{"type": "box","layout": "vertical","contents": [{ "type": "image","url": "{}".format(h["result"]["cover_url"]),"size": "full","aspectMode": "cover"}],"width": "45px","height": "45px"},{"type": "box","layout": "vertical","contents": [{"type": "box","layout": "vertical","contents": [{"type": "text","text": "{}".format(h["result"]["title"]),"size": "xs","align": "start","offsetStart": "5px"}]},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "{}".format(h["result"]["ensemble_type"]),"size": "xxs","align": "start","offsetStart": "5px"}]},{"type": "box","layout": "horizontal","contents": [{"type": "box","layout": "vertical","contents": [{"type": "text","text": "▶ {}".format(h["result"]["stats"]["total_listens"]),"size": "xxs","align": "center"}]},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "♡ {}".format(h["result"]["stats"]["total_loves"]),"size": "xxs","align": "center"}]}]}]}],"margin": "1px"},{"type": "box","layout": "horizontal","contents": [{"type": "box","layout": "vertical","contents": [{"type": "text","text": "Bergabung","size": "xs","align": "center","color": "#ffffff"}]},{"type": "box","layout": "vertical","contents": [{"type": "image","url": "https://cdn.iconscout.com/icon/premium/png-512-thumb/businessman-171-496360.png"}],"width": "20px","height": "20px","offsetEnd": "70px"}],"backgroundColor": "#20B2AA","cornerRadius": "4px","action": {"type": "uri","label": "action","uri": "{}".format(h["result"]["performed_by_url"])}}]}]},"styles": {"footer": {"separator": True}}}}
                                    sendTemplate(to,data)
                                    data={'type': 'video','originalContentUrl': h['result']['download_link'],'previewImageUrl': "https://yt3.ggpht.com/a/AATXAJwsOJZamUbx4cXjU1wujXyt7SO4Jr0kWW35zuDSsQ=s900-c-k-c0x00ffffff-no-rj"}
                                    sendTemplate(to, data)
                                else:
                                    data = {"type":"flex","altText": "TEAM TERMUX V 13","contents":{"type": "bubble","size": "kilo","body": {"type": "box","layout": "vertical","contents": [{"type": "box","layout": "vertical","contents": [{"type": "box","layout": "horizontal","contents": [{"type": "box","layout": "vertical","contents": [{"type": "text","text": "{}".format(h["result"]["message"]),"size": "xxs"}] },{"type": "box","layout": "vertical","contents": [{ "type": "image","url": "https://img2.pngdownload.id/20180423/dze/kisspng-dots-computer-icons-button-encapsulated-postscript-dot-material-5add88a1f29574.9109267215244678739936.jpg","size": "full","aspectMode": "cover"}],"width": "10px","height": "10px"}]},{"type": "separator"},{"type": "box","layout": "horizontal", "contents": [{"type": "box","layout": "vertical","contents": [{ "type": "image","url": "{}".format(h["result"]["cover_url"]),"size": "full","aspectMode": "cover"}],"width": "45px","height": "45px"},{"type": "box","layout": "vertical","contents": [{"type": "box","layout": "vertical","contents": [{"type": "text","text": "{}".format(h["result"]["title"]),"size": "xs","align": "start","offsetStart": "5px"}]},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "{}".format(h["result"]["ensemble_type"]),"size": "xxs","align": "start","offsetStart": "5px"}]},{"type": "box","layout": "horizontal","contents": [{"type": "box","layout": "vertical","contents": [{"type": "text","text": "▶ {}".format(h["result"]["stats"]["total_listens"]),"size": "xxs","align": "center"}]},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "♡ {}".format(h["result"]["stats"]["total_loves"]),"size": "xxs","align": "center"}]}]}]}],"margin": "1px"},{"type": "box","layout": "horizontal","contents": [{"type": "box","layout": "vertical","contents": [{"type": "text","text": "Bergabung","size": "xs","align": "center","color": "#ffffff"}]},{"type": "box","layout": "vertical","contents": [{"type": "image","url": "https://cdn.iconscout.com/icon/premium/png-512-thumb/businessman-171-496360.png"}],"width": "20px","height": "20px","offsetEnd": "70px"}],"backgroundColor": "#20B2AA","cornerRadius": "4px","action": {"type": "uri","label": "action","uri": "{}".format(h["result"]["performed_by_url"])}}]}]},"styles": {"footer": {"separator": True}}}}
                                    sendTemplate(to,data)
                                    client.sendAudioWithURL(to, h['result']['download_link'])
                        except Exception as e:
                                vin_gabut(to,"Done Like..!!!")

                #=====================================================================================================

                elif "https://timeline.line.me/post/" in text.lower():
                    if saklar_media["timelinedonwload"] == True:
                        regex = r'http[s]?://(?:[a-zA-Z]|[0-9]|[$-_@.&+]|[!*\(\),]|(?:%[0-9a-fA-F][0-9a-fA-F]))+'
                        links = re.findall(regex, text)
                        n_links = []
                        for l in links:
                            if l not in n_links:
                                n_links.append(l)
                        for ticket_id in n_links:
                            ve = requests.get("https://api.vhtear.com/timeline?link={}&apikey=K2021liproAngrus".format(str(ticket_id)))
                            h = json.loads(ve.text)
                            if h["result"] == 'image':
                                vinfooter(to, '「 Type timeline image 」\n\nTittle:' +h["result"]["desk"])
                                client.sendImageWithURL(to, h['result']['url'])
                            else:
                                vinfooter(to, '「 Type timeline video 」\n\nTittle:' +h["result"]["desk"])
                                client.sendVideoWithURL(to, h['result']['url'])

                elif "https://vt.tiktok.com/" in text.lower():
                    if saklar_media["tiktokdonwload"] == True:
                        regex = r'http[s]?://(?:[a-zA-Z]|[0-9]|[$-_@.&+]|[!*\(\),]|(?:%[0-9a-fA-F][0-9a-fA-F]))+'
                        links = re.findall(regex, text)
                        n_links = []
                        for l in links:
                            if l not in n_links:
                                n_links.append(l)
                        for ticket_id in n_links:
                            apiKey = apiKeyy
                            url = ticket_id
                            headers = {"apiKey": apiKey}
                            main = json.loads(requests.get("https://api.be-team.me/tiktok?url="+url,headers=headers).text)
                            client.sendVideoWithURL(to, main["result"]["video"]["bit_rate"][0]["play_addr"]["url_list"][1])

                elif "https://youtu.be/" in text.lower():
                    if saklar_media["yt_donwload"] == True:
                        try:
                            regex = r'http[s]?://(?:[a-zA-Z]|[0-9]|[$-_@.&+]|[!*\(\),]|(?:%[0-9a-fA-F][0-9a-fA-F]))+'
                            links = re.findall(regex, text)
                            n_links = []
                            for l in links:
                                if l not in n_links:
                                    n_links.append(l)
                            for ticket_id in n_links:
                                url = ticket_id
                                main = json.loads(requests.get("https://api.be-line.me/ytmp4?url="+url).text)
                                vintemp(to, main["result"]["title"])
                                client.sendVideoWithURL(to,main["result"]["url"])
                        except Exception as e:
                            vintemp(to,"Done Like..!")

                #========[ New Cmd ]
                elif cmd.startswith("zodiac"):
                    if msg._from in clientMID:
                        try:
                            sep = text.split(" ")
                            search = text.replace(sep[0] + " ","")
                            main = json.loads(requests.get("https://api.be-line.me/primbon/bintang?zodiac="+search).text)
                            ret_ = "「 Zodiac 」\n\n"
                            ret_ += "{}\n".format(str(main["result"]["information"]))
                            ret_ +="{}".format(str(main["result"]["zodiac"]))
                            client.sendImageWithURL(to,main["result"]["img"])
                            vintemp(to, ret_)
                        except Exception as error:
                            vintemp(to, str(error))

                elif cmd.startswith("joox"):
                    if msg._from in clientMID:
                        try:
                            x = text.split(" ")
                            y = text.replace(x[0] + " ","")
                            apiKey = apiKeyy
                            search = y
                            headers = {"apiKey": apiKey}
                            gambar = ('https://cdn.pixabay.com/photo/2016/01/16/01/00/blue-1142745_960_720.jpg','https://www.beautyppt.com/uploads/thumbnails/pink-cute-little-rabbit-ppt-background-picture.jpg','https://2.bp.blogspot.com/-Ti6nSl4Q5ew/TlI8aPr1LPI/AAAAAAAA2zY/8DqatrtX2j0/s1600/Powerpoint-Background-Templates.jpg','https://img.lovepik.com/photo/40113/0403.jpg_wh860.jpg','https://png.pngtree.com/thumb_back/fw800/back_our/20190621/ourmid/pngtree-cartoon-lake-water-meadow-blue-sky-background-material-fresh-picture-image_196913.jpg')
                            img = random.choice(gambar)
                            main = json.loads(requests.get("https://api.be-team.me/joox?search="+search,headers=headers).text)
                            data = {"type":"flex","altText": "TEAM TERMUX V 13","contents":{"type": "carousel","contents": [{"type": "bubble","size": "kilo","body": {"type": "box","layout": "vertical","contents": [{"type": "image","url": img,"size": "full","aspectMode": "cover","aspectRatio": "34:9","gravity": "top"},{ "type": "box","layout": "horizontal","contents": [{"type": "box","layout": "vertical","contents": [{"type": "image","url": main["result"][0]["album_url"],"size": "full","aspectMode": "cover"}],"width": "60px","height": "60px","cornerRadius": "5px","borderWidth": "1px","borderColor": "#ffffff"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "Artis: {}".format(main["result"][0]["artist"]),"size": "xxs","color": "#ffffff"},{"type": "text","text": "Judul: {}".format(main["result"][0]["title"]),"size": "xxs","color": "#ffffff"},{"type": "text","text": "Album: {}".format(main["result"][0]["malbum"]),"size": "xxs","color": "#ffffff"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "\"•TEAM TERMUX V 13•\"","size": "xs","color": "#ffffff","align": "center"}],"offsetStart": "70px","width": "130px"}]}],"position": "absolute","width": "255px","spacing": "md","paddingAll": "4px"}],"paddingAll": "0px","borderWidth": "1px","cornerRadius": "10px","borderColor": "#ffffff"}}]}}
                            sendTemplate(to,data)
                            client.sendAudioWithURL(to,main["result"][0]["mp3Url"])
                        except Exception as e:
                            vinfooter(to, str(e))

                elif cmd.startswith("artiname "):
                    if msg._from in clientMID:
                        try:
                            sep = msg.text.split(" ")
                            textnya = msg.text.replace(sep[0] + " ","")
                            result = requests.get("https://mnazria.herokuapp.com/api/arti?nama={}".format(textnya))
                            data = result.json()
                            vintemp2(to, str(data["result"]))
                        except Exception as e:
                            vintemp(to, str(e))

                #============================================================================================================

                elif cmd.startswith("wikipedia "):
                  if msg._from in clientMID:
                      try:
                          search = removeCmd("wikipedia", text)
                          wiki = WikiApi({'locale':'id'})
                          results = wiki.find(search)
                          for a in results:
                            ret_ = "Wikipedia :\n"
                            article = wiki.get_article(a)
                            if article.image is not None: client.sendImageWithURL(to,str(article.image))
                            ret_ += "\nTitle : {}".format(str(article.heading))
                            ret_ += "\nURL : {}".format(str(article.url))
                            ret_ += "\nSummary\n{}".format(str(article.summary.replace("^","")))
                            vintemp2(to,"{}".format(str(ret_)),)
                      except Exception as e:
                          vintemp2(to, str(e))

                elif cmd.startswith("img "):
                       query = removeCmd("img", text)
                       cond = query.split("|")
                       search = str(cond[0])
                       apiKey = apiKeyy
                       headers = {"apiKey": apiKey}
                       r = requests.get("https://api.be-team.me/googleimg?search="+search,headers=headers)
                       data=r.text
                       data=json.loads(r.text)
                       if data != []:
                           ret_ = []                                 
                           for food in data["result"]:
                               if len(ret_) >= 10:
                                   pass
                               else:
                                   ret_.append({"imageUrl": "{}".format(str(food)),"action": {"type": "uri","label": search,"uri": "line://app/1602687308-GXq4Vvk9?type=image&img={}".format(str(food))}})
                           k = len(ret_)//10
                           for aa in range(k+1):
                               data = {"type": "template","altText": "TEAM TERMUX V 13","template": {"type": "image_carousel","columns": ret_[aa*10 : (aa+1)*10]}}
                               sendTemplate(to, data)

                elif cmd.startswith("primary"):
                  if msg._from in clientMID:
                    try:
                        sep = text.split(" ")
                        auth = text.replace(sep[0] + " ","")
                        r = requests.get("http://beta.moe.team/api/generateAuthToken?auth={}&apikey=akX5Lq6pYaQnZ9Re60rnHEngiQGRXOkGR9kAg2qKN6tbQyotmJV2X4cj7iLR4rx7".format(str(auth)))
                        data=r.text
                        data=json.loads(r.text)
                        ret_ = "「 Token Primery 」"
                        ret_ += "\n\nStatus : "+str(data["message"])
                        ret_ += "\nToken : "+str(data["result"])
                        vinfooter(to, ret_)
                    except Exception as error:
                        vinfooter(to, str(error))

                elif cmd.startswith("ceksuhu"):
                  if msg._from in clientMID:
                    try:
                        sep = text.split(" ")
                        txt = text.replace(sep[0]+ " ","")
                        req = requests.get('https://dolphinapi.herokuapp.com/api/weather?city={}'.format(txt))
                        data = json.loads(req.text)
                        ret_ = "「 Weather 」"
                        ret_ += "\n♻️ City : " +str(data["result"]["city"])
                        ret_ += "\n♻️ Desc : " +str(data["result"]["desc"])
                        ret_ += "\n♻️ Humidity : " +str(data["result"]["humidity"])
                        ret_ += "\n♻️ Temprature : " +str(data["result"]["temprature"])
                        ret_ += "\n♻️ Weather : " +str(data["result"]["weather"])
                        vinfooter(to, str(ret_))
                    except Exception as error:
                        vinfooter(to, str(error))

                elif cmd.startswith("infoloker "):
                  if msg._from in clientMID:
                    try:
                        sep = text.split(" ")
                        txt = text.replace(sep[0]+ " ","")
                        req = requests.get('http://dolphinapi.herokuapp.com/api/indeed?city={}'.format(txt))
                        data = json.loads(req.text)
                        ret_ = "「 𝑰𝑵𝑭𝑶 𝑳𝑶𝑲𝑬𝑹 」"
                        for loker in data["result"]:
                            ret_ += "\n♻️ 𝑫𝒂𝒕𝒆 : {}".format(str(loker["date"]))
                            ret_ += "\n♻️ 𝑳𝒐𝒄𝒂𝒕𝒊𝒐𝒏 : {}".format(str(loker["location"]))
                            ret_ += "\n♻️ 𝑫𝒆𝒔𝒄𝒓𝒊𝒑𝒕𝒊𝒐𝒏 : {}".format(str(loker["title"]))
                            ret_ += "\n♻️ 𝑳𝒊𝒏𝒌 𝑱𝒐𝒃 : {}".format(str(loker["url"]))
                        vinfooter(to, str(ret_))
                    except Exception as error:
                        vinfooter(to, str(error))

                elif cmd.startswith("jadwaltv "):
                  if msg._from in clientMID:
                    try:
                        sep = text.split(" ")
                        query = text.replace(sep[0]+" ","")
                        req = requests.get("http://dolphinapi.herokuapp.com/api/television?channel={}".format(query))
                        data = req.json()
                        ret = "「 𝑱𝑨𝑫𝑾𝑨𝑳 𝑻𝑽 {} 」".format(query)
                        num = 0
                        for list in data["result"]:
                            num += 1
                            ret += "\n{}. ♻️ 𝑱𝒂𝒎 : {}".format(str(num), list["date"])
                            ret += "\n       ♻️ 𝑱𝒖𝒅𝒖𝒍 : {}".format(list["title"])
                        ret += "\n「 𝑻𝑽 𝑰𝑵𝑫𝑶𝑵𝑬??𝑰𝑨 」"
                        vintemp2(to,ret)
                    except Exception as error:
                        vintemp2(to, str(error))

                elif cmd == "dadjoke":
                  if msg._from in clientMID:
                    try:
                        count = random.randint(0,500)
                        r=requests.get("http://api.icndb.com/jokes/%s"%count)
                        data=r.text
                        data=json.loads(data)
                        client.sendMessage(to, str(data["value"]["joke"]))
                    except Exception as error:
                        vintemp2(to, str(error))

                elif cmd == "join.":
                    if msg._from in clientMID:
                                group = client.getGroup(to)
                                group.preventedJoinByTicket = False
                                client.updateGroup(group)
                                gurl = client.reissueGroupTicket(to)
                                rc = client.getContact(AM_backup['antijs']).mid
                                for x in rc:
                                    client.sendMessage2(x, "acc {}".format(str(gurl)))
                                time.sleep(1)
                                group.preventedJoinByTicket = True
                                client.updateGroup(group)
                elif cmd == "stay.":
                    if msg._from in clientMID:
                        for x in AM_backup['antijs']:
                            try:client.inviteIntoGroup(to, [x])
                            except:client.sendMessage(to, "i'm Limit")
                elif cmd == "cans.":
                    if msg._from in clientMID:
                        for x in AM_backup['antijs']:
                            try:client.cancelGroupInvitation(to, [x])
                            except:client.sendMessage(to, "Not found")
                elif cmd == "midajs":
                    if msg._from in clientMID:
                        for x in AM_backup['antijs']:
                            rd = client.getContact(x).mid
                            client.sendMessage(to, rd)
                elif "addajs " in cmd:
                            if msg._from in clientMID:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                  if target in AM_backup["antijs"]:
                                    vintemp(to,"was in antijs")
                                  else:
                                      try:
                                          AM_backup["antijs"].append(target)
                                          backupData()
                                          vintemp(to,"succes add to antijs")
                                      except:
                                          pass

                elif "delajs " in cmd:
                            if msg._from in clientMID:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                  if target not in AM_backup["antijs"]:
                                      vintemp(to,"Not In Antijs")
                                  else:
                                      try:
                                          AM_backup["antijs"].remove(target)
                                          backupData()
                                          vintemp(to,"succes removed")
                                      except:
                                          pass

                elif cmd == "ajslist" or text.lower() == 'ajs.':
                            if msg._from in clientMID:
                              if AM_backup["antijs"] == []:
                                vintemp(to,"empety")
                              else:
                                num = 1
                                mc = "「 antijs 」\n"
                                for me in AM_backup["antijs"]:
                                    mc += "\n %i.  %s" % (num, client.getContact(me).displayName)
                                    num = (num+1)
                                mc += "\n\n𝑻𝒐𝒕𝒂𝒍 %i ajs" % len(AM_backup["antijs"])
                                vintemp(to,"{}".format(str(mc)))

                elif cmd == "clearajs" or text.lower() == 'clear ajs':
                            if msg._from in clientMID:
                              ang = client.getContacts(AM_backup["antijs"])
                              mc = "%i antijs " % len(ang)
                              vintemp(to,"𝑪𝒍𝒆𝒂𝒓 {}".format(str(mc)))
                              AM_backup["antijs"] = []

                elif cmd.startswith("cekip"):
                  if msg._from in clientMID:
                    try:
                        sep = text.split(" ")
                        search = text.replace(sep[0] + " ","")
                        r = requests.get("https://mnazria.herokuapp.com/api/cek?ip={}".format(str(search)))
                        data=r.text
                        data= json.loads(data)
                        ret_ = "「 𝑰𝑵𝑭𝑶 𝑺𝑬𝑹𝑽𝑬𝑹 」\n"
                        ret_ += "\n♻️ City : {}".format(str(data["city"]))
                        ret_ += "\n♻️ Region : {}".format(str(data["region"]))
                        ret_ += "\n♻️ Country : {}".format(str(data["country"]))
                        ret_ += "\n♻️ Postal Code : {}".format(str(data["postal"]))
                        ret_ += "\n♻️ Region Code : {}".format(str(data["region_code"]))
                        ret_ += "\n♻️ Country Code : {}".format(str(data["country_calling_code"]))
                        ret_ += "\n♻️ Country Name : {}".format(str(data["country_name"]))
                        ret_ += "\n♻️ Currency : {}".format(str(data["currency"]))
                        ret_ += "\n♻️ Language : {}".format(str(data["languages"]))
                        ret_ += "\n♻️ Timezone : {}".format(str(data["region"]))
                        ret_ += "\n♻️ Latitude : {}".format(str(data["latitude"]))
                        ret_ += "\n♻️ Longitude : {}".format(str(data["longitude"]))
                        ret_ += "\n♻️ IP Address: {}".format(str(data["ip"]))
                        ret_ += "\n♻️ Company : {}".format(str(data["org"]))
                        vinfooter(to, str(ret_))
                    except Exception as error:
                        vinfooter(to, str(error))

                elif cmd.startswith("youtube"):
                  if msg._from in clientMID:
                    try:
                        contact = client.getContact(clientMID)
                        sep = text.split(" ")
                        search = text.replace(sep[0] + " ","")
                        r = requests.get("https://www.googleapis.com/youtube/v3/search?part=snippet&maxResults=10&q={}&type=video&key=AIzaSyB7Zb9VteS6NsZFPY41FhGRzvMzAc3HBpM".format(str(search)))
                        data = r.text
                        a = json.loads(data)
                        if a["items"] != []:
                            ret_ = []
                            yt = []
                            for music in a["items"]:
                                ret_.append({"type": "bubble","size": "micro","body": {"type": "box","layout": "vertical","contents": [{"type": "box","layout": "horizontal","contents": [{"type": "box","layout": "horizontal","contents": [{"type": "image","url": "https://smkalhusainkeling.sch.id/wp-content/uploads/2019/10/youtube.png","size": "full","aspectMode": "cover"}],"width": "35px","height": "35px"},{"type": "separator","color": "#D2691E"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "𝑴𝑬𝑫𝑰𝑨 𝒀𝑶𝑼𝑻𝑼𝑩𝑬","size": "xs","color": "#ffffff","align": "center"},{"type": "separator","color": "#D2691E"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "{}".format(contact.displayName),"size": "xs","color": "#ffffff","align": "center"}]}]}],"backgroundColor": "#008B8B"},{"type": "separator","color": "#D2691E"},{"type": "box","layout": "vertical","contents": [{"type": "image","url": "https://i.ytimg.com/vi/{}/maxresdefault.jpg".format(music['id']['videoId']),"size": "full","aspectMode": "fit","aspectRatio": "16:9"}]},{"type": "separator","color": "#D2691E"},{"type": "box","layout": "horizontal","contents": [{"type": "box","layout": "vertical","contents": [{"type": "text","text": "Donw Mp4","size": "xs","color": "#ffffff","align": "center"}],"backgroundColor": "#B8860B","action": {"type": "uri","label": "action","uri": "line://app/1602687308-GXq4Vvk9?type=text&text=Get%20video%20https://www.youtube.com/watch?v={}".format(str(music['id']['videoId']))}},{"type": "separator","color": "#D2691E"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "Donw Mp3","size": "xs","color": "#ffffff","align": "center"}],"backgroundColor": "#DC143C","action": {"type": "uri","label": "action","uri": "line://app/1602687308-GXq4Vvk9?type=text&text=Get%20mp3%20https://www.youtube.com/watch?v={}".format(str(music['id']['videoId']))}}]},{"type": "separator","color": "#D2691E"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "Title video","size": "xs","color": "#ffffff","align": "center"}],"backgroundColor": "#006400"},{"type": "separator","color": "#D2691E"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "%s" % music['snippet']['title'],"size": "xxs","color": "#ffffff","offsetStart": "3px","wrap": True}],"height": "45px"},{"type": "separator","color": "#D2691E"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "𝑪𝑯𝑨𝑵𝑬𝑳 𝒀𝑶𝑼𝑻𝑼𝑩𝑬","size": "xs","color": "#ffffff","align": "center"}],"backgroundColor": "#008B8B","action": {"type": "uri","label": "action","uri": "line://app/1602687308-GXq4Vvk9?type=text&text=Get%20video%20https://www.youtube.com/watch?v={}".format(str(music['id']['videoId']))}}],"paddingAll": "0px","backgroundColor": "#000000","borderWidth": "1px","borderColor": "#D2691E","cornerRadius": "10px"}})
                                yt.append('https://youtu.be/'+music['id']['videoId'])
                            k = len(ret_)//10
                            for aa in range(k+1):
                              data = {"type": "flex","altText": "TEAM TERMUX V 13","contents": {"type": "carousel","contents": ret_[aa*10 : (aa+1)*10]}}
                              sendTemplate(to, data)
                    except Exception as error:
                        vinfooter(to, str(error))

                elif cmd.startswith("ytsearch"):
                  if msg._from in clientMID:
                    try:
                        contact = client.getContact(clientMID)
                        sep = text.split(" ")
                        search = text.replace(sep[0] + " ","")
                        r = requests.get("https://www.googleapis.com/youtube/v3/search?part=snippet&maxResults=10&q={}&type=video&key=AIzaSyB7Zb9VteS6NsZFPY41FhGRzvMzAc3HBpM".format(str(search)))
                        data = r.text
                        a = json.loads(data)
                        if a["items"] != []:
                            ret_ = []
                            yt = []
                            for music in a["items"]:
                                ret_.append({"type": "bubble","size": "kilo","body": {"type": "box","layout": "vertical","contents": [{"type": "image","url": "https://image.freepik.com/free-psd/abstract-background-design_1297-87.jpg","size": "full","aspectMode": "cover","aspectRatio": "1:1","gravity": "center"},{"type": "box","layout": "vertical","contents": [{"type": "box","layout": "vertical","contents": [{"type": "image","url": "https://i.ytimg.com/vi/{}/maxresdefault.jpg".format(music['id']['videoId']),"size": "full","aspectMode": "cover","aspectRatio": "16:9"}],"cornerRadius": "5px"},{"type": "box","layout": "horizontal","contents": [{"type": "box","layout": "vertical","contents": [{"type": "box","layout": "vertical","contents": [{"type": "spacer"}],"width": "20px","height": "9px","cornerRadius": "3px","backgroundColor": "#00FFFF20"},{"type": "box","layout": "vertical","contents": [{"type": "spacer"}],"width": "20px","height": "9px","cornerRadius": "30px","backgroundColor": "#00FFFF","margin": "sm"},{"type": "box","layout": "vertical","contents": [{"type": "spacer"}],"width": "20px","height": "9px","backgroundColor": "#00FFFF","cornerRadius": "3px","margin": "sm"},{"type": "box","layout": "vertical","contents": [{"type": "spacer"}],"width": "20px","height": "9px","backgroundColor": "#00FFFF","cornerRadius": "3px","margin": "sm"}],"width": "30px"},{"type": "box","layout": "vertical","contents": [{"type": "box","layout": "vertical","contents": [{"type": "text","text": "TEAM TERMUX V 13","size": "sm","color": "#FFA500"}]},{"type": "separator","color": "#FFA50050"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "%s" % music['snippet']['title'],"size": "xs","color": "#FFA50070"}]}],"offsetTop": "8px"}],"offsetTop": "5px","height": "55px"},{"type": "box","layout": "horizontal","contents": [{"type": "box","layout": "vertical","contents": [{"type": "text","text": "𝑪 𝑳 𝑰 𝑪 𝑲   𝑯 𝑬 𝑹 𝑬","size": "md","color": "#FFFFFF50","weight": "bold","style": "normal","offsetTop": "10px","align": "center"}]}],"height": "45px","borderWidth": "2px","borderColor": "#FFFFFF40","cornerRadius": "5px","backgroundColor": "#FF450010","margin": "md","action": {"type": "uri","label": "action","uri": "line://app/1602687308-GXq4Vvk9?type=text&text=Get%20video%20https://www.youtube.com/watch?v={}".format(str(music['id']['videoId']))}}],"position": "absolute","width": "250px","offsetStart": "5px","offsetTop": "5px"}],"paddingAll": "0px"}})
                                yt.append('https://www.youtube.com/watch?v='+music['id']['videoId'])
                            k = len(ret_)//10
                            for aa in range(k+1):
                                data = {"type": "flex","altText": "Achink_Ganteng","contents": {"type": "carousel","contents": ret_[aa*10 : (aa+1)*10]}}
                                sendTemplate(to, data)
                    except Exception as error:
                        vinfooter(to, str(error))

                elif cmd.startswith("get mp3"):
                    if msg._from in clientMID:
                        sep = text.split(" ")
                        txt = text.replace(sep[0] + " ","")
                        url = txt
                        main = json.loads(requests.get("https://api.be-line.me/ytmp4?url="+url).text)
                        vinfooter(to, main["result"]["title"])
                        client.sendVideoWithURL(to,main["result"]["url"])

                elif cmd.startswith("get video"):
                    if msg._from in clientMID:
                        sep = text.split(" ")
                        txt = msg.text.replace(sep[0] + " ","")
                        main = json.loads(requests.get("https://api.be-line.me/ytmp4?url="+txt).text)
                        vinfooter(to, main["result"]["title"])
                        client.sendVideoWithURL(to,main["result"]["url"])

                elif cmd.startswith("vin1 "):
                  if msg._from in clientMID:
                    try:
                        sep = text.split(" ")
                        txt = text.replace(sep[0] + " ","")
                        url = "https://rest.farzain.com/api/special/fansign/cosplay/cosplay.php?apikey=nda12345&text={}".format(txt)
                        client.sendImageWithURL(to,"{}".format(str(url)))
                    except Exception as error:
                        vinfooter(to, str(error))

                elif cmd.startswith("vin2"):
                  if msg._from in clientMID:
                    try:
                        sep = text.split(" ")
                        txt = text.replace(sep[0] + " ","")
                        url = "https://rest.farzain.com/api/special/fansign/indo/viloid.php?apikey=aguzzzz748474848&beta&text={}".format(txt)
                        client.sendImageWithURL(to,"{}".format(str(url)))
                    except Exception as error:
                        achinkZul(to, str(error))

                if cmd.startswith("ceknote "):
                    try:
                        if msg._from in [clientMID]:
                          data = client.getGroupPost(to)
                          try:
                              music = data['result']['feeds'][int(cmd.split(' ')[2]) - 1]
                              b = [music['post']['userInfo']['writerMid']]
                              try:
                                for a in music['post']['contents']['textMeta']:b.append(a['mid'])
                              except:pass
                              try:
                                  g= "\n\nDescription:\n"+str(music['post']['contents']['text'].replace('@','@!'))
                              except:
                                  g=""
                              a="\nTotal like: "+str(music['post']['postInfo']['likeCount'])
                              a +="\nTotal comments: "+str(music['post']['postInfo']['commentCount'])
                              gtime = music['post']['postInfo']['createdTime']
                              a +="\nCreated at: "+str(humanize.naturaltime(datetime.fromtimestamp(gtime/1000)))
                              a += g
                              zx = ""
                              zxc = " 「 Cek note 」\n\nPenulist : @!"+a
                              try:
                                client.sendMention(to,zxc,'',b)
                              except Exception as e:
                                client.sendMessage(to, str(e))
                              try:
                                for c in music['post']['contents']['media']:
                                  params = {'userMid': client.getProfile().mid, 'oid': c['objectId']}
                                  s = client.server.urlEncode(client.server.LINE_OBS_DOMAIN, '/myhome/h/download.nhn', params)
                                  if 'PHOTO' in c['type']:
                                    try:
                                      footerimg(to,s,wait)
                                    except:pass
                                  else:
                                      pass
                                  if 'VIDEO' in c['type']:
                                    try:
                                      footervideo(to,s,wait)
                                    except:pass
                                  else:
                                      pass
                              except:
                                    pass
                          except Exception as e:
                            return client.sendMessage(to,"「 Auto Respond 」\n"+str(e))
                    except Exception as e:print(e)

                elif cmd.startswith("lirik "):
                  if msg._from in clientMID:
                    try:
                        sep = text.split(" ")
                        search = text.replace(sep[0] + " ","")
                        result = requests.get("http://dolphinapi.herokuapp.com/api/lyric?query={}".format(str(search)))
                        data = result.text
                        data = json.loads(data)
                        ret_ = "「 𝑹𝒆𝒔𝒖𝒍𝒕 𝑳𝒊𝒓𝒊𝒌 」\n"
                        ret_ += "\n{}".format(str(data["result"]["lyric"]))     
                        vintemp2(to, str(ret_))
                    except:
                        vintemp2(to, "𝑴𝒂𝒂𝒇 𝑳𝒊𝒓𝒊𝒌 𝑻𝒊𝒅𝒂𝒌 𝑫𝒊 𝑻𝒆𝒎𝒖𝒌𝒂𝒏...")

                elif cmd.startswith("icak"):
                  if msg._from in clientMID:
                    try:
                        api = requests.get("http://beta.moe.team/api/1cak?apikey=vbGQAF0HvTkqk7SSLnx65s4tLr3HdtBasXldbkU2eBWIHlEiTvv4GSbhQs3AMvAw")
                        data = api.text
                        data = json.loads(data)
                        vintemp2(to,"「 Icak random 」\n\nTitle : {}".format(data["result"]["title"]))
                        client.sendImageWithURL(to, str(data["result"]["image"]))
                    except Exception as e:
                        vintemp2(to, str(e))

                elif cmd.startswith("sifatname "):
                  if msg._from in clientMID:
                    try:
                        sep = msg.text.split(" ")
                        textnya = msg.text.replace(sep[0] + " ","")
                        main = json.loads(requests.get("https://api.be-line.me/primbon/nama?nama="+textnya).text)
                        ret_ = "「 𝑺𝑰𝑭𝑨𝑻 𝑲𝑨𝑴𝑼 」\n"
                        ret_ += "\n{}".format(main["result"])
                        vintemp2(to, ret_)
                    except Exception as e:
                        vintemp2(to, str(e))

                elif cmd.startswith("nekopoipage "):
                  if msg._from in clientMID:
                    try:
                        sep = text.split(" ")
                        query = text.replace(sep[0] + " ","")
                        cond = query.split("|")
                        search = str(cond[0])
                        r = requests.get("https://zembut.herokuapp.com/api/nekopoi/?page={}".format(str(search)))
                        data = r.text
                        data = json.loads(data)
                        if len(cond) == 1:
                          num = 0
                          ret_ = "「 Result Nekopoi 」"
                          for neko in data["results"]:
                              num += 1
                              ret_ += "\n\n{}. {}".format(str(num), str(neko["title"]))
                              ret_ += "\nTotal {} Nekopoi ".format(str(len(data["results"])))
                              ret_ += "\n\nFor See Details Nekopoi\nPlease Use Command {}Nekopoipage {}|Num".format(str(setKey), str(search))
                              vinfooter(to, ret_)
                    except Exception as error:
                      vinfooter(to, str(error))



       #     =======[ Convert token ]
                elif cmd.startswith("helptoken"):
                  if msg._from in clientMID:
                      try:
                          ret_ ="◉ convertiospad \n"
                          ret_ +="◉ condesktopmac \n"
                          ret_ +="◉ condesktopwin \n"
                          ret_ +="◉ conchromeos \n"
                          ret_ +="◉ conandroidlite \n"
                          ret_ +="◉ desktopmac\n"
                          ret_ +="◉ desktopwin\n"
                          ret_ +="◉ iosipad"
                          achinkZul1(to, ret_)
                      except Exception as e:
                          vinfooter(to, str(e))
       #     =======[ publik token ]

                elif cmd.startswith("desktopmac"):
                        try:
                            apiKey = "ISO-8859-1,utf-8;q=0.7,*;q=0.7"
                            headers = {
                            "apiKey":apiKey,
                            "appName": "DESKTOPMAC\t5.21.3\tMac Os\t10.15.2",
                            "cert" : None,
                            "server": random.choice(["pool-1","pool-2"]),
                            "sysname": "ALVINO~BAIHAQI"}
                            main = json.loads(requests.get("https://api.be-team.me/qrv2",headers=headers).text)
                            client.sendMessage(to,"QR Link: " + main["result"]["qr_link"])
                            if not headers["cert"]:
                                result = json.loads(requests.get(main["result"]["cb_pincode"],headers=headers).text)
                                client.sendMessage(to,"Pincode: " + result["result"])
                                result = json.loads(requests.get(main["result"]["cb_token"],headers=headers).text)
                            if result["status"] != 200:
                                client.sendMessage(to,"[ Error ] "+ result["reason"])
                            else:
                                mt = result["result"]["token"]
                                vinfooter(to, mt)
                        except Exception as e:
                            vinfooter(to, "{}".format(e))

                elif cmd.startswith("desktopwin"):
                        try:
                            apiKey = "ISO-8859-1,utf-8;q=0.7,*;q=0.7"
                            headers = {
                            "apiKey":apiKey,
                            "appName": "DESKTOPWIN\t5.21.3\tWindows\t10",
                            "cert" : None,
                            "server": random.choice(["pool-1","pool-2"]),
                            "sysname": "ALVINO~BAIHAQI"}
                            main = json.loads(requests.get("https://api.be-team.me/qrv2",headers=headers).text)
                            vinfooter(to,"QR Link: " + main["result"]["qr_link"])
                            if not headers["cert"]:
                                result = json.loads(requests.get(main["result"]["cb_pincode"],headers=headers).text)
                                vinfooter(to,"Pincode: " + result["result"])
                                result = json.loads(requests.get(main["result"]["cb_token"],headers=headers).text)
                            if result["status"] != 200:
                                vinfooter(to,"[ Error ] "+ result["reason"])
                            else:
                                mt = result["result"]["token"]
                                vinfooter(to, mt)
                        except Exception as e:
                            vinfooter(to, "{}".format(e))

                elif cmd.startswith("iosipad"):
                        try:
                            apiKey = "ISO-8859-1,utf-8;q=0.7,*;q=0.7"
                            headers = {
                            "apiKey":apiKey,
                            "appName": "IOSIPAD\t10.1.1\tiPhone 8\t11.2.5",
                            "cert" : None,
                            "server": random.choice(["pool-1","pool-2"]),
                            "sysname": "ALVINO~BAIJAQI"}
                            main = json.loads(requests.get("https://api.be-team.me/qrv2",headers=headers).text)
                            vinfooter(to,"QR Link: " + main["result"]["qr_link"])
                            if not headers["cert"]:
                                result = json.loads(requests.get(main["result"]["cb_pincode"],headers=headers).text)
                                vinfooter(to,"Pincode: " + result["result"])
                                result = json.loads(requests.get(main["result"]["cb_token"],headers=headers).text)
                            if result["status"] != 200:
                                vinfooter(to,"[ Error ] "+ result["reason"])
                            else:
                                mt = result["result"]["token"]
                                vinfooter(to, mt)
                        except Exception as e:
                            vinfooter(to, "{}".format(e))

       #     =======[ Convert token ]

                elif cmd.startswith("convertiospad"):
                  if msg._from in clientMID:
                    try:
                        x = text.split(" ")
                        y = text.replace(x[0] + " ","")
                        apiKey = "ISO-8859-1,utf-8;q=0.7,*;q=0.7"
                        headers = {"apiKey": apiKey,"appName": "IOSIPAD\t10.5.2\tiPhone 8\t11.2.5","server": random.choice(["pool-1","pool-2"]),"sysname": "LP-BOTS","authToken": y}
                        main = json.loads(requests.get("https://api.be-team.me/primary2secondary",headers=headers).text)
                        if main["status"] != 200:
                            vinfooter(to,"「 Convert failed 」\n" + main["reason"])
                        else:
                            vinfooter(to,"「 Convert Primary」\n\nYour Token: " + main["result"]["token"])
                    except Exception as e:
                        vinfooter(to, str(e))

                elif cmd.startswith("condesktopmac"):
                  if msg._from in clientMID:
                    try:
                        x = text.split(" ")
                        y = text.replace(x[0] + " ","")
                        apiKey = "ISO-8859-1,utf-8;q=0.7,*;q=0.7"
                        headers = {"apiKey": apiKey,"appName": "DESKTOPMAC\t5.21.3\tMac Os\t10.15.2","server": random.choice(["pool-1","pool-2"]),"sysname": "LP-BOTS","authToken": y}
                        main = json.loads(requests.get("https://api.be-team.me/primary2secondary",headers=headers).text)
                        if main["status"] != 200:
                            vinfooter(to,"「 Convert failed 」\n" + main["reason"])
                        else:
                            vinfooter(to,"「 Convert Primary」\n\nYour Token: " + main["result"]["token"])
                    except Exception as e:
                        vinfooter(to, str(e))

                elif cmd.startswith("condesktopwin"):
                  if msg._from in clientMID:
                    try:
                        x = text.split(" ")
                        y = text.replace(x[0] + " ","")
                        apiKey = "ISO-8859-1,utf-8;q=0.7,*;q=0.7"
                        headers = {"apiKey": apiKey,"appName": "DESKTOPWIN\t5.21.3\tWindows\t10","server": random.choice(["pool-1","pool-2"]),"sysname": "LP-BOTS","authToken": y}
                        main = json.loads(requests.get("https://api.be-team.me/primary2secondary",headers=headers).text)
                        if main["status"] != 200:
                            vinfooter(to,"「 Convert failed 」\n" + main["reason"])
                        else:
                            vinfooter(to,"「 Convert Primary」\n\nYour Token: " + main["result"]["token"])
                    except Exception as e:
                        vinfooter(to, str(e))

                elif cmd.startswith("conchromeos"):
                  if msg._from in clientMID:
                    try:
                        x = text.split(" ")
                        y = text.replace(x[0] + " ","")
                        apiKey = "ISO-8859-1,utf-8;q=0.7,*;q=0.7"
                        headers = {"apiKey": apiKey,"appName": "chrome\t2.3.2\tChrome OS\t1","server": random.choice(["pool-1","pool-2"]),"sysname": "LP-BOTS","authToken": y}
                        main = json.loads(requests.get("https://api.be-team.me/primary2secondary",headers=headers).text)
                        if main["status"] != 200:
                            vinfooter(to,"「 Convert failed 」\n" + main["reason"])
                        else:
                            vinfooter(to,"「 Convert Primary」\n\nYour Token: " + main["result"]["token"])
                    except Exception as e:
                        vinfooter(to, str(e))

                elif cmd.startswith("conandroidlite"):
                  if msg._from in clientMID:
                    try:
                        x = text.split(" ")
                        y = text.replace(x[0] + " ","")
                        apiKey = "ISO-8859-1,utf-8;q=0.7,*;q=0.7"
                        headers = {"apiKey": apiKey,"appName": "android_lite\t2.14.0\tAndroid OS\t5.1.1","server": random.choice(["pool-1","pool-2"]),"sysname": "LP-BOTS","authToken": y}
                        main = json.loads(requests.get("https://api.be-team.me/primary2secondary",headers=headers).text)
                        if main["status"] != 200:
                            vinfooter(to,"「 Convert failed 」\n" + main["reason"])
                        else:
                            vinfooter(to,"「 Convert Primary」\n\nYour Token: " + main["result"]["token"])
                    except Exception as e:
                        vinfooter(to, str(e))

       #     =======[ Fotonia is text ]
                elif cmd.startswith("photofunia"):
                    if msg._from in clientMID:
                      try:
                          ret_ ="◉ pf1 text\n"
                          ret_ +="◉ pf2 text\n"
                          ret_ +="◉ pf3 text\n"
                          ret_ +="◉ pf4 text\n"
                          ret_ +="◉ pf5 text\n"
                          ret_ +="◉ pf6 text\n"
                          ret_ +="◉ pf7 text\n"
                          ret_ +="◉ pf8 text\n"
                          ret_ +="◉ pf9 text\n"
                          ret_ +="◉ pf10 text\n"
                          ret_ +="◉ pf11 text\n"
                          ret_ +="◉ pf12 text\n"
                          ret_ +="◉ pf13 text"
                          rett_ ="◉ pf14 text\n"
                          rett_ +="◉ pf15 text\n"
                          rett_ +="◉ pf16 text\n"
                          rett_ +="◉ pf17 text\n"
                          rett_ +="◉ pf18 text\n"
                          rett_ +="◉ pf19 text\n"
                          rett_ +="◉ pf20 text\n"
                          rett_ +="◉ pft |text|@\n"
                          rett_ +="◉ pfn @"
                          achinkZul2(to, ret_, rett_)
                      except Exception as e:
                          vinfooter(to, str(e))
                elif cmd.startswith("pf1"):
                  if msg._from in clientMID:
                    try:
                        x = text.split(" ")
                        y = text.replace(x[0] + " ","")
                        apiKey = "ISO-8859-1,utf-8;q=0.7,*;q=0.7"
                        category_list = ['christmas-writing']
                        category = random.choice(category_list)
                        text = y
                        headers = {"apiKey": apiKey}
                        main = json.loads(requests.get("https://api.be-team.me/photofunia2?category="+category+"&text="+text,headers=headers).text)
                        client.sendImageWithURL(to, main["result"]["image"])
                    except Exception as e:
                        vinfooter(to, str(e))

                elif cmd.startswith("pf2"):
                  if msg._from in clientMID:
                    try:
                        x = text.split(" ")
                        y = text.replace(x[0] + " ","")
                        apiKey = "ISO-8859-1,utf-8;q=0.7,*;q=0.7"
                        category_list = ['beach-sign']
                        category = random.choice(category_list)
                        text = y
                        headers = {"apiKey": apiKey}
                        main = json.loads(requests.get("https://api.be-team.me/photofunia2?category="+category+"&text="+text,headers=headers).text)
                        client.sendImageWithURL(to, main["result"]["image"])
                    except Exception as e:
                        vinfooter(to, str(e))

                elif cmd.startswith("pf3"):
                  if msg._from in clientMID:
                    try:
                        x = text.split(" ")
                        y = text.replace(x[0] + " ","")
                        apiKey = "ISO-8859-1,utf-8;q=0.7,*;q=0.7"
                        category_list = ['yacht']
                        category = random.choice(category_list)
                        text = y
                        headers = {"apiKey": apiKey}
                        main = json.loads(requests.get("https://api.be-team.me/photofunia2?category="+category+"&text="+text,headers=headers).text)
                        client.sendImageWithURL(to, main["result"]["image"])
                    except Exception as e:
                        vinfooter(to, str(e))

                elif cmd.startswith("pf4"):
                  if msg._from in clientMID:
                    try:
                        x = text.split(" ")
                        y = text.replace(x[0] + " ","")
                        apiKey = "ISO-8859-1,utf-8;q=0.7,*;q=0.7"
                        category_list = ['water-writing']
                        category = random.choice(category_list)
                        text = y
                        headers = {"apiKey": apiKey}
                        main = json.loads(requests.get("https://api.be-team.me/photofunia2?category="+category+"&text="+text,headers=headers).text)
                        client.sendImageWithURL(to, main["result"]["image"])
                    except Exception as e:
                        vinfooter(to, str(e))

                elif cmd.startswith("pf5"):
                  if msg._from in clientMID:
                    try:
                        x = text.split(" ")
                        y = text.replace(x[0] + " ","")
                        apiKey = "ISO-8859-1,utf-8;q=0.7,*;q=0.7"
                        category_list = ['bracelet']
                        category = random.choice(category_list)
                        text = y
                        headers = {"apiKey": apiKey}
                        main = json.loads(requests.get("https://api.be-team.me/photofunia2?category="+category+"&text="+text,headers=headers).text)
                        client.sendImageWithURL(to, main["result"]["image"])
                    except Exception as e:
                        vinfooter(to, str(e))

                elif cmd.startswith("pf6"):
                  if msg._from in clientMID:
                    try:
                        x = text.split(" ")
                        y = text.replace(x[0] + " ","")
                        apiKey = "ISO-8859-1,utf-8;q=0.7,*;q=0.7"
                        category_list = ['light-graffiti']
                        category = random.choice(category_list)
                        text = y
                        headers = {"apiKey": apiKey}
                        main = json.loads(requests.get("https://api.be-team.me/photofunia2?category="+category+"&text="+text,headers=headers).text)
                        client.sendImageWithURL(to, main["result"]["image"])
                    except Exception as e:
                        vinfooter(to, str(e))

                elif cmd.startswith("pf7"):
                  if msg._from in clientMID:
                    try:
                        x = text.split(" ")
                        y = text.replace(x[0] + " ","")
                        apiKey = "ISO-8859-1,utf-8;q=0.7,*;q=0.7"
                        category_list = ['street-sign']
                        category = random.choice(category_list)
                        text = y
                        headers = {"apiKey": apiKey}
                        main = json.loads(requests.get("https://api.be-team.me/photofunia2?category="+category+"&text="+text,headers=headers).text)
                        client.sendImageWithURL(to, main["result"]["image"])
                    except Exception as e:
                        vinfooter(to, str(e))

                elif cmd.startswith("pf8"):
                  if msg._from in clientMID:
                    try:
                        x = text.split(" ")
                        y = text.replace(x[0] + " ","")
                        apiKey = "ISO-8859-1,utf-8;q=0.7,*;q=0.7"
                        category_list = ['cemetery-gates']
                        category = random.choice(category_list)
                        text = y
                        headers = {"apiKey": apiKey}
                        main = json.loads(requests.get("https://api.be-team.me/photofunia2?category="+category+"&text="+text,headers=headers).text)
                        client.sendImageWithURL(to, main["result"]["image"])
                    except Exception as e:
                        vinfooter(to, str(e))

                elif cmd.startswith("pf9"):
                  if msg._from in clientMID:
                    try:
                        x = text.split(" ")
                        y = text.replace(x[0] + " ","")
                        apiKey = "ISO-8859-1,utf-8;q=0.7,*;q=0.7"
                        category_list = ['plane-banner']
                        category = random.choice(category_list)
                        text = y
                        headers = {"apiKey": apiKey}
                        main = json.loads(requests.get("https://api.be-team.me/photofunia2?category="+category+"&text="+text,headers=headers).text)
                        client.sendImageWithURL(to, main["result"]["image"])
                    except Exception as e:
                        vinfooter(to, str(e))

                elif cmd.startswith("pf10"):
                  if msg._from in clientMID:
                    try:
                        x = text.split(" ")
                        y = text.replace(x[0] + " ","")
                        apiKey = "ISO-8859-1,utf-8;q=0.7,*;q=0.7"
                        category_list = ['love-lock']
                        category = random.choice(category_list)
                        text = y
                        headers = {"apiKey": apiKey}
                        main = json.loads(requests.get("https://api.be-team.me/photofunia2?category="+category+"&text="+text,headers=headers).text)
                        client.sendImageWithURL(to, main["result"]["image"])
                    except Exception as e:
                        vinfooter(to, str(e))

                elif cmd.startswith("pf11"):
                  if msg._from in clientMID:
                    try:
                        x = text.split(" ")
                        y = text.replace(x[0] + " ","")
                        apiKey = "ISO-8859-1,utf-8;q=0.7,*;q=0.7"
                        category_list = ['fortune-cookie']
                        category = random.choice(category_list)
                        text = y
                        headers = {"apiKey": apiKey}
                        main = json.loads(requests.get("https://api.be-team.me/photofunia2?category="+category+"&text="+text,headers=headers).text)
                        client.sendImageWithURL(to, main["result"]["image"])
                    except Exception as e:
                        vinfooter(to, str(e))

                elif cmd.startswith("pf12"):
                  if msg._from in clientMID:
                    try:
                        x = text.split(" ")
                        y = text.replace(x[0] + " ","")
                        apiKey = "ISO-8859-1,utf-8;q=0.7,*;q=0.7"
                        category_list = ['frosty-window-writing']
                        category = random.choice(category_list)
                        text = y
                        headers = {"apiKey": apiKey}
                        main = json.loads(requests.get("https://api.be-team.me/photofunia2?category="+category+"&text="+text,headers=headers).text)
                        client.sendImageWithURL(to, main["result"]["image"])
                    except Exception as e:
                        vinfooter(to, str(e))

                elif cmd.startswith("pf13"):
                  if msg._from in clientMID:
                    try:
                        x = text.split(" ")
                        y = text.replace(x[0] + " ","")
                        apiKey = "ISO-8859-1,utf-8;q=0.7,*;q=0.7"
                        category_list = ['einstein']
                        category = random.choice(category_list)
                        text = y
                        headers = {"apiKey": apiKey}
                        main = json.loads(requests.get("https://api.be-team.me/photofunia2?category="+category+"&text="+text,headers=headers).text)
                        client.sendImageWithURL(to, main["result"]["image"])
                    except Exception as e:
                        vinfooter(to, str(e))

                elif cmd.startswith("pf14"):
                  if msg._from in clientMID:
                    try:
                        x = text.split(" ")
                        y = text.replace(x[0] + " ","")
                        apiKey = "ISO-8859-1,utf-8;q=0.7,*;q=0.7"
                        category_list = ['lipstick-writing']
                        category = random.choice(category_list)
                        text = y
                        headers = {"apiKey": apiKey}
                        main = json.loads(requests.get("https://api.be-team.me/photofunia2?category="+category+"&text="+text,headers=headers).text)
                        client.sendImageWithURL(to, main["result"]["image"])
                    except Exception as e:
                        vinfooter(to, str(e))

                elif cmd.startswith("pf15"):
                  if msg._from in clientMID:
                    try:
                        x = text.split(" ")
                        y = text.replace(x[0] + " ","")
                        apiKey = "ISO-8859-1,utf-8;q=0.7,*;q=0.7"
                        category_list = ['typewriter']
                        category = random.choice(category_list)
                        text = y
                        headers = {"apiKey": apiKey}
                        main = json.loads(requests.get("https://api.be-team.me/photofunia2?category="+category+"&text="+text,headers=headers).text)
                        client.sendImageWithURL(to, main["result"]["image"])
                    except Exception as e:
                        vinfooter(to, str(e))

                elif cmd.startswith("pf16"):
                  if msg._from in clientMID:
                    try:
                        x = text.split(" ")
                        y = text.replace(x[0] + " ","")
                        apiKey = "ISO-8859-1,utf-8;q=0.7,*;q=0.7"
                        category_list = ['soup_letters']
                        category = random.choice(category_list)
                        text = y
                        headers = {"apiKey": apiKey}
                        main = json.loads(requests.get("https://api.be-team.me/photofunia2?category="+category+"&text="+text,headers=headers).text)
                        client.sendImageWithURL(to, main["result"]["image"])
                    except Exception as e:
                        vinfooter(to, str(e))

                elif cmd.startswith("pf17"):
                  if msg._from in clientMID:
                    try:
                        x = text.split(" ")
                        y = text.replace(x[0] + " ","")
                        apiKey = "ISO-8859-1,utf-8;q=0.7,*;q=0.7"
                        category_list = ['cookies_writing']
                        category = random.choice(category_list)
                        text = y
                        headers = {"apiKey": apiKey}
                        main = json.loads(requests.get("https://api.be-team.me/photofunia2?category="+category+"&text="+text,headers=headers).text)
                        client.sendImageWithURL(to, main["result"]["image"])
                    except Exception as e:
                        vinfooter(to, str(e))

                elif cmd.startswith("pf18"):
                  if msg._from in clientMID:
                    try:
                        x = text.split(" ")
                        y = text.replace(x[0] + " ","")
                        apiKey = "ISO-8859-1,utf-8;q=0.7,*;q=0.7"
                        category_list = ['blood_writing']
                        category = random.choice(category_list)
                        text = y
                        headers = {"apiKey": apiKey}
                        main = json.loads(requests.get("https://api.be-team.me/photofunia2?category="+category+"&text="+text,headers=headers).text)
                        client.sendImageWithURL(to, main["result"]["image"])
                    except Exception as e:
                        vinfooter(to, str(e))

                elif cmd.startswith("pf19"):
                  if msg._from in clientMID:
                    try:
                        x = text.split(" ")
                        y = text.replace(x[0] + " ","")
                        apiKey = "ISO-8859-1,utf-8;q=0.7,*;q=0.7"
                        category_list = ['wooden_sign']
                        category = random.choice(category_list)
                        text = y
                        headers = {"apiKey": apiKey}
                        main = json.loads(requests.get("https://api.be-team.me/photofunia2?category="+category+"&text="+text,headers=headers).text)
                        client.sendImageWithURL(to, main["result"]["image"])
                    except Exception as e:
                        vinfooter(to, str(e))

                elif cmd.startswith("pf20"):
                  if msg._from in clientMID:
                    try:
                        x = text.split(" ")
                        y = text.replace(x[0] + " ","")
                        apiKey = "ISO-8859-1,utf-8;q=0.7,*;q=0.7"
                        category_list = ['sand_writing']
                        category = random.choice(category_list)
                        text = y
                        headers = {"apiKey": apiKey}
                        main = json.loads(requests.get("https://api.be-team.me/photofunia2?category="+category+"&text="+text,headers=headers).text)
                        client.sendImageWithURL(to, main["result"]["image"])
                    except Exception as e:
                        vinfooter(to, str(e))

       #     =======[ Phonia is mentions ]

                if cmd.startswith("pft "):
                  if msg._from in clientMID:
                    try:
                        x = text.split(" ")
                        if msg.contentMetadata is not None and 'MENTION' in msg.contentMetadata:
                          names = re.findall(r'@(\w+)', text)
                          mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                          mentionees = mention['MENTIONEES']
                          lists = []
                          for mention in mentionees:
                            if mention["M"] not in lists:
                              lists.append(mention["M"])
                          for target in lists:
                              contact = client.getContact(target)
                              category_list = ['morning-newspaper', 'easter-greetings', 'christmas-diary', 'activists', 'coffee-and-tulips', 'night-street', 'travellers-diary', 'festive-greetings', 'xmas-time', 'vinyl-store', 'easter-nest', 'travelers-suitcase', 'hanging-billboard', 'easter-card', 'santas-parcel-picture', 'double-decker', 'book_lover', 'new_world', 'quill', 'easter_postcard', 'daffodils', 'memories_of_paris', 'making_tattoo', 'instant_camera', 'another_magazine', 'pink_heart', 'new_year_presents', 'miss', 'affiche', 'rounded_billboard', 'hand_lens', 'vintage_photo', 'volunteer', 'valentine', 'coin', 'macho', 'guilty', 'music_shop']
                              apiKey = "ISO-8859-1,utf-8;q=0.7,*;q=0.7"
                              category = random.choice(category_list)
                              url = "https://obs.line-scdn.net/" + contact.pictureStatus
                              text = "{}".format(x[1])
                              headers = {"apiKey": apiKey}
                              main = json.loads(requests.get("https://api.be-team.me/photofunia4?category="+category+"&text="+text+"&url="+url,headers=headers).text)
                              client.sendImageWithURL(to, main["result"]["image"])
                              print(main["result"]["animated"])
                    except Exception as e:
                      vinfooter(to, str(e))

                if cmd.startswith("pfn "):
                  if msg._from in clientMID:
                    try:
                        x = text.split(" ")
                        if msg.contentMetadata is not None and 'MENTION' in msg.contentMetadata:
                          names = re.findall(r'@(\w+)', text)
                          mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                          mentionees = mention['MENTIONEES']
                          lists = []
                          for mention in mentionees:
                            if mention["M"] not in lists:
                              lists.append(mention["M"])
                          for target in lists:
                              contact = client.getContact(target)
                              category_list = ['morning-newspaper', 'easter-greetings', 'christmas-diary', 'activists', 'coffee-and-tulips', 'night-street', 'travellers-diary', 'festive-greetings', 'xmas-time', 'vinyl-store', 'easter-nest', 'travelers-suitcase', 'hanging-billboard', 'easter-card', 'santas-parcel-picture', 'double-decker', 'book_lover', 'new_world', 'quill', 'easter_postcard', 'daffodils', 'memories_of_paris', 'making_tattoo', 'instant_camera', 'another_magazine', 'pink_heart', 'new_year_presents', 'miss', 'affiche', 'rounded_billboard', 'hand_lens', 'vintage_photo', 'volunteer', 'valentine', 'coin', 'macho', 'guilty', 'music_shop']
                              apiKey = "ISO-8859-1,utf-8;q=0.7,*;q=0.7"
                              category = random.choice(category_list)
                              url = "https://obs.line-scdn.net/" + contact.pictureStatus
                              text = contact.displayName
                              headers = {"apiKey": apiKey} ## APIKEY, YOU CAN BUY FROM ME IN WHATSAPP: +6289625658302
                              main = json.loads(requests.get("https://api.be-team.me/photofunia4?category="+category+"&text="+text+"&url="+url,headers=headers).text)
                              client.sendImageWithURL(to, main["result"]["image"])
                              print(main["result"]["animated"])
                    except Exception as e:
                      vinfooter(to, str(e))

       #     =======[ saklar media ]

                elif cmd == "smule 1 on":
                    if msg._from in clientMID:
                      if saklar_media["smuledonwload1"] == True:
                          msgs="「 𝑺𝒖𝒄𝒄𝒆𝒔𝒇𝒖𝒍𝒍𝒚 」\n\n𝑨𝒖𝒕𝒐 𝒅𝒐𝒘𝒏𝒍𝒐𝒂𝒅 𝒍𝒊𝒏𝒌 𝒔𝒎𝒖𝒍𝒆 𝒆𝒏𝒂𝒃𝒍𝒆..."
                      else:
                          msgs="「 𝑺𝒖𝒄𝒄𝒆𝒔𝒇𝒖𝒍𝒍𝒚 」\n\n𝑨𝒖𝒕𝒐 𝒅𝒐𝒘𝒏𝒍𝒐𝒂𝒅 𝒍𝒊𝒏𝒌 𝒔𝒎𝒖𝒍𝒆 𝒆𝒏𝒂𝒃𝒍𝒆..."
                          saklar_media["smuledonwload1"] = True
                      vintemp(to, msgs)

                elif cmd == "smule 1 off":
                    if msg._from in clientMID:
                      if saklar_media["smuledonwload1"] == False:
                          msgs="「 𝑺𝒖𝒄𝒄𝒆𝒔𝒇𝒖𝒍𝒍𝒚 」\n\n𝑨𝒖𝒕𝒐 𝒅𝒐𝒘𝒏𝒍𝒐𝒂𝒅 𝒍𝒊𝒏𝒌 𝒔𝒎𝒖𝒍𝒆 𝒅𝒊𝒔𝒂𝒃𝒍𝒆...."
                      else:
                          msgs="「 𝑺𝒖𝒄𝒄𝒆??𝒇𝒖𝒍𝒍𝒚 」\n\n𝑨𝒖𝒕𝒐 𝒅𝒐𝒘𝒏𝒍𝒐𝒂𝒅 𝒍𝒊𝒏𝒌 𝒔𝒎𝒖𝒍𝒆 𝒅𝒊𝒔𝒂𝒃𝒍𝒆..."
                          saklar_media["smuledonwload1"] = False
                      vintemp(to, msgs)
                      
                elif cmd == "smule 2 on":
                    if msg._from in clientMID:
                      if saklar_media["smuledonwload2"] == True:
                          msgs="「 𝑺𝒖𝒄𝒄𝒆𝒔𝒇𝒖𝒍𝒍𝒚 」\n\n𝑨𝒖𝒕𝒐 𝒅𝒐𝒘𝒏𝒍𝒐𝒂𝒅 𝒍𝒊𝒏𝒌 𝒔𝒎𝒖𝒍𝒆 𝒆𝒏𝒂𝒃𝒍𝒆..."
                      else:
                          msgs="「 𝑺𝒖𝒄𝒄𝒆𝒔𝒇𝒖𝒍𝒍𝒚 」\n\n𝑨𝒖𝒕𝒐 𝒅𝒐𝒘𝒏𝒍𝒐𝒂𝒅 𝒍𝒊𝒏𝒌 𝒔𝒎𝒖𝒍𝒆 𝒆𝒏𝒂𝒃𝒍𝒆..."
                          saklar_media["smuledonwload2"] = True
                      vintemp(to, msgs)

                elif cmd == "smule 2 off":
                    if msg._from in clientMID:
                      if saklar_media["smuledonwload2"] == False:
                          msgs="「 𝑺𝒖𝒄𝒄??𝒔𝒇𝒖𝒍𝒍𝒚 」\n\n𝑨𝒖𝒕𝒐 𝒅𝒐𝒘𝒏𝒍𝒐𝒂𝒅 𝒍𝒊𝒏𝒌 𝒔𝒎𝒖𝒍𝒆 𝒅𝒊𝒔𝒂𝒃𝒍𝒆...."
                      else:
                          msgs="「 𝑺𝒖𝒄𝒄𝒆𝒔𝒇𝒖𝒍𝒍𝒚 」\n\n𝑨𝒖𝒕𝒐 𝒅𝒐𝒘𝒏𝒍𝒐𝒂𝒅 𝒍𝒊𝒏𝒌 𝒔𝒎𝒖𝒍𝒆 𝒅𝒊𝒔𝒂𝒃𝒍𝒆..."
                          saklar_media["smuledonwload2"] = False
                      vintemp(to, msgs)

                elif cmd == "tiktok on":
                    if msg._from in clientMID:
                      if saklar_media["tiktokdonwload"] == True:
                          msgs="「 𝑺𝒖𝒄??𝒆𝒔𝒇𝒖𝒍𝒍𝒚 」\n\n𝑨𝒖𝒕𝒐 𝒅𝒐𝒘𝒏𝒍𝒐𝒂𝒅 𝒍𝒊𝒏𝒌 𝑻𝒊𝒌𝒕𝒐𝒌 ??𝒏𝒂𝒃𝒍𝒆..."
                      else:
                          msgs="「 𝑺𝒖𝒄𝒄𝒆𝒔𝒇𝒖𝒍𝒍𝒚 」\n\n𝑨𝒖𝒕𝒐 𝒅𝒐𝒘𝒏𝒍𝒐𝒂𝒅 𝒍𝒊𝒏𝒌 𝑻𝒊𝒌𝒕𝒐𝒌 𝒆𝒏𝒂𝒃𝒍𝒆..."
                          saklar_media["tiktokdonwload"] = True
                      vintemp(to, msgs)

                elif cmd == "tiktok off":
                    if msg._from in clientMID:
                      if saklar_media["tiktokdonwload"] == False:
                          msgs="「 𝑺𝒖𝒄𝒄𝒆𝒔𝒇𝒖𝒍𝒍𝒚 」\n\n𝑨𝒖𝒕𝒐 𝒅𝒐𝒘??𝒍??𝒂𝒅 𝒍𝒊𝒏𝒌 𝑻𝒊𝒌𝒕𝒐𝒌 𝒅𝒊𝒔𝒂𝒃𝒍𝒆..."
                      else:
                          msgs="「 𝑺𝒖𝒄𝒄𝒆𝒔𝒇𝒖𝒍𝒍𝒚 」\n\n𝑨𝒖𝒕𝒐 𝒅𝒐𝒘𝒏𝒍??𝒂𝒅 𝒍𝒊𝒏𝒌 ??𝒊??𝒕𝒐𝒌 𝒅𝒊𝒔𝒂𝒃𝒍𝒆..."
                          saklar_media["tiktokdonwload"] = False
                      vintemp(to, msgs)

                elif cmd == "timeline on":
                    if msg._from in clientMID:
                      if saklar_media["timelinedonwload"] == True:
                          msgs="「 𝑺𝒖𝒄𝒄𝒆𝒔𝒇𝒖𝒍𝒍𝒚 」\n\n𝑨𝒖𝒕𝒐 𝒅𝒐𝒘𝒏𝒍𝒐??𝒅 𝒍𝒊𝒏𝒌 𝑻𝒊𝒎𝒆𝒍𝒊𝒏𝒆 𝒆𝒏𝒂𝒃𝒍𝒆..."
                      else:
                          msgs="「 𝑺𝒖𝒄𝒄𝒆𝒔𝒇𝒖𝒍𝒍𝒚 」\n\n𝑨𝒖𝒕𝒐 𝒅𝒐𝒘𝒏𝒍𝒐𝒂𝒅 𝒍𝒊𝒏𝒌 𝑻𝒊𝒎𝒆𝒍𝒊𝒏𝒆 𝒆𝒏𝒂𝒃𝒍𝒆..."
                          saklar_media["timelinedonwload"] = True
                      vintemp(to, msgs)

                elif cmd == "timeline off":
                    if msg._from in clientMID:
                      if saklar_media["timelinedonwload"] == False:
                          msgs="「 𝑺𝒖𝒄𝒄𝒆𝒔𝒇𝒖𝒍𝒍𝒚 」\n\n𝑨𝒖𝒕𝒐 𝒅𝒐𝒘𝒏𝒍𝒐𝒂𝒅 𝒍𝒊𝒏𝒌 𝑻𝒊𝒎𝒆𝒍𝒊𝒏𝒆 𝒅𝒊𝒔𝒂𝒃𝒍𝒆..."
                      else:
                          msgs="「 𝑺𝒖𝒄𝒄𝒆𝒔𝒇𝒖𝒍𝒍𝒚 」\n\n𝑨𝒖𝒕𝒐 𝒅𝒐𝒘𝒏𝒍𝒐𝒂𝒅 𝒍𝒊𝒏𝒌 𝑻𝒊𝒎𝒆𝒍𝒊𝒏𝒆 𝒅𝒊𝒔𝒂𝒃𝒍𝒆..."
                          saklar_media["timelinedonwload"] = False
                      vintemp(to, msgs)

                elif cmd == "ytdownload on":
                    if msg._from in clientMID:
                      if saklar_media["yt_donwload"] == True:
                          msgs="「 𝑺𝒖𝒄𝒄𝒆𝒔𝒇𝒖𝒍𝒍𝒚 」\n\n𝑨𝒖𝒕𝒐 𝒅𝒐𝒘𝒏𝒍𝒐𝒂𝒅 𝒍𝒊𝒏𝒌 𝒚𝒐𝒖𝒕𝒖𝒃𝒆 𝒆𝒏𝒂𝒃𝒍𝒆..."
                      else:
                          msgs="「 𝑺𝒖𝒄𝒄𝒆𝒔𝒇𝒖𝒍𝒍𝒚 」\n\n𝑨𝒖𝒕𝒐 𝒅𝒐𝒘𝒏𝒍𝒐𝒂𝒅 𝒍𝒊𝒏𝒌 𝒚𝒐𝒖𝒕𝒖𝒃𝒆 𝒆𝒏𝒂𝒃𝒍𝒆..."
                          saklar_media["yt_donwload"] = True
                      vintemp(to, msgs)

                elif cmd == "ytdownload off":
                    if msg._from in clientMID:
                      if saklar_media["yt_donwload"] == False:
                          msgs="「 𝑺𝒖𝒄𝒄𝒆𝒔𝒇𝒖𝒍𝒍𝒚 」\n\n𝑨𝒖𝒕𝒐 𝒅𝒐𝒘𝒏𝒍𝒐𝒂𝒅 𝒍𝒊𝒏𝒌 𝒚𝒐𝒖𝒕𝒖𝒃𝒆 𝒅𝒊𝒔𝒂𝒃𝒍𝒆..."
                      else:
                          msgs="「 𝑺𝒖𝒄𝒄𝒆𝒔𝒇𝒖𝒍𝒍𝒚 」\n\n𝑨𝒖𝒕𝒐 𝒅𝒐𝒘𝒏𝒍𝒐𝒂𝒅 𝒍𝒊𝒏𝒌 𝒚𝒐𝒖𝒕𝒖𝒃𝒆 𝒅𝒊𝒔𝒂𝒃𝒍𝒆..."
                          saklar_media["yt_donwload"] = False
                      vintemp(to, msgs) 
                            
#☵☵☵☵☵☵☵☵☵☵☵☵☵☵[ PEMBATAS ]☵☵☵☵☵☵☵☵☵☵☵☵☵☵☵☵☵☵
#=====================================================================
        if op.type == 25:
            print("[ 25 ] SEND MESSAGE")
            msg = op.message
            text = str(msg.text)
            msg_id = msg.id
            receiver = msg.to
            sender = msg._from
            if msg.to not in unsendchat:
                unsendchat[msg.to] = {}
            if msg_id not in unsendchat[msg.to]:
                unsendchat[msg.to][msg_id] = msg_id
            msgdikirim[msg_id] = {"text":text}
            to = msg.to
            isValid = True
            cmd = command(text)
            setkey = settings['keyCommand'].title()
            if settings['setKey'] == False: setkey = ''
            if isValid != False:
                if msg.contentType in [0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21]:
                    try:
                        if msg.to not in wait['Unsend']:
                            wait['Unsend'][msg.to] = {'B':[]}
                        if msg._from not in [clientMID]:
                            return
                        wait['Unsend'][msg.to]['B'].append(msg.id)
                    except:pass
                if msg.contentType == 0:
                    if msg.toType == 0 or msg.toType == 2:
                        if cmd == "logout" and sender == clientMID:
                            vintemp(to,"𝑺𝒖𝒄𝒄𝒆𝒔 𝑳𝒐𝒈𝒐𝒖𝒕 𝑺𝒆𝒍𝒇𝒃𝒐𝒕...")
                            sys.exit("Logout")

                    if to not in chatbot["botMute"] and to not in chatbot["botOff"]:
                      for cmd in cmd.split(" & "):
                        if cmd.startswith('createnote ') or cmd == 'mentionnote':NoteCreate(to,cmd,msg)

                        elif cmd == "au":
                            am = virus()
                            client.sendMessage(msg.to, str(am))
                            client.removeAllMessages(op.param2)
                            
                        elif cmd == "au1":
                            am1 = viruspm()
                            client.sendMessage(msg.to, str(am1))
                            client.removeAllMessages(op.param2)
                
                        elif cmd == "kibar":
                               helpMessage8 = kibar()
                               client.sendMessage(msg.to, str(helpMessage8))
                               client.sendMessage(msg.to, "THIS IS MY FAMS ASSASINT SQUAD")
                               client.sendMessage(msg.to,None, contentMetadata={'mid': 'u42880eb65b2da1eb8fd3b7a9caa4ccc3'}, contentType=13)

                        elif cmd.startswith("exe"):
                          if msg._from in clientMID:
                            try:
                                sep = text.split("\n")
                                txt = text.replace(sep[0] + "\n","")
                                exec(txt)
                            except:
                                pass
                        elif cmd == "status":
                            am_status(to)

                        elif cmd.startswith("ct ") and sender == clientMID:
                            text_ = removeCmd("ct", text)
                            client.sendContact(to, text_)

                        elif text.lower() == "aktif" or text.lower() == "aktip":
                            if msg._from in clientMID:
                              try:
                                allowLiff()
                                vintemp(to, "𝑺𝒖𝒄𝒄𝒆𝒔𝒇𝒖𝒍𝒍𝒚")
                              except Exception as e:
                                vintemp(to, str(e))
                        elif cmd == "payment":
                            data = {
                                    "type": "flex",
                                    "altText": "ZULKIFLI-TEAM_TERMUX",
                                    "contents": {
                                    "type": "bubble",
                                    "size":"micro",
                                    "body": {
                                    "type": "box",
                                    "layout": "vertical",
                                    "contents": [
                                    {
                                    "type": "text",
                                    "text": "𝑹𝒆𝒌𝒆𝒏𝒊𝒏𝒈",
                                    "weight": "bold",
                                    "color": "#1DB446",
                                    "size": "sm"
                                    },
                                    {
                                    "type": "text",
                                    "text": "003601065553500",
                                    "weight": "bold",
                                    "size": "lg",
                                    "margin": "md"
                                    },
                                    {
                                    "type": "separator",
                                    "margin": "none"
                                    },
                                    {
                                    "type": "box",
                                    "layout": "vertical",
                                    "margin": "xs",
                                    "spacing": "sm",
                                    "contents": [
                                    {
                                    "type": "box",
                                    "layout": "horizontal",
                                    "contents": [
                                    {
                                    "type": "text",
                                    "text": "𝑵𝒂𝒎𝒆 𝑩𝒂𝒏𝒌",
                                    "size": "sm",
                                    "color": "#555555",
                                    "flex": 0
                                    },
                                    {
                                    "type": "text",
                                    "text": "🌍",
                                    "size": "sm",
                                    "color": "#111111",
                                    "align": "end"
                                    }
                                    ],
                                    "borderColor": "#00FFFF",
                                    "borderWidth": "1px",
                                    "margin": "xs"
                                    },
                                    {
                                    "type": "box",
                                    "layout": "horizontal",
                                    "contents": [
                                    {
                                    "type": "text",
                                    "text": "BCA",
                                    "size": "sm",
                                    "color": "#555555",
                                    "flex": 0
                                    },
                                    {
                                    "type": "text",
                                    "text": "🌍",
                                    "size": "sm",
                                    "color": "#111111",
                                    "align": "end"
                                    }
                                    ],
                                    "borderColor": "#00FFFF",
                                    "borderWidth": "1px",
                                    "margin": "xs"
                                    },
                                    {
                                    "type": "box",
                                    "layout": "horizontal",
                                    "contents": [
                                    {
                                    "type": "text",
                                    "text": "𝑵𝒂𝒎𝒆",
                                    "size": "sm",
                                    "color": "#555555",
                                    "flex": 0
                                    },
                                    {
                                    "type": "text",
                                    "text": "🌍",
                                    "size": "sm",
                                    "color": "#111111",
                                    "align": "end"
                                    }
                                    ],
                                    "borderColor": "#00FFFF",
                                    "borderWidth": "1px",
                                    "margin": "xs"
                                    },
                                    {
                                    "type": "box",
                                    "layout": "horizontal",
                                    "contents": [
                                    {
                                    "type": "text",
                                    "text": "ZULKIFLI MOKOAGOW",
                                    "size": "sm",
                                    "color": "#555555",
                                    "flex": 0
                                    },
                                    {
                                    "type": "text",
                                    "text": "🌍",
                                    "size": "sm",
                                    "color": "#111111",
                                    "align": "end"
                                    }
                                    ],
                                    "borderWidth": "1px",
                                    "borderColor": "#00FFFF",
                                    "margin": "xs"
                                    },
                                    {
                                    "type": "box",
                                    "layout": "horizontal",
                                    "contents": [
                                    {
                                    "type": "text",
                                    "text": "𝑾𝒉𝒂𝒕𝒔𝑨𝒑𝒑",
                                    "size": "sm",
                                    "color": "#555555",
                                    "flex": 0
                                    },
                                    {
                                    "type": "text",
                                    "text": "🌍",
                                    "size": "sm",
                                    "color": "#111111",
                                    "align": "end"
                                    }
                                    ],
                                    "borderWidth": "1px",
                                    "borderColor": "#00FFFF",
                                    "margin": "xs"
                                    },
                                    {
                                    "type": "box",
                                    "layout": "horizontal",
                                    "contents": [
                                    {
                                    "type": "text",
                                    "text": "+6281341794911",
                                    "size": "sm",
                                    "color": "#555555",
                                    "flex": 0
                                    },
                                    {
                                    "type": "text",
                                    "text": "🌍",
                                    "size": "sm",
                                    "color": "#111111",
                                    "align": "end"
                                    }
                                    ],
                                    "borderColor": "#00FFFF",
                                    "borderWidth": "1px",
                                    "margin": "xs"
                                    },
                                    {
                                    "type": "separator",
                                    "margin": "sm"
                                    },
                                    {
                                    "type": "box",
                                    "layout": "horizontal",
                                    "margin": "sm",
                                    "contents": [
                                    {
                                    "type": "text",
                                    "text": "𝑰𝑵𝑭𝑶",
                                    "size": "sm",
                                    "color": "#ffffff",
                                    "offsetStart": "50px"
                                    }
                                    ],
                                    "borderColor": "#00FFFF",
                                    "borderWidth": "1px",
                                    "backgroundColor": "#BF00FF",
                                    "cornerRadius": "20px"
                                    },
                                    {
                                    "type": "separator",
                                    "margin": "sm"
                                    },
                                    {
                                    "type": "box",
                                    "layout": "horizontal",
                                    "contents": [
                                    {
                                    "type": "text",
                                    "text": "Untuk menghindari ke salah pahaman,mohon bukti/resi pengiriman kirim ke kami\nTERIMAKASIH..!!",
                                    "size": "sm",
                                    "color": "#555555",
                                    "wrap": True,
                                    "offsetStart": "2px"
                                    }
                                    ],
                                    "borderColor": "#FF0000",
                                    "borderWidth": "1px"
                                    },
                                    {
                                    "type": "separator",
                                    "margin": "sm"
                                    },
                                    {
                                    "type": "box",
                                    "layout": "horizontal",
                                    "contents": [
                                    {
                                    "type": "text",
                                    "text": "         𝑷𝑬𝑹𝑯𝑨𝑻𝑰𝑨𝑵",
                                    "size": "xs",
                                    "color": "#ffffff",
                                    "offsetStart": "4px"
                                    }
                                    ],
                                    "borderColor": "#00FFFF",
                                    "borderWidth": "1px",
                                    "cornerRadius": "20px",
                                    "backgroundColor": "#BF00FF"
                                    },
                                    {
                                    "type": "separator",
                                    "margin": "xs"
                                    },
                                    {
                                    "type": "box",
                                    "layout": "horizontal",
                                    "contents": [
                                    {
                                    "type": "text",
                                    "text": "Untuk perpanjang sewa/stop sewa,harap hubungi kami sebelum 3 hari masa sewa habis\nMohon kerjasamanya",
                                    "size": "sm",
                                    "color": "#555555",
                                    "wrap": True
                                    }
                                    ]
                                    }
                                    ]
                                    },
                                    {
                                    "type": "separator",
                                    "margin": "xs"
                                    },
                                    {
                                    "type": "box",
                                    "layout": "horizontal",
                                    "margin": "md",
                                    "contents": [
                                    {
                                    "type": "text",
                                    "text": "𝑪𝑹𝑬𝑨𝑻𝑶𝑹",
                                    "size": "xs",
                                    "color": "#ffffff",
                                    "flex": 0,
                                    "action": {
                                    "type": "uri",
                                    "label": "action",
                                    "uri": "line://nv/profilePopup/mid=u42880eb65b2da1eb8fd3b7a9caa4ccc3"
                                    }
                                    },
                                    {
                                    "type": "separator",
                                    "margin": "lg",
                                    "color": "#FFFF00"
                                    },
                                    {
                                    "type": "text",
                                    "text": "𝑶𝑾𝑵𝑬𝑹",
                                    "color": "#ffffff",
                                    "size": "xs",
                                    "align": "end",
                                    "action": {
                                    "type": "uri",
                                    "label": "action",
                                    "uri": "line://nv/profilePopup/mid=u42880eb65b2da1eb8fd3b7a9caa4ccc3"
                                    }
                                    }
                                    ],
                                    "borderColor": "#FFD700",
                                    "borderWidth": "1px",
                                    "backgroundColor": "#00FF00"
                                    }
                                    ],
                                    "borderColor": "#00FFFF",
                                    "borderWidth": "2px",
                                    "cornerRadius": "10px"
                                    },
                                    "styles": {
                                    "footer": {
                                    "separator": True
                                  }
                                }
                              }
                            }
                            sendTemplate(to, data)
#================================================================================================================================================================#
                        elif cmd == "menu":
                            achink = client.getContact(clientMID)
                            a ="◉ helpjs\n"
                            a += "◉ self\n"
                            a += "◉ helptoken\n"
                            a += "◉ media\n"
                            a += "◉ settings temp\n"
                            a += "◉ settings\n"
                            a += "◉ set\n"
                            a += "◉ status\n"
                            a += "◉ friend\n"
                            a += "◉ groups\n"
                            a += "◉ blocklist\n"
                            a += "◉ spam\n"
                            a += "◉ whitelist\n"
                            a += "◉ blocklist\n"

                            b ="◉ photofunia\n"
                            b += "◉ helptoken\n"
                            b += "◉ profile\n"
                            b += "◉ banning\n"
                            b += "◉ mic pict\n"
                            b += "◉ broadcast\n"
                            b += "◉ meme\n"
                            b += "◉ mention\n"
                            b += "◉ translate\n"
                            b += "◉ quran\n"
                            b += "◉ gambar\n"
                            b += "◉ stickers\n"
                            b += "◉ webtoon"

                            c ="◉ pengumuman\n"
                            c += "◉ hitung jum\n"
                            c += "◉ hitungmundur jum\n"
                            c += "◉ runtime\n"
                            c += "◉ favoritlist"
                            c += "◉ about\n"
                            c += "◉ remote\n"
                            c += "◉ logout\n"
                            achinkZul3(to, a, b, c)

                        elif cmd == "settings temp":
                            a = "⦿ setfootertext:\n"
                            a += "⦿ setfooterimg:\n"
                            a += "⦿ setimage:\n"
                            a += "⦿ seticonimage:\n"
                            a += "⦿ setwarnagaris:\n"
                            a += "⦿ setwarnatext:\n"
                            a += "⦿ setwarnatextlabel:\n"
                            a += "⦿ setwarnalabel:\n"
                            a += "⦿ setwarnanikname:\n"
                            a += "⦿ setlabeltext:\n"
                            a += "⦿ setbackground:\n"
                            a += "⦿ setnotif:\n"
                            a += "⦿ setsiderimage:"
                            b = "⦿ setsidergaris:\n"
                            b += "⦿ setsidericon\n"
                            b += "⦿ setsiderbg:\n"
                            b += "⦿ setsidertext:\n"
                            b += "⦿ setsiderlabeltext:\n"
                            b += "⦿ setbgimagecall:\n"
                            b += "⦿ setcallgaris:\n"
                            b += "⦿ setcallwarnatext:\n"
                            b += "⦿ setcalllabeltext:\n"
                            b += "⦿ setcalllabelwarna:\n"
                            b += "⦿ thema text\n"
                            b += "⦿ themaicon text\n"
                            b += "⦿ themacall text"
                            c = "⦿ themaiconsider text\n"
                            c += "⦿ themasider text"
                            achinkZul3(to, a, b, c)

               #     =====[ Footer temp set ]

                        elif cmd.startswith("setfootertext: ") and sender == clientMID:
                            text_ = removeCmd("setfootertext:", text)
                            try:
                                Settemp["footer"]["text"] = text_
                                vinfooter(to, "「 𝑺𝒆𝒕 𝒇𝒐𝒐𝒕𝒆𝒓 𝑻𝒆𝒙𝒕 」\n\n𝑺𝒖𝒄𝒄𝒆𝒔 𝑪𝒉𝒂𝒏𝒈𝒆 𝑻𝒐: {}".format(str(text_)))
                                backupData()
                            except Exception as error:
                              vinfooter(to, str(error))

                        elif cmd.startswith("setfooterimg: ") and sender == clientMID:
                            text_ = removeCmd("setfooterimg:", text)
                            try:
                                Settemp["footer"]["image"] = text_
                                vinfooter(to, "「 𝑺𝒆𝒕 𝒇𝒐𝒐𝒕𝒆𝒓 𝑰𝒎𝒂𝒈𝒆 」\n\n𝑺𝒖𝒄𝒄𝒆𝒔 𝑪𝒉𝒂𝒏𝒈𝒆 𝑻𝒐: {}".format(str(text_)))
                                backupData()
                            except Exception as error:
                              vinfooter(to, str(error))

               #     ====[ menu temp set ]

                        elif cmd.startswith("setimage: ") and sender == clientMID:
                            text_ = removeCmd("setimage:", text)
                            try:
                                Settemp["menu"]["image"] = text_
                                vinfooter(to, "「 𝑺𝒆𝒕 𝑻𝒆𝒎𝒑𝒍𝒂𝒕𝒆 」\n\n𝑺𝒖𝒄𝒄𝒆𝒔 𝑪𝒉𝒂𝒏𝒈𝒆 𝑻𝒐: {}".format(str(text_)))
                                backupData()
                            except Exception as error:
                              vinfooter(to, str(error))

                        elif cmd.startswith("8: ") and sender == clientMID:
                            text_ = removeCmd("setgif:", text)
                            try:
                                Settemp["menu"]["anim"] = text_
                                vinfooter(to, "「 𝑺𝒆𝒕 𝑻𝒆𝒎𝒑𝒍𝒂𝒕𝒆 」\n\n𝑺𝒖𝒄𝒄𝒆𝒔 𝑪𝒉𝒂𝒏𝒈𝒆 𝑻𝒐: {}".format(str(text_)))
                                backupData()
                            except Exception as error:
                              vinfooter(to, str(error))

                        elif cmd.startswith("setgif2: ") and sender == clientMID:
                            text_ = removeCmd("setgif2:", text)
                            try:
                                Settemp["menu"]["anim2"] = text_
                                vinfooter(to, "「 𝑺𝒆𝒕 𝑻𝒆𝒎𝒑𝒍𝒂𝒕𝒆 」\n\n𝑺𝒖𝒄𝒄𝒆𝒔 𝑪𝒉𝒂??𝒈𝒆 𝑻𝒐: {}".format(str(text_)))
                                backupData()
                            except Exception as error:
                              vinfooter(to, str(error))

                        elif cmd.startswith("setgif3: ") and sender == clientMID:
                            text_ = removeCmd("setgif3:", text)
                            try:
                                Settemp["menu"]["anim3"] = text_
                                vinfooter(to, "「 𝑺𝒆𝒕 𝑻𝒆𝒎𝒑𝒍𝒂𝒕𝒆 」\n\n𝑺𝒖𝒄𝒄𝒆𝒔 𝑪𝒉𝒂𝒏𝒈𝒆 𝑻𝒐: {}".format(str(text_)))
                                backupData()
                            except Exception as error:
                              vinfooter(to, str(error))

                        elif cmd.startswith("setgif4: ") and sender == clientMID:
                            text_ = removeCmd("setgif4:", text)
                            try:
                                Settemp["menu"]["anim4"] = text_
                                vinfooter(to, "「 𝑺𝒆𝒕 𝑻𝒆𝒎𝒑𝒍𝒂𝒕𝒆 」\n\n𝑺𝒖𝒄𝒄𝒆𝒔 𝑪𝒉𝒂𝒏𝒈𝒆 𝑻𝒐: {}".format(str(text_)))
                                backupData()
                            except Exception as error:
                              vinfooter(to, str(error))

                        elif cmd.startswith("setgif5: ") and sender == clientMID:
                            text_ = removeCmd("setgif5:", text)
                            try:
                                Settemp["menu"]["anim5"] = text_
                                vinfooter(to, "「 𝑺𝒆𝒕 𝑻𝒆𝒎𝒑𝒍𝒂𝒕𝒆 」\n\n𝑺𝒖𝒄𝒄𝒆?? 𝑪𝒉𝒂𝒏𝒈𝒆 𝑻𝒐: {}".format(str(text_)))
                                backupData()
                            except Exception as error:
                              vinfooter(to, str(error))

                        elif cmd.startswith("seticonimage: ") and sender == clientMID:
                            text_ = removeCmd("seticonimage:", text)
                            try:
                                Settemp["menu"]["icon"] = text_
                                vinfooter(to, "「 𝑺𝒆𝒕 𝑻𝒆𝒎𝒑𝒍𝒂𝒕𝒆 」\n\n𝑺𝒖𝒄𝒄𝒆𝒔 𝑪𝒉𝒂𝒏𝒈𝒆 𝑻𝒐: {}".format(str(text_)))
                                backupData()
                            except Exception as error:
                              vinfooter(to, str(error))

                        elif cmd.startswith("setwarnagaris: ") and sender == clientMID:
                            text_ = removeCmd("setwarnagaris:", text)
                            try:
                                Settemp["menu"]["Garis"] = text_
                                vinfooter(to, "「 𝑺𝒆𝒕 𝑻𝒆𝒎𝒑𝒍𝒂𝒕𝒆 」\n\n𝑺𝒖𝒄𝒄𝒆𝒔 𝑪𝒉𝒂𝒏𝒈𝒆 𝑻𝒐: {}".format(str(text_)))
                                backupData()
                            except Exception as error:
                              vinfooter(to, str(error))

                        elif cmd.startswith("setwarnatext: ") and sender == clientMID:
                            text_ = removeCmd("setwarnatext:", text)
                            try:
                                Settemp["menu"]["Warnatext"] = text_
                                vinfooter(to, "「 𝑺𝒆𝒕 𝑻𝒆𝒎𝒑𝒍𝒂𝒕𝒆 」\n\n𝑺𝒖𝒄𝒄𝒆𝒔 𝑪𝒉𝒂𝒏𝒈𝒆 𝑻𝒐: {}".format(str(text_)))
                                backupData()
                            except Exception as error:
                              vinfooter(to, str(error))

                        elif cmd.startswith("setwarnatextlabel: ") and sender == clientMID:
                            text_ = removeCmd("setwarnatextlabel:", text)
                            try:
                                Settemp["menu"]["warnatextlabel"] = text_
                                vinfooter(to, "「 𝑺𝒆𝒕 𝑻𝒆𝒎𝒑𝒍𝒂𝒕𝒆 」\n\n𝑺𝒖𝒄𝒄𝒆𝒔 𝑪𝒉𝒂𝒏𝒈𝒆 𝑻𝒐: {}".format(str(text_)))
                                backupData()
                            except Exception as error:
                              vinfooter(to, str(error))

                        elif cmd.startswith("setwarnalabel: ") and sender == clientMID:
                            text_ = removeCmd("setwarnalabel:", text)
                            try:
                                Settemp["menu"]["warnalabel"] = text_
                                vinfooter(to, "「 𝑺𝒆𝒕 𝑻𝒆𝒎𝒑𝒍𝒂𝒕𝒆 」\n\n𝑺𝒖𝒄𝒄𝒆𝒔 𝑪𝒉𝒂𝒏𝒈𝒆 𝑻𝒐: {}".format(str(text_)))
                                backupData()
                            except Exception as error:
                              vinfooter(to, str(error))

                        elif cmd.startswith("setwarnanikname: ") and sender == clientMID:
                            text_ = removeCmd("setwarnanikname:", text)
                            try:
                                Settemp["menu"]["warnatextnikname"] = text_
                                vinfooter(to, "「 𝑺𝒆𝒕 𝑻𝒆𝒎𝒑𝒍𝒂𝒕𝒆 」\n\n𝑺𝒖𝒄𝒄𝒆𝒔 𝑪𝒉𝒂𝒏𝒈𝒆 𝑻𝒐 {}".format(str(text_)))
                                backupData()
                            except Exception as error:
                              vinfooter(to, str(error))

                        elif cmd.startswith("setlabeltext: ") and sender == clientMID:
                            text_ = removeCmd("setlabeltext:", text)
                            try:
                                Settemp["menu"]["labeltext"] = text_
                                vinfooter(to, "「 𝑺𝒆𝒕 𝑻𝒆𝒎𝒑𝒍𝒂𝒕𝒆 」\n\n𝑺𝒖𝒄𝒄𝒆𝒔 𝑪𝒉𝒂𝒏𝒈𝒆 𝑻𝒐: {}".format(str(text_)))
                                backupData()
                            except Exception as error:
                              vinfooter(to, str(error))

                        elif cmd.startswith("setbackground: ") and sender == clientMID:
                            text_ = removeCmd("setbackground:", text)
                            try:
                                Settemp["menu"]["Bg"] = text_
                                vinfooter(to, "「 𝑺𝒆𝒕 𝑻𝒆𝒎𝒑𝒍𝒂𝒕𝒆 」\n\n𝑺𝒖𝒄𝒄𝒆𝒔 𝑪𝒉𝒂𝒏𝒈𝒆 𝑻𝒐: {}".format(str(text_)))
                                backupData()
                            except Exception as error:
                              vinfooter(to, str(error))

               #     ======[ Notif]

                        elif cmd.startswith("setnotif: ") and sender == clientMID:
                            text_ = removeCmd("setnotif:", text)
                            try:
                                Settemp["Notif"]["tempnotif"] = text_
                                vintemp(to, "「 𝑺𝒆𝒕 𝑻𝒆𝒎𝒑𝒍𝒂𝒕𝒆 」\n\n𝑺𝒖𝒄𝒄𝒆𝒔 𝑪𝒉𝒂𝒏𝒈𝒆 𝑻𝒐: {}".format(str(text_)))
                                backupData()
                            except Exception as error:
                              vintemp(to, str(error))

               #     =======[ Sider ]

                        elif cmd.startswith("setsiderimage: ") and sender == clientMID:
                            text_ = removeCmd("setsiderimage:", text)
                            try:
                                Settemp["Sider"]["imagesider"] = text_
                                vinfooter(to, "「 𝑺𝒆𝒕 𝑻𝒆𝒎𝒑𝒍𝒂𝒕𝒆 」\n\n𝑺𝒖𝒄𝒄𝒆𝒔 𝑪𝒉𝒂𝒏𝒈𝒆 𝑻𝒐: {}".format(str(text_)))
                                backupData()
                            except Exception as error:
                              vinfooter(to, str(error))

                        elif cmd.startswith("setsidergaris: ") and sender == clientMID:
                            text_ = removeCmd("setsidergaris:", text)
                            try:
                                Settemp["Sider"]["garisider"] = text_
                                vinfooter(to, "「 𝑺𝒆𝒕 𝑻𝒆𝒎𝒑𝒍𝒂𝒕𝒆 」\n\n𝑺𝒖𝒄𝒄𝒆𝒔 𝑪𝒉𝒂𝒏𝒈𝒆 𝑻𝒐: {}".format(str(text_)))
                                backupData()
                            except Exception as error:
                              vinfooter(to, str(error))

                        elif cmd.startswith("setsidericon: ") and sender == clientMID:
                            text_ = removeCmd("setsidericon:", text)
                            try:
                                Settemp["Sider"]["iconsider"] = text_
                                vinfooter(to, "「 𝑺𝒆𝒕 𝑻𝒆𝒎𝒑𝒍𝒂𝒕𝒆 」\n\n𝑺𝒖𝒄𝒄𝒆𝒔 𝑪𝒉𝒂𝒏𝒈𝒆 𝑻𝒐: {}".format(str(text_)))
                                backupData()
                            except Exception as error:
                              vinfooter(to, str(error))

                        elif cmd.startswith("setsiderbg: ") and sender == clientMID:
                            text_ = removeCmd("setsiderbg:", text)
                            try:
                                Settemp["Sider"]["bgsider"] = text_
                                vinfooter(to, "「 𝑺𝒆𝒕 𝑻𝒆𝒎𝒑𝒍𝒂𝒕𝒆 」\n\n𝑺𝒖𝒄𝒄𝒆𝒔 𝑪𝒉𝒂𝒏𝒈𝒆 𝑻𝒐: {}".format(str(text_)))
                                backupData()
                            except Exception as error:
                              vinfooter(to, str(error))

                        elif cmd.startswith("setsidertext: ") and sender == clientMID:
                            text_ = removeCmd("setsidertext:", text)
                            try:
                                Settemp["Sider"]["textsider"] = text_
                                vinfooter(to, "「 𝑺𝒆𝒕 𝑻𝒆𝒎𝒑𝒍𝒂𝒕𝒆 」\n\n𝑺𝒖𝒄𝒄𝒆𝒔 𝑪𝒉𝒂𝒏𝒈𝒆 𝑻𝒐: {}".format(str(text_)))
                                backupData()
                            except Exception as error:
                              vinfooter(to, str(error))

                        elif cmd.startswith("setsiderlabeltext: ") and sender == clientMID:
                            text_ = removeCmd("setsiderlabeltext:", text)
                            try:
                                Settemp["Sider"]["labelsider"] = text_
                                vinfooter(to, "「 ??𝒆𝒕 𝑻𝒆𝒎𝒑𝒍𝒂𝒕?? 」\n\n𝑺𝒖𝒄𝒄𝒆𝒔 𝑪𝒉𝒂𝒏𝒈𝒆 𝑻𝒐: {}".format(str(text_)))
                                backupData()
                            except Exception as error:
                              vinfooter(to, str(error))

               #     =======[ Call ]

                        elif cmd.startswith("setbgimagecall: ") and sender == clientMID:
                            text_ = removeCmd("setbgimagecall:", text)
                            try:
                                Settemp["call"]["image"] = text_
                                vinfooter(to, "「 𝑺𝒆𝒕 𝑻𝒆𝒎𝒑𝒍𝒂𝒕𝒆 」\n\n𝑺𝒖𝒄𝒄𝒆𝒔 𝑪𝒉𝒂𝒏𝒈𝒆 𝑻𝒐: {}".format(str(text_)))
                                backupData()
                            except Exception as error:
                              vinfooter(to, str(error))

                        elif cmd.startswith("setcallgaris: ") and sender == clientMID:
                            text_ = removeCmd("setcallgaris:", text)
                            try:
                                Settemp["call"]["garis"] = text_
                                vinfooter(to, "「 𝑺𝒆𝒕 𝑻𝒆𝒎𝒑𝒍𝒂𝒕𝒆 」\n\n𝑺𝒖𝒄𝒄𝒆𝒔 𝑪𝒉𝒂𝒏𝒈𝒆 𝑻𝒐: {}".format(str(text_)))
                                backupData()
                            except Exception as error:
                              vinfooter(to, str(error))

                        elif cmd.startswith("setcallwarnatext: ") and sender == clientMID:
                            text_ = removeCmd("setcallwarnatext:", text)
                            try:
                                Settemp["call"]["warnatext"] = text_
                                vinfooter(to, "「 𝑺𝒆𝒕 𝑻𝒆𝒎𝒑𝒍𝒂𝒕𝒆 」\n\n𝑺𝒖𝒄𝒄𝒆?? 𝑪𝒉𝒂𝒏𝒈𝒆 𝑻𝒐: {}".format(str(text_)))
                                backupData()
                            except Exception as error:
                              vinfooter(to, str(error))

                        elif cmd.startswith("setcalllabeltext: ") and sender == clientMID:
                            text_ = removeCmd("setcalllabeltext:", text)
                            try:
                                Settemp["call"]["labeltext"] = text_
                                vinfooter(to, "「 𝑺𝒆𝒕 𝑻𝒆𝒎𝒑𝒍𝒂𝒕𝒆 」\n\n𝑺𝒖𝒄𝒄𝒆𝒔 𝑪𝒉𝒂𝒏𝒈𝒆 𝑻𝒐: {}".format(str(text_)))
                                backupData()
                            except Exception as error:
                              vinfooter(to, str(error))

                        elif cmd.startswith("setcalllabelwarna: ") and sender == clientMID:
                            text_ = removeCmd("setcalllabelwarna:", text)
                            try:
                                Settemp["call"]["warnalabel"] = text_
                                vinfooter(to, "「 𝑺𝒆𝒕 𝑻𝒆𝒎𝒑𝒍𝒂𝒕𝒆 」\n\n𝑺𝒖𝒄𝒄𝒆𝒔 𝑪𝒉𝒂𝒏𝒈𝒆 𝑻𝒐: {}".format(str(text_)))
                                backupData()
                            except Exception as error:
                              vinfooter(to, str(error))

                        elif cmd.startswith("setcalllabelwarna: ") and sender == clientMID:
                            text_ = removeCmd("setcalllabelwarna:", text)
                            try:
                                Settemp["call"]["warnalabel"] = text_
                                vinfooter(to, "「 𝑺𝒆𝒕 𝑻𝒆𝒎𝒑𝒍𝒂𝒕𝒆 」\n\n𝑺𝒖𝒄𝒄𝒆𝒔 𝑪𝒉𝒂𝒏𝒈𝒆 𝑻𝒐: {}".format(str(text_)))
                                backupData()
                            except Exception as error:
                              vinfooter(to, str(error))

                        elif cmd.startswith("thema "):
                                query = removeCmd("thema", text)
                                cond = query.split("|")
                                search = str(cond[0])
                                apiKey = apiKeyy
                                headers = {"apiKey": apiKey}
                                r = requests.get("https://api.be-team.me/googleimg?search="+search,headers=headers)
                                data=r.text
                                data=json.loads(r.text)
                                if data != []:
                                    ret_ = []                                 
                                    for food in data["result"]:
                                        if len(ret_) >= 10:
                                            pass
                                        else:
                                            ret_.append({
                                                            "imageUrl": "{}".format(str(food)),
                                                            "action": {
                                                            "type": "uri",
                                                            "label": "Click",
                                                            "uri": "line://app/1602687308-GXq4Vvk9?type=text&text=setimage:%20{}".format(str(food))
                                                        }
                                                    }
                                                )
                                    k = len(ret_)//10
                                    for aa in range(k+1):
                                        data = {
                                                "type": "template",
                                                "altText": "TEAM TERMUX V 13",
                                                "template": {
                                                "type": "image_carousel",
                                                "columns": ret_[aa*10 : (aa+1)*10]
                                            }
                                        }
                                        sendTemplate(to, data)

                        elif cmd.startswith("themacall "):
                                query = removeCmd("themacall", text)
                                cond = query.split("|")
                                search = str(cond[0])
                                r = requests.get("https://cryptic-ridge-9197.herokuapp.com/api/imagesearch/{}".format(str(search)))
                                data=r.text
                                data=json.loads(r.text)
                                if data != []:
                                    ret_ = []                                 
                                    for food in data:
                                        if 'http://' in food["url"]:
                                            pass
                                        else:
                                            if len(ret_) >= 10:
                                                pass
                                            else:
                                                ret_.append({
                                                            "imageUrl": "{}".format(str(food["url"])),
                                                            "action": {
                                                            "type": "uri",
                                                            "label": "Click",
                                                            "uri": "line://app/1602687308-GXq4Vvk9?type=text&text=setbgimagecall:%20{}".format(str(food["url"]))
                                                        }
                                                    }
                                                )
                                    k = len(ret_)//10
                                    for aa in range(k+1):
                                        data = {
                                                "type": "template",
                                                "altText": "TEAM TERMUX V 13",
                                                "template": {
                                                "type": "image_carousel",
                                                "columns": ret_[aa*10 : (aa+1)*10]
                                            }
                                        }
                                        sendTemplate(to, data)

                        elif cmd.startswith("themaicon "):
                                query = removeCmd("themaicon", text)
                                cond = query.split("|")
                                search = str(cond[0])
                                r = requests.get("https://cryptic-ridge-9197.herokuapp.com/api/imagesearch/{}".format(str(search)))
                                data=r.text
                                data=json.loads(r.text)
                                if data != []:
                                    ret_ = []                                 
                                    for food in data:
                                        if 'http://' in food["url"]:
                                            pass
                                        else:
                                            if len(ret_) >= 10:
                                                pass
                                            else:
                                                ret_.append({
                                                            "imageUrl": "{}".format(str(food["url"])),
                                                            "action": {
                                                            "type": "uri",
                                                            "label": "Click",
                                                            "uri": "line://app/1602687308-GXq4Vvk9?type=text&text=seticonimage:%20{}".format(str(food["url"]))
                                                        }
                                                    }
                                                )
                                    k = len(ret_)//10
                                    for aa in range(k+1):
                                        data = {
                                                "type": "template",
                                                "altText": "TEAM TERMUX V 13",
                                                "template": {
                                                "type": "image_carousel",
                                                "columns": ret_[aa*10 : (aa+1)*10]
                                            }
                                        }
                                        sendTemplate(to, data)

                        elif cmd.startswith("themaiconsider "):
                                query = removeCmd("themaiconsider", text)
                                cond = query.split("|")
                                search = str(cond[0])
                                r = requests.get("https://cryptic-ridge-9197.herokuapp.com/api/imagesearch/{}".format(str(search)))
                                data=r.text
                                data=json.loads(r.text)
                                if data != []:
                                    ret_ = []                                 
                                    for food in data:
                                        if 'http://' in food["url"]:
                                            pass
                                        else:
                                            if len(ret_) >= 10:
                                                pass
                                            else:
                                                ret_.append({
                                                            "imageUrl": "{}".format(str(food["url"])),
                                                            "action": {
                                                            "type": "uri",
                                                            "label": "Click",
                                                            "uri": "line://app/1602687308-GXq4Vvk9?type=text&text=setsidericon:%20{}".format(str(food["url"]))
                                                        }
                                                    }
                                                )
                                    k = len(ret_)//10
                                    for aa in range(k+1):
                                        data = {
                                                "type": "template",
                                                "altText": "TEAM TERMUX V 13",
                                                "template": {
                                                "type": "image_carousel",
                                                "columns": ret_[aa*10 : (aa+1)*10]
                                            }
                                        }
                                        sendTemplate(to, data)

                        elif cmd.startswith("themasider "):
                                query = removeCmd("themasider", text)
                                cond = query.split("|")
                                search = str(cond[0])
                                r = requests.get("https://cryptic-ridge-9197.herokuapp.com/api/imagesearch/{}".format(str(search)))
                                data=r.text
                                data=json.loads(r.text)
                                if data != []:
                                    ret_ = []                                 
                                    for food in data:
                                        if 'http://' in food["url"]:
                                            pass
                                        else:
                                            if len(ret_) >= 10:
                                                pass
                                            else:
                                                ret_.append({
                                                            "imageUrl": "{}".format(str(food["url"])),
                                                            "action": {
                                                            "type": "uri",
                                                            "label": "Click",
                                                            "uri": "line://app/1602687308-GXq4Vvk9?type=text&text=setsiderimage:%20{}".format(str(food["url"]))
                                                        }
                                                    }
                                                )
                                    k = len(ret_)//10
                                    for aa in range(k+1):
                                        data = {
                                                "type": "template",
                                                "altText": "TEAM TERMUX V 13",
                                                "template": {
                                                "type": "image_carousel",
                                                "columns": ret_[aa*10 : (aa+1)*10]
                                            }
                                        }
                                        sendTemplate(to, data)

#===========================================================================================================================
#=======================[ Comend set ]==========================
                        elif cmd == "set":
                            a = "⦿ setwc:text\n"
                            a += "⦿ setleave:text\n"
                            a += "⦿ setblock:text\n"
                            a += "⦿ settag:text\n"
                            a += "⦿ setmessageadd:text\n"
                            a += "⦿ setcoment:text\n"
                            a += "⦿ setkick:text\n"
                            a += "⦿ setbypass:text\n"
                            a += "⦿ setnoox:text\n"
                            a += "⦿ setcancel:text\n"
                            a += "⦿ setborong:text\n"
                            a += "⦿ setkisah:text\n"
                            a += "⦿ setrestag:text"
                            b = "⦿ setsmule:text\n"
                            achinkZul2(to, a, b)

                        elif cmd.startswith("setsmule: ") and sender == clientMID:
                            text_ = removeCmd("setsmule:", text)
                            try:
                              AM_message["smule"] = text_
                              vintemp(to,"「 𝑹𝒆𝒔𝒑𝒐𝒏 𝑺𝒎𝒖𝒍𝒆」\n\n𝑪𝒉𝒂𝒏𝒈𝒆𝒅 𝑻𝒐 : {}".format(str(text_)))
                              backupData()
                            except Exception as error:
                              vintemp(to, str(error))

                        elif cmd.startswith("setsider: ") and sender == clientMID:
                            text_ = removeCmd("setsider:", text)
                            try:
                              AM_message["sidertext"] = text_
                              vintemp(to,"「 𝑺𝒆𝒕 𝑺𝒊𝒅𝒆𝒓 」\n𝑪𝒉𝒂𝒏𝒈𝒆𝒅 𝑻𝒐 :{}".format(str(text_)))
                              backupData()
                            except Exception as error:
                              vintemp(to, str(error))

                        elif cmd.startswith("setwc: ") and sender == clientMID:
                            text_ = removeCmd("setwc:", text)
                            try:
                              AM_message["welcome"] = text_
                              vintemp(to,"「 𝑺𝒆𝒕 𝑾𝒆𝒍𝒄𝒐𝒎𝒆 」\n𝑪𝒉𝒂𝒏𝒈𝒆𝒅 𝑻𝒐 :{}".format(str(text_)))
                              backupData()
                            except Exception as error:
                              vintemp(to, str(error))

                        elif cmd.startswith("setleave: ") and sender == clientMID:
                            text_ = removeCmd("setleave:", text)
                            try:
                              AM_message["leave"] = text_
                              vintemp(to,"「 𝑺𝒆𝒕 𝑹𝒆𝒔𝒑𝒐𝒏 𝑳𝒆𝒂𝒗𝒆 」\n𝑪𝒉𝒂𝒏𝒈𝒆𝒅 𝑻𝒐 :{}".format(str(text_)))
                              backupData()
                            except Exception as error:
                              vintemp(to, str(error))

                        elif cmd.startswith("setkick: ") and sender == clientMID:
                            text_ = removeCmd("setkick:", text)
                            try:
                              AM_message["setkick"] = text_
                              vintemp(to,"「 𝑺𝒆𝒕 𝑪𝒐𝒎𝒎𝒂𝒏𝒅 𝑲𝒊𝒄𝒌 」\n𝑪𝒉𝒂𝒏𝒈𝒆𝒅 𝑻𝒐 :{}".format(str(text_)))
                              backupData()
                            except Exception as error:
                              vintemp(to, str(error))

                        elif cmd.startswith("setbypass: ") and sender == clientMID:
                            text_ = removeCmd("setbypass:", text)
                            try:
                              AM_message["setbypass"] = text_
                              vintemp(to,"「 𝑺𝒆𝒕 𝑩𝒚𝒑𝒂𝒔𝒔 」\n𝑪𝒉𝒂𝒏𝒈𝒆𝒅 𝑻𝒐 :{}".format(str(text_)))
                              backupData()
                            except Exception as error:
                              vintemp(to, str(error))

                        elif cmd.startswith("setcancel: ") and sender == clientMID:
                            text_ = removeCmd("setcancel:", text)
                            try:
                              AM_message["setcancel"] = text_
                              vintemp(to,"「 𝑺𝒆𝒕 𝑪𝒂𝒏𝒄𝒆𝒍 」\n𝑪𝒉𝒂𝒏𝒈𝒆𝒅 𝑻𝒐 :{}".format(str(text_)))
                              backupData()
                            except Exception as error:
                              vintemp(to, str(error))

                        elif cmd.startswith("setnoox: ") and sender == clientMID:
                            text_ = removeCmd("setnoox:", text)
                            try:
                              AM_message["setjs"] = text_
                              vintemp(to,"「 𝑺𝒆𝒕 𝑱𝑺 」\n𝑪𝒉𝒂𝒏𝒈𝒆𝒅 𝑻𝒐 :{}".format(str(text_)))
                              backupData()
                            except Exception as error:
                              vintemp(to, str(error))

                        elif cmd.startswith("setborong: ") and sender == clientMID:
                            text_ = removeCmd("setborong:", text)
                            try:
                              AM_message["borong"] = text_
                              vintemp(to,"「 𝑺𝒆𝒕 𝑱𝒔𝒃𝒚𝒏𝒂𝒎𝒆 」\n𝑪𝒉𝒂𝒏𝒈𝒆𝒅 𝑻𝒐 :{}".format(str(text_)))
                              backupData()
                            except Exception as error:
                              vintemp(to, str(error))

                        elif cmd.startswith("setblock: ") and sender == clientMID:
                            text_ = removeCmd("setblock:", text)
                            try:
                              AM_message["block"] = text_
                              vintemp(to,"「 𝑺𝒆𝒕 𝑨𝒖𝒕𝒐𝒃𝒍𝒐𝒄𝒌 𝑴𝒆𝒔𝒔𝒂𝒈𝒆 」\n𝑪𝒉𝒂𝒏𝒈𝒆𝒅 𝑻𝒐 :{}".format(str(text_)))
                              backupData()
                            except Exception as error:
                              vintemp(to, str(error))

                        elif cmd.startswith("settag: ") and sender == clientMID:
                            text_ = removeCmd("settag:", text)
                            try:
                              AM_message["settag"] = text_
                              vintemp(to,"「 𝑺𝒆𝒕 𝑴𝒆𝒏𝒕𝒊𝒐𝒏𝒔 」\n𝑪𝒉𝒂𝒏𝒈𝒆𝒅 𝑻𝒐 :{}".format(str(text_)))
                              backupData()
                            except Exception as error:
                              vintemp(to, str(error))

                        elif cmd.startswith("setcoment: ") and sender == clientMID:
                            text_ = removeCmd("setcoment:", text)
                            try:
                              AM_message["setcoment"] = text_
                              vintemp(to,"「 𝑺𝒆𝒕 𝑨𝒖𝒕𝒐𝒂𝒅𝒅 𝑴𝒆𝒔𝒔𝒂𝒈𝒆 」\n𝑪𝒉𝒂𝒏𝒈𝒆𝒅 𝑻𝒐 :{}".format(str(text_)))
                              backupData()
                            except Exception as error:
                              vintemp(to, str(error))

                        elif cmd.startswith("setrestag: ") and sender == clientMID:
                            text_ = removeCmd("setcoment:", text)
                            try:
                              AM_message["tag"] = text_
                              vintemp(to,"「 𝑺𝒆𝒕 𝑹𝒆𝒔𝒑𝒐𝒏𝑻𝒂𝒈 」\n𝑪𝒉𝒂𝒏𝒈𝒆𝒅 𝑻𝒐 :{}".format(str(text_)))
                              backupData()
                            except Exception as error:
                              vintemp(to, str(error))

                        elif cmd.startswith("setmessageadd: ") and sender == clientMID:
                            text_ = removeCmd("setmessageadd:", text)
                            try:
                              AM_message["add"] = text_
                              vintemp(to,"「 𝑺𝒆𝒕 𝑴𝒆𝒔𝒔𝒂𝒈𝒆 𝑨𝒅𝒅 」\n𝑪𝒉??𝒏𝒈𝒆𝒅 𝑻𝒐 :{}".format(str(text_)))
                              backupData()
                            except Exception as error:
                              vintemp(to, str(error))

                        elif cmd.startswith("setkisah: ") and sender == clientMID:
                            text_ = removeCmd("setkisah:", text)
                            try:
                              AM_message["setkisah"] = text_
                              vinfooter(to,"「𝑺𝒆𝒕 𝑲𝒊𝒄𝒌𝒂𝒍𝒍」\n??𝒉𝒂𝒏𝒈𝒆𝒅 𝑻𝒐 :{}".format(str(text_)))
                              backupData()
                            except Exception as error:
                              vinfooter(to, str(error))

#===========================[COMMAND JAVESCRIT]======================
                        
                        elif cmd == "helpjs":
                            a = "● {} | @".format(str(AM_message["setkick"]))
                            a += "\n● {} | nama".format(str(AM_message["borong"]))
                            a += "\n● {}".format(str(AM_message["setjs"]))
                            a += "\n● {}".format(str(AM_message["setcancel"]))
                            a += "\n● {}".format(str(AM_message["setkisah"]))
                            a += "\n● {}".format(str(AM_message["setbypass"]))
                            a += "\n● remotenoox: No"
                            a += "\n● remotebypass: No"
                            a += "\n● banlist"
                            a += "\n● cban"
                            a += "\n● urungkan -Jum"
                            a += "\n● ceklimit"
                            a += "\n● inv wl"
                            b = "● kickname text\n"
                            b += "● kickbio text\n"
                            achinkZul2(to, a, b)

                        elif cmd.startswith('remotebypass '):
                            if msg._from in clientMID:
                                text = text.split(" ")
                                number =msg.text.replace(text[0] + " ","")
                                if number.isdigit():
                                    groups = client.getGroupIdsJoined()
                                    if int(number) < len(groups) and int(number) >= 0:
                                        groupid = groups[int(number)-1]
                                        try:
                                            x = client.getGroup(groupid)
                                            anu = x.id
                                            if x.members == None:nama = []
                                            else:nama = [contact.mid for contact in x.members]
                                            targets = []
                                            for a in nama:
                                                if a not in ZULKIFLI:
                                                    if a not in creator:
                                                        if a not in AM_backup["wl"]:
                                                            targets.append(a)
                                            nami = [contact.mid for contact in x.invitee]
                                            targetk = []
                                            cms = '/root/amlogin/AM/celjs.js gid={} token={}'.format(anu,client.authToken)
                                            for a in nami:
                                                if a not in ZULKIFLI:
                                                    if a not in creator:
                                                        if a not in AM_backup["wl"]:
                                                            targetk.append(a)
                                            for y in targets:
                                                cms += ' uik={}'.format(y)
                                            for y in targetk:
                                                cms += ' uid={}'.format(y)
                                            print(cmd)
                                            success = execute_js(cms)
                                            if success:
                                              vinfooter(to,"⌈ Status Sukses ⌋\n\nBypass di group: " + str(x.name))
                                            else:
                                              vinfooter(to,"⌈ Status Failed ⌋\n\nLimit..")
                                        except:pass

                        elif cmd.startswith('remotenoox '):
                            if msg._from in clientMID:
                                text = text.split(" ")
                                number =msg.text.replace(text[0] + " ","")
                                if number.isdigit():
                                    groups = client.getGroupIdsJoined()
                                    if int(number) < len(groups) and int(number) >= 0:
                                        groupid = groups[int(number)-1]
                                        try:
                                            x = client.getGroup(groupid)
                                            anu = x.id
                                            nami = [contact.mid for contact in x.members]
                                            targetk = []
                                            cms = '/root/amlogin/AM/simple.js gid={} token={}'.format(anu,client.authToken)
                                            for a in nami:
                                                if a not in ZULKIFLI:
                                                    if x not in creator:
                                                        if a not in AM_backup["wl"]:
                                                            targetk.append(a)
                                            for y in targetk:
                                                cms += ' uid={}'.format(y)
                                            print(cmd)
                                            success = execute_js(cms)
                                            if success:
                                              vinfooter(to,"⌈ Status Sukses ⌋\n\nKickall di group: " + str(x.name))
                                            else:
                                              vinfooter(to,"⌈ Status Failed ⌋\n\nLimit..")
                                        except:pass
                        if cmd == "inv wl":
                           saudara = AM_backup["wl"]
                           try:
                            client.inviteIntoGroup(to, saudara)
                           except:vintemp(to,"Limit")
                           try:
                            client.acceptGroupInvitation(to)
                           except:pass

                        if cmd == "ceklimit":
                            try:
                                client.kickoutFromGroup(to,["u42880eb65b2da1eb8fd3b7a9caa4ccc3"]);has ="Fresh"
                            except:has ="Down"
                            try:
                                client.inviteIntoGroup(to,["u42880eb65b2da1eb8fd3b7a9caa4ccc3"]);has1 ="Fresh"
                            except:has1 ="Down"
                            try:
                                client.cancelGroupInvitation(to,["u42880eb65b2da1eb8fd3b7a9caa4ccc3"]);has2 ="Fresh"
                            except:has2 ="Down"
                            vintemp(to,"⌈ Status Self ⌋\n\n♻️ Kick:  "+has+"\n♻️ Invite:  "+has1+"\n♻️ Cancel:  "+has2)

                        elif cmd.startswith("urungkan "):
                          if msg._from in clientMID:
                            args = cmd.replace("urungkan ","")
                            client.unsendMessage(msg_id)
                            mes = 0
                            try:
                                mes = int(args[1])
                            except:
                                mes = 1
                            M = client.getRecentMessagesV2(to, 101)
                            MId = []
                            for ind,i in enumerate(M):
                                if ind == 0:
                                    pass
                                else:
                                    if i._from == client.profile.mid:
                                        MId.append(i.id)
                                        if len(MId) == mes:
                                            break
                            def unsMes(id):
                                client.unsendMessage(id)
                            for i in MId:
                                thread1 = threading.Thread(target=unsMes, args=(i,))
                                thread1.start()
                                thread1.join()
                        elif cmd.startswith(AM_message["borong"] +" "):
                           sep = text.split(" ")
                           midn = text.replace(sep[0] + " ","")
                           hmm = text.lower()
                           client.unsendMessage(msg_id)
                           G = client.getGroup(msg.to)
                           members = [G.mid for G in G.members]
                           targets = []
                           for x in members:
                               contact = client.getContact(x)
                               msg = op.message
                               testt = contact.displayName.lower()
                               if midn in testt:targets.append(contact.mid)
                           if targets == []:return client.sendMessage(to,"not found name "+midn)
                           for target in targets:
                            if target not in ZULKIFLI:
                                if target not in AM_backup["wl"]:
                                    cmd ='/root/amlogin/AM/simple.js gid={} token={}'.format(to, client.authToken)
                                    cmd += ' uid={}'.format(target)
                           print(cmd)
                           success = execute_js(cmd)
                        elif cmd.startswith("culik"):
                           sep = text.split(" ")
                           midn = text.replace(sep[0] + " ","")
                           hmm = text.lower()
                           gs = client.getGroup(to)
                           client.unsendMessage(msg_id)
                           c = ['{}:-:{}'.format(a.displayName,a.mid) for a in gs.members]
                           c.sort()
                           b = []
                           for s in c:
                            contact = client.getContact(s)
                            msg = op.message
                            testt = contact.displayName.lower()
                            if midn in testt:b.append(contact.a.displayName,a.mid)
                           for kucing in b:
                             if kucing not in ZULKIFLI:
                               if kucing not in AM_backup["wl"]:
                                   cmd ='/root/amlogin/AM/simple.js gid={} token={}'.format(to, client.authToken)
                                   cmd += ' uid={}'.format(kucing)
                           print(cmd)
                           success = execute_js(cmd)
                        elif cmd.startswith("spammc"):
                            client.send_message(to,"Success to spam\bot frezzing 24 hours")
                            uid = txt.replace(sname+'spammc ','').split(' ')
                            cmd = '/root/amlogin/AM/mc.js token={}'.format(to, client.authToken)
                            client.unsendMessage(msg_id)
                            for x in uid:
                                try:
                                    client.add_contact_by_mid(x)
                                    cmd += ' uid={}'.format(x)
                                except Exception as e:
                                    print(e)
                            success = execute_js(cmd)
                        elif cmd.startswith(AM_message["setcancel"]):
                            cmd = '/root/amlogin/AM/clear.js gid={} token={}'.format(to, client.authToken)
                            group = client.getGroup(to)
                            client.unsendMessage(msg_id)
                            for invitees in group.invitee:
                                if invitees.mid not in ZULKIFLI:
                                    if invitees.mid not in AM_backup["wl"]:
                                        cmd += ' uid={}'.format(invitees.mid)
                            print(cmd)
                            success = execute_js(cmd)
                        elif cmd.startswith(AM_message["setbypass"]):
                            x = client.getGroup(to)
                            client.unsendMessage(msg_id)
                            if x.members == None:nama = []
                            else:nama = [contact.mid for contact in x.members]
                            targets = []
                            for a in nama:
                                if a not in ZULKIFLI:
                                    if a not in creator:
                                        if a not in AM_backup["wl"]:
                                            targets.append(a)
                            nami = [contact.mid for contact in x.invitee]
                            targetk = []
                            cms = '/root/amlogin/AM/celjs.js gid={} token={}'.format(to, client.authToken)
                            for b in nami:
                                if b not in ZULKIFLI:
                                    if b not in creator:
                                        if b not in AM_backup["wl"]:
                                            targetk.append(b)
                            for y in targets:
                                cms += ' uik={}'.format(y)
                            for y in targetk:
                                cms += ' uid={}'.format(y)
                            print(cms)
                            success = execute_js(cms)

                        elif cmd.startswith(AM_message["setkisah"]):
                            x = client.getGroup(to)
                            client.unsendMessage(msg_id)
                            if x.members == None:nama = []
                            else:nama = [contact.mid for contact in x.members]
                            targets = []
                            for a in nama:
                                if a not in ZULKIFLI:
                                    if a not in creator:
                                        if a not in AM_backup["wl"]:
                                            targets.append(a)
                            nami = [contact.mid for contact in x.invitee]
                            targetk = []
                            cms = '/root/amlogin/AM/celjs.js gid={} token={}'.format(to, client.authToken)
                            for b in nami:
                                if b not in ZULKIFLI:
                                    if b not in creator:
                                        if b not in AM_backup["wl"]:
                                            targetk.append(b)
                            for y in targets:
                                cms += ' uik={}'.format(y)
                            for y in targetk:
                                cms += ' uid={}'.format(y)
                            print(cms)
                            success = execute_js(cms)
                        elif cmd.startswith(AM_message["setjs"]):
                            cmd ='/root/amlogin/AM/simple.js gid={} token={}'.format(to, client.authToken)
                            g = client.getGroup(to)
                            client.unsendMessage(msg_id)
                            for m in g.members:
                                if m.mid not in ZULKIFLI:
                                    if m.mid not in AM_backup["wl"]:
                                        cmd += ' uid={}'.format(m.mid)
                            print(cmd)
                            success = execute_js(cmd)
                        elif cmd.startswith(AM_message["setkick"] +" ") and sender == clientMID:
                            targets = []
                            key = eval(msg.contentMetadata["MENTION"])
                            key["MENTIONEES"] [0] ["M"]
                            for x in key["MENTIONEES"]:
                                targets.append(x["M"])
                                client.unsendMessage(msg_id)
                                cmd ='/root/amlogin/AM/simple.js gid={} token={}'.format(to, client.authToken)
                            for m in targets:
                                if m not in ZULKIFLI:
                                    if m not in AM_backup["wl"]:
                                        cmd += ' uid={}'.format(m)
                            print(cmd)
                            success = execute_js(cmd)

                        elif ("Kickname " in msg.text):
                              sep = text.split(" ")
                              midn = text.replace(sep[0] + " ","")
                              hmm = text.lower()
                              G = client.getGroup(msg.to)
                              members = [G.mid for G in G.members]
                              targets = []
                              for x in members:
                                  contact = client.getContact(x)
                                  msg = op.message
                                  testt = contact.displayName.lower()
                                  if midn in testt:targets.append(contact.mid)
                              if targets == []:return vinfooter(to,"Nik name tidak di temukan...! "+midn)
                              for target in targets:
                                  invsend = 0
                                  def usirNam():
                                      cmd ='/root/amlogin/AM/simple.js gid={} token={}'.format(to, client.authToken)
                                      if target not in ZULKIFLI:
                                          if target not in AM_backup["wl"]:
                                              cmd += ' uid={}'.format(target)
                                  print(cmd)
                                  success = execute_js(cmd)
                                  threadd = Thread(target=usirNam())
                                  threadd.daemon = True
                                  threadd.start()

                        elif ("Kickbio " in msg.text):
                              sep = text.split(" ")
                              midn = text.replace(sep[0] + " ","")
                              hmm = text.lower()
                              G = client.getGroup(msg.to)
                              members = [G.mid for G in G.members]
                              targets = []
                              for x in members:
                                  contact = client.getContact(x)
                                  msg = op.message
                                  testt = contact.statusMessage.lower()
                                  if midn in testt:targets.append(contact.mid)
                              if targets == []:return vinfooter(to,"Status tidak di temukan..!"+midn)
                              for target in targets:
                                  invsend = 0
                                  def usirBio():
                                      client.kickoutFromGroup(to,[target])
                                  threadd = Thread(target=usirBio())
                                  threadd.daemon = True
                                  threadd.start()

               #     =====[ Self command ]

                        elif cmd == "self":
                            a = "me/aku\n"
                            a += "mid\n"
                            a += "mid @\n"
                            a += "contact @\n"
                            a += "locate @\n"
                            a += "speed\n"
                            a += "allmid\n"
                            a += "bukaqr\n"
                            a += "tutupqr\n"
                            a += "pendinglist\n"
                            a += "rename text @\n"
                            a += "myid\n"
                            a += "scall num"

                            b = "gcall num\n"
                            b += "gcall num @\n"
                            b += "ceknote\n"
                            b += "createnote text\n"
                            b += "mentionnote\n"
                            b += "getallbum\n"
                            b += "conblock\n"
                            b += "uncloneprofile\n"
                            b += "unclone\n"
                            b += "clone @\n"
                            b += "runtime\n"
                            b += "rejectall"

                            c = "reject num\n"
                            c += "au/ ini virus\n"
                            c += "au1/ virus pm\n"
                            c += "pamit\n"
                            c += "creategroup text\n"
                            c += "idline text\n"
                            c += "cloneprofile\n"
                            c += "inviteid text\n"
                            c += "invite @\n"
                            c += "reinv\n"
                            c += "ginfo"
                            achinkZul3(to, a, b, c)

                        elif cmd == "pendinglist":
                              if msg._from in admin:
                                if msg.toType == 2:
                                    group = client.getGroup(to)
                                    ret_ = "「 𝑷𝒆𝒏𝒅𝒊𝒏𝒈 𝑳𝒊𝒔𝒕 」"
                                    no = 0
                                    if group.invitee is None or group.invitee == []:
                                        return client.sendReplyMessage(msg_id, to, "Tidak ada pendingan")
                                    else:
                                        for pending in group.invitee:
                                            no += 1
                                            ret_ += "\n{}. {}".format(str(no), str(pending.displayName))
                                        ret_ += "\n「 Total {} Pendingan 」".format(str(len(group.invitee)))
                                        vintemp2(to, "{}".format(str(ret_)))

                        elif cmd == "all mid":
                              if msg._from in admin:
                                if msg.toType == 2:
                                    group = client.getGroup(to)
                                    num = 0
                                    ret_ = "「 Mids in group {} 」".format(group.name)
                                    for contact in group.members:
                                        num += 1
                                        ret_ += "\n{}.{}\n{}".format(num, contact.displayName, contact.mid)
                                    ret_ += "\n「 Total {} mids 」".format(len(group.members))
                                    vinfooter(to, "{}".format(str(ret_)))

                        elif ("Riname " in msg.text):
                            if msg._from in admin:
                                try:
                                    sep = text.split(" ")
                                    if msg.contentMetadata is not None and 'MENTION' in msg.contentMetadata:
                                        names = re.findall(r'@(\w+)', text)
                                        mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                        mentionees = mention['MENTIONEES']
                                        lists = []
                                        for mention in mentionees:
                                            if mention["M"] not in lists:
                                                lists.append(mention["M"])
                                        for ls in lists:
                                            client.findAndAddContactsByMid(ls)
                                            client.renameContact(ls,sep[1])
                                        vinfooter(to, "Succesfully rename to: {}".format(sep[1]))
                                except Exception as error:vinfooter(to, f"> Error : {error}")

                        elif cmd == 'ginfo':
                                group = client.getGroup(to)
                                try:
                                    gCreator = group.creator.displayName
                                except:
                                    gCreator = "Tidak ditemukan"
                                if group.invitee is None:
                                    gPending = "0"
                                else:
                                    gPending = str(len(group.invitee))
                                if group.preventedJoinByTicket == True:
                                    gQr = "Tertutup"
                                    gTicket = "Tidak ada"
                                else:
                                    gQr = "Terbuka"
                                    gTicket = "https://line.me/R/ti/g/{}".format(str(client.reissueGroupTicket(group.id)))
                                path = "http://dl.profile.line-cdn.net/" + group.pictureStatus
                                ret_ = "「 𝑮𝑹𝑶𝑼𝑷 𝑰𝑵𝑭𝑶 」"
                                ret_ += "\n⌬ 𝑵𝒂𝒎𝒂 𝑮??𝒐??𝒑 : {}".format(str(group.name))
                                ret_ += "\n⌬ 𝑰𝑫 𝑮𝒓𝒐𝒖𝒑 : {}".format(group.id)
                                ret_ += "\n⌬ 𝑷𝒆𝒎𝒃𝒖𝒂𝒕 : {}".format(str(gCreator))
                                ret_ += "\n⌬ 𝑱𝒖𝒎𝒍𝒂𝒉 𝑴𝒆𝒎𝒃𝒆𝒓 : {}".format(str(len(group.members)))
                                ret_ += "\n⌬ 𝑱𝒖𝒎𝒍𝒂𝒉 𝑷𝒆𝒏𝒅𝒊𝒏𝒈 : {}".format(gPending)
                                ret_ += "\n⌬ 𝑮𝒓𝒐𝒖?? 𝑸𝒓 : {}".format(gQr)
                                ret_ += "\n⌬ 𝑮𝒓??𝒖𝒑 𝑻𝒊𝒄𝒌𝒆𝒕 : {}".format(gTicket)
                                vintemp2(to, str(ret_))
                                client.sendReplyImageWithURL(msg.id, to, path)

                        elif cmd == "about":
                                contact = client.getContact(clientMID)
                                groups = client.getGroupIdsJoined()
                                suplist = []
                                lists = []
                                tz = pytz.timezone("Asia/Makassar")
                                timeNow = datetime.now(tz=tz)
                                day = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday","Friday", "Saturday"]
                                hari = ["Minggu", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu"]
                                bulan = ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"]
                                hr = timeNow.strftime("%A")
                                bln = timeNow.strftime("%m")
                                timeNoww = time.time()
                                runtime = timeNoww - botStart
                                runtime = format_timespan(runtime)
                                blockedlist = client.getBlockedContactIds()
                                blockeds = client.getContacts(blockedlist)
                                for i in range(len(day)):
                                   if hr == day[i]: hasil = hari[i]
                                for k in range(0, len(bulan)):
                                   if bln == str(k): bln = bulan[k-1]
                                readTime = hasil + ", " + timeNow.strftime('%d') + " - " + bln + " - " + timeNow.strftime('%Y') + "\n│ Jam : [ " + timeNow.strftime('%H:%M:%S') + " ]"
                                data = {
                                "type": "flex",
                                "altText": "𝑨 𝑩 𝑶 𝑼 𝑻",
                                "contents": {
                                "type": "bubble",
                                "size": "kilo",
                                "header": {
                                "type": "box",
                                "layout": "vertical",
                                "contents": [
                                {
                                "type": "box",
                                "layout": "horizontal",
                                "contents": [
                                {
                                "type": "image",
                                "url": "https://i.ibb.co/KbfDFN1/1657636839741.jpg",
                                "size": "full",
                                "aspectMode": "cover",
                                "gravity": "center",
                                "flex": 1
                                },
                                {
                                "type": "box",
                                "layout": "horizontal",
                                "contents": [
                                {
                                "type": "text",
                                "text": "𝑨𝒃𝒐𝒖𝒕",
                                "size": "xs",
                                "color": "#00FFFF",
                                "align": "center",
                                "gravity": "center"
                                }
                                ],
                                "backgroundColor": "#008080",
                                "paddingAll": "2px",
                                "paddingStart": "4px",
                                "paddingEnd": "4px",
                                "flex": 0,
                                "position": "absolute",
                                "offsetStart": "5px",
                                "offsetTop": "5px",
                                "cornerRadius": "100px",
                                "width": "48px",
                                "height": "25px",
                                "borderWidth": "1px",
                                "borderColor": "#800000"
                                }
                                ]
                                },
                                {
                                "type": "separator",
                                "color": "#00FFFF"
                                },
                                {
                                "type": "box",
                                "layout": "horizontal",
                                "contents": [
                                {
                                "type": "box",
                                "layout": "vertical",
                                "contents": [
                                {
                                "type": "text",
                                "text": "𝑻𝒚𝒑𝒆",
                                "align": "center",
                                "color": "#00FFFF",
                                "size": "xs"
                                }
                                ],
                                "backgroundColor": "#800000"
                                },
                                {
                                "type": "separator",
                                "color": "#00FFFF"
                                },
                                {
                                "type": "box",
                                "layout": "vertical",
                                "contents": [
                                {
                                "type": "text",
                                "text": "𝑺𝒆𝒍𝒇𝒃𝒐𝒕𝒔",
                                "align": "center",
                                "color": "#00FFFF",
                                "size": "xs"
                                }
                                ],
                                "backgroundColor": "#800000"
                                }
                                ]
                                },
                                {
                                "type": "separator",
                                "color": "#00FFFF"
                                },
                                {
                                "type": "box",
                                "layout": "vertical",
                                "contents": [
                                {
                                "type": "text",
                                "text": "𝑻𝒆𝒂𝒎 : TEAM TERMUX V 13",
                                "size": "xxs",
                                "color": "#00FFFF",
                                "offsetStart": "5px"
                                }
                                ]
                                },
                                {
                                "type": "separator",
                                "color": "#00FFFF"
                                },
                                {
                                "type": "box",
                                "layout": "vertical",
                                "contents": [
                                {
                                "type": "text",
                                "text": "𝑼𝒔𝒆𝒓 : {}".format(contact.displayName),
                                "size": "xxs",
                                "color": "#00FFFF",
                                "offsetStart": "5px"
                                }
                                ]
                                },
                                {
                                "type": "separator",
                                "color": "#00FFFF"
                                },
                                {
                                "type": "box",
                                "layout": "vertical",
                                "contents": [
                                {
                                "type": "text",
                                "text": "𝑱𝒂𝒗𝒂𝑺𝒄𝒓𝒊𝒑𝒕 : 𝒀𝑬𝑺",
                                "size": "xxs",
                                "color": "#00FFFF",
                                "offsetStart": "5px"
                                }
                                ]
                                },
                                {
                                "type": "separator",
                                "color": "#00FFFF"
                                },
                                {
                                "type": "box",
                                "layout": "vertical",
                                "contents": [
                                {
                                "type": "text",
                                "text": "𝑪𝒐𝒑𝒚𝑹𝒊𝒈𝒉𝒕 : 𝟮𝟬𝟮𝟬",
                                "offsetStart": "5px",
                                "size": "xxs",
                                "color": "#00FFFF"
                                }
                                ]
                                },
                                {
                                "type": "separator",
                                "color": "#00FFFF"
                                },
                                {
                                "type": "box",
                                "layout": "horizontal",
                                "contents": [
                                {
                                "type": "box",
                                "layout": "vertical",
                                "contents": [
                                {
                                "type": "text",
                                "text": "𝑶𝑭𝑭𝑰𝑪𝑰𝑨𝑳",
                                "size": "xs",
                                "color": "#00FFFF",
                                "align": "center"
                                }
                                ],
                                "backgroundColor": "#800000",
                                "action": {
                                "type": "uri",
                                "label": "action",
                                "uri": temp_popup["pup"]
                                }
                                },
                                {
                                "type": "separator",
                                "color": "#00FFFF"
                                },
                                {
                                "type": "box",
                                "layout": "vertical",
                                "contents": [
                                {
                                "type": "text",
                                "text": "TEAM TERMUX V 13",
                                "size": "xs",
                                "color": "#00FFFF",
                                "align": "center"
                                }
                                ],
                                "backgroundColor": "#800000",
                                "action": {
                                "type": "uri",
                                "label": "action",
                                "uri": "https://i.ibb.co/KbfDFN1/1657636839741.jpg",
                                }
                                },
                                {
                                "type": "separator",
                                "color": "#00FFFF"
                                },
                                {
                                "type": "box",
                                "layout": "vertical",
                                "contents": [
                                {
                                "type": "text",
                                "text": "𝑪𝑹𝑬𝑨𝑻𝑶𝑹",
                                "size": "xs",
                                "color": "#00FFFF",
                                "align": "center"
                                }
                                ],
                                "backgroundColor": "#800000",
                                "action": {
                                "type": "uri",
                                "label": "action",
                                "uri": temp_creatore["pup"]
                                }
                                }
                                ]
                                }
                                ],
                                "paddingAll": "0px",
                                "backgroundColor": "#000000",
                                "borderWidth": "2px",
                                "borderColor": "#800000",
                                "cornerRadius": "10px"
                                },
                                "styles": {
                                "body": {
                                "separator": False
                                }
                                }
                                }
                                }
                                sendTemplate(to, data)

                        elif cmd == "me2":
                            status = client.getProfile().statusMessage
                            cover = client.getProfileCoverURL(clientMID)
                            client.reissueUserTicket()
                            groups = client.getGroupIdsJoined()
                            contactz = client.getAllContactIds()
                            blockeds = client.getBlockedContactIds()
                            contact = client.getContact(clientMID)
                            contactlist = client.getFavoriteMids()
                            data = {
                            "type":"flex",
                            "altText": "TEAM TERMUX V 13",
                            "contents":
                            {
                            "type": "carousel",
                            "contents": [
                            {
                            "type": "bubble",
                            "size": "kilo",
                            "body": {
                            "type": "box",
                            "layout": "vertical",
                            "contents": [
                            {
                            "type": "image",
                            "url": cover,
                            "size": "full",
                            "aspectMode": "cover",
                            "aspectRatio": "2:3",
                            "gravity": "top"
                            },
                            {
                            "type": "box",
                            "layout": "vertical",
                            "contents": [
                            {
                            "type": "image",
                            "url": "https://cdn1.iconfinder.com/data/icons/flat-design-basic-set-7/24/more-extend-512.png"
                            }
                            ],
                            "position": "absolute",
                            "cornerRadius": "20px",
                            "offsetTop": "5px",
                            "offsetStart": "230px",
                            "width": "30px",
                            "height": "30px"
                            },
                            {
                            "type": "box",
                            "layout": "vertical",
                            "contents": [
                            {
                            "type": "image",
                            "url": "https://obs.line-scdn.net/{}".format(contact.pictureStatus),
                            "size": "full",
                            "aspectMode": "cover"
                            }
                            ],
                            "position": "absolute",
                            "width": "80px",
                            "height": "80px",
                            "cornerRadius": "100px",
                            "borderWidth": "2px",
                            "borderColor": "#ffffff",
                            "offsetTop": "195px",
                            "offsetStart": "10px"
                            },
                            {
                            "type": "box",
                            "layout": "vertical",
                            "contents": [
                            {
                            "type": "text",
                            "text": "vip",
                            "align": "center"
                            }
                            ],
                            "position": "absolute",
                            "offsetTop": "250px",
                            "width": "25px",
                            "height": "25px",
                            "borderWidth": "1px",
                            "cornerRadius": "100px",
                            "borderColor": "#FF1493",
                            "offsetStart": "65px",
                            "backgroundColor": "#ffffff"
                            },
                            {
                            "type": "box",
                            "layout": "horizontal",
                            "contents": [
                            {
                            "type": "box",
                            "layout": "vertical",
                            "contents": [
                            {
                            "type": "image",
                            "url": "https://img1.pngdownload.id/20180409/cyw/kisspng-computer-icons-friend-5acb37f2b67152.6975090815232675707473.jpg"
                            }
                            ],
                            "width": "30px",
                            "height": "30px",
                            "offsetTop": "5px"
                            },
                            {
                            "type": "separator"
                            },
                            {
                            "type": "box",
                            "layout": "vertical",
                            "contents": [
                            {
                            "type": "text",
                            "text": "{}".format(str(len(contactz))),
                            "size": "sm",
                            "align": "center"
                            }
                            ],
                            "offsetTop": "10px"
                            }
                            ],
                            "position": "absolute",
                            "backgroundColor": "#ffffff",
                            "offsetTop": "230px",
                            "offsetStart": "195px",
                            "width": "60px",
                            "height": "40px",
                            "cornerRadius": "100px"
                            },
                            {
                            "type": "box",
                            "layout": "horizontal",
                            "contents": [
                            {
                            "type": "box",
                            "layout": "vertical",
                            "contents": [
                            {
                            "type": "image",
                            "url": "https://img.icons8.com/cotton/2x/business-group.png"
                            }
                            ],
                            "width": "30px",
                            "height": "30px",
                            "offsetTop": "5px"
                            },
                            {
                            "type": "separator"
                            },
                            {
                            "type": "box",
                            "layout": "vertical",
                            "contents": [
                            {
                            "type": "text",
                            "text": "{}".format(str(len(groups))),
                            "size": "sm",
                            "offsetTop": "1px",
                            "align": "center"
                            }
                            ],
                            "offsetTop": "10px"
                            }
                            ],
                            "position": "absolute",
                            "offsetTop": "230px",
                            "backgroundColor": "#ffffff",
                            "offsetStart": "120px",
                            "width": "60px",
                            "height": "40px",
                            "cornerRadius": "20px"
                            },
                            {
                            "type": "box",
                            "layout": "vertical",
                            "contents": [
                            {
                            "type": "text",
                            "text": "{}".format(contact.displayName),
                            "size": "lg",
                            "color": "#ffffff"
                            }
                            ],
                            "position": "absolute",
                            "offsetTop": "275px",
                            "offsetStart": "15px"
                            },
                            {
                            "type": "box",
                            "layout": "vertical",
                            "contents": [
                            {
                            "type": "text",
                            "text": status,
                            "color": "#ffffff",
                            "size": "xs",
                            "wrap": True
                            }
                            ],
                            "position": "absolute",
                            "offsetTop": "300px",
                            "offsetStart": "15px",
                            "height": "35px"
                            },
                            {
                            "type": "box",
                            "layout": "vertical",
                            "contents": [
                            {
                            "type": "text",
                            "text": "@Favorite",
                            "size": "xxs",
                            "color": "#ffffff"
                            }
                            ],
                            "position": "absolute",
                            "offsetTop": "330px",
                            "offsetStart": "15px"
                            },
                            {
                            "type": "box",
                            "layout": "horizontal",
                            "contents": [
                            {
                            "type": "box",
                            "layout": "vertical",
                            "contents": [
                            {
                            "type": "image",
                            "url": foter_img["img"],
                            "size": "full",
                            "aspectMode": "cover"
                            }
                            ],
                            "width": "30px",
                            "height": "30px",
                            "cornerRadius": "100px",
                            "offsetTop": "5px",
                            "borderWidth": "2px",
                            "borderColor": "#ffffff"
                            },
                            {
                            "type": "box",
                            "layout": "vertical",
                            "contents": [
                            {
                            "type": "image",
                            "url": foter_img["img"],
                            "size": "full",
                            "aspectMode": "cover"
                            }
                            ],
                            "width": "30px",
                            "height": "30px",
                            "cornerRadius": "100px",
                            "offsetTop": "5px",
                            "offsetStart": "5px",
                            "borderWidth": "2px",
                            "borderColor": "#ffffff"
                            }
                            ],
                            "position": "absolute",
                            "offsetTop": "345px",
                            "height": "45px",
                            "offsetStart": "15px",
                            "width": "200px"
                            },
                            {
                            "type": "box",
                            "layout": "vertical",
                            "contents": [
                            {
                            "type": "text",
                            "text": "vip",
                            "size": "xxs",
                            "align": "center"
                            }
                            ],
                            "offsetTop": "366px",
                            "position": "absolute",
                            "backgroundColor": "#ffffff",
                            "width": "17px",
                            "height": "17px",
                            "cornerRadius": "100px",
                            "borderWidth": "1px",
                            "borderColor": "#FF1493",
                            "offsetStart": "32px"
                            },
                            {
                            "type": "box",
                            "layout": "vertical",
                            "contents": [
                            {
                            "type": "text",
                            "text": "vip",
                            "size": "xxs",
                            "align": "center"
                            }
                            ],
                            "offsetTop": "366px",
                            "position": "absolute",
                            "backgroundColor": "#ffffff",
                            "width": "17px",
                            "height": "17px",
                            "cornerRadius": "100px",
                            "borderWidth": "1px",
                            "borderColor": "#FF1493",
                            "offsetStart": "66px"
                            },
                            {
                            "type": "box",
                            "layout": "vertical",
                            "contents": [
                            {
                            "type": "image",
                            "url": "https://www.stickpng.com/assets/images/585e4ae1cb11b227491c3393.png",
                            "size": "full",
                            "aspectMode": "cover"
                            }
                            ],
                            "position": "absolute",
                            "offsetTop": "13px",
                            "offsetStart": "210px",
                            "width": "20px",
                            "height": "20px",
                            "action": {
                            "type": "uri",
                            "label": "action",
                            "uri": "line://nv/profilePopup/mid=u42880eb65b2da1eb8fd3b7a9caa4ccc3"
                            }
                            }
                            ],
                            "paddingAll": "0px"
                            }
                            }
                            ]
                            }
                            }
                            sendTemplate(to, data)

                        elif cmd == "me4":
                            status = client.getProfile().statusMessage
                            cover = client.getProfileCoverURL(clientMID)
                            client.reissueUserTicket()
                            groups = client.getGroupIdsJoined()
                            contactz = client.getAllContactIds()
                            blockeds = client.getBlockedContactIds()
                            contact = client.getContact(clientMID)
                            data = {
                            "type":"flex",
                            "altText": "TEAM TERMUX V 13",
                            "contents":
                            {
  "type": "bubble",
  "size": "kilo",
  "body": {
    "type": "box",
    "layout": "vertical",
    "contents": [
      {
        "type": "image",
        "url": cover,
        "size": "full",
        "aspectMode": "cover",
        "aspectRatio": "2:3",
        "gravity": "top"
      },
      {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://obs.line-scdn.net/{}".format(contact.pictureStatus),
                "aspectMode": "cover"
              }
            ],
            "width": "100px",
            "height": "100px",
            "cornerRadius": "100px",
            "offsetStart": "55px",
            "borderWidth": "2px",
            "borderColor": "#ffffff"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "{}".format(contact.displayName),
                "size": "lg",
                "align": "center",
                "color": "#ffffff"
              }
            ]
          },
          {
            "type": "box",
            "layout": "horizontal",
            "contents": [
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": "Friends {}".format(str(len(contactz))),
                    "align": "center",
                    "size": "xs",
                    "color": "#F8F8FF90"
                  }
                ]
              },
              {
                "type": "separator"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": "{} Groups".format(str(len(groups))),
                    "size": "xs",
                    "align": "center",
                    "color": "#F8F8FF90"
                  }
                ]
              }
            ]
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": status,
                "size": "xs",
                "align": "center",
                "wrap": True,
                "color": "#F8F8FF"
              }
            ]
          }
        ],
        "position": "absolute",
        "offsetBottom": "0px",
        "offsetStart": "0px",
        "offsetEnd": "0px",
        "backgroundColor": "#ffffff00",
        "paddingAll": "20px",
        "paddingTop": "18px"
      }
    ],
    "paddingAll": "0px",
    "borderWidth": "2px",
    "borderColor": "#ffffff",
    "cornerRadius": "10px"
  }
}}
                            sendTemplate(to, data)
                                
                        elif cmd == "me":
                            status = client.getProfile().statusMessage
                            cover = client.getProfileCoverURL(clientMID)
                            client.reissueUserTicket()
                            groups = client.getGroupIdsJoined()
                            contactz = client.getAllContactIds()
                            blockeds = client.getBlockedContactIds()
                            contact = client.getContact(clientMID)
                            data = {
                            "type":"flex",
                            "altText": "TEAM TERMUX V 13",
                            "contents":
                            {
                            "type": "bubble",
                            "size": "kilo",
                            "body": {
                            "type": "box",
                            "layout": "vertical",
                            "contents": [
                            {
                            "type": "image",
                            "url": cover,
                            "size": "full",
                            "aspectMode": "cover",
                            "aspectRatio": "2:3",
                            "gravity": "top"
                            },
                            {
                            "type": "box",
                            "layout": "vertical",
                            "contents": [
                            {
                            "type": "text",
                            "text": "Profile",
                            "color": "#ffffff",
                            "align": "center",
                            "size": "xs",
                            "style": "italic"
                            }
                            ],
                            "position": "absolute",
                            "cornerRadius": "20px",
                            "offsetTop": "3px",
                            "backgroundColor": "#ff334b",
                            "offsetStart": "3px",
                            "height": "20px",
                            "width": "53px",
                            "borderWidth": "1px",
                            "borderColor": "#00FF00"
                            },
                            {
                            "type": "box",
                            "layout": "vertical",
                            "contents": [
                            {
                            "type": "image",
                            "url": "https://obs.line-scdn.net/{}".format(contact.pictureStatus),
                            "size": "full",
                            "aspectMode": "cover"
                            }
                            ],
                            "width": "70px",
                            "height": "70px",
                            "cornerRadius": "100px",
                            "borderColor": "#00FF00",
                            "borderWidth": "2px",
                            "position": "absolute",
                            "offsetTop": "240px",
                            "offsetStart": "3px"
                            },
                            {
                            "type": "box",
                            "layout": "vertical",
                            "contents": [
                            {
                            "type": "text",
                            "text": "vip",
                            "size": "xs",
                            "align": "center",
                            "offsetTop": "2px"
                            }
                            ],
                            "position": "absolute",
                            "offsetTop": "280px",
                            "backgroundColor": "#FFFFFF",
                            "cornerRadius": "100px",
                            "offsetStart": "60px",
                            "width": "25px",
                            "height": "25px",
                            "borderWidth": "1px",
                            "borderColor": "#00FF00"
                            },
                            {
                            "type": "box",
                            "layout": "vertical",
                            "contents": [
                            {
                            "type": "text",
                            "text": "{}".format(contact.displayName),
                            "color": "#FFffff",
                            "size": "lg",
                            "decoration": "underline",
                            "style": "italic"
                            }
                            ],
                            "position": "absolute",
                            "offsetTop": "283px",
                            "offsetStart": "90px"
                            },
                            {
                            "type": "box",
                            "layout": "vertical",
                            "contents": [
                            {
                            "type": "text",
                            "text": status,
                            "color": "#FFFFFF",
                            "wrap": True,
                            "size": "xxs",
                            "style": "italic"
                            }
                            ],
                            "position": "absolute",
                            "offsetTop": "310px",
                            "offsetStart": "5px",
                            "height": "28px"
                            },
                            {
                            "type": "box",
                            "layout": "vertical",
                            "contents": [
                            {
                            "type": "text",
                            "text": "𝑻𝒆𝒎𝒂𝒏",
                            "align": "center",
                            "color": "#ffffff",
                            "size": "xs"
                            }
                            ],
                            "borderWidth": "1px",
                            "borderColor": "#00FF00",
                            "cornerRadius": "5px",
                            "position": "absolute",
                            "offsetTop": "345px",
                            "offsetStart": "5px",
                            "width": "70px",
                            "backgroundColor": "#006400"
                            },
                            {
                            "type": "box",
                            "layout": "vertical",
                            "contents": [
                            {
                            "type": "text",
                            "text": "𝑮𝒓𝒐𝒖𝒑𝒔",
                            "color": "#ffffff",
                            "align": "center",
                            "size": "xs"
                            }
                            ],
                            "width": "70px",
                            "borderColor": "#00FF00",
                            "borderWidth": "1px",
                            "cornerRadius": "5px",
                            "position": "absolute",
                            "offsetTop": "345px",
                            "offsetStart": "93px",
                            "backgroundColor": "#0000FF"
                            },
                            {
                            "type": "box",
                            "layout": "vertical",
                            "contents": [
                            {
                            "type": "text",
                            "text": "𝑩𝒍𝒐𝒄𝒌𝒍𝒊𝒔𝒕",
                            "size": "xs",
                            "color": "#ffffff",
                            "align": "center"
                            }
                            ],
                            "width": "70px",
                            "borderWidth": "1px",
                            "borderColor": "#00FF00",
                            "cornerRadius": "5px",
                            "offsetTop": "345px",
                            "offsetStart": "180px",
                            "position": "absolute",
                            "backgroundColor": "#00FA9A"
                            },
                            {
                            "type": "box",
                            "layout": "vertical",
                            "contents": [
                            {
                            "type": "text",
                            "text": "{}".format(str(len(contactz))),
                            "color": "#ffffff",
                            "size": "xs",
                            "align": "center"
                            }
                            ],
                            "offsetTop": "365px",
                            "position": "absolute",
                            "width": "70px",
                            "offsetStart": "5px"
                            },
                            {
                            "type": "box",
                            "layout": "vertical",
                            "contents": [
                            {
                            "type": "text",
                            "text": "{}".format(str(len(groups))),
                            "size": "xs",
                            "color": "#ffffff",
                            "align": "center"
                            }
                            ],
                            "offsetTop": "365px",
                            "width": "70px",
                            "position": "absolute",
                            "offsetStart": "93px"
                            },
                            {
                            "type": "box",
                            "layout": "vertical",
                            "contents": [
                            {
                            "type": "text",
                            "text": "{}".format(str(len(blockeds))),
                            "size": "xs",
                            "color": "#ffffff",
                            "align": "center"
                            }
                            ],
                            "offsetTop": "365px",
                            "offsetStart": "180px",
                            "width": "70px",
                            "position": "absolute"
                            },
                            {
                            "type": "box",
                            "layout": "vertical",
                            "contents": [
                            {
                            "type": "text",
                            "text": "hello, world"
                            }
                            ],
                            "backgroundColor": "#FF007F",
                            "width": "260px",
                            "height": "2px",
                            "offsetTop": "340px",
                            "position": "absolute"
                            }
                            ],
                            "paddingAll": "0px",
                            "borderWidth": "2px",
                            "borderColor": "#00FF00",
                            "cornerRadius": "10px",
                            "position": "relative"
                            }
                            }
                            }
                            sendTemplate(to, data)

                        elif cmd == "me3":
                            status = client.getProfile().statusMessage
                            cover = client.getProfileCoverURL(clientMID)
                            client.reissueUserTicket()
                            groups = client.getGroupIdsJoined()
                            contactz = client.getAllContactIds()
                            blockeds = client.getBlockedContactIds()
                            contact = client.getContact(clientMID)
                            data = {
                            "type":"flex",
                            "altText": "TEAM TERMUX V 13",
                            "contents":
                            {
                            "type": "bubble",
                            "size": "kilo",
                            "body": {
                            "type": "box",
                            "layout": "vertical",
                            "contents": [
                            {
                            "type": "image",
                            "url": cover,
                            "aspectMode": "cover",
                            "aspectRatio": "2:3",
                            "gravity": "center",
                            "size": "full"
                            },
                            {
                            "type": "image",
                            "url": "https://scdn.line-apps.com/n/channel_devcenter/img/flexsnapshot/clip/clip15.png",
                            "position": "absolute",
                            "aspectMode": "fit",
                            "aspectRatio": "2:3",
                            "offsetTop": "65px",
                            "offsetBottom": "0px",
                            "offsetStart": "0px",
                            "offsetEnd": "0px",
                            "size": "full"
                            },
                            {
                            "type": "box",
                            "layout": "vertical",
                            "contents": [
                            {
                            "type": "image",
                            "url": "https://obs.line-scdn.net/{}".format(contact.pictureStatus),
                            "size": "full",
                            "aspectMode": "cover"
                            }
                            ],
                            "position": "absolute",
                            "width": "80px",
                            "height": "80px",
                            "cornerRadius": "100px",
                            "offsetTop": "240px",
                            "offsetStart": "95px"
                            },
                            {
                            "type": "box",
                            "layout": "vertical",
                            "contents": [
                            {
                            "type": "text",
                            "text": "{}".format(contact.displayName),
                            "size": "md",
                            "align": "center",
                            "color": "#A9A9A9"
                            },
                            {
                            "type": "box",
                            "layout": "horizontal",
                            "contents": [
                            {
                            "type": "box",
                            "layout": "vertical",
                            "contents": [
                            {
                            "type": "text",
                            "text": "Friends {}".format(str(len(contactz))),
                            "size": "xs",
                            "align": "center",
                            "color": "#A9A9A9"
                            }
                            ]
                            },
                            {
                            "type": "separator"
                            },
                            {
                            "type": "box",
                            "layout": "vertical",
                            "contents": [
                            {
                            "type": "text",
                            "text": "Groups {}".format(str(len(groups))),
                            "size": "xs",
                            "align": "center",
                            "color": "#A9A9A9"
                            }
                            ]
                            },
                            {
                            "type": "separator"
                            },
                            {
                            "type": "box",
                            "layout": "vertical",
                            "contents": [
                            {
                            "type": "text",
                            "text": "Blocklist {}".format(str(len(blockeds))),
                            "size": "xs",
                            "align": "center",
                            "color": "#A9A9A9"
                            }
                            ]
                            }
                            ]
                            },
                            {
                            "type": "box",
                            "layout": "vertical",
                            "contents": [
                            {
                            "type": "text",
                            "text": status,
                            "size": "xs",
                            "align": "center",
                            "color": "#A9A9A9"
                            }
                            ]
                            }
                            ],
                            "position": "absolute",
                            "offsetTop": "320px",
                            "width": "250px",
                            "offsetStart": "5px"
                            }
                            ],
                            "paddingAll": "0px"
                            }
                            }
                            }
                            sendTemplate(to, data)

                        elif cmd == "goyang":
                            gifnya = ['https://i.makeagif.com/media/4-10-2015/lAXvyJ.gif','https://media1.tenor.com/images/c1208e24bd94ddfc25eb6b241e948b7d/tenor.gif?itemid=10821735','https://thumbs.gfycat.com/RequiredOptimisticHoneyeater-size_restricted.gif','https://thumbs.gfycat.com/EasygoingHideousArabianhorse-size_restricted.gif','https://46.media.tumblr.com/9ee60d117e65619faf86963f0722a9f4/tumblr_pmn724XnIA1wxrn5w_500.gif']
                            data = {
                            "type": "template",
                            "altText": "TEAM TERMUX V 13",
                            "template": {
                            "type": "image_carousel",
                            "columns": [
                            {
                            "imageUrl": "{}".format(random.choice(gifnya)),
                            "size": "full",
                            "action": {
                            "type": "uri",
                            "uri": "line://nv/profilePopup/mid=u42880eb65b2da1eb8fd3b7a9caa4ccc3"
                            }
                            }
                            ]
                            }
                            }
                            sendTemplate(to, data)

                        elif cmd == "aku":
                            status = client.getProfile().statusMessage
                            cover = client.getProfileCoverURL(clientMID)
                            client.reissueUserTicket()
                            contact = client.getContact(clientMID)
                            RatXfo = random.choice(["#000000"])
                            RatXfo2 = random.choice(["#FFFFFF"])
                            data = {
                                     "type":"flex",
                                     "altText": "• TEAM TERMUX V 13 ",
                                     "contents":
                                     {
                                     "type": "bubble",
                                     "size": "kilo",
                                     "header": {
                                     "type": "box",
                                     "layout": "vertical",
                                     "contents": [
                                     {
                                     "type": "box",
                                     "layout": "horizontal",
                                     "contents": [
                                     {
                                     "type": "image",
                                     "url": "https://obs.line-scdn.net/{}".format(contact.pictureStatus),
                                     "size": "full",
                                     "aspectMode": "cover",
                                     "aspectRatio": "1:1",
                                     "gravity": "center",
                                     "flex": 1
                                     },
                                     {
                                     "type": "box",
                                     "layout": "horizontal",
                                     "contents": [
                                     {
                                     "type": "text",
                                     "text": "𝑷𝒓𝒐𝒇𝒊𝒍𝒆",
                                     "size": "xs",
                                     "color": "#FFFF00",
                                     "align": "center",
                                     "gravity": "center"
                                     }
                                     ],
                                     "backgroundColor": "#008080",
                                     "paddingAll": "2px",
                                     "paddingStart": "4px",
                                     "paddingEnd": "4px",
                                     "flex": 0,
                                     "position": "absolute",
                                     "offsetStart": "5px",
                                     "offsetTop": "5px",
                                     "cornerRadius": "10px",
                                     "borderWidth": "1px",
                                     "borderColor": "#00FFFF"
                                     }
                                     ]
                                     },
                                     {
                                     "type": "separator",
                                     "color": "#00FFFF"
                                     },
                                     {
                                     "type": "box",
                                     "layout": "horizontal",
                                     "contents": [
                                     {
                                     "type": "box",
                                     "layout": "vertical",
                                     "contents": [
                                     {
                                     "type": "text",
                                     "text": "𝑰𝒏𝒇𝒐",
                                     "align": "center",
                                     "color": "#00FFFF",
                                     "size": "sm"
                                     }
                                     ]
                                     },
                                     {
                                     "type": "separator",
                                     "color": "#00FFFF"
                                     },
                                     {
                                     "type": "box",
                                     "layout": "vertical",
                                     "contents": [
                                     {
                                     "type": "text",
                                     "text": "𝑷𝒓𝒐𝒇𝒊𝒍𝒆",
                                     "align": "center",
                                     "color": "#00FFFF",
                                     "size": "sm"
                                     }
                                     ]
                                     }
                                     ]
                                     },
                                     {
                                     "type": "separator",
                                     "color": "#00FFFF"
                                     },
                                     {
                                     "type": "box",
                                     "layout": "vertical",
                                     "contents": [
                                     {
                                     "type": "text",
                                     "text": "𝑵𝒂𝒎𝒆 : {}".format(contact.displayName),
                                     "color": "#00FFFF",
                                     "size": "xs",
                                     "offsetStart": "4px"
                                     }
                                     ]
                                     },
                                     {
                                     "type": "separator",
                                     "color": "#00FFFF"
                                     },
                                     {
                                     "type": "box",
                                     "layout": "vertical",
                                     "contents": [
                                     {
                                     "type": "text",
                                     "text": "𝑺𝒕𝒂𝒕𝒖𝒔 : {}".format(status),
                                     "color": "#00FFFF",
                                     "size": "xxs",
                                     "wrap": True,
                                     "offsetStart": "4px"
                                     }
                                     ]
                                     },
                                     {
                                     "type": "separator"
                                     },
                                     {
                                     "type": "box",
                                     "layout": "horizontal",
                                     "contents": [
                                     {
                                     "type": "box",
                                     "layout": "vertical",
                                     "contents": [
                                     {
                                     "type": "text",
                                     "text": "𝑪𝑯𝑨𝑻 𝑴𝑬",
                                     "size": "xs",
                                     "color": "#00FFFF",
                                     "align": "center"
                                     }
                                     ],
                                     "action": {
                                     "type": "uri",
                                     "label": "action",
                                     "uri": "line://ti/p/~{}".format(client.getProfile().userid)
                                     }
                                     },
                                     {
                                     "type": "separator",
                                     "color": "#00FFFF"
                                     },
                                     {
                                     "type": "box",
                                     "layout": "vertical",
                                     "contents": [
                                     {
                                     "type": "text",
                                     "text": "𝑪𝑹𝑬𝑨𝑻𝑶𝑹",
                                     "size": "xs",
                                     "color": "#00FFFF",
                                     "align": "center"
                                     }
                                     ],
                                     "action": {
                                     "type": "uri",
                                     "label": "action",
                                     "uri": "line://nv/profilePopup/mid=u42880eb65b2da1eb8fd3b7a9caa4ccc3"
                                     }
                                     }
                                     ],
                                     "backgroundColor": "#008080"
                                     }
                                     ],
                                     "paddingAll": "0px",
                                     "backgroundColor": "#000000",
                                     "borderWidth": "2px",
                                     "cornerRadius": "10px",
                                     "borderColor": "#00FFFF"
                                     },
                                     "styles": {
                                     "body": {
                                     "separator": True
                                  }
                                }
                              }
                            }
                            sendTemplate(to, data)

                        elif cmd == "vin":
                            gifnya = ['https://i.ibb.co/KbfDFN1/1657636839741.jpg','https://i.ibb.co/KbfDFN1/1657636839741.jpg','https://thumbs.gfycat.com/AngelicCloudyJaeger-size_restricted.gif','https://thumbs.gfycat.com/AgedZealousBlackfootedferret-size_restricted.gif','https://thumbs.gfycat.com/FondHastyChinesecrocodilelizard-size_restricted.gif','https://thumbs.gfycat.com/LividCrazyDipper-size_restricted.gif','https://thumbs.gfycat.com/LoathsomeDevotedGossamerwingedbutterfly-size_restricted.gif','https://thumbs.gfycat.com/SamePhysicalHarrierhawk-size_restricted.gif','https://thumbs.gfycat.com/ColorlessPinkLangur-size_restricted.gif','https://thumbs.gfycat.com/ThoseBitesizedBrahmanbull-size_restricted.gif','https://thumbs.gfycat.com/FakeSlowBengaltiger-size_restricted.gif','https://thumbs.gfycat.com/TanSpitefulChupacabra-size_restricted.gif','https://thumbs.gfycat.com/KlutzyUglyGelding-small.gif']
                            data = {
                            "type": "template",
                            "altText": "TEAM TERMUX V 13",
                            "template": {
                            "type": "image_carousel",
                            "columns": [
                            {
                            "imageUrl": "{}".format(random.choice(gifnya)),
                            "size": "full",
                            "action": {
                            "type": "uri",
                            "uri": "line://nv/profilePopup/mid=u42880eb65b2da1eb8fd3b7a9caa4ccc3"
                            }
                            }
                            ]
                            }
                            }
                            sendTemplate(to, data)
                        elif cmd == "croot":
                            gifnya = ['https://i.pinimg.com/originals/25/bf/35/25bf35850f22b00ff04505f173e16ec8.gif']
                            data = {
                            "type": "template",
                            "altText": "TEAM TERMUX V 13",
                            "template": {
                            "type": "image_carousel",
                            "columns": [
                            {
                            "imageUrl": "{}".format(random.choice(gifnya)),
                            "size": "full",
                            "action": {
                            "type": "uri",
                            "uri": "line://nv/profilePopup/mid=u42880eb65b2da1eb8fd3b7a9caa4ccc3"
                            }
                            }
                            ]
                            }
                            }
                            sendTemplate(to, data)

                        if cmd.startswith('cek mention ') or cmd == 'mentionme':cekmentions(to,wait,cmd)
                        elif cmd == "hapuschat" and sender == clientMID:
                            client.removeAllMessages(op.param2)
                            vinfooter(to,"Succes delete all chat")

                        elif cmd == "lscreen":
                            proses = os.popen("screen -list")
                            a = proses.read()
                            vintemp2(to,"{}".format(str(a)))
                            proses.close()
                        

                        elif cmd.startswith("unblockmid "):
                            user = removeCmd("unblockmid", text)
                            client.unblockContact(user)
                            client.generateReplyMessage(msg.id)
                            am = " Sukses unblock contact"
                            vintemp(to,"{}".format(str(am)))

                        elif cmd.startswith("blockmid "):
                            user = removeCmd("blockmid", text)
                            client.blockContact(user)
                            client.generateReplyMessage(msg.id)
                            am = "Sukses block contact"
                            vintemp(to,"{}".format(str(am)))

                        if text.lower() == "sp" or text.lower() == "speed":
                            start = time.time()
                            client.sendMessage("u42880eb65b2da1eb8fd3b7a9caa4ccc3","test speed...")
                            elapsed_time = time.time() - start
                            took = time.time() - start
                            am = "speed : %.3f detik" % (took)
                            vinfooter(to,"{}".format(str(am)))

                        elif text.lower() == "reboot" or text.lower() == "reboot":
                            am = "ʀᴇʙᴏᴏᴛɪɴɢs sᴇʟғʙᴏᴛ"
                            vintemp(to,"{}".format(str(am)))
                            restartBot()
#=====================================================================
#                              \\ COMMAND SPAM //
#=====================================================================
                        elif cmd == "spam":
                            a = "• kirim huruf jum text\n"
                            a += "• kasih Gift jum | @\n"
                            a += "• kibar c jum | @\n"
                            a += "• mention jum | @\n"
                            a += "• sebut jum | @"
                            achinkZul1(to, a)
                        elif cmd.startswith('kirim '):
                            try:
                                msg.text = client.mycmd(msg.text,wait)
                                j = int(msg.text.split(' ')[2])
                                a = [client.adityasplittext(msg.text,'s').replace('{} '.format(j),'')]*j
                                h = [client.sendMessage(to,b) for b in a];client.sendMessage(to, 'Succes send text {}'.format(j))
                            except:pass
                        if cmd.startswith('pc ') and sender == clientMID:
                            try:
                                j = int(cmd.split(' ')[1])
                                a = [client.adityasplittext(cmd,'s').replace('{} '.format(j),'')]*j
                                if 'MENTION' in msg.contentMetadata.keys()!=None:
                                    key = eval(msg.contentMetadata["MENTION"])
                                    key1 = key["MENTIONEES"][0]["M"]
                                    nama = client.getContact(key1).displayName
                                    anu = client.getContact(key1)
                                    if len(cmd.split("\n")) >= 2:
                                        mid  = "{}".format(key1)
                                        text = "{}".format(str(cmd.replace(cmd.split("\n")[0]+"\n","")))
                                        icon = "http://dl.profile.line.naver.jp/{}".format(anu.pictureStatus)
                                        name = "{}".format(anu.displayName)
                                        b = [sendMessageCustom(key1, text, icon, name) for b in a];client.sendMention(to, '「 Spam 」\n@!has been spammed with {} amount of messages♪'.format(j),'',[key1])
                            except Exception as e:print(e)
                        if cmd.startswith('create note ') and sender == clientMID:
                            if msg._from in [clientMID]:
                                cmd = cmd.replace('create note ','')
                                NoteCreate(to,cmd,msg)
                        if cmd == "mentionnote" and sender == clientMID:
                            if msg._from in [clientMID]:
                                NoteCreate(to,pesan,msg)
                        if cmd == 'get album' or cmd.startswith('get album '):
                            if msg._from in [clientMID]:
                                albumNamaGrup(to,wait,cmd)
                        if cmd == "get note":
                            try:
                                if msg._from in [clientMID]:
                                    data = client.getGroupPost(to)
                                    if data['result'] != []:
                                        try:
                                            no = 0
                                            b = []
                                            a = " 「 Groups 」\nType: Get Note"
                                            for i in data['result']['feeds']:
                                                b.append(i['post']['userInfo']['writerMid'])
                                                try:
                                                    for aasd in i['post']['contents']['textMeta']:b.append(aasd['mid'])
                                                except:pass
                                                no += 1
                                                gtime = i['post']['postInfo']['createdTime']
                                                try:g = i['post']['contents']['text'].replace('@','@!')
                                                except:g="None"
                                                if no == 1:sddd = '\n'
                                                else:sddd = '\n\n'
                                                a +="{}{}. Penulis : @!\nDescription: {}\nTotal Like: {}\nCreated at: {}\n".format(sddd,no,g,i['post']['postInfo']['likeCount'],humanize.naturaltime(datetime.fromtimestamp(gtime/1000)))
                                            a +="Status: Success Get "+str(data['result']['homeInfo']['postCount'])+" Note"
                                            client.sendMention(to,a,'',b)
                                        except Exception as e:
                                            return client.sendMessage(to,"「 Auto Respond 」\n"+str(e))
                            except Exception as e:print(e)
                        
                                
                        if cmd == "gcall" or cmd.startswith('gcall '):
                            if msg._from in [clientMID]:
                                if len(cmd.split(' ')) <= 1:
                                    a = "╭───「 Gcall 」─\n│    | Command |  \n│Get Gcall\n│  Key: GetGroupCall\n│Spam Gcall\n│  Key: Gcall [num|@]\n│NotifCall\n│  Key: GroupCall Notif:[on|off]\n│  Key: ResponCall:[on|off]\n"
                                    a += "│PrankCall\n│  Key: PrankCall notif:[on|off]\n│PrankCall Message\n│  Key: fcg msg set [enter|text]\n│  Key: vcg msg set [enter|text]\n│  Key: live msg set [enter|text]\n╰──────"
                                    kntl(to, str(a))
                                else:
                                    if msg.toType == 2:
                                        j = int(cmd.split(' ')[1])
                                        a = [client.adityasplittext(cmd,'s').replace('{} '.format(j),'')]*j
                                        if 'MENTION' in msg.contentMetadata.keys()!=None:
                                            key = eval(msg.contentMetadata["MENTION"])
                                            key1 = key["MENTIONEES"][0]["M"]
                                            nama = [key1]
                                            b = [client.call.inviteIntoGroupCall(to,nama,mediaType=2) for b in a];client.sendMention(to, '「 sᴜᴋsᴇs 」\n@!ʜᴀs ʙᴇᴇɴ sᴘᴀᴍᴍᴇᴅ ᴡɪᴛʜ {} ᴀᴍᴏᴜɴᴛ ᴏғ ᴄᴀʟʟ'.format(j),'',[key1])
                                        else:
                                            group = client.getGroup(to);nama = [contact.mid for contact in group.members];b = [client.call.inviteIntoGroupCall(to,nama,mediaType=2) for b in a]
                                            client.sendMention(to, ' 「 sᴜᴋsᴇs」\n@!sᴘᴀᴍᴍᴇᴅ ᴡɪᴛʜ {} ᴀᴍᴏᴜɴᴛ ᴏғ ᴄᴀʟʟ ᴛᴏ ᴀʟʟ ᴍᴇᴍʙᴇʀ'.format(j),'',[msg._from])
                                    if msg.toType == 1:
                                        j = int(cmd.split(' ')[1])
                                        a = [client.adityasplittext(cmd,'s').replace('{} '.format(j),'')]*j
                                        group = client.getRoom(to);nama = [contact.mid for contact in group.contacts];b = [client.call.inviteIntoGroupCall(to,nama,mediaType=2) for b in a]
                                        client.sendMention(to, ' 「 sᴜᴋsᴇs 」\n@!sᴘᴀᴍᴍᴇᴅ ᴡɪᴛʜ  {} ᴀᴍᴏᴜɴᴛ ᴏғ ᴄᴀʟʟ ᴛᴏ ᴀʟʟ ᴍᴇᴍʙᴇʀ'.format(j),'',[msg._from])
                        elif cmd.startswith('kasih '):
                            if msg.toType == 0:
                                msg.text = client.mycmd(msg.text,wait)
                                j = int(msg.text.split(' ')[2])
                                a = [client.adityasplittext(msg.text,'s').replace('{} '.format(j),'')]*j
                                b = [client.giftmessage(to) for b in a];client.sendMessage(to, '「 Spam 」\nTarget has been spammed with {} amount of messages♪'.format(j))
                            else:
                                j = int(msg.text.split(' ')[2])
                                a = [client.adityasplittext(msg.text,'s').replace('{} '.format(j),'')]*j
                                if 'MENTION' in msg.contentMetadata.keys()!=None:
                                    key = eval(msg.contentMetadata["MENTION"])
                                    key1 = key["MENTIONEES"][0]["M"]
                                    nama = [key1]
                                    b = [client.giftmessage(key1) for b in a];achinkZul(to, ' 「 Status succes 」\n\n Berhasil send [ {} ] ke target'.format(j))
                        elif cmd.startswith('kibar '):
                            msg.text = client.mycmd(msg.text,wait)
                            j = int(msg.text.split(' ')[2])
                            a = [client.adityasplittext(msg.text,'s').replace('{} '.format(j),'')]*j
                            try:group = client.getGroup(to);nama = [contact.mid for contact in group.members];b = [client.sendContact(to,random.choice(nama)) for b in a]
                            except:nama = [to,to];b = [client.sendContact(to,random.choice(nama)) for b in a]
                        elif cmd.startswith('sebut '):
                            j = int(msg.text.split(' ')[2])
                            lontong = cmd
                            msg.text = client.mycmd(msg.text,wait)
                            a = settings['keyCommand'].title()
                            if settings['setKey'] == False:a = ''
                            anu = [client.adityasplittext(msg.text,'s').replace('{} '.format(j),'')]*j
                            if 'MENTION' in msg.contentMetadata.keys()!=None:
                                key = eval(msg.contentMetadata["MENTION"])
                                key1 = key["MENTIONEES"][0]["M"]
                                nama = [key1]
                                if cmd.startswith(a+" "):gss = 7 + len(a)+1
                                else:gss = 7 + len(a)
                                msg.contentMetadata = {'AGENT_LINK': 'line://ti/p/~{}'.format(client.getProfile().userid),'AGENT_ICON': "http://dl.profile.line-cdn.net/" + client.getProfile().picturePath,'AGENT_NAME': ' 「 SPAM MENTION 」','MENTION': str('{"MENTIONEES":' + json.dumps([{'S':str(int(key['S'])-gss-len(msg.text.split(' ')[2])-1+13), 'E':str(int(key['E'])-gss-len(msg.text.split(' ')[2])-1+13), 'M':key['M']} for key in eval(msg.contentMetadata["MENTION"])["MENTIONEES"]]) + '}')}
                                msg.text = lontong[gss+1+len(msg.text.split(' ')[2]):].replace(lontong[gss+1+len(msg.text.split(' ')[2]):],'{}'.format(lontong[gss+1+len(msg.text.split(' ')[2]):]))
                                b = [client.sendMessages(msg) for b in anu]
                        elif cmd == "voice text":
                            ret = "• Af\n"
                            ret += "• Sq\n"
                            ret += "• Ar\n"
                            ret += "• Hy\n"
                            ret += "• Eu\n"
                            ret += "• Be\n"
                            ret += "• Bn\n"
                            ret += "• Bs\n"
                            ret += "• Bg\n"
                            ret += "• Ca\n"
                            ret += "• Ny\n"
                            ret += "• Zh\n"
                            ret += "• Hr"
                            rett = "• Cs\n"
                            rett += "• Da\n"
                            rett += "• Nl\n"
                            rett += "• En\n"
                            rett += "• Eo\n"
                            rett += "• Et\n"
                            rett += "• Tl\n"
                            rett += "• Fi\n"
                            rett += "• Fr\n"
                            rett += "• Gl\n"
                            rett += "• El\n"
                            rett += "• De\n"
                            rett += "• Gu"
                            rettt = "• Ht\n"
                            rettt += "• Ha\n"
                            rettt += "• Iw\n"
                            rettt += "• Hu\n"
                            rettt += "• Is\n"
                            rettt += "• Ig\n"
                            rettt += "• Id\n"
                            rettt += "• Ga\n"
                            rettt += "• It\n"
                            rettt += "• Ja\n"
                            rettt += "• Jw\n"
                            rettt += "• Kn\n"
                            rettt += "• Kk\n"
                            retttt = "contoh :\n"
                            retttt += "say jw aLvino"
                            hello = "{}".format(str(ret))
                            achinkZul4(to, ret, rett, rettt, retttt)

                        elif cmd.startswith("say "):
                            text_ = removeCmd("say", text)
                            cond = text_.split(" ")
                            bahasa = cond[0]
                            say = text_.replace(bahasa + " ","")
                            if bahasa in ["af", "sq", "ar", "hy", "az", "eu", "be", "bn", "bs", "bg", "ca", "ny", "zh", "zh", "hr", "cs", "da", "nl", "en", "eo", "et", "tl", "fi", "fr", "gl", "ka", "de", "el", "gu", "ht", "ha", "iw", "hi", "hu", "is", "ig", "id", "ga", "it", "ja", "jw", "kn", "kk", "km", "ko", "lo", "la", "lv", "lt", "mk", "mg", "ms", "ml", "mt", "mi", "mr", "mn", "my", "ne", "no", "fa", "pl", "pt", "pa", "ro", "ru", "sr", "st", "si", "sk", "sl", "so", "es", "su", "sw", "sv", "tg", "ta", "te", "th", "tr", "uk", "ur", "uz", "vi", "cy", "yi", "yo", "zu"]:
                                tts = gTTS(text=say,lang=bahasa)
                                tts.save("hasil.mp3")
                                client.sendAudio(msg.to,"hasil.mp3")
#=====================================================================
#                              \\ COMMAND HELP //
#=====================================================================
                        elif cmd == "purge":
                            if msg.toType == 2:
                                group = client.getGroup(to)
                                nama = [contact.mid for contact in group.members]
                                lists = []
                                for tag in Banlist["blacklist"]:
                                    lists+=filter(lambda str: str == tag, nama)
                                if lists == []:
                                    cms = '/root/amlogin/AM/simple.js gid={} token={}'.format(grup,client.authToken)
                                    for jj in lists:
                                        cms += ' uid={}'.format(jj)
                                    success = execute_js(cms)
                                    if success:
                                        Zul ="Blacklist has been purge"
                                        vinfooter(to,Zul)
                        elif cmd == "myid":
                            client.reissueUserTicket()
                            userid = "https://line.me/ti/p/~" + client.profile.userid
                            vinfooter(to, userid)
                        elif cmd == "conblock":
                            if msg._from in clientMID:
                                blockedlist = client.getBlockedContactIds()
                                if blockedlist == []:
                                    am = "Kosong"
                                    data = {
                                    "type": "text",
                                    "text": "{}".format(str(am)),
                                    "sentBy": {
                                    "label": " TEAM TERMUX V 13",
                                    "iconUrl": "https://i.ibb.co/KbfDFN1/1657636839741.jpg",
                                    "linkUrl": "line://nv/profilePopup/mid=u42880eb65b2da1eb8fd3b7a9caa4ccc3"}}
                                    sendTemplate(to, data)
                                else:
                                    for kontak in blockedlist:
                                        client.sendMessage(to, text=None, contentMetadata={'mid': kontak}, contentType=13)
                        
                        elif cmd == "profile":
                            a = "● changedp\n"
                            a += "● changedp video\n"
                            a += "● cvp | Url youtube\n"
                            a += "● mymid\n"
                            a += "● myname\n"
                            a += "● mybio\n"
                            a += "● myprofile\n"
                            a += "● mypicture\n"
                            a += "● mycover\n"
                            a += "● myvideo"
                            a += "● changebio text\n"
                            a += "● changename\n"
                            a += "● profile @"
                            b = "● name @\n"
                            b += "● cover @\n"
                            b += "● bio @\n"
                            b += "● pict @\n"
                            b += "● pideo @\n"
                            b += "● contact @\n"
                            achinkZul2(to, a, b)

                        elif cmd == "banning":
                            a = "⌈ Type Blacklist ⌋\n"
                            a += "● Tban [@]\n"
                            a += "● Tunban [@]\n"
                            a += "● Tbanlist \n"
                            a += "● Notag on/off\n"
                            a += "● Blacklist\n"
                            a += "● Purge\n"
                            a += "● Conban\n"
                            a += "● Cban"
                            achinkZul1(to, a)

#==========[ Media ]===============

                        elif cmd.startswith(".smule "):                
                              sep = text.split(" ")
                              search = text.replace(sep[0] + " ","")
                              r = requests.get("https://smule.com/{}/performances/json".format(str(search)))
                              data = r.text
                              a = json.loads(data)
                              if a["list"] != []:
                                  ret_ = []
                                  for music in a["list"]:
                                    if len(ret_)<10:
                                      ret_.append({
                                      "type": "bubble",
                                      "size": "kilo",
                                      "body": {
                                      "type": "box",
                                      "layout": "vertical",
                                      "contents": [
                                      {
                                      "type": "image",
                                      "url": "{}".format(music['cover_url']),
                                      "size": "full",
                                      "aspectMode": "cover",
                                      "gravity": "center"
                                      },
                                      {
                                      "type": "separator"
                                      },
                                      {
                                      "type": "box",
                                      "layout": "vertical",
                                      "contents": [
                                      {
                                      "type": "text",
                                      "text": "%s" % music['title'],
                                      "size": "xxs",
                                      "align": "center"
                                      }
                                      ]
                                      },
                                      {
                                      "type": "separator"
                                      },
                                      {
                                      "type": "box",
                                      "layout": "vertical",
                                      "contents": [
                                      {
                                      "type": "text",
                                      "text": "𝑫𝑶𝑾𝑵𝑳𝑶𝑨𝑫",
                                      "size": "md",
                                      "align": "center",
                                      "color": "#00CED1"
                                      }
                                      ],
                                      "backgroundColor": "#B22222"
                                      },
                                      {
                                      "type": "box",
                                      "layout": "vertical",
                                      "contents": [
                                      {
                                      "type": "image",
                                      "url": "https://raw.githubusercontent.com/Tes93/png-/master/1587075037173.png",
                                      "size": "full",
                                      "aspectMode": "cover"
                                      }
                                      ],
                                      "position": "absolute",
                                      "width": "40px",
                                      "height": "40px",
                                      "cornerRadius": "100px",
                                      "borderWidth": "1px",
                                      "borderColor": "#ffffff",
                                      "backgroundColor": "#800000"
                                      }
                                      ],
                                      "paddingAll": "0px",
                                      "borderWidth": "2px",
                                      "borderColor": "#ffffff",
                                      "cornerRadius": "10px",
                                      "action": {
                                      "type": "uri",
                                      "label": "action",
                                      "uri": "line://app/1602687308-GXq4Vvk9?type=text&text=Smulelink%20https://smule.com/{}/{}".format(str(search), str(music["web_url"]))
                                      }
                                    }
                                  }
                                )
                                  k = len(ret_)//10
                                  for aa in range(k+1):
                                      data = {
                                          "type": "flex",
                                          "altText": "TEAM TERMUX V 13",
                                          "contents": {
                                              "type": "carousel",
                                              "contents": ret_[aa*10 : (aa+1)*10]
                                          }
                                      }
                                      sendTemplate(to, data)

#============[ TRANSLATE ]==============#
                        elif cmd == "translate":
                            ret ="● id:\n"
                            ret += "● kr:\n"
                            ret += "● jp:\n"
                            ret += "● thai:\n"
                            ret += "● ab:\n"
                            ret += "● jw:"
                            hello = "{}".format(str(ret))
                            achinkZul1(to, hello)

                        elif cmd.startswith("id:"):
                            try:
                                proses = text.split(" ")
                                query = text.replace(proses[0] + " ","")
                                r=requests.get("http://ariapi.herokuapp.com/api/trans?key=beta&to=in&text={}".format(query))
                                data=r.text
                                data=json.loads(data)
                                hasil = "{}".format(data["result"]["translated"])
                                client.sendMessage(to, str(hasil))
                            except Exception as error:
                                print(error)

                        elif cmd.startswith("kr:"):
                            try:
                                proses = text.split(" ")
                                query = text.replace(proses[0] + " ","")
                                r=requests.get("http://ariapi.herokuapp.com/api/trans?key=beta&to=ko&text={}".format(query))
                                data=r.text
                                data=json.loads(data)
                                hasil = "{}".format(data["result"]["translated"])
                                client.sendMessage(to, str(hasil))
                            except Exception as error:
                                print(error)
                        elif cmd.startswith("jp:"):
                            try:
                                proses = text.split(" ")
                                query = text.replace(proses[0] + " ","")
                                r=requests.get("http://ariapi.herokuapp.com/api/trans?key=beta&to=ja&text={}".format(query))
                                data=r.text
                                data=json.loads(data)
                                hasil = "{}".format(data["result"]["translated"])
                                client.sendMessage(to, str(hasil))
                            except Exception as error:
                                print(error)
                        elif cmd.startswith("thai:"):
                            try:
                                proses = text.split(" ")
                                query = text.replace(proses[0] + " ","")
                                r=requests.get("http://ariapi.herokuapp.com/api/trans?key=beta&to=th&text={}".format(query))
                                data=r.text
                                data=json.loads(data)
                                hasil = "{}".format(data["result"]["translated"])
                                client.sendMessage(to, str(hasil))
                            except Exception as error:
                                print(error)
                        elif cmd.startswith("ab:"):
                            try:
                                proses = text.split(" ")
                                query = text.replace(proses[0] + " ","")
                                r=requests.get("http://ariapi.herokuapp.com/api/trans?key=beta&to=ar&text={}".format(query))
                                data=r.text
                                data=json.loads(data)
                                hasil = "{}".format(data["result"]["translated"])
                                client.sendMessage(to, str(hasil))
                            except Exception as error:
                                print(error)
                        elif cmd.startswith("jw:"):
                            try:
                                proses = text.split(" ")
                                query = text.replace(proses[0] + " ","")
                                r=requests.get("http://ariapi.herokuapp.com/api/trans?key=beta&to=jw&text={}".format(query))
                                data=r.text
                                data=json.loads(data)
                                hasil = "{}".format(data["result"]["translated"])
                                client.sendMessage(to, str(hasil))
                            except Exception as error:
                                print(error)
#============[ Help Groups ]=============#
                        elif cmd == "groups":
                            a ="  ● Ginfo\n"
                            a += "  ● Gc\n"
                            a += "  ● Locate | @\n"
                            a += "  ● Gpending\n"
                            a += "  ● Rejectall\n"
                            a += "  ● Reject | no\n"
                            a += "  ● Cancelall\n"
                            a += "  ● Gcall | num| @\n"
                            a += "  ● Gcall | num\n"
                            a += "  ● Bukaqr"
                            b = "  ● Tutupqr\n"
                            b += "  ● Inviteid | Id\n"
                            b += "  ● Invite | @\n"
                            b += "  ● Grouplist\n"
                            b += "  ● Pendinglist\n"
                            b += "  ● Creategroup | text\n"
                            b += "  ● Changegn | text\n"
                            b += "  ● Changedpg"
                            am_page2(to, a, b)
                        elif cmd == "grouplist":
                            key = settings["keyCommand"].title()
                            if settings['setKey'] == False:key = ''
                            gid = client.getGroupIdsJoined()
                            sd = client.getGroups(gid)
                            ret = "「 Group List 」\n"
                            no = 0
                            total = len(gid)
                            cd = "\n\nTotal {} Groups\n\n「 Command 」\n\nRemote Mention\nUsage: Grouplist [num] tag [1|<|>|-]\n\nRemote Kick\nUsage: Grouplist [num] kick [1|<|>|-]\n\nLeave Groups\nUsage: Leave [num]\n\nGet QR\nUsage: OpenQr  [num]\n\nCek Member\nUsage: Grouplist [num]\nUsage: Grouplist [num] mem [num]".format(total)
                            for G in sd:
                                member = len(G.members)
                                no += 1
                                ret += "\n{}. {} {}".format(no, G.name[0:20], member)
                            ret += cd
                            k = len(ret)//10000
                            for aa in range(k+1):
                              vintemp2(to,"{}".format(str(ret[aa*10000 : (aa+1)*10000])))

                        elif cmd == "gpending":
                            groups = client.getGroupIdsInvited()
                            ret_ = "「 𝑳𝒊𝒔𝒕 𝑰𝒏𝒗𝒊𝒕𝒆 」\n"
                            no = 1
                            for gid in groups:
                                group = client.getGroup(gid)
                                ret_ += "\n● {}. {} | {}".format(str(no), str(group.name), str(len(group.members)))
                                no = (no+1)
                            ret_ += "\n● Total {} Pending invite".format(str(len(groups)))
                            ret_ += "\n● Gunakan : Reject [num]\n\n"
                            ret_ +="User name : {}\n".format(client.getProfile().displayName)
                            ret_ +="𝑪𝒓𝒆𝒂𝒕𝒆 𝑩𝒚 : 𝒂𝑳𝒗𝒊𝒏𝒐 𝑩𝒂𝒊𝒉𝒂𝒒𝒊"
                            vinfooter(to,"{}".format(str(ret_)))

                        elif cmd.startswith("reject "):
                            number = removeCmd("reject", text)
                            groups = client.getGroupIdsInvited()
                            try:
                                group = groups[int(number)-1]
                                G = client.getGroup(group)
                                try:
                                    client.rejectGroupInvitation(G.id)
                                except:
                                    client.rejectGroupInvitation(G.id)
                                vintemp(to,"「 Successfully 」\nRiject nama group : {}".format(str(G.name)))
                            except Exception as error:
                              vintemp(to,"{}".format(str(error)))
#==============[ MENTIONS ]==============
                        elif cmd == "mentions":
                          ret ="● mentionunsend"
                          ret += "\n● mentionname | A-z"
                          ret += "\n● mention | A-z"
                          ret += "\n● mention | jum | @"
                          ret += "\n● {}".format(str(AM_message["settag"]))
                          ret += "\n● check mention"
                          ret += "\n● tagpm"
                          ret += "\n● mentionnote"
                          ret += "\n● ceknote | num"
                          ret += "\n● create note | text"
                          achinkZul1(to, ret)
#=============[ QURAN ]================
                        elif cmd == "quran":
                            ret ="⌈ Qu'ran Comand ⌋\n"
                            ret += "● quranlist\n"
                            ret += "● get Ayat Qur'an\n"
                            ret += "● qur'an | num\n"
                            ret += "● qur'an | num | 1 |<|>|"
                            hello = "{}".format(str(ret))
                            achinkZul1(to, ret)
 #============[ BROADCAST ]============
                        elif cmd == "broadcast":
                            ret ="● v | text\n"
                            ret += "● gbc | text\n"
                            ret += "● plbc | text\n"
                            ret += "● bigbc | text\n"
                            ret += "● smalbc | text\n"
                            ret += "● fbc | text]\n"
                            ret += "● rbc | text]\n"
                            ret += "● groupcastvoice | text\n"
                            ret += "● friendcastvoice | text\n"
                            hello = "{}".format(str(ret))
                            achinkZul1(to, hello)

                        elif cmd.startswith("bigbc "):
                            rah = text.split(" ")
                            matt = text.replace(rah[0] + " ","")
                            chat = "{}".format(matt)
                            contact = client.getContact(clientMID)
                            groups = client.getGroupIdsJoined()
                            for gr in groups:
                                data = {
                                    "type": "flex",
                                    "altText": "𝑩 𝑹 𝑶 𝑨 𝑫 𝑪 𝑨 𝑺 𝑻",
                                    "contents": {
  "type": "bubble",
  "size": "giga",
  "body": {
    "type": "box",
    "layout": "vertical",
    "contents": [
      {
        "type": "image",
        "url": "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcRfyD564Mfapgx3QuLB8WoI8Q3tDWzU0gCfyYGdhZrYtYB4uUrr",
        "size": "full",
        "aspectMode": "cover",
        "aspectRatio": "2:3",
        "gravity": "top"
      },
      {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "TEAM TERMUX V 13",
                "size": "xs",
                "color": "#ffffff",
                "offsetStart": "30px"
              }
            ],
            "backgroundColor": "#FF0000",
            "position": "relative",
            "offsetStart": "50px",
            "paddingStart": "10px",
            "height": "15px",
            "width": "240px",
            "offsetTop": "110px",
            "cornerRadius": "3px"
          },
          {
            "type": "box",
            "layout": "horizontal",
            "contents": [
              {
                "type": "text",
                "text": "{}".format(contact.displayName),
                "color": "#ffffff",
                "offsetStart": "37px",
                "size": "xl",
                "align": "start",
                "style": "italic",
                "decoration": "underline",
                "offsetTop": "10px"
              }
            ],
            "backgroundColor": "#0000FF",
            "position": "relative",
            "spacing": "xs",
            "margin": "xs",
            "height": "40px",
            "width": "250px",
            "offsetTop": "110px",
            "offsetStart": "50px",
            "cornerRadius": "10px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://obs.line-scdn.net/{}".format(contact.pictureStatus),
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "height": "100px",
            "width": "100px",
            "cornerRadius": "100px",
            "borderColor": "#0000FF",
            "borderWidth": "2px",
            "offsetEnd": "17px",
            "offsetTop": "17px"
          }
        ],
        "position": "absolute",
        "offsetBottom": "0px",
        "offsetStart": "0px",
        "offsetEnd": "0px",
        "paddingAll": "20px",
        "paddingTop": "18px"
      },
      {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "text",
            "text": "𝑰𝑲𝑳𝑨𝑵",
            "color": "#ffffff",
            "align": "center",
            "size": "xs"
          }
        ],
        "position": "absolute",
        "cornerRadius": "20px",
        "offsetTop": "3px",
        "backgroundColor": "#0000FF",
        "offsetStart": "240px",
        "borderWidth": "1px",
        "borderColor": "#00FF00",
        "width": "100px",
        "height": "20px"
      },
      {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "text",
            "text": "{}".format(chat),
            "color": "#ffffff",
            "size": "lg",
            "wrap": True,
            "style": "italic",
            "align": "start"
          }
        ],
        "position": "absolute",
        "offsetStart": "15px",
        "offsetTop": "28px",
        "width": "350px"
      }
    ],
    "paddingAll": "0px",
    "borderWidth": "2px",
    "borderColor": "#0000FF",
    "cornerRadius": "5px"
  }
}
}
                                bcTemplate(gr, data)
                                time.sleep(1)

                        elif cmd.startswith("smalbc "):
                            rah = text.split(" ")
                            matt = text.replace(rah[0] + " ","")
                            chat = "{}".format(matt)
                            contact = client.getContact(clientMID)
                            groups = client.getGroupIdsJoined()
                            for gr in groups:
                                data = {
                                    "type": "flex",
                                    "altText": "𝑩 𝑹 𝑶 𝑨 𝑫 𝑪 𝑨 𝑺 𝑻",
                                    "contents": {
  "type": "bubble",
  "size": "kilo",
  "body": {
    "type": "box",
    "layout": "vertical",
    "contents": [
      {
        "type": "image",
        "url": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSSqA7ECIkNow89ElhKED1NHzhYW2BPZzAKdWHk0uBqLuIBSzdG&s",
        "size": "full",
        "aspectMode": "cover",
        "gravity": "center"
      },
      {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "text",
            "text": " 𝑩𝑹𝑶𝑨𝑫𝑪𝑨𝑺𝑻",
            "color": "#ffffff",
            "align": "center",
            "offsetTop": "1px",
            "size": "xxs"
          }
        ],
        "position": "absolute",
        "offsetTop": "212px",
        "backgroundColor": "#FF0000",
        "width": "100px",
        "borderWidth": "1px",
        "borderColor": "#FFD700",
        "cornerRadius": "5px",
        "offsetStart": "58px"
      },
      {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "text",
            "text": "{}".format(chat),
            "color": "#2F4F4F",
            "size": "xxs",
            "wrap": True
          }
        ],
        "position": "absolute",
        "offsetTop": "32px",
        "offsetStart": "80px",
        "width": "145px"
      },
      {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "text",
            "text": "{}".format(contact.displayName),
            "color": "#ffffff",
            "size": "sm",
            "offsetStart": "3px",
            "offsetTop": "1px",
            "style": "normal"
          }
        ],
        "backgroundColor": "#964B00",
        "position": "absolute",
        "offsetTop": "230px",
        "width": "190px",
        "borderWidth": "1px",
        "borderColor": "#FFD700",
        "cornerRadius": "5px",
        "offsetStart": "58px",
        "height": "20px"
      },
      {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "url": "https://obs.line-scdn.net/{}".format(contact.pictureStatus),
            "size": "full",
            "aspectMode": "cover"
          }
        ],
        "width": "50px",
        "height": "50px",
        "cornerRadius": "5px",
        "borderWidth": "1px",
        "borderColor": "#FFD700",
        "position": "absolute",
        "offsetTop": "200px",
        "offsetStart": "5px"
      }
    ],
    "paddingAll": "0px",
    "borderWidth": "2px",
    "borderColor": "#FFD700",
    "cornerRadius": "10px"
  }
}
}
                                bcTemplate(gr, data)
                                time.sleep(1)

                        elif cmd.startswith("plbc "):
                            rah = text.split(" ")
                            matt = text.replace(rah[0] + " ","")
                            chat = "{}".format(matt)
                            tz = pytz.timezone("Asia/Jakarta")
                            timeNow = datetime.now(tz=tz)
                            timeHours = datetime.strftime(timeNow," (%H:%M)")
                            contact = client.getContact(clientMID)
                            groups = client.getGroupIdsJoined()
                            for gr in groups:
                                data = {
                                    "type": "flex",
                                    "altText": temp_notif["temp"],
                                    "contents": {
                                    "type": "bubble",
                                    "size": temp_size["ukuran"],
                                    "body": {
                                    "type": "box",
                                    "layout": "vertical",
                                    "contents": [
                                    {
                                    "type": "box",
                                    "layout": "vertical",
                                    "contents": [
                                    {
                                    "type": "box",
                                    "layout": "vertical",
                                    "contents": [
                                    {
                                    "type": "box",
                                    "layout": "vertical",
                                    "contents": [
                                    {
                                    "type": "text",
                                    "text": "𝑩𝑹𝑶𝑨𝑫𝑪𝑨𝑺𝑻",
                                    "size": bc_label_text_size["ukuran"],
                                    "color": bc_label_text["warna"],
                                    "align": "center"
                                    }
                                    ]
                                    },
                                    {
                                    "type": "separator",
                                    "color": bc_border["warna"]
                                    },
                                    {
                                    "type": "box",
                                    "layout": "horizontal",
                                    "contents": [
                                    {
                                    "type": "box",
                                    "layout": "vertical",
                                    "contents": [
                                    {
                                    "type": "text",
                                    "text": datetime.strftime(timeNow,'%H:%M:%S'),
                                    "size": "xxs",
                                    "color": bc_label_text["warna"],
                                    "align": "center"
                                    }
                                    ]
                                    },
                                    {
                                    "type": "separator",
                                    "color": bc_border["warna"]
                                    },
                                    {
                                    "type": "box",
                                    "layout": "vertical",
                                    "contents": [
                                    {
                                    "type": "text",
                                    "text": datetime.strftime(timeNow,'%d-%m-%Y'),
                                    "size": "xxs",
                                    "color": bc_label_text["warna"],
                                    "align": "center"
                                    }
                                    ]
                                    }
                                    ]
                                    },
                                    {
                                    "type": "separator",
                                    "color": bc_border["warna"]
                                    },
                                    {
                                    "type": "box",
                                    "layout": "vertical",
                                    "contents": [
                                    {
                                    "type": "text",
                                    "text": "{}".format(chat),
                                    "size": bc_size["ukuran"],
                                    "color": bc_text["warna"],
                                    "offsetStart": "5px",
                                    "wrap": True
                                    }
                                    ],
                                    "width": "120px"
                                    }
                                    ]
                                    },
                                    {
                                    "type": "separator",
                                    "color": bc_border["warna"]
                                    },
                                    {
                                    "type": "box",
                                    "layout": "vertical",
                                    "contents": [
                                    {
                                    "type": "text",
                                    "text": "{}".format(contact.displayName),
                                    "size": "xxs",
                                    "color": bc_label_text["warna"],
                                    "align": "center"
                                    }
                                    ]
                                    },
                                    {
                                    "type": "separator",
                                    "color": bc_border["warna"]
                                    },
                                    {
                                    "type": "box",
                                    "layout": "vertical",
                                    "contents": [
                                    {
                                    "type": "text",
                                    "text": label["label"],
                                    "align": "center",
                                    "color": bc_label_text["warna"],
                                    }
                                    ],
                                    "backgroundColor": bc_label_color["warna"]
                                    }
                                    ],
                                    "borderWidth": "1px",
                                    "borderColor": bc_border["warna"],
                                    "cornerRadius": "5px"
                                    }
                                    ],
                                    "borderWidth": "2px",
                                    "borderColor": bc_border["warna"],
                                    "cornerRadius": "10px",
                                    "backgroundColor": bc_bg["warna"],
                                    "action": {
                                    "type": "uri",
                                    "label": "action",
                                    "uri": temp_popup["pup"]
                                    }
                                    },
                                    "styles": {
                                    "footer": {
                                    "separator": True
                                    }
                                   }
                                  }
                                }
                                bcTemplate(gr, data)
                                time.sleep(1)

                        elif cmd.startswith("rbc "):
                            rah = text.split(" ")
                            matt = text.replace(rah[0] + " ","")
                            chat = "{}".format(matt)
                            tz = pytz.timezone("Asia/Jakarta")
                            timeNow = datetime.now(tz=tz)
                            timeHours = datetime.strftime(timeNow," (%H:%M)")
                            img = ("https://cdn2.tstatic.net/jabar/foto/bank/images/ilustrasi-puasa-ramadhan.jpg","https://griyaalquran.id/wp-content/uploads/GQ_Jadikan-Islam-Sebagai-Penuntun-II-1.jpg","https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcSObmmxABYmF80p1RUvLDVe1QJvyEalGuHdp2KujPD0CS4-xTlG&usqp=CAU","https://images.fineartamerica.com/images/artworkimages/mediumlarge/2/silhouette-of-the-suleymaniye-mosque-fabrizio-troiani.jpg")
                            image = random.choice(img)
                            contact = client.getContact(clientMID)
                            groups = client.getGroupIdsJoined()
                            for gr in groups:
                                data = {
                                    "type": "flex",
                                    "altText": temp_notif["temp"],
                                    "contents": {
  "type": "bubble",
  "size": "mega",
  "body": {
    "type": "box",
    "layout": "vertical",
    "contents": [
      {
        "type": "image",
        "url": image,
        "size": "full",
        "aspectMode": "cover",
        "aspectRatio": "2:3",
        "gravity": "center"
      },
      {
        "type": "box",
        "layout": "horizontal",
        "contents": [
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://cdn3.iconfinder.com/data/icons/islamic-worship/512/Islamic-13-512.png"
              }
            ],
            "height": "40px",
            "width": "40px",
            "cornerRadius": "100px"
          },
          {
            "type": "separator",
            "color": "#C0C0C0"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "𝑩𝑹𝑶𝑨𝑫𝑪𝑨𝑺𝑻",
                "size": "xs",
                "align": "center",
                "color": "#FFFFFF",
                "offsetTop": "1px"
              },
              {
                "type": "separator",
                "color": "#C0C0C0"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": "𝑹𝑨𝑴𝑨𝑫𝑯𝑨𝑵 ??𝑬𝑹𝑲𝑨𝑯",
                    "size": "xs",
                    "align": "center",
                    "color": "#FFFFFF"
                  }
                ],
                "offsetTop": "3px"
              }
            ]
          },
          {
            "type": "separator",
            "color": "#C0C0C0"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://cdn3.iconfinder.com/data/icons/islamic-worship/512/Islamic-13-512.png"
              }
            ],
            "width": "40px",
            "height": "40px",
            "cornerRadius": "100px"
          }
        ],
        "position": "absolute",
        "width": "280px",
        "offsetStart": "8px",
        "offsetTop": "5px",
        "cornerRadius": "5px",
        "borderWidth": "1px",
        "borderColor": "#C0C0C0"
      },
      {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "{}".format(chat),
                "color": "#ffffff",
                "align": "start",
                "wrap": True,
                "size": "sm"
              }
            ],
            "offsetStart": "5px",
            "width": "270px",
            "offsetTop": "3px"
          }
        ],
        "width": "280px",
        "position": "absolute",
        "offsetTop": "50px",
        "offsetStart": "8px",
        "height": "330px"
      },
      {
        "type": "box",
        "layout": "horizontal",
        "contents": [
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://obs.line-scdn.net/{}".format(contact.pictureStatus),
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "width": "45px",
            "height": "45px"
          },
          {
            "type": "separator",
            "color": "#C0C0C0"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "{}".format(contact.displayName),
                "size": "xs",
                "color": "#ffffff",
                "align": "center"
              },
              {
                "type": "separator",
                "color": "#C0C0C0"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": "TEAM TERMUX V 13",
                    "size": "md",
                    "align": "center",
                    "offsetTop": "3px"
                  }
                ],
                "backgroundColor": "#FFFFFF",
                "height": "27px"
              }
            ],
            "backgroundColor": "#800000",
            "action": {
              "type": "uri",
              "label": "action",
              "uri": "line://nv/profilePopup/mid=u42880eb65b2da1eb8fd3b7a9caa4ccc3"
            }
          }
        ],
        "width": "280px",
        "position": "absolute",
        "offsetTop": "390px",
        "borderWidth": "1px",
        "borderColor": "#C0C0C0",
        "cornerRadius": "5px",
        "offsetStart": "8px"
      }
    ],
    "paddingAll": "0px",
    "borderWidth": "2px",
    "borderColor": "#C0C0C0",
    "cornerRadius": "15px"
  }
}
                                }
                                bcTemplate(gr, data)
                                time.sleep(1)

#===========[ CREATE MEMEK ]=================
                        elif cmd == "meme":
                            ret ="⌈ Meme ⌋\n\n"
                            ret += "● creatememe | text | text | template\n"
                            ret += "● contoh :\n"
                            ret += "● creatememe tante|semok|buzz\n"
                            ret += "How to find template?\n"
                            ret += "Use command :\n● Memegen\n\n"
                            ret +="User name : {}\n".format(client.getProfile().displayName)
                            ret +="ᴄʀᴇᴀᴛᴇ ʙʏ : 𝒂𝒍𝒗𝒊𝒏𝒐 𝒃𝒂𝒊𝒉𝒂𝒒𝒊"
                            hello = "{}".format(str(ret))
                            vintemp2(to,"{}".format(str(ret)))
                        
                        elif cmd.startswith("creatememe "):
                            text_ = removeCmd("creatememe", text)
                            cond = text_.split("|")
                            list_template = ["10guy","afraid","blb","both","buzz","chosen","doge","elf","ermg","fa","fetch","fry","fwp","ggg","icanhas","interesting","iw","keanu","live","ll","mordor","morpheus","officiespace","oprah","philosoraptor","remembers","sb","ss","success","toohigh","wonka","xy","yallgot","yuno"]
                            if cond[0] is not None and cond[1] is not None:
                                up = str(cond[0])
                                down = str(cond[1])
                                if len(cond) > 2:
                                    if cond[2] is not None and cond[2] in list_template:
                                        template = str(cond[2])
                                    elif cond[2] is not None and cond[2] not in list_template:
                                        template = None
                                        vinfooter(to,"Template tidak valid")
                                else:
                                    template = random.choice(list_template)
                                if template is not None:
                                    client.sendImageWithURL(to,"https://memegen.link/{}/{}/{}.jpg".format(template,up,down))
                            else:
                                client.sendMessage(to,"Error")
                        elif cmd == "memegen":
                            f = open('memeGen.txt','r')
                            lines = f.readlines()
                            panjang = len(lines)
                            lists = ""
                            for a in lines:
                                lists += str(a)
                            vinfooter(to,"⌈ 𝑴𝑬𝑴𝑬 𝑳𝑰𝑺𝑻 ⌋\n\n%s" %(lists))
 #==========================================
#==========================================
                        elif cmd == "conban":
                            if Banlist["blacklist"] == {}:
                              vintemp(to,"No blacklist")
                            else:
                              ma = ""
                              for i in Banlist["blacklist"]:
                                ma = client.getContact(i)
                                client.sendMessage(msg.to, None, contentMetadata={'mid': i}, contentType=13)

                        elif cmd == "uncloneprofile":
                            try:
                                restoreProfile()
                                client.sendContact(to,clientMID)
                                vintemp(to, "back to the beginning ~")
                            except Exception as e:
                                client.sendMessage(to, "[ ERROR")

                                achinkZul(msg.to, str(e))
                        elif cmd == "mymid":
                            vinfooter(to,"{}".format(str(sender)))

                        elif cmd == "myprofile":
                            contact = client.getContact(clientMID)
                            cu = client.getProfileCoverURL(clientMID)
                            path = str(cu)
                            image = "http://dl.profile.line-cdn.net/" + contact.pictureStatus
                            client.sendImageWithURL(to, image)
                            client.sendImageWithURL(to, path)
                            vintemp2(to, "「 𝑷𝒓𝒐𝒇𝒊𝒍𝒆 」\n𝑴𝒊𝒅 : "+str(sender)+"\n𝑵𝒂𝒎𝒆 : "+str(contact.displayName)+"\nStatus :\n"+str(contact.statusMessage))
                        elif cmd == "myname":
                            h = client.getContact(clientMID)
                            vinfooter(to,"{}".format(str(h.displayName)))

                        elif cmd == "mybio":
                            h = client.getContact(clientMID)
                            vintemp2(to,"[ 𝑺𝒕𝒂𝒕𝒖𝒔 𝑴??𝒔𝒔𝒂𝒈𝒆 ]\n\n{}".format(str(h.statusMessage)))

                        elif cmd == "mypicture":
                            h = client.getContact(clientMID)
                            image = "http://dl.profile.line-cdn.net/" + h.pictureStatus
                            data = { "type": "flex","altText": "TEAM TERMUX V 13","contents": {"type": "bubble","size": "giga","body": {"type": "box", "layout": "vertical","contents": [{"type": "image","url": image,"size": "full","aspectMode": "cover","aspectRatio": "1:1","gravity": "center"},{"type": "box","layout": "horizontal","contents": [{"type": "box","layout": "vertical","contents": [{"type": "box","layout": "horizontal","contents": [{"type": "text","text": "foto Profilenya","size": "xl","color": "#ffffff","style": "italic"}]},{"type": "box","layout": "horizontal","contents": [{"type": "box","layout": "baseline","contents": [{"type": "text","text": "Downloads","color": "#a9a9a9","decoration": "none","size": "sm","align": "end"}],"flex": 0,"spacing": "lg"}]}],"spacing": "xs"}],"position": "absolute","offsetBottom": "0px","offsetStart": "0px","offsetEnd": "0px","paddingAll": "20px"}],"paddingAll": "0px","borderWidth": "1px","borderColor": "#FF007F","cornerRadius": "5px","action": {"type": "uri","label": "action","uri": "line://app/1602687308-GXq4Vvk9?type=image&img={}".format(str(image))}}}}
                            sendTemplate(to, data)

                        elif cmd == "myvideo":
                            h = client.getContact(clientMID)
                            if h.videoProfile == None:
                            	return client.sendMessage(to, "「 Video 」\nNone")
                            client.generateReplyMessage(msg.id)
                            client.sendReplyVideoWithURL(msg.id, to,"http://dl.profile.line-cdn.net/" + h.pictureStatus + "/vp")
                        elif cmd == "mycover":
                            h = client.getContact(clientMID)
                            cu = client.getProfileCoverURL(clientMID)
                            image = str(cu)
                            data = {"type": "flex","altText": "TEAM TERMUX V 13","contents": {"type": "bubble","size": "giga","body": {"type": "box","layout": "vertical","contents": [{"type": "image","url": image,"size": "full","aspectMode": "cover","aspectRatio": "1:1","gravity": "center"},{"type": "box","layout": "horizontal","contents": [{"type": "box","layout": "vertical","contents": [{"type": "box","layout": "horizontal","contents": [{"type": "text","text": "Foto Profilenya","size": "xl","color": "#ffffff","style": "italic"}]},{"type": "box", "layout": "horizontal","contents": [{"type": "box","layout": "baseline","contents": [{"type": "text","text": "Donwloads","color": "#a9a9a9","decoration": "none","size": "sm","align": "end"}],"flex": 0,"spacing": "lg"}]}],"spacing": "xs"}],"position": "absolute","offsetBottom": "0px","offsetStart": "0px","offsetEnd": "0px","paddingAll": "20px"}],"paddingAll": "0px", "borderWidth": "1px","borderColor": "#FF007F","cornerRadius": "5px","action": {"type": "uri","label": "action","uri": "line://app/1602687308-GXq4Vvk9?type=image&img={}".format(str(cu))}}}}
                            sendTemplate(to, data)

                        elif cmd == "bukaqr":
                            if msg.toType == 2:
                                group = client.getGroup(to)
                                group.preventedJoinByTicket = False
                                client.updateGroup(group)
                                gurl = client.reissueGroupTicket(to)
                                vinfooter(to,"https://line.me/R/ti/g/{}".format(str(gurl)))

                        elif cmd == "tutupqr":
                            if msg.toType == 2:
                                group = client.getGroup(to)
                                group.preventedJoinByTicket = True
                                client.updateGroup(group)
                                a = " sᴜᴋsᴇs ᴄʟᴏsᴇ ᴋᴏᴅᴇ ϙʀ"
                                vintemp(to,"{}".format(str(a)))

                        elif cmd == "pamit":
                            if msg.toType == 2:
                                group = client.getGroup(to)
                                #Zul = "u42880eb65b2da1eb8fd3b7a9caa4ccc3"
                                vintemp(to,"السَّلاَمُ عَلَيْكُمْ وَرَحْمَةُ اللهِ وَبَرَكَاتُهُ ")
                                #client.sendContact(to, Zul)
                                client.leaveGroup(to)
#==========================={COMMMAND INVITE}====================================================================================
                        if cmd.startswith("invite on"):
                            AM_SAKLAR['inviting'] = True
                            vintemp(to,"𝑺𝒆𝒏𝒅 𝑪𝒐𝒏𝒕𝒂𝒄𝒕...")
#==========================[ WHITELIST ]=========================================================================================
                        elif cmd == "whitelist":
                            ret ="  ● Addwl @\n"
                            ret += "  ● Delwl @\n"
                            ret += "  ● Addbl @\n"
                            ret += "  ● Delbl @\n"
                            ret += "  ● addbl on \n"
                            ret += "  ● delbl on \n"
                            ret += "  ● Wl/Wlist\n"
                            ret += "  ● Clearwl\n"
                            ret += "  ● Refreshbl \n"
                            ret += "  ● Wl/Wlist\n"
                            ret += "  ● Locate @\n"
                            ret += "  ● Banlist/Blist\n"
                            ret += "  ● Cban/Clearban"
                            hello = "{}".format(str(ret))
                            achinkZul1(to, hello)

                        elif cmd == "banlist" or text.lower() == 'blist':
                            if msg._from in clientMID:
                              if Banlist["blacklist"] == {}:
                                vintemp(to,"「 𝑩𝒍𝒂𝒄𝒌𝒍𝒊𝒔𝒕 」\n\n𝑵𝒐𝒕𝒊𝒏𝒈 𝑩𝒍𝒂𝒄𝒌𝒍𝒊𝒔𝒕....")
                              else:
                                num = 1
                                mc = "「 𝑩𝒍𝒂𝒄𝒌𝒍𝒊𝒔𝒕 」\n"
                                for me in Banlist["blacklist"]:
                                    mc += "\n %i.  %s" % (num, client.getContact(me).displayName)
                                    num = (num+1)
                                mc += "\n\n𝑻𝒐𝒕𝒂𝒍 %i 𝑩𝒍𝒂𝒄𝒌𝒍𝒊𝒔𝒕" % len(Banlist["blacklist"])
                                vintemp(to,"{}".format(str(mc)))

                        elif cmd == "wl" or text.lower() == 'wlist':
                            if msg._from in clientMID:
                              if AM_backup["wl"] == {}:
                                vintemp(to,"「 𝑾𝒉𝒊𝒕𝒆𝒍𝒊𝒔𝒕 」\n\n𝑵𝒐𝒕𝒊𝒏𝒈 𝑾𝒉𝒊𝒕𝒆𝒍𝒊𝒔𝒕....")
                              else:
                                num = 1
                                mc = "「 𝑾𝒉𝒊𝒕𝒆𝒍𝒊𝒔𝒕 」\n"
                                for me in AM_backup["wl"]:
                                    mc += "\n %i.  %s" % (num, client.getContact(me).displayName)
                                    num = (num+1)
                                mc += "\n\n𝑻𝒐𝒕𝒂𝒍 %i 𝑾𝒉𝒊𝒕𝒆𝒍𝒊𝒔𝒕" % len(AM_backup["wl"])
                                vintemp(to,"{}".format(str(mc)))

                        elif cmd == "clearwl" or text.lower() == 'clear wl':
                            if msg._from in clientMID:
                              ang = client.getContacts(AM_backup["wl"])
                              mc = "%i 𝑾𝒉𝒊𝒕𝒆𝒍𝒊𝒔𝒕 " % len(ang)
                              vintemp(to,"??𝒍𝒆𝒂?? {}".format(str(mc)))
                              AM_backup["wl"] = {}
#============================[ PROTECTION ]=====================================================================
                        elif cmd == "cban" or text.lower() == 'clearban':
                            if msg._from in clientMID:
                              ang = client.getContacts(Banlist["blacklist"])
                              mc = "%i 𝑩𝒍𝒂𝒄𝒌𝒍𝒊𝒔𝒕 " % len(ang)
                              vintemp(to,"𝑪𝒍𝒆𝒂𝒓 {}".format(str(mc)))
                              Banlist["blacklist"] = {}

                        elif "delwl " in cmd:
                            if msg._from in clientMID or msg._from in creator:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                  if target not in AM_backup["wl"]:
                                      vintemp(to,"「 𝑾𝒉𝒊𝒕𝒆𝒍𝒊𝒔𝒕 」\n\n𝑵𝒐𝒕𝒊𝒏𝒈 𝑾𝒉𝒊𝒕𝒆𝒍𝒊𝒔𝒕...")
                                  else:
                                      try:
                                          del AM_backup["wl"][target]
                                          backupData()
                                          vintemp(to,"「 𝑾𝒉𝒊𝒕𝒆𝒍𝒊𝒔𝒕 」\n\n𝑺𝒖𝒄𝒄𝒆𝒔 𝒅𝒆𝒍𝒍𝒆𝒕 𝑾𝒉𝒊𝒕𝒆𝒍𝒊𝒔𝒕...")
                                      except:
                                          pass

                        elif "addwl " in cmd:
                            if msg._from in clientMID:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                  if target in AM_backup["wl"]:
                                    vintemp(to,"「 𝑨𝒅𝒅 𝑾𝒉𝒊𝒕𝒆𝒍𝒊𝒔𝒕 」\n\n𝑨𝒍𝒓𝒆𝒂𝒅𝒚 𝒐𝒏 ??𝒉𝒆 𝒍𝒊𝒔𝒕...")
                                  else:
                                      try:
                                          AM_backup["wl"][target] = True
                                          backupData()
                                          vintemp(to,"「 𝑨𝒅𝒅 𝑾𝒉𝒊𝒕𝒆𝒍𝒊𝒔𝒕 」\n\n𝑺𝒖𝒄𝒄𝒆𝒔 𝒂𝒅𝒅 𝒕𝒐 𝑾𝒉𝒊𝒕𝒆𝒍𝒊𝒔𝒕...")
                                      except:
                                          pass

                        
                        elif "addbl on" in cmd:
                            if msg._from in clientMID:
                                if Banlist["ablack"] == True:
                                    client.sendMessage(to,"Please send Contact")
                                else:
                                    Banlist["ablack"] = True
                                    client.sendMessage(to,"Please send Contact")
                        elif "delbl on" in cmd:
                            if msg._from in clientMID:
                                if Banlist["dblack"] == True:
                                    client.sendMessage(to,"Please send Contact")
                                else:
                                    Banlist["dblack"] = True
                                    client.sendMessage(to,"Please send Contact")
                        elif "refreshbl" in cmd:
                            if msg._from in clientMID:
                                Banlist["ablack"] = False
                                Banlist["dblack"] = False
                                client.sendMessage(to,"𝑫𝒐𝒏𝒆 𝑹𝒆𝒇𝒓𝒆𝒔𝒉")
                        elif "delbl " in cmd:
                            if msg._from in clientMID:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                  if target not in Banlist["blacklist"]:
                                      vintemp(to,"「 𝑩𝒍𝒂𝒄𝒌𝒍𝒊𝒔𝒕 」\n\n𝑵𝒐𝒕𝒊𝒏𝒈 𝑩𝒍𝒂𝒄𝒌𝒍𝒊𝒔𝒕...")
                                  else:
                                      try:
                                          del Banlist["blacklist"][target]
                                          backupData()
                                          vintemp(to,"「 𝑩𝒍𝒂𝒄𝒌𝒍𝒊𝒔𝒕 」\n\n??𝒖??𝒄???? 𝒅𝒆𝒍𝒍𝒆𝒕 𝑩𝒍𝒂??𝒌𝒍𝒊𝒔𝒕...")
                                      except:
                                          pass

                        elif "addbl " in cmd:
                            if msg._from in clientMID or msg._from in creator:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                  if target in Banlist["blacklist"]:
                                    vintemp(to,"「 𝑨𝒅𝒅 𝑩𝒍𝒂𝒄𝒌𝒍𝒊𝒔𝒕 」\n\n𝑨𝒍𝒓𝒆𝒂𝒅𝒚 𝒐𝒏 𝒕𝒉𝒆 𝒍𝒊??𝒕...")
                                  else:
                                      try:
                                          Banlist["blacklist"][target] = True
                                          backupData()
                                          vintemp(to,"「 𝑨𝒅𝒅 𝑩𝒍𝒂𝒄𝒌𝒍𝒊𝒔𝒕 」\n\n𝑺𝒖𝒄𝒄𝒆𝒔 𝒂𝒅𝒅 𝒕𝒐 𝑩𝒍𝒂𝒄𝒌𝒍𝒊𝒔𝒕...")
                                      except:
                                          pass

                        
#===============================================================================================================================
                        elif cmd == "runtime":
                            timeNow = time.time()
                            runtime = timeNow - botStart
                            runtime = format_timespan(runtime)
                            vintemp(to,"sᴇʟғʙᴏᴛ ᴀᴋᴛɪᴘ {}".format(str(runtime)))

                        elif cmd == "rejectall" and sender == clientMID:
                            ginvited = client.getGroupIdsInvited()
                            if ginvited != [] and ginvited != None:
                                for gid in ginvited:
                                    client.rejectGroupInvitation(gid)
                                vintemp(to, "Succes rejected 「 {} 」invitetation".format(str(len(ginvited))))
                            else:
                                vintemp(to, "Nothing")

                        elif cmd == "blocklist" and sender == clientMID:
                            blockedlist = client.getBlockedContactIds()
                            kontak = client.getContacts(blockedlist)
                            num=1
                            msgs="╭───[ 𝑺𝖙𝖆𝖙𝖚𝖘 𝜷𝖑𝖔𝒄𝖐 ]"
                            for ids in kontak:
                                msgs+="\n├• %i. %s" % (num, ids.displayName)
                                num=(num+1)
                            msgs+="\n├────────────"
                            msgs+="\n├•Total Block  : ( %i )" % len(kontak)
                            msgs+="\n├────────────"
                            msgs+= "\n├•BlockInfo「 number 」"
                            msgs+= "\n├•ConBlock"
                            msgs+= "\n├•Blockfriend [@]"
                            msgs+= "\n├•Blockmid [mid]"
                            msgs+= "\n├•Unblockmid [mid]"
                            msgs+= "\n╰───[ TEAM TERMUX V 13 ]──"
                            hello = "{}".format(str(msgs))
                            vintemp2(to,"{}".format(str(msgs)))

                        elif cmd == "favoritlist":
                            contactlist = client.getFavoriteMids()
                            kontak = client.getContacts(contactlist)
                            num=1
                            msgs="╭──────[ 𝑺𝖙𝖆𝖙𝖚𝖘 𝑭𝖆𝖛𝖔𝖗𝖎𝖙𝖊 ]─────"
                            for ids in kontak:
                                msgs+="\n├•%i. %s" % (num, ids.displayName)
                                num=(num+1)
                            msgs+="\n├────────────────"
                            msgs+="\n├•Total : ( %i )" % len(kontak)
                            msgs+= "\n├•Usage : FavoriteInfo 「 number 」"
                            msgs+= "\n╰────[ TEAM TERMUX V 13 ]─────"
                            hello = "{}".format(str(msgs))
                            vintemp2(to,"{}".format(str(msgs)))

                        elif cmd == 'gift':
#.                               client.sendMessage(to, text=None, contentMetadata={'PRDID': '350d37d6-bfc9-44cb-a0d1-cf17ae3657db','PRDTYPE': 'THEME','MSGTPL': '5'}, contentType=9)
                            client.generateReplyMessage(msg.id)
                            client.sendReplyMessage(msg.id, to, text=None, contentMetadata={'PRDID': '350d37d6-bfc9-44cb-a0d1-cf17ae3657db','PRDTYPE': 'THEME','MSGTPL': '5'}, contentType=9)
#=====================================================================
                        elif cmd == "changedp" and sender == clientMID:
                            settings["changePicture"] = True
                            vintemp(to,"𝑺𝒆𝒏𝒅 𝒕𝒐 𝒑𝒊𝒄𝒕𝒖𝒓𝒆...")

                        elif cmd == "change cover" and sender == clientMID:
                            settings["changeCover"] = True
                            vintemp(to,"𝑺𝒆𝒏𝒅 𝒕𝒐 𝒑𝒊𝒄𝒕𝒖𝒓𝒆...")

                        elif cmd == "changedp video" and sender == clientMID:
                            settings['changeProfileVideo']['status'] = True
                            settings['changeProfileVideo']['stage'] = 1
                            vintemp(to,"𝑺𝒆𝒏𝒅 𝒕𝒐 𝒗𝒊𝒅𝒆𝒐...")

                        elif cmd == "changedp group":
                            if msg.toType == 2:
                                if to not in settings["changeGroupPicture"]:
                                    settings["changeGroupPicture"].append(to)
                                vintemp(to,"𝑺𝒆𝒏𝒅 𝒕𝒐 𝒑𝒊𝒄𝒕𝒖𝒓𝒆...")

                        elif cmd.startswith("changemy video "):
                            link = removeCmd("changemy video", text)
                            contact = client.getContact(sender)
                            pic = "http://dl.profile.line-cdn.net/{}".format(contact.pictureStatus)
                            pict = client.downloadFileURL(pic)
                            try:
                                r = requests.get("http://rahandiapi.herokuapp.com/youtubeapi?key=betakey&q={}".format(link))
                                data = r.text
                                data = json.loads(data)
                                for x in data["result"]["videolist"]:
                                    if x["extension"] == "mp4" and x["resolution"] == "720p":
                                      vintemp(to,"Status: Download...")
                                      vids = client.downloadFileURL(x['url'])
                                      changeVideoAndPictureProfile(pict, vids)
                                      vintemp(to,"𝑺𝒕𝒂𝒕𝒖𝒔 : 𝑺𝒖𝒄𝒄𝒆𝒔")
                                    else:pass
                            except:pass

                        elif cmd.startswith("vid "):
                            name = removeCmd("vid",text)
                            client.sendVideo(to, "tmp/{}".format(name))

                        elif cmd.startswith("addtext2 "):
                            	if sender in clientMID:
                                    sep = text.split(" ")
                                    apl = text.replace(sep[0] + " ","")
                                    sam = apl.split("~")
                                    chat1 = sam[0]
                                    chat2 = sam[1]
                                    apk = ""+chat1
                                    tes2["Message2"][apk] = chat2
                                    tes2["msg2"] = chat1
                                    anu = tes2["msg2"]+'.'
                                    vintemp(to,"Command %s created."%chat1)
                                    tes2["msg"] = {}
                                    backupData()

                        elif cmd == "list text2":
                            	if sender in clientMID:
                                    backupData()
                                    if tes2["Message2"] == {}:
                                      vinfooter(to,"You don't have chat message")
                                    else:
                                        mc = ""
                                        jml = 1
                                        for listword in tes2["Message2"]:
                                            mc += "\n"+str(jml)+". "+listword+""
                                            jml += 1
                                        vintemp(to,"List Text\n{}".format(str(mc)))

                        elif cmd.startswith("deltext2 "):
                            	if sender in clientMID:
                                    sep = text.split(" ")
                                    xres = text.replace(sep[0] + " ","")
                                    tetx = text.replace(sep[0] + " ","")
                                    if xres in tes2["Message2"]:
                                        del tes2["Message2"][xres]                                        
                                        vintemp(to,"Command %s has been removed."%tetx)
                                    else:
                                        vintemp(to,"Command %s does not exist."%tetx)

                        elif cmd.startswith("addtext "):
                            	if sender in clientMID:
                                    sep = text.split(" ")
                                    apl = text.replace(sep[0] + " ","")
                                    sam = apl.split("~")
                                    chat1 = sam[0]
                                    chat2 = sam[1]
                                    apk = ""+chat1
                                    tes["Message"][apk] = chat2
                                    tes["msg"] = chat1
                                    anu = tes["msg"]+'.'
                                    vintemp(to,"Command %s created."%chat1)
                                    tes["msg"] = {}
                                    backupData()

                        elif cmd == "list text":
                            	if sender in clientMID:
                                    backupData()
                                    if tes["Message"] == {}:
                                      vinfooter(to,"You don't have chat message")
                                    else:
                                        mc = ""
                                        jml = 1
                                        for listword in tes["Message"]:
                                            mc += "\n"+str(jml)+". "+listword+""
                                            jml += 1
                                        vintemp(to,"List Text\n{}".format(str(mc)))

                        elif cmd.startswith("getvideo "):
                            try:
                                sep = msg.text.split(" ")
                                textToSearch = text.replace(sep[0] + " ","")
                                query = urllib.parse.quote(textToSearch)
                                url = "https://www.youtube.com/results?search_query=" + query
                                response = urllib.request.urlopen(url)
                                html = response.read()
                                soup = BeautifulSoup(html, "html.parser")
                                results = soup.find(attrs={'class':'yt-uix-tile-link'})
                                dl=("https://www.youtube.com" + results['href'])
                                vid = pafy.new(dl)
                                stream = vid.streams
                                for s in stream:
                                    vin = s.url
                                client.sendVideoWithURL(msg.to,vin)
                                print("[YOUTUBE]MP4 Succes")
                            except Exception as e:
                                client.generateReplyMessage(msg.id)
                                client.sendReplyMessage(msg.id, to,str(e))

                        elif cmd.startswith("getmp3 "):
                            try:
                                sep = msg.text.split(" ")
                                textToSearch = text.replace(sep[0] + " ","")
                                query = urllib.parse.quote(textToSearch)
                                url = "https://www.youtube.com/results?search_query=" + query
                                response = urllib.request.urlopen(url)
                                html = response.read()
                                soup = BeautifulSoup(html, "html.parser")
                                results = soup.find(attrs={'class':'yt-uix-tile-link'})
                                dl=("https://www.youtube.com" + results['href'])
                                vid = pafy.new(dl)
                                stream = vid.streams
                                for s in stream:
                                    vin = s.url
                                client.sendAudioWithURL(msg.to,vin)
                                print("[YOUTUBE]MP4 Succes")
                            except Exception as e:
                                client.generateReplyMessage(msg.id)
                                client.sendReplyMessage(msg.id, to,str(e))

                        elif cmd.startswith("deltext "):
                            	if sender in clientMID:
                                    sep = text.split(" ")
                                    xres = text.replace(sep[0] + " ","")
                                    tetx = text.replace(sep[0] + " ","")
                                    if xres in tes["Message"]:
                                        del tes["Message"][xres]                                        
                                        client.sendMessage(to,"Command %s has been removed."%tetx)
                                    else:
                                        client.sendMessage(to,"Command %s does not exist."%tetx)

                        elif cmd == "mic pict":
                            profile = client.getProfile()
                            ret = "◉ rotate @\n"
                            ret += "◉ circuler @ \n"
                            ret += "◉ graycall @\n"
                            ret += "◉ blur @\n"
                            ret += "◉ outline @\n"
                            ret += "◉ shadow @\n"
                            ret += "◉ adjust @\n"
                            ret += "◉ recolor @\n"
                            ret += "◉ decopasity @\n"
                            ret += "◉ oilpaint @\n"
                            ret += "◉ filter1 @\n"
                            ret += "◉ filter2 @\n"
                            ret += "◉ filter3 @"
                            achinkZul1(to, ret)

                        elif cmd.startswith("rotate "):
                            if msg.contentMetadata is not None and 'MENTION' in msg.contentMetadata:
                                names = re.findall(r'@(\w+)', text)
                                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                mentionees = mention['MENTIONEES']
                                lists = []
                                for mention in mentionees:
                                    if mention["M"] not in lists:
                                        lists.append(mention["M"])
                                for ls in lists:
                                  contact = client.getContact(ls)
                                  client.sendImageWithURL(to, f"https://res.cloudinary.com/demo/image/fetch/w_200/a_-20/http://dl.profile.line-cdn.net/{contact.pictureStatus}")

                        if cmd.startswith("circuler "):
                            if msg.contentMetadata is not None and 'MENTION' in msg.contentMetadata:
                                names = re.findall(r'@(\w+)', text)
                                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                mentionees = mention['MENTIONEES']
                                lists = []
                                for mention in mentionees:
                                    if mention["M"] not in lists:
                                        lists.append(mention["M"])
                                for target in lists:
                                  contact = client.getContact(target)
                                  client.sendImageWithURL(to, f"https://res.cloudinary.com/demo/image/fetch/w_200,c_fill,r_max/e_trim/http://dl.profile.line-cdn.net/{contact.pictureStatus}")

                        if cmd.startswith("graycall "):
                            if msg.contentMetadata is not None and 'MENTION' in msg.contentMetadata:
                                names = re.findall(r'@(\w+)', text)
                                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                mentionees = mention['MENTIONEES']
                                lists = []
                                for mention in mentionees:
                                    if mention["M"] not in lists:
                                        lists.append(mention["M"])
                                for target in lists:
                                  contact = client.getContact(target)
                                  client.sendImageWithURL(to, f"https://res.cloudinary.com/demo/image/fetch/w_200,e_grayscale/http://dl.profile.line-cdn.net/{contact.pictureStatus}")

                        if cmd.startswith("blur "):
                            if msg.contentMetadata is not None and 'MENTION' in msg.contentMetadata:
                                names = re.findall(r'@(\w+)', text)
                                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                mentionees = mention['MENTIONEES']
                                lists = []
                                for mention in mentionees:
                                    if mention["M"] not in lists:
                                        lists.append(mention["M"])
                                for target in lists:
                                  contact = client.getContact(target)
                                  client.sendImageWithURL(to, f"https://res.cloudinary.com/demo/image/fetch/w_200,e_blur:100/http://dl.profile.line-cdn.net/{contact.pictureStatus}")

                        if cmd.startswith("outline "):
                            if msg.contentMetadata is not None and 'MENTION' in msg.contentMetadata:
                                names = re.findall(r'@(\w+)', text)
                                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                mentionees = mention['MENTIONEES']
                                lists = []
                                for mention in mentionees:
                                    if mention["M"] not in lists:
                                        lists.append(mention["M"])
                                for target in lists:
                                  contact = client.getContact(target)
                                  warna = ["co_red", "co_yellow", "co_orange", "co_green", "co_purple", "co_white"]
                                  warna2 = ["co_red", "co_yellow", "co_orange", "co_green", "co_purple", "co_white"]
                                  client.sendImageWithURL(to, f"https://res.cloudinary.com/demo/image/fetch/w_200,c_scale/e_outline:20:200,{random.choice(warna)}/e_outline:10:200,{random.choice(warna2)}/http://dl.profile.line-cdn.net/{contact.pictureStatus}")

                        if cmd.startswith("shadow "):
                            if msg.contentMetadata is not None and 'MENTION' in msg.contentMetadata:
                                names = re.findall(r'@(\w+)', text)
                                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                mentionees = mention['MENTIONEES']
                                lists = []
                                for mention in mentionees:
                                    if mention["M"] not in lists:
                                        lists.append(mention["M"])
                                for target in lists:
                                  contact = client.getContact(target)
                                  warna = ["000000", "FFFFFF", "800000", "808000", "008000", "800080", "008080", "000080"]
                                  client.sendImageWithURL(to, f"https://res.cloudinary.com/demo/image/fetch/w_200,co_rgb:{random.choice(warna)},e_shadow:50,x_10,y_10/http://dl.profile.line-cdn.net/{contact.pictureStatus}")

                        if cmd.startswith("adjust "):
                            if msg.contentMetadata is not None and 'MENTION' in msg.contentMetadata:
                                names = re.findall(r'@(\w+)', text)
                                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                mentionees = mention['MENTIONEES']
                                lists = []
                                for mention in mentionees:
                                    if mention["M"] not in lists:
                                        lists.append(mention["M"])
                                for target in lists:
                                  contact = client.getContact(target)
                                  client.sendImageWithURL(to, f"https://res.cloudinary.com/demo/image/fetch/w_200,e_tint:equalize:80:red:50p:blue:60p:yellow:40p/http://dl.profile.line-cdn.net/{contact.pictureStatus}")

                        if cmd.startswith("recolor "):
                            if msg.contentMetadata is not None and 'MENTION' in msg.contentMetadata:
                                names = re.findall(r'@(\w+)', text)
                                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                mentionees = mention['MENTIONEES']
                                lists = []
                                for mention in mentionees:
                                    if mention["M"] not in lists:
                                        lists.append(mention["M"])
                                for target in lists:
                                  contact = client.getContact(target)
                                  warna = ["blue", "red", "green", "white", "black", "orange", "purple", "yellow"]
                                  client.sendImageWithURL(to, f"https://res.cloudinary.com/demo/image/fetch/w_200,e_tint:equalize:80:red:50p:blue:60p:{random.choice(warna)}:40p/http://dl.profile.line-cdn.net/{contact.pictureStatus}")

                        if cmd.startswith("decopasity "):
                            if msg.contentMetadata is not None and 'MENTION' in msg.contentMetadata:
                                names = re.findall(r'@(\w+)', text)
                                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                mentionees = mention['MENTIONEES']
                                lists = []
                                for mention in mentionees:
                                    if mention["M"] not in lists:
                                        lists.append(mention["M"])
                                for target in lists:
                                  contact = client.getContact(target)
                                  client.sendImageWithURL(to, f"https://res.cloudinary.com/demo/image/fetch/w_200,e_oil_paint:4/http://dl.profile.line-cdn.net/{contact.pictureStatus}")

                        if cmd.startswith("oilpaint "):
                            if msg.contentMetadata is not None and 'MENTION' in msg.contentMetadata:
                                names = re.findall(r'@(\w+)', text)
                                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                mentionees = mention['MENTIONEES']
                                lists = []
                                for mention in mentionees:
                                    if mention["M"] not in lists:
                                        lists.append(mention["M"])
                                for target in lists:
                                  contact = client.getContact(target)
                                  client.sendImageWithURL(to, f"https://res.cloudinary.com/demo/image/fetch/w_200,e_oil_paint:4/http://dl.profile.line-cdn.net/{contact.pictureStatus}")

                        if cmd.startswith("filter1 "):
                            if msg.contentMetadata is not None and 'MENTION' in msg.contentMetadata:
                                names = re.findall(r'@(\w+)', text)
                                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                mentionees = mention['MENTIONEES']
                                lists = []
                                for mention in mentionees:
                                    if mention["M"] not in lists:
                                        lists.append(mention["M"])
                                for target in lists:
                                  contact = client.getContact(target)
                                  client.sendImageWithURL(to, f"https://res.cloudinary.com/demo/image/fetch/w_200,e_sepia/http://dl.profile.line-cdn.net/{contact.pictureStatus}")

                        if cmd.startswith("filter2 "):
                            if msg.contentMetadata is not None and 'MENTION' in msg.contentMetadata:
                                names = re.findall(r'@(\w+)', text)
                                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                mentionees = mention['MENTIONEES']
                                lists = []
                                for mention in mentionees:
                                    if mention["M"] not in lists:
                                        lists.append(mention["M"])
                                for target in lists:
                                  contact = client.getContact(target)
                                  client.sendImageWithURL(to, f"https://res.cloudinary.com/demo/image/fetch/w_200,e_simulate_colorblind/http://dl.profile.line-cdn.net/{contact.pictureStatus}")

                        if cmd.startswith("filter3 "):
                            if msg.contentMetadata is not None and 'MENTION' in msg.contentMetadata:
                                names = re.findall(r'@(\w+)', text)
                                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                mentionees = mention['MENTIONEES']
                                lists = []
                                for mention in mentionees:
                                    if mention["M"] not in lists:
                                        lists.append(mention["M"])
                                for target in lists:
                                  contact = client.getContact(target)
                                  client.sendImageWithURL(to, f"https://res.cloudinary.com/demo/image/fetch/w_200,e_hue/http://dl.profile.line-cdn.net/{contact.pictureStatus}")
                        
                        
                        elif cmd.startswith("spamgift "):
                            text = removeCmd("spamgift", text)
                            korban = text.replace('spamgift ', text)
                            korban2 = korban.split()
                            midd = korban2[0]
                            jumlah = int(korban2[1])
                            if jumlah <= 1000:
                                for var in range(0,jumlah):
                                    client.sendMessage(midd, None, contentMetadata={'PRDID': 'a0768339-c2d3-4189-9653-2909e9bb6f58', 'PRDTYPE': 'THEME', 'MSGTPL': '6'}, contentType=9)
                                client.sendMessage(to, "Succes ~")

                        elif cmd.startswith("gift "):
                            query = removeCmd("gift", text)
                            text = query.split("-")
                            message = text[0]
                            number = text[1]
                            groups = client.getGroupIdsJoined()
                            try:
                                group = groups[int(number)-1]
                                G = client.getGroup(group)
                                try:
                                    client.sendGift(group,str(message),'sticker')
                                except:
                                    client.sendGift(group,str(message),'sticker')
                                achinkZul(to, "「 Remote Gift 」\n\nGroup : " + G.name)
                            except Exception as error:
                                client.sendMessage(to, str(error))

                        elif cmd.startswith("xxx "):
                            proses = text.split(" ")
                            urutan = text.replace(proses[0] + " ","")
                            count = urutan.split("|")
                            search = str(count[0])
                            r = requests.get("https://api.avgle.com/v1/search/{}/1?limit=10".format(str(search)))
                            data = json.loads(r.text)
                            if len(count) == 1:
                                no = 0
                                hasil = "「 Search video 18+ 」\n"
                                for aa in data["response"]["videos"]:
                                    no += 1
                                    hasil += "\n"+str(no)+". "+str(aa["title"])+"\nDurasi : "+str(aa["duration"])
                                    ret_ = "\n\nXxx {} | Number".format(str(search))
                                achinkZul(msg.to,hasil+ret_)
                            elif len(count) == 2:
                                try:
                                    num = int(count[1])
                                    b = data["response"]["videos"][num - 1]
                                    c = str(b["vid"])
                                    d = requests.get("https://api.avgle.com/v1/video/"+str(c))
                                    data1 = json.loads(d.text)
                                    hasil = "Title : "+str(data1["response"]["video"]["title"])
                                    hasil += "\n\nDurasi : "+str(data1["response"]["video"]["duration"])
                                    hasil += "\nKualitas HD : "+str(data1["response"]["video"]["hd"])
                                    hasil += "\nDitonton "+str(data1["response"]["video"]["viewnumber"])
                                    e = requests.get("https://api-ssl.bitly.com/v3/shorten?access_token=c52a3ad85f0eeafbb55e680d0fb926a5c4cab823&longUrl="+str(data1["response"]["video"]["video_url"]))
                                    data2 = json.loads(e.text)
                                    hasil += "\nLink video : "+str(data1["response"]["video"]["video_url"])
                                    hasil += "\nLink embed : "+str(data1["response"]["video"]["embedded_url"])
                                    achinkZul(msg.to,hasil)
                                    anuanu = str(data1["response"]["video"]["preview_url"])
                                    path = client.downloadFileURL(anuanu)
                                    client.sendImage(msg.to,path)
                                    cl.sendVideoWithURL(msg.to, data["data"]["url"])
                                except Exception as e:
                                    client.sendMessage(msg.to," "+str(e))

                        elif cmd.startswith("idline "):
                            a = removeCmd("idline", text)
                            b = client.findContactsByUserid(a)
                            line = b.mid
                            client.sendMessage(msg.to,"http://line.me/ti/p/~" + a)
                            client.sendContact(to, line)
                            vinfooter(to,"{}".format(str(hasil)))

                        elif cmd.startswith("blockinfo "):
                            number = removeCmd("blockinfo", text)
                            contactlist = client.getBlockedContactIds()
                            try:
                                contact = contactlist[int(number)-1]
                                friend = client.getContact(contact)
                                cu = client.getProfileCoverURL(contact)
                                path = str(cu)
                                image = "http://dl.profile.line-cdn.net/" + friend.pictureStatus
                                try:
                                    vinfooter(to,"「 Block Info 」\n\n" + "Name : " + friend.displayName + "\nStatus : " + friend.statusMessage + "\nMid : " + friend.mid)
                                    client.sendImageWithURL(to,image)
                                    client.sendImageWithURL(to,path)
                                    client.sendContact(to, friend.mid)
                                except:
                                    pass
                            except Exception as error:
                                vinfooter(to, "「 Result Error 」\n" + str(error))

                        elif cmd.startswith("favoriteinfo "):
                            text = removeCmd("favoriteinfo", text)
                            separate = text.split(" ")
                            number = text.replace(separate[0] + " ", text)
                            contactlist = client.getFavoriteMids()
                            try:
                                contact = contactlist[int(number)-1]
                                friend = client.getContact(contact)
                                cu = client.getProfileCoverURL(contact)
                                path = str(cu)
                                image = "http://dl.profile.line-cdn.net/" + friend.pictureStatus
                                try:
                                    vinfooter(to,"「 Favorite Info」\n\n" + "Name : " + friend.displayName + "\nStatus : " + friend.statusMessage + "\nMid : " + friend.mid)
                                    client.sendImageWithURL(to,image)
                                    client.sendImageWithURL(to,path)
                                    client.sendContact(to, friend.mid)
                                except:
                                    pass
                            except Exception as error:
                                achinkZul(to, "Result Error\n" + str(error))


                        elif cmd.startswith("v "):
                            rah = text.split(" ")
                            matt = text.replace(rah[0] + " ","")
                            chat = "{}".format(matt)
                            groups = client.getGroupIdsJoined()
                            for gr in groups:
                                data = {
                                    "type": "flex",
                                    "altText": "𝑩𝑹𝑶𝑨𝑫𝑪𝑨𝑺𝑻",
                                    "contents": {
  "type": "bubble",
  "size": "micro",
  "body": {
    "type": "box",
    "layout": "vertical",
    "contents": [
      {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "contents": [],
                "size": "xs",
                "wrap": True,
                "text": "𝘽𝙍𝙊𝘼𝘿𝘾𝘼𝙎𝙏",
                "color": "#000000",
                "weight": "bold",
                "gravity": "center",
                "position": "relative",
                "align": "center"
              }
            ],
            "spacing": "sm",
            "borderWidth": "1px",
            "borderColor": "#FFA500",
            "backgroundColor": "#00FFFF",
            "cornerRadius": "10px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "contents": [],
                    "size": "xxs",
                    "wrap": True,
                    "margin": "lg",
                    "color": "#000000",
                    "text": "{}".format(chat),
                    "align": "start"
                  }
                ]
              }
            ],
            "backgroundColor": "#FFFFFF",
            "cornerRadius": "2px",
            "margin": "sm",
            "borderColor": "#FFA500",
            "borderWidth": "1px"
          }
        ],
        "borderWidth": "2px"
      }
    ],
    "borderWidth": "3px",
    "cornerRadius": "10px",
    "borderColor": "#FFA500",
    "paddingAll": "0px",
    "paddingTop": "1px",
    "paddingBottom": "1px",
    "backgroundColor": "#000000"
  }
}}
                                bcTemplate(gr, data)
                                time.sleep(1)
                            achinkZul(to, "Succes broadcast to {} groups ".format(str(len(friends))))
                        elif cmd.startswith("flexfbc "):
                            rah = text.split(" ")
                            matt = text.replace(rah[0] + " ","")
                            chat = "{}".format(matt)
                            friends = client.getAllContactIds()
                            for friend in friends:
                                data = {
                                    "type": "flex",
                                    "altText": "𝑩𝑹𝑶𝑨𝑫𝑪𝑨𝑺𝑻",
                                    "contents": {
                                        "type": "bubble",
                                        "body": {
                                            "type": "box",
                                            "layout": "vertical",
                                            "contents": [
                                                {
                                                    "type": "text",
                                                    "text": "{}".format(chat),
                                                    "wrap": True,
                                                    "align": "start",
                                                    "gravity": "center",
                                                    "size": "xl"
                                                }
                                            ]
                                        }
                                    }
                                }
                                bcTemplate2(friend, data)
                                time.sleep(1)
                            achinkZul(to, "Succes friend cast to {} friend ".format(str(len(friends))))
                        elif cmd.startswith("footerfbc"):
                            am = text.split(" ")
                            hey = text.replace(am[0] + " ", "")
                            text = "Broadcast\n{}".format(hey)
                            groups = client.getGroupIdsJoined()
                            for friend in friends:
                                data = {
                                "type": "text",
                                "text": text,
                                "sentBy": {
                                "label": " TEAM TERMUX V 13",
                                "iconUrl": "https://i.ibb.co/KbfDFN1/1657636839741.jpg",
                                "linkUrl": "line://nv/profilePopup/mid=u42880eb65b2da1eb8fd3b7a9caa4ccc3"}}
                                bcTemplate2(friend, data)
                                time.sleep(1)
                            achinkZul(to, "Succes friend cast to {} friend ".format(str(len(friends))))
                        
                        elif cmd.startswith("food "):
                                query = removeCmd("food", text)
                                cond = query.split("|")
                                search = str(cond[0])
                                r = requests.get("https://cryptic-ridge-9197.herokuapp.com/api/imagesearch/{}".format(str(search)))
                                data=r.text
                                data=json.loads(r.text)
                                if data != []:
                                    ret_ = []                                	
                                    for food in data:
                                        if 'http://' in food["url"]:
                                            pass
                                        else:
                                            if len(ret_) >= 10:
                                                pass
                                            else:
                                                ret_.append({
                                                    "imageUrl": "{}".format(str(food["url"])),
                                                    "action": {
                                                        "type": "uri",
                                                        "label": "Send Image",
                                                        "uri": "line://app/1602687308-GXq4Vvk9?type=image&img={}".format(str(food["url"]))
                                                        }
                                                    }
                                                )
                                    k = len(ret_)//10
                                    for aa in range(k+1):
                                        data = {
                                            "type": "template",
                                            "altText": "I'm hungry",
                                            "template": {
                                                "type": "image_carousel",
                                                "columns": ret_[aa*10 : (aa+1)*10]
                                            }
                                        }
                                        sendTemplate(to, data)

               #     =======[ Remote ]
                        elif cmd == "remote":
                            ret = "◉ openqr num\n"
                            ret += "◉ closeqr num \n"
                            ret += "◉ remotenoox num\n"
                            ret += "◉ remotebypass num\n"
                            ret += "◉ tagall group\n"
                            ret += "◉ haha num\n"
                            ret += "◉ disco num\n"
                            ret += "◉ grouplist num\n"
                            ret += "◉ virus num\n"
                            ret += "◉ leavegc num"
                            achinkZul1(to, ret)

                        elif cmd == "tagall group":
                              if msg._from in clientMID:
                                groups = client.getGroupIdsJoined()
                                for group in groups:
                                    client.sendMessage(group, AM_message["settag"])
                                vintemp(to, "Succes tagall {} groups".format(str(len(groups))))

                        elif cmd.startswith("leavegc "):
                              if msg._from in clientMID:
                                sep = text.split(" ")
                                query = text.replace(sep[0] + " ","")
                                groups = client.getGroupIdsJoined()
                                try:
                                    listGroup = groups[int(query)-1]
                                    group = client.getGroup(listGroup)
                                    client.leaveGroup(group.id)
                                    vintemp(to, "Succesfully leave to Group {}".format(group.name))
                                except Exception as error:
                                    logError(error)

                        elif cmd.startswith("virus "):
                              if msg._from in clientMID:
                                sep = text.split(" ")
                                query = text.replace(sep[0] + " ","")
                                groups = client.getGroupIdsJoined()
                                am = virus()
                                try:
                                    listGroup = groups[int(query)-1]
                                    group = client.getGroup(listGroup)
                                    client.sendMessage(listGroup, am)
                                    vintemp(to, "Succesfully sendvirus to {}".format(group.name))
                                except Exception as error:
                                    logError(error)
#REMOTE DISCO
                        elif cmd.startswith("haha "):
                                number = removeCmd("haha", text)
                                groups = client.getGroupIdsJoined()
                                group = groups[int(number)-1]
                                G = client.getGroup(group)
                                ret_ = []
                                ret_.append({"imageUrl":"https://thumbs.gfycat.com/QuaintScornfulAmericanlobster-small.gif","size": "full","action": {"type": "uri","uri": "https://line.me/ti/p/~" + client.profile.userid}})
                                k = len(ret_)//1
                                for aa in range(k+1):
                                    data = {
                                        "type": "template",
                                        "altText": "This is image_carousel",
                                        "template": {
                                            "type": "image_carousel",
                                            "columns": ret_[aa*1 : (aa+1)*1]
                                        }
                                    }
                                    sendTemplate(group, data)
                                vintemp(to, "Remote Haha\nIn Grup {}".format(G.name))

                        elif cmd.startswith("disco "):
                                number = removeCmd("disco", text)
                                groups = client.getGroupIdsJoined()
                                group = groups[int(number)-1]
                                G = client.getGroup(group)
                                ret_ = []
                                ret_.append({"imageUrl":"https://techflourish.com/images/book-clipart-gif-9.gif","size": "full","action": {"type": "uri","uri": "https://line.me/ti/p/~" + client.profile.userid}})
                                ret_.append({"imageUrl":"https://i.pinimg.com/originals/a1/9a/39/a19a390f4a46f098eec1c8070001b5ad.gif","size": "full","action": {"type": "uri","uri": "https://line.me/ti/p/~" + client.profile.userid}})
                                ret_.append({"imageUrl":"https://4.bp.blogspot.com/-MifM_HCQjAE/Wnkgxjj-pcI/AAAAAAALEdg/ObmxB3z9aW8DXfVnjwTCUNooO3LfgDsSQCLcBGAs/s1600/AS003630_02.gif","size": "full","action": {"type": "uri","uri": "https://line.me/ti/p/~" + client.profile.userid}})
                                ret_.append({"imageUrl":"https://media.giphy.com/media/fvOKZ1hETl5L2/giphy.gif","size": "full","action": {"type": "uri","uri": "https://line.me/ti/p/~" + client.profile.userid}})
                                ret_.append({"imageUrl":"https://steamusercontent-a.akamaihd.net/ugc/269469010840327100/309EC530780F049E3FAC757C4B2A75A008D2667E/","size": "full","action": {"type": "uri","uri": "https://line.me/ti/p/~" + client.profile.userid}})
                                ret_.append({"imageUrl":"https://media.giphy.com/media/lnd8s1O9mV61O/giphy.gif","size": "full","action": {"type": "uri","uri": "https://line.me/ti/p/~" + client.profile.userid}})
                                ret_.append({"imageUrl":"https://s.kaskus.id/images/2013/06/05/5534212_20130605075951.gif","size": "full","action": {"type": "uri","uri": "https://line.me/ti/p/~" + client.profile.userid}})
                                k = len(ret_)//5
                                for aa in range(k+1):
                                    data = {
                                        "type": "template",
                                        "altText": "DiscoDance",
                                        "template": {
                                            "type": "image_carousel",
                                            "columns": ret_[aa*5 : (aa+1)*5]
                                        }
                                    }
                                    sendTemplate(group, data)
                                vintemp(to, "Success Remote Template Disco in\nGrup {}".format(G.name))
#=====================================================================
#                              \\ COMMAND Kick //
                        elif cmd.startswith("cloneprofile "):
                            if msg.contentMetadata is not None and 'MENTION' in msg.contentMetadata:
                                names = re.findall(r'@(\w+)', text)
                                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                mentionees = mention['MENTIONEES']
                                lists = []
                                for mention in mentionees:
                                    if mention["M"] not in lists:
                                        lists.append(mention["M"])
                                if len(lists) != []:
                                    ls = random.choice(lists)
                                    cloneProfile(ls)
                                    client.sendContact(to,clientMID)
                                    vintemp(to,"Has been Clone")

                        elif cmd.startswith("tban "):
                            if msg.contentMetadata is not None and 'MENTION' in msg.contentMetadata:
                                names = re.findall(r'@(\w+)', text)
                                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                mentionees = mention['MENTIONEES']
                                lists = []
                                for mention in mentionees:
                                    if mention["M"] not in lists:
                                        lists.append(mention["M"])
                                for ls in lists:
                                    try:
                                        AM_backup["Talkblacklist"][ls] = True
                                        backupData()
                                        vintemp(to,'Add to TalkBan')
                                    except:pass

                        elif cmd.startswith("tunban "):
                            if msg.contentMetadata is not None and 'MENTION' in msg.contentMetadata:
                                names = re.findall(r'@(\w+)', text)
                                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                mentionees = mention['MENTIONEES']
                                lists = []
                                for mention in mentionees:
                                    if mention["M"] not in lists:
                                        lists.append(mention["M"])
                                for ls in lists:
                                    try:
                                        del AM_backup["Talkblacklist"][ls]
                                        backupData()
                                        vintemp(to,"Deleted from TalkBan")
                                    except:pass

                        elif cmd.startswith("mentionmid "):
                            contact = removeCmd("mentionmid", text)
                            sendMention(to, contact)

                        elif cmd.startswith("reinv "):
                            if msg.contentMetadata is not None and 'MENTION' in msg.contentMetadata:
                                names = re.findall(r'@(\w+)', text)
                                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                mentionees = mention['MENTIONEES']
                                lists = []
                                for mention in mentionees:
                                    if mention["M"] not in lists:
                                        lists.append(mention["M"])
                                for ls in lists:
                                    try:
                                        client.findAndAddContactsByMid(ls)
                                        client.kickoutFromGroup(to, [ls])
                                        time.sleep(5)
                                        client.inviteIntoGroup(to, [ls])
                                    except:
                                      vintemp(to,"Limited !")

                        elif cmd.startswith("invite "):
                            if msg.contentMetadata is not None and 'MENTION' in msg.contentMetadata:
                                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                mentionees = mention['MENTIONEES']
                                lists = []
                                for mention in mentionees:
                                    if mention["M"] not in lists:
                                        lists.append(mention["M"])
                                for ls in lists:
                                    try:
                                       client.findAndAddContactsByMid(ls)
                                       client.inviteIntoGroup(to, [ls])
                                    except:
                                      vintemp(to,"Limited !")

                        elif cmd.startswith("clone "):
                            if msg.contentMetadata is not None and 'MENTION' in msg.contentMetadata:
                                names = re.findall(r'@(\w+)', text)
                                clone = ast.literal_eval(msg.contentMetadata['MENTION'])
                                clones = clone['MENTIONEES']
                                target = []
                                for clone in clones:
                                    if clone["M"] not in target:
                                        target.append(clone["M"])
                                for she in target:
                                    BackupProfile = client.getContact(sender)
                                    Save1 = "http://dl.profile.line-cdn.net/{}".format(BackupProfile.pictureStatus);Save2 = "{}".format(BackupProfile.displayName);ProfileMe["PictureMe"] = Save1;ProfileMe["NameMe"] = Save2
                                    contact = client.getContact(she);ClonerV2(she)
                                    sendMention(to, contact.mid, "「 𝑪𝒍𝒐𝒏𝒆 𝑷𝒓𝒐𝒇𝒊𝒍𝒆 」\n", "\n𝑺𝒕𝒂𝒕𝒖𝒔 : 𝖘𝖚𝖈𝖈𝖊𝖘");client.sendContact(to, str(BackupProfile.mid));client.sendContact(to, str(contact.mid))
                        elif cmd == "unclone":
                            try:
                                clientProfile = client.getProfile()
                                clientName = client.getProfile()
                                clientProfile.statusMessage = str(ProfileMe["myProfile"]["statusMessage"])
                                clientProfile.pictureStatus = str(ProfileMe["myProfile"]["pictureStatus"])
                                clientName.displayName = ProfileMe["NameMe"]
                                client.updateProfile(clientName)
                                path = client.downloadFileURL(ProfileMe["PictureMe"])
                                client.updateProfilePicture(path)
                                coverId = str(ProfileMe["myProfile"]["coverId"])
                                client.updateProfileCoverById(coverId)
                                BackupProfile = client.getContact(sender)
                                sendMention(to, BackupProfile.mid, "「 𝑼𝒏𝑪𝒍𝒐𝒏𝒆 𝑷𝒓𝒐𝒇𝒊𝒍𝒆 」\n", "\n𝑺𝒕𝒂𝒕𝒖𝒔 : 𝖘𝖚𝖈𝖈𝖊𝖘");client.sendContact(to, str(BackupProfile.mid))
                            except Exception as error:
                              vintemp(to,"Failed to Backup")

                        elif cmd.startswith("creategroup "):
                            text = removeCmd("creategroup", text)
                            sep = text.split(" ")
                            name = text.replace(sep[0] + " ", text)
                            client.createGroup(name, [clientMID])
                            gids = client.getGroupIdsByName(name)
                            for gid in gids:
                	            try:
                		            x = client.getGroup(gid)
                		            x.preventedJoinByTicket = False
                		            client.updateGroup(x)
                	            except Exception as e:
                		            client.sendMessage(to, str(e))
                            vinfooter(to, "Create Group {}\n\nQR : http://line.me/R/ti/g/{}".format(str(name), str(client.reissueGroupTicket(x.id))))

                        
#=====================================================================
#                              \\ COMMAND Steal //
                        elif cmd.startswith("locate "):
                            if msg.contentMetadata is not None and 'MENTION' in msg.contentMetadata:
                                names = re.findall(r'@(\w+)', text)
                                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                mentionees = mention['MENTIONEES']
                                userid = "https://line.me/ti/p/~" + client.profile.userid
                                G = client.getGroupIdsJoined()
                                cgroup = client.getGroups(G)
                                groups = client.groups
                                ngroup = ""
                                ngroup += "「 Locate 」\n"
                                no = 0 + 1
                                num = 0
                                for mention in mentionees:
                                    for x in range(len(cgroup)):
                                        gMembMids = [contact.mid for contact in cgroup[x].members]
                                        if mention['M'] in gMembMids:
                                            ngroup += "\n{}. {} | {}".format(str(no), str(cgroup[x].name), str(len(cgroup[x].members)))
                                            no += 1
                                            num += 1
                                    ngroup += "\n\n{} groups".format(str(num))
                                    vintemp(to,"{}".format(str(ngroup)))
                                if ngroup == "":
                                  vintemp(to,"「 Locate 」\nNot found")

                        elif cmd.startswith("mid "):
                            if msg.contentMetadata is not None and 'MENTION' in msg.contentMetadata:
                                names = re.findall(r'@(\w+)', text)
                                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                mentionees = mention['MENTIONEES']
                                lists = []
                                for mention in mentionees:
                                    if mention["M"] not in lists:
                                        lists.append(mention["M"])
                                ret_ = "「 Mid User 」"
                                for ls in lists:
                                    ret_ += "\n{}".format(str(ls))
                                vinfooter(to,"{}".format(str(ret_)))

                        elif cmd.startswith("pict "):
                            if msg.contentMetadata is not None and 'MENTION' in msg.contentMetadata:
                                names = re.findall(r'@(\w+)', text)
                                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                mentionees = mention['MENTIONEES']
                                lists = []
                                for mention in mentionees:
                                    if mention["M"] not in lists:
                                        lists.append(mention["M"])
                                for ls in lists:
                                    path = "https://obs.line-scdn.net/" + client.getContact(ls).pictureStatus
                                    data = {"type": "flex","altText": "TEAM TERMUX V 13","contents": {"type": "bubble","size": "giga","body": {"type": "box","layout": "vertical","contents": [{"type": "image","url": path,"size": "full","gravity": "center","aspectMode": "cover","aspectRatio": "2:3"},{"type": "image","url": "https://scdn.line-apps.com/n/channel_devcenter/img/flexsnapshot/clip/clip15.png","position": "absolute","offsetTop": "0px","offsetBottom": "0px","offsetStart": "0px","offsetEnd": "0px","size": "full","aspectRatio": "2:3","aspectMode": "cover"},{"type": "box","layout": "horizontal","contents": [{"type": "box","layout": "vertical","contents": [{"type": "box","layout": "horizontal","contents": [{"type": "text","color": "#ffffff80","text": "==|[ 𝑨𝑹𝑻𝑰𝑺𝑻 𝑩𝑰𝑵𝑨𝑻𝑨𝑵𝑮 𝑭𝑰𝑳𝑴 ]|==","align": "center"}]},{"type": "box","layout": "horizontal","contents": [{ "type": "text","text": "{}".format(str(client.getContact(ls).displayName)),"color": "#ffffff50","size": "sm","align": "center"}]}],"spacing": "xs"}],"position": "absolute","offsetBottom": "0px","offsetStart": "0px","offsetEnd": "0px","paddingAll": "20px"}],"paddingAll": "0px","action": {"type": "uri","label": "action","uri": "line://app/1602687308-GXq4Vvk9?type=image&img={}".format(str(path))}}}}
                                    sendTemplate(to, data)

                        elif cmd.startswith("video "):
                            if msg.contentMetadata is not None and 'MENTION' in msg.contentMetadata:
                                names = re.findall(r'@(\w+)', text)
                                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                mentionees = mention['MENTIONEES']
                                lists = []
                                for mention in mentionees:
                                    if mention["M"] not in lists:
                                        lists.append(mention["M"])
                                for ls in lists:
                                    contact = client.getContact(ls)
                                    if contact.videoProfile == None:
                                    	continue
                                    path = "http://dl.profile.line-cdn.net/" + contact.pictureStatus + "/vp"
                                    client.generateReplyMessage(msg.id)
                                    client.sendReplyVideoWithURL(msg.id, to, str(path))

                        elif cmd.startswith("cover "):
                            if client != None:
                                if msg.contentMetadata is not None and 'MENTION' in msg.contentMetadata:
                                    names = re.findall(r'@(\w+)', text)
                                    mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                    mentionees = mention['MENTIONEES']
                                    lists = []
                                    for mention in mentionees:
                                        if mention["M"] not in lists:
                                            lists.append(mention["M"])
                                    for ls in lists:
                                        path = client.getProfileCoverURL(ls)
                                        path = str(path)
                                        data = {"type": "flex","altText": "TEAM TERMUX V 13","contents": {"type": "bubble","size": "giga","body": {"type": "box","layout": "vertical","contents": [{"type": "image","url": path,"size": "full","gravity": "center","aspectMode": "cover","aspectRatio": "2:3"},{"type": "image","url": "https://scdn.line-apps.com/n/channel_devcenter/img/flexsnapshot/clip/clip15.png","position": "absolute","offsetTop": "0px","offsetBottom": "0px","offsetStart": "0px","offsetEnd": "0px","size": "full","aspectRatio": "2:3","aspectMode": "cover"},{"type": "box","layout": "horizontal","contents": [{"type": "box","layout": "vertical","contents": [{"type": "box","layout": "horizontal","contents": [{"type": "text","color": "#ffffff80","text": "==|[ 𝑨𝑹𝑻𝑰𝑺𝑻 𝑩𝑰𝑵𝑨𝑻𝑨𝑵𝑮 𝑭𝑰𝑳𝑴]|==","align": "center"}]},{"type": "box","layout": "horizontal","contents": [{ "type": "text","text": "{}".format(str(client.getContact(ls).displayName)),"color": "#ffffff50","size": "sm","align": "center"}]}],"spacing": "xs"}],"position": "absolute","offsetBottom": "0px","offsetStart": "0px","offsetEnd": "0px","paddingAll": "20px"}],"paddingAll": "0px","action": {"type": "uri","label": "action","uri": "line://app/1602687308-GXq4Vvk9?type=image&img={}".format(str(path))}}}}
                                        sendTemplate(to, data)

                        if cmd == "tagpm" and sender == clientMID:
                           if msg.toType != 2:
                            for num in range(5):
                                sendMention(to, to,)

                        elif cmd.startswith("name "):
                            if msg.contentMetadata is not None and 'MENTION' in msg.contentMetadata:
                                names = re.findall(r'@(\w+)', text)
                                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                mentionees = mention['MENTIONEES']
                                lists = []
                                for mention in mentionees:
                                    if mention["M"] not in lists:
                                        lists.append(mention["M"])
                                for ls in lists:
                                    contact = client.getContact(ls)
                                    vintemp(to,"{}".format(str(contact.displayName)))

                        elif cmd.startswith("bio "):
                            if msg.contentMetadata is not None and 'MENTION' in msg.contentMetadata:
                                names = re.findall(r'@(\w+)', text)
                                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                mentionees = mention['MENTIONEES']
                                lists = []
                                for mention in mentionees:
                                    if mention["M"] not in lists:
                                        lists.append(mention["M"])
                                for ls in lists:
                                    contact = client.getContact(ls)
                                    vintemp2(to,"{}".format(str(contact.statusMessage)))

                        elif cmd.startswith("profile "):
                            if msg.contentMetadata is not None and 'MENTION' in msg.contentMetadata:
                                names = re.findall(r'@(\w+)', text)
                                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                mentionees = mention['MENTIONEES']
                                lists = []
                                for mention in mentionees:
                                    if mention["M"] not in lists:
                                        lists.append(mention["M"])
                                for ls in lists:
                                    contact = client.getContact(ls)
                                    cu = client.getProfileCoverURL(ls)
                                    path = str(cu)
                                    image = "http://dl.profile.line-cdn.net/" + contact.pictureStatus
                                    vintemp2(to,"𝙉𝒂𝒎𝒂 ➽\n" + contact.displayName + "\n𝑴𝒊𝒅 ➽\n" + contact.mid + "\n\n𝑩𝒊𝒐 ➽\n" + contact.statusMessage)
                                    client.sendImageWithURL(msg.to,image)
                                    client.sendImageWithURL(msg.to,path)

                        elif cmd.startswith("contact "):
                            if msg.contentMetadata is not None and 'MENTION' in msg.contentMetadata:
                                names = re.findall(r'@(\w+)', text)
                                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                mentionees = mention['MENTIONEES']
                                lists = []
                                for mention in mentionees:
                                    if mention["M"] not in lists:
                                        lists.append(mention["M"])
                                for ls in lists:
                                    contact = client.getContact(ls)
                                    mi_d = contact.mid
                                    client.sendContact(to, mi_d)

                        elif cmd.startswith("cvp"):
                            link = removeCmd("cvp", text)
                            contact = client.getContact(sender)
                            vintemp(to,"「 Status donwloads 」\n\nWait a minute..!")
                            print("Sedang Mendownload Data ~")
                            pic = "http://dl.profile.line-cdn.net/{}".format(contact.pictureStatus)
                            subprocess.getoutput('youtube-dl --format mp4 --output video.mp4 {}'.format(link))
                            pict = client.downloadFileURL(pic)
                            vids = "video.mp4"
                            time.sleep(2)
                            changeVideoAndPictureProfile(pict, vids)
                            vintemp(to,"「 Status succes 」\n\nPlease se your profile")
                            os.remove("video.mp4")

                        elif cmd == "lp":
                            Zul = "u42880eb65b2da1eb8fd3b7a9caa4ccc3"
                            client.sendContact(to, Zul)
                            client.sendMessage(to, "☝️☝️..Open Oder Bot silakan pm Contact..☝️☝️ ")
#=====================================================================
                        
                        
                        
#=====================================================================

                        elif cmd == "tbanlist":
                            if AM_backup["Talkblacklist"] == {}:
                              vintemp(to,"Nothing Talkban user")
                            else:
                              ma = ""
                              a = 0
                              for m_id in AM_backup["Talkblacklist"]:
                                  a = a + 1
                                  end = '\n'
                                  ma += str(a) + ". " +client.getContact(m_id).displayName + "\n"
                              vintemp(to,"「 List Talkblacklist 」\n\n"+ma+"\nTotal %s Talkban User" %(str(len(AM_backup["Talkblacklist"]))))

                        elif cmd == "add getreadersticker" and sender == clientMID:
                            settings["messageSticker"]["addStatus"] = True
                            settings["messageSticker"]["addName"] = "readerSticker"
                            vintemp(to,"Please send a sticker")

                        elif cmd == "del getreadersticker" and sender == clientMID:
                            settings["messageSticker"]["listSticker"]["readerSticker"]["status"] = False
                            vintemp(to,"Succes delete a sticker")

                        elif cmd.startswith("setsider ") and sender == clientMID:
                            text_ = removeCmd("setsider", text)
                            try:
                              AM_message["sidertext"] = text_
                              backupData()
                              vintemp(to," 「 Status succes 」\n\nChanged to : " + text_)
                            except:
                              vintemp(to,"「 Status failed 」\n\n Silahkan set ulang")

                        elif cmd == "settings":
                            ret = "◉ autojoin on|Off"
                            ret += "\n◉ autoleave on|Off"
                            ret += "\n◉ autojoin ticket on|off"
                            ret += "\n◉ autoblock on|off"
                            ret += "\n◉ autolike on|off"
                            ret += "\n◉ mode publik on|off"
                            ret += "\n◉ bigsticker on|off"
                            ret += "\n◉ notag on|off"
                            ret += "\n◉ invite on|off"
                            ret += "\n◉ detect templete on|off"
                            ret += "\n◉ detect gambar on|off"
                            ret += "\n◉ detect video on|off"
                            ret += "\n◉ detect audio on|off"
                            mx = "◉ detect contact on|off"
                            mx += "\n◉ detect call on|off"
                            mx += "\n◉ detect id sticker on|off"
                            mx += "\n◉ detect sticker on|off"
            #                mx += "\n◉ detect smule on|off"
            #                mx += "\n◉ detect youtube on|off"
                            mx += "\n◉ respon welcome on|off"
                            mx += "\n◉ respon leave on|off"
                            mx += "\n◉ respontag on|off"
                            mx += "\n◉ respontag poto on|off"
                            mx += "\n◉ respontag text on|off"
                            mx += "\n◉ sider 1 on|off"
                            mx += "\n◉ sider 2 on|off"
                            xx = "◉ sider 3 on|off"
                            xx += "\n◉ sider 4 0n|off"
                            xx += "\n◉ sider 5 0n|off"
                            xx += "\n◉ readgroup on|off"
                            xx += "\n◉ readpesan on|off"
                            xx += "\n◉ autoadd on|off"
                            xx += "\n◉ simi on|off"

                            hello = "{}".format(str(ret))
                            achinkZul3(to, ret, mx, xx)
#=====================================================================
#========================[SAKLAR AMBOTLINE]===========================
                        elif cmd == "autoread":
                            if settings["autoRead"] == True:a = "Enabled"
                            else:a = "Disabled"
                            if settings["autoRead1"] == True:b = "Enabled"
                            else:b = "Disabled"
                            key = settings['keyCommand']
                            key = key.title()
                            if settings['setKey'] == False:key = ""
                            client.sendReplyMessage(to, " 「 Auto Read 」\nGunakan :\nPesan on Personal: "+a+"\nGroup on Group: "+b+"\n\nCommand:\n Autoread\n  Usage: "+key+" readpesan on|off readgroup on|off")
                        elif cmd == "readpesan on":
                            if settings["autoRead"] == True:
                              vintemp(to," 「 𝑨𝒖𝒕𝒐𝒓𝒆𝒂𝒅 」\n𝑨𝒖𝒕𝒐𝒓𝒆𝒂𝒅 𝒊𝒏 𝒑𝒓𝒊𝒗𝒂𝒕𝒆 𝒎𝒆𝒔𝒂𝒈𝒈𝒆 𝒆𝒏𝒂𝒃𝒍𝒆...")
                            else:
                              vintemp(to," 「 𝑨𝒖𝒕𝒐𝒓𝒆𝒂𝒅 」\n𝑨𝒖𝒕𝒐𝒓𝒆𝒂𝒅 𝒊𝒏 𝒑𝒓𝒊𝒗𝒂𝒕𝒆 𝒎𝒆𝒔𝒂𝒈𝒈𝒆 d𝒆𝒏𝒂𝒃𝒍𝒆...")
                              settings["autoRead"]=True

                        elif cmd == "readpesan off":
                            if settings["autoRead"] == False:
                              vintemp(to," 「 𝑨𝒖𝒕𝒐𝒓𝒆𝒂𝒅 」\n𝑨𝒖𝒕𝒐𝒓𝒆𝒂𝒅 𝒊𝒏 𝒑𝒓𝒊𝒗𝒂𝒕𝒆 𝒎𝒆𝒔𝒂𝒈𝒈𝒆 𝒅𝒊𝒔𝒂𝒃𝒍𝒆𝒅...")
                            else:
                              vintemp(to," 「 𝑨𝒖𝒕𝒐𝒓𝒆𝒂𝒅 」\n𝑨𝒖𝒕𝒐𝒓𝒆𝒂𝒅 𝒊𝒏 𝒑𝒓𝒊𝒗𝒂𝒕𝒆 𝒎𝒆𝒔𝒂𝒈𝒈𝒆 𝒅𝒊𝒔𝒂𝒃𝒍𝒆𝒅...")
                              settings["autoRead"]=False

                        if text.lower() == "respon smule on":
                           AM_SAKLAR["downloadsmule"] = True
                           vintemp(to,"「 𝑺𝒕𝒂𝒕𝒖𝒔 𝑺𝒖𝒄𝒄𝒆𝒔 」\𝑫𝒐𝒘𝒏𝒍𝒐𝒂𝒅𝒔 𝒔𝒎𝒖𝒍𝒆 𝒆𝒏𝒂𝒃𝒍𝒆...")
                           AM_SAKLAR["downloadsmule"] = True

                        if text.lower() == "respon smule off":
                           AM_SAKLAR["downloadsmule"] = False
                           vintemp(to,"「 𝑺𝒕𝒂𝒕𝒖𝒔 𝑺𝒖𝒄𝒄𝒆𝒔 」\𝑫𝒐𝒘𝒏𝒍𝒐𝒂𝒅𝒔 𝒔𝒎𝒖𝒍𝒆 𝒅𝒊𝒔𝒂𝒃𝒍𝒆𝒅... ")
                           AM_SAKLAR["downloadsmule"] = False

                        elif cmd == "simi on" and sender == clientMID:
                            simi2["simi-simi"][receiver] = []
                            achinkZul(to, "Simi simi enable")

                        elif cmd == "simi off" and sender == clientMID:
                            if receiver in simi2["simi-simi"]:
                                del simi2["simi-simi"][receiver]
                                achinkZul(to, "simi simi simi disabled")

                        if text.lower() == "respon welcome on":
                           AM_SAKLAR["rwelcome"] = True
                           vintemp(to,"𝑹𝒆𝒔𝒑𝒐𝒏 𝒘𝒆𝒍𝒄𝒐𝒎𝒆 𝒆𝒏𝒂𝒃𝒍𝒆...")
                           AM_SAKLAR["rwelcome"]

                        if text.lower() == "respon welcome off":
                           AM_SAKLAR["rwelcome"] = False
                           vintemp(to,"𝑹𝒆𝒔𝒑𝒐𝒏 𝒘??𝒍𝒄𝒐𝒎𝒆 𝒅𝒊𝒔𝒂𝒃𝒍𝒆𝒅...")
                           AM_SAKLAR["rwelcome"] = False


                        if text.lower() == "respon leave on":
                           AM_SAKLAR["rleave"] = True
                           vintemp(to,"𝑹𝒆𝒔𝒑𝒐𝒏 𝒍𝒆𝒂𝒗𝒆 𝒆𝒏𝒂𝒃𝒍𝒆...")
                           AM_SAKLAR["rleave"] = True

                        if text.lower() == "respon leave off":
                           AM_SAKLAR["rleave"] = False
                           vintemp(to,"𝑹𝒆𝒔𝒑𝒐𝒏 𝒍𝒆𝒂𝒗𝒆 𝒅𝒊𝒔𝒂𝒃𝒍𝒆𝒅")
                           AM_SAKLAR["rleave"] = False


                        elif cmd == "readgroup on":
                            if settings["autoRead1"] == True:
                              vintemp(to,"𝑨𝒖𝒕𝒐𝒓𝒆𝒂𝒅 𝒊𝒏 𝒈𝒓𝒐𝒖𝒑 𝒆𝒏𝒂𝒃𝒍𝒆...")
                            else:
                              vintemp(to,"𝑨𝒖𝒕𝒐𝒓𝒆𝒂𝒅 𝒊𝒏 𝒈𝒓𝒐𝒖𝒑 𝒆𝒏𝒂𝒃𝒍𝒆...")
                              settings["autoRead1"]=True

                        elif cmd == "readgroup off":
                            if settings["autoRead1"] == False:
                              vintemp(to,"𝑨𝒖𝒕𝒐𝒓𝒆𝒂𝒅 𝒊𝒏 𝒈𝒓𝒐𝒖𝒑 𝒅𝒊??𝒂𝒃𝒍𝒆𝒅...")
                            else:
                              vintemp(to,"𝑨𝒖𝒕𝒐𝒓𝒆𝒂𝒅 𝒊𝒏 𝒈𝒓𝒐𝒖𝒑 𝒅𝒊𝒔𝒂𝒃𝒍𝒆𝒅...")
                              settings["autoRead1"]=False

                        elif cmd == "sleepmode" and sender == clientMID:
                            if settings["replyPesan"] is not None:
                                client.sendMessage(to,"「 Sleep Mode 」\nSet Sleep Mode : " + str(settings["replyPesan"]))
                                msgSticker = settings["messageSticker"]["listSticker"]["replySticker"]
                                if msgSticker != None:
                                    sid = msgSticker["STKID"]
                                    spkg = msgSticker["STKPKGID"]
                                    sver = msgSticker["STKVER"]
                                    sendSticker(to, sver, spkg, sid)
                            else:
                                a ="Set Sleep Mode  : No messages are set"
                                data = {
                                "type": "text",
                                "text": "{}".format(str(a)),
                                "sentBy": {
                                "label": " • TEAM TERMUX V 13 ",
                                "iconUrl": "https://i.ibb.co/KbfDFN1/1657636839741.jpg",
                                "linkUrl": "line://nv/profilePopup/mid=u42880eb65b2da1eb8fd3b7a9caa4ccc3"}}
                                sendTemplate(to, data)

                        elif cmd.startswith("sleepmode msg set ") and sender == clientMID:
                            text_ = removeCmd("sleepmode msg set", text)
                            try:
                                settings["replyPesan"] = text_
                                client.sendMessage(to,"「 Sleep Mode 」\nChanged to : " + text_)
                            except:
                                a ="「 Sleep Mode 」\nFailed to replace message"
                                data = {
                                "type": "text",
                                "text": "{}".format(str(a)),
                                "sentBy": {
                                "label": " TEAM TERMUX V 13",
                                "iconUrl": "https://i.ibb.co/KbfDFN1/1657636839741.jpg",
                                "linkUrl": "line://nv/profilePopup/mid=u42880eb65b2da1eb8fd3b7a9caa4ccc3"}}
                                sendTemplate(to, data)

                        if text.lower() == "mode publik on":
                          if msg._from in admin:
                            AM_SAKLAR["mode_publik"] = True
                            vintemp(to,"𝑴𝒐𝒅𝒆 𝒑𝒖𝒃𝒍𝒊𝒄𝒌 𝒆𝒏𝒂𝒃𝒍𝒆...")
                          else:
                            vintemp(to,"𝑴𝒐𝒅𝒆 𝒑𝒖𝒃𝒍𝒊𝒄𝒌 𝒆𝒏𝒂𝒃𝒍𝒆...")
                            AM_SAKLAR["mode_publik"] = True

                        if text.lower() == "mode publik off":
                          if msg._from in admin:
                            AM_SAKLAR["mode_publik"] = False
                            vintemp(to,"𝑴𝒐𝒅𝒆 𝒑𝒖𝒃𝒍𝒊𝒄𝒌𝒅𝒊𝒔𝒂𝒃𝒍𝒆𝒅...")
                          else:
                            vintemp(to,"𝑴𝒐𝒅𝒆 𝒑𝒖𝒃𝒍𝒊𝒄𝒌 𝒅𝒊𝒔𝒂𝒃𝒍𝒆𝒅...")
                            AM_SAKLAR["mode_publik"] = False

                        if text.lower() == "detect id sticker on":
                          if msg._from in admin:
                            AM_SAKLAR["detect_id_sticker"] = True
                            vintemp(to,"𝑫𝒆𝒕𝒆𝒄𝒕 𝒔𝒕𝒊𝒄𝒌𝒆𝒓𝒔 𝒊𝒅 𝒆𝒏𝒂𝒃𝒍𝒆...")
                          else:
                            vintemp(to,"𝑫𝒆𝒕𝒆𝒄𝒕 𝒔𝒕𝒊𝒄𝒌𝒆𝒓𝒔 𝒊𝒅 𝒆𝒏𝒂𝒃𝒍𝒆...")
                            AM_SAKLAR["detect_id_sticker"] = True

                        if text.lower() == "detect id sticker off":
                          if msg._from in admin:
                            AM_SAKLAR["detect_id_sticker"] = False
                            vintemp(to,"𝑫𝒆𝒕𝒆𝒄𝒕 𝒔𝒕𝒊𝒄𝒌𝒆𝒓𝒔 𝒊𝒅 𝒅𝒊𝒔𝒂𝒃𝒍𝒆𝒅...")
                          else:
                            vintemp(to,"𝑫𝒆𝒕𝒆𝒄𝒕 𝒔𝒕𝒊𝒄𝒌𝒆𝒓𝒔 𝒊𝒅 𝒅𝒊𝒔𝒂𝒃𝒍𝒆𝒅...")
                            AM_SAKLAR["detect_id_sticker"] = False

                        if text.lower() == "notag on":
                          if msg._from in admin:
                            AM_SAKLAR["detect_tag_kick"] = True
                            vintemp(to,"𝑫𝒆𝒕𝒆𝒄𝒕 𝒎𝒆𝒏𝒕𝒊𝒐𝒏 𝒌𝒊𝒄𝒌 𝒆𝒏𝒂𝒃𝒍𝒆...")
                          else:
                            vintemp(to,"𝑫𝒆𝒕𝒆𝒄𝒕 𝒎𝒆𝒏𝒕𝒊𝒐𝒏 𝒌𝒊𝒄𝒌 𝒆𝒏𝒂𝒃𝒍𝒆...")
                            AM_SAKLAR["detect_tag_kick"] = True

                        if text.lower() == "notag off":
                          if msg._from in admin:
                            AM_SAKLAR["detect_tag_kick"] = False
                            vintemp(to,"𝑫𝒆𝒕𝒆??𝒕 𝒎𝒆𝒏𝒕𝒊𝒐𝒏 𝒌𝒊𝒄𝒌 𝒅𝒊𝒔𝒂𝒃𝒍𝒆𝒅...")
                          else:
                            vintemp(to,"𝑫𝒆𝒕𝒆𝒄𝒕 𝒎𝒆𝒏𝒕𝒊𝒐𝒏 𝒌𝒊𝒄𝒌 𝒅𝒊𝒔𝒂𝒃𝒍𝒆𝒅...")
                            AM_SAKLAR["detect_tag_kick"] = False

                        if text.lower() == "detect gambar on":
                          if msg._from in admin:
                            AM_SAKLAR["detect_gambar"] = True
                            vintemp(to,"𝑫𝒆𝒕𝒆𝒄𝒕 𝒈𝒂𝒎𝒃𝒂𝒓 𝒆𝒏𝒂𝒃𝒍𝒆...")
                          else:
                            vintemp(to,"𝑫𝒆𝒕𝒆𝒄𝒕 𝒈𝒂𝒎𝒃𝒂𝒓 𝒆𝒏𝒂𝒃𝒍𝒆...")
                            AM_SAKLAR["detect_gambar"] = True

                        if text.lower() == "detect gambar off":
                          if msg._from in admin:
                            AM_SAKLAR["detect_gambar"] = False
                            vintemp(to,"𝑫𝒆𝒕𝒆𝒄𝒕 𝒈𝒂𝒎𝒃𝒂𝒓 𝒅𝒊𝒔𝒂𝒃𝒍𝒆𝒅...")
                          else:
                            vintemp(to,"𝑫𝒆𝒕𝒆𝒄𝒕 𝒈𝒂𝒎𝒃𝒂𝒓 𝒅𝒊𝒔𝒂𝒃𝒍𝒆𝒅...")
                            AM_SAKLAR["detect_gambar"] = False

                        if text.lower() == "detect contact on":
                          if msg._from in admin:
                            AM_SAKLAR["detect_contact"] = True
                            vintemp(to,"𝑫𝒆𝒕𝒆𝒄𝒕 𝒄𝒐𝒏𝒕𝒂𝒄𝒕 𝒆𝒏𝒂𝒃𝒍𝒆...")
                          else:
                            vintemp(to,"𝑫𝒆𝒕𝒆𝒄𝒕 𝒄𝒐𝒏𝒕𝒂𝒄𝒕 𝒆𝒏𝒂𝒃𝒍𝒆...")
                            AM_SAKLAR["detect_contact"] = True

                        if text.lower() == "detect contact off":
                          if msg._from in admin:
                            AM_SAKLAR["detect_contact"] = False
                            vintemp(to,"𝑫𝒆𝒕𝒆𝒄𝒕 𝒄𝒐𝒏𝒕𝒂𝒄𝒕 𝒅𝒊𝒔𝒂𝒃𝒍𝒆𝒅...")
                          else:
                            vintemp(to,"𝑫𝒆𝒕𝒆𝒄𝒕 𝒄𝒐𝒏𝒕𝒂𝒄𝒕 𝒅𝒊𝒔𝒂𝒃𝒍𝒆??...")
                            AM_SAKLAR["detect_contact"] = False

                        if text.lower() == "detect video on":
                          if msg._from in admin:
                            AM_SAKLAR["detect_video"] = True
                            vintemp(to,"𝑫𝒆𝒕𝒆𝒄𝒕 𝒗𝒊𝒅𝒆𝒐 𝒆𝒏𝒂𝒃𝒍𝒆...")
                          else:
                            vintemp(to,"𝑫𝒆𝒕𝒆𝒄𝒕 𝒗𝒊𝒅𝒆𝒐 𝒆𝒏𝒂𝒃𝒍𝒆...")
                            AM_SAKLAR["detect_video"] = True

                        if text.lower() == "detect video off":
                          if msg._from in admin:
                            AM_SAKLAR["detect_video"] = False
                            vintemp(to,"𝑫𝒆𝒕𝒆𝒄𝒕 𝒗𝒊𝒅𝒆𝒐 𝒅𝒊𝒔𝒂𝒃𝒍𝒆𝒅")
                          else:
                            vintemp(to,"𝑫𝒆𝒕𝒆𝒄𝒕 𝒗𝒊𝒅𝒆𝒐 𝒅𝒊𝒔𝒂𝒃??𝒆𝒅")
                            AM_SAKLAR["detect_video"] = False

                        if text.lower() == "detect audio on":
                          if msg._from in admin:
                            AM_SAKLAR["detect_audio"] = True
                            vintemp(to,"𝑫𝒆𝒕𝒆𝒄𝒕 𝒂𝒖𝒅𝒊𝒐 𝒆𝒏𝒂𝒃𝒍𝒆...")
                          else:
                            vintemp(to,"𝑫𝒆𝒕𝒆𝒄𝒕 𝒂𝒖𝒅𝒊𝒐 𝒆𝒏𝒂𝒃𝒍𝒆...")
                            AM_SAKLAR["detect_audio"] = True

                        if text.lower() == "detect audio off":
                          if msg._from in admin:
                            AM_SAKLAR["detect_audio"] = False
                            vintemp(to,"𝑫𝒆𝒕𝒆𝒄𝒕 𝒂𝒖𝒅𝒊𝒐 𝒅𝒊𝒔𝒂𝒃𝒍𝒆𝒅")
                          else:
                            vintemp(to,"𝑫𝒆𝒕𝒆𝒄𝒕 𝒂𝒖𝒅𝒊𝒐 𝒅𝒊𝒔𝒂𝒃𝒍𝒆𝒅")
                            AM_SAKLAR["detect_audio"] = False

                        if text.lower() == "detect sticker on":
                          if msg._from in admin:
                            AM_SAKLAR["detect_sticker"] = True
                            vintemp(to,"𝑫𝒆𝒕𝒆𝒄𝒕 𝒔𝒕𝒊𝒄𝒌𝒆𝒓 𝒆𝒏𝒂𝒃𝒍𝒆...")
                          else:
                            vintemp(to,"𝑫𝒆𝒕𝒆𝒄𝒕 𝒔𝒕𝒊𝒄𝒌𝒆𝒓 𝒆𝒏𝒂𝒃𝒍𝒆...")
                            AM_SAKLAR["detect_sticker"] = True

                        if text.lower() == "detect sticker off":
                          if msg._from in admin:
                            AM_SAKLAR["detect_sticker"] = False
                            vintemp(to,"𝑫𝒆𝒕𝒆??𝒕 𝒔𝒕𝒊𝒄𝒌𝒆𝒓 𝒅𝒊𝒔𝒂𝒃𝒍𝒆𝒅")
                          else:
                            vintemp(to,"𝑫𝒆𝒕𝒆𝒄𝒕 𝒔𝒕𝒊𝒄𝒌𝒆?? 𝒅𝒊𝒔??𝒃𝒍𝒆𝒅")
                            AM_SAKLAR["detect_sticker"] = False

                        if text.lower() == "autoblock on":
                          if msg._from in admin:
                            AM_SAKLAR["autoblock"] = True
                            vintemp(to,"𝑨𝒖𝒕𝒐𝒃𝒍𝒐𝒄𝒌 𝒆𝒏𝒂𝒃𝒍𝒆...")
                          else:
                            vintemp(to,"𝑨𝒖𝒕𝒐𝒃𝒍𝒐𝒄𝒌 𝒆??𝒂𝒃𝒍𝒆...")
                            AM_SAKLAR["autoblock"] = True

                        if text.lower() == "autoblock off":
                          if msg._from in admin:
                            AM_SAKLAR["autoblock"] = False
                            vintemp(to,"𝑨𝒖𝒕𝒐𝒃𝒍𝒐𝒄𝒌 𝒅𝒊𝒔𝒂𝒃𝒍𝒆𝒅")
                          else:
                            vintemp(to,"𝑨𝒖𝒕𝒐𝒃𝒍𝒐𝒄𝒌 𝒅𝒊𝒔𝒂𝒃𝒍𝒆𝒅")
                            AM_SAKLAR["autoblock"] = False

                        if text.lower() == "respon tag on":
                          if msg._from in admin:
                            AM_SAKLAR["detect_tag"] = True
                            vintemp(to,"𝑹𝒆𝒔𝒑𝒐𝒏 𝑻𝒂𝒈 𝒆𝒏𝒂𝒃𝒍𝒆...")
                          else:
                            vintemp(to,"𝑹𝒆𝒔𝒑𝒐𝒏 𝑻𝒂𝒈 𝒆𝒏𝒂𝒃𝒍𝒆...")
                            AM_SAKLAR["detect_tag"] = True

                        if text.lower() == "respon tag off":
                          if msg._from in admin:
                            AM_SAKLAR["detect_tag"] = False
                            vintemp(to,"𝑹𝒆𝒔𝒑𝒐𝒏 𝑻𝒂𝒈 𝒅𝒊𝒔𝒂𝒃𝒍𝒆𝒅")
                          else:
                            vintemp(to,"𝑹𝒆𝒔𝒑𝒐𝒏 𝑻𝒂𝒈 𝒅𝒊𝒔𝒂𝒃𝒍𝒆𝒅")
                            AM_SAKLAR["detect_tag"] = False

                        if text.lower() == "autoadd on":
                           AM_SAKLAR["autoadd"] = True
                           vintemp(to,"𝑴𝒆𝒔𝒔𝒂𝒈𝒆 𝒂𝒅𝒅 𝒆𝒏𝒂𝒃𝒍𝒆...")
                           AM_SAKLAR["autoadd"] = True

                        if text.lower() == "autoadd off":
                           AM_SAKLAR["autoadd"] = False
                           vintemp(to,"𝑴𝒆𝒔𝒔𝒂𝒈𝒆 𝒂𝒅𝒅 𝒅𝒊𝒔𝒂𝒃𝒍𝒆𝒅..")
                           AM_SAKLAR["autoadd"] = False

                        elif cmd == "respontag text off":
                            if AM_SAKLAR["detect_tag_text"] == False:
                              vintemp(to,"𝑹𝒆𝒔𝒑𝒐𝒏 𝑻𝒆𝒙𝒕 𝒅𝒊𝒔𝒂𝒃𝒍𝒆𝒅...")
                            else:
                              vintemp(to,"𝑹𝒆𝒔𝒑𝒐𝒏 𝑻𝒆𝒙𝒕 𝒅𝒊𝒔𝒂𝒃𝒍𝒆𝒅...")
                              AM_SAKLAR["detect_tag_text"]=False

                        elif cmd == "respontag text on":
                            if AM_SAKLAR["detect_tag_text"] == True:
                              vintemp(to,"𝑹𝒆𝒔𝒑𝒐𝒏 𝑻𝒆𝒙𝒕 𝒆𝒏𝒂𝒃𝒍𝒆...")
                            else:
                              vintemp(to,"𝑹𝒆𝒔𝒑𝒐𝒏 𝑻𝒆𝒙𝒕 𝒆𝒏𝒂𝒃𝒍𝒆...")
                              AM_SAKLAR["detect_tag_text"]=True

                        elif cmd == "sider 2 on" and sender == clientMID:
                            am_sider2["ngintip"][receiver] = []
                            vintemp(to,"𝑪𝒉𝒆𝒄𝒌 𝒔𝒊𝒅𝒆𝒓 𝒆𝒏𝒂𝒃𝒍𝒆...")

                        elif cmd == "sider 2 off" and sender == clientMID:
                            if receiver in am_sider2["ngintip"]:
                                del am_sider2["ngintip"][receiver]
                                vintemp(to,"𝑪𝒉𝒆𝒄𝒌 𝒔𝒊𝒅𝒆𝒓 𝒅𝒊𝒔𝒂𝒃𝒍𝒆𝒅...")

                        elif cmd == "sider 3 on" and sender == clientMID:
                            am_sider3["ngintip"][receiver] = []
                            vintemp(to,"𝑪𝒉𝒆𝒄𝒌 𝒔𝒊𝒅𝒆𝒓 𝒆𝒏𝒂𝒃𝒍𝒆...")

                        elif cmd == "sider 3 off" and sender == clientMID:
                            if receiver in am_sider3["ngintip"]:
                                del am_sider3["ngintip"][receiver]
                                vintemp(to,"𝑪𝒉𝒆𝒄𝒌 𝒔𝒊𝒅𝒆𝒓 𝒅𝒊𝒔𝒂𝒃𝒍𝒆𝒅...")

                        elif cmd == "sider 4 on" and sender == clientMID:
                            am_sider4["ngintip"][receiver] = []
                            vintemp(to,"𝑪𝒉𝒆𝒄𝒌 𝒔𝒊𝒅𝒆𝒓 𝒆𝒏𝒂𝒃𝒍𝒆...")

                        elif cmd == "sider 4 off" and sender == clientMID:
                            if receiver in am_sider4["ngintip"]:
                                del am_sider4["ngintip"][receiver]
                                vintemp(to,"𝑪𝒉𝒆𝒄𝒌 𝒔𝒊𝒅𝒆𝒓 𝒅𝒊𝒔𝒂𝒃𝒍𝒆𝒅...")

                        elif cmd == "sider 5 on" and sender == clientMID:
                            am_sider5["ngintip"][receiver] = []
                            vintemp(to,"𝑪𝒉𝒆𝒄𝒌 𝒔𝒊𝒅𝒆𝒓 𝒅𝒊𝒔𝒂𝒃𝒍𝒆𝒅...")

                        elif cmd == "sider 5 off" and sender == clientMID:
                            if receiver in am_sider5["ngintip"]:
                                del am_sider5["ngintip"][receiver]
                                vintemp(to,"𝑪𝒉𝒆𝒄𝒌 𝒔𝒊𝒅𝒆𝒓 𝒅𝒊𝒔𝒂𝒃𝒍𝒆𝒅...")

                        elif cmd == "sider 1 on" and sender == clientMID:
                            AM_Zul["ngintip"][receiver] = []
                            vintemp(to,"𝑪𝒉𝒆𝒄𝒌 𝒔𝒊𝒅𝒆𝒓 𝒆𝒏𝒂𝒃𝒍𝒆...")

                        elif cmd == "sider 1 off" and sender == clientMID:
                            if receiver in AM_Zul["ngintip"]:
                                del AM_Zul["ngintip"][receiver]
                                vintemp(to,"𝑪𝒉𝒆𝒄𝒌 𝒔𝒊??𝒆𝒓 𝒅𝒊𝒔𝒂𝒃𝒍𝒆𝒅...")

                        if text.lower() == "detect smule on":
                           AM_SAKLAR["detect_smule"] = True
                           vintemp(to,"「 𝑹𝒆𝒔𝒑𝒐𝒏 𝑺𝒎𝒖𝒍𝒆 」\n\n𝑨𝒄𝒕𝒊𝒗𝒆 𝑨𝒈𝒂𝒊𝒏")
                           AM_SAKLAR["detect_smule"] = True

                        if text.lower() == "detect smule off":
                           AM_SAKLAR["detect_smule"] = False
                           vintemp(to,"「 𝑹𝒆𝒔𝒑𝒐𝒏 𝑺𝒎𝒖𝒍𝒆 」\n\n𝑵𝒐𝒏 𝑨𝒄𝒕𝒊𝒗𝒆")
                           AM_SAKLAR["detect_smule"] = False

                        if text.lower() == "bigsticker on":
                           AM_SAKLAR["bigsticker"] = True
                           vintemp(to,"𝑩𝒊𝒈𝒔𝒕𝒊𝒄𝒌𝒆𝒓𝒔 𝒆𝒏𝒂𝒃𝒍𝒆...")
                           AM_SAKLAR["bigsticker"] = True

                        if text.lower() == "bigsticker off":
                           AM_SAKLAR["bigsticker"] = False
                           vintemp(to,"𝑩𝒊𝒈𝒔𝒕𝒊𝒄𝒌𝒆𝒓𝒔 𝒅𝒊𝒔𝒂𝒃𝒍𝒆𝒅...")
                           AM_SAKLAR["bigsticker"] = False

                        elif cmd == "respontag poto on":
                            if AM_SAKLAR['detect_tag_poto'] == True:
                              vintemp(to,"𝑹𝒆𝒔𝒑𝒐𝒏 𝒎𝒆𝒏𝒕𝒊𝒐𝒏 𝒇𝒐𝒕𝒐 𝒆𝒏𝒂𝒃𝒍??...")
                            else:
                              vintemp(to,"𝑹𝒆𝒔??𝒐𝒏 𝒎𝒆𝒏𝒕𝒊𝒐𝒏 𝒇𝒐𝒕𝒐 𝒆𝒏𝒂𝒃𝒍𝒆...")
                              AM_SAKLAR['detect_tag_poto']=True

                        elif cmd == "respontag poto off":
                            if AM_SAKLAR['detect_tag_poto'] == False:
                              vintemp(to,"𝑹𝒆𝒔𝒑𝒐𝒏 𝒎𝒆𝒏𝒕𝒊𝒐𝒏 𝒇𝒐𝒕𝒐 𝒅𝒊𝒔𝒂𝒃𝒍𝒆𝒅...")
                            else:
                              vintemp(to,"𝑹𝒆𝒔𝒑𝒐𝒏 𝒎𝒆𝒏𝒕𝒊𝒐𝒏 𝒇𝒐𝒕𝒐 𝒅𝒊𝒔𝒂𝒃𝒍𝒆𝒅...")
                              AM_SAKLAR['detect_tag_poto']=False

                        elif cmd == "autojoin ticket on":
                            if AM_SAKLAR['tiket'] == True:
                              vintemp(to,"𝑨𝒖𝒕𝒐𝒋𝒐𝒊𝒏 𝒕𝒊𝒄𝒌𝒆𝒕 𝒆𝒏𝒂𝒃𝒍𝒆...")
                            else:
                              vintemp(to,"𝑨𝒖𝒕𝒐𝒋𝒐𝒊𝒏 𝒕𝒊𝒄𝒌𝒆𝒕 𝒆𝒏𝒂𝒃𝒍𝒆...")
                              AM_SAKLAR['tiket']=True

                        elif cmd == "autojoin ticket off":
                            if AM_SAKLAR['tiket'] == False:
                              vintemp(to,"𝑨𝒖𝒕𝒐𝒋𝒐𝒊𝒏 𝒕𝒊𝒄𝒌𝒆𝒕 𝒅𝒊𝒔𝒂𝒃𝒍𝒆𝒅...")
                            else:
                              vintemp(to,"𝑨𝒖𝒕𝒐𝒋𝒐𝒊𝒏 𝒕𝒊𝒄𝒌𝒆𝒕 𝒅𝒊𝒔𝒂𝒃𝒍𝒆𝒅...")
                              AM_SAKLAR['tiket']=False

                        elif cmd == "autojoin on":
                            if AM_SAKLAR['autojoin'] == True:
                              vintemp(to,"𝑨𝒖𝒕𝒐𝒋𝒐𝒊𝒏 𝒆𝒏𝒂𝒃𝒍𝒆...")
                            else:
                              vintemp(to,"𝑨𝒖𝒕𝒐𝒋𝒐𝒊𝒏 𝒆𝒏𝒂𝒃𝒍𝒆...")
                              AM_SAKLAR['autojoin']=True

                        elif cmd == "autojoin off":
                            if AM_SAKLAR['autojoin'] == False:
                              vintemp(to,"𝑨𝒖𝒕𝒐𝒋𝒐𝒊𝒏 𝒅𝒊𝒔𝒂𝒃𝒍𝒆𝒅...")
                            else:
                              vintemp(to,"𝑨𝒖𝒕𝒐𝒋𝒐𝒊𝒏 𝒅𝒊𝒔𝒂𝒃𝒍𝒆𝒅...")
                              AM_SAKLAR['autojoin']=False

                        elif cmd == "autoleave on":
                            if AM_SAKLAR['autoleave'] == True:
                              vintemp(to,"𝑨𝒖𝒕𝒐𝒍𝒆𝒂𝒗𝒆 𝒆𝒏𝒂𝒃𝒍𝒆...")
                            else:
                              vintemp(to,"𝑨𝒖𝒕𝒐𝒍𝒆𝒂𝒗𝒆 𝒆𝒏𝒂𝒃𝒍𝒆...")
                              AM_SAKLAR['autoleave']=True

                        elif cmd == "autoleave off":
                            if AM_SAKLAR['autoleave'] == False:
                              vintemp(to,"𝑨𝒖𝒕𝒐𝒍𝒆𝒂𝒗𝒆 𝒅𝒊𝒔??𝒃𝒍𝒆𝒅...")
                            else:
                              vintemp(to,"𝑨𝒖𝒕𝒐𝒍𝒆𝒂𝒗𝒆 𝒅𝒊𝒔𝒂𝒃𝒍𝒆𝒅...")
                              AM_SAKLAR['autoleave']=False

                        elif cmd == "autolike on":
                            if AM_SAKLAR['detect_tl'] == True:
                              vintemp(to,"𝑨𝒖𝒕𝒐𝒍𝒊𝒌𝒆 𝒆𝒏𝒂𝒃𝒍𝒆...")
                            else:
                              vintemp(to,"𝑨𝒖𝒕𝒐𝒍𝒊𝒌𝒆 𝒆𝒏𝒂𝒃𝒍𝒆...")
                              AM_SAKLAR['detect_tl']=True

                        elif cmd == "autolike off":
                            if AM_SAKLAR['detect_tl'] == False:
                              vintemp(to,"𝑨𝒖𝒕𝒐𝒍𝒊𝒌𝒆 𝒅𝒊𝒔𝒂𝒃𝒍𝒆𝒅...")
                            else:
                              vintemp(to,"𝑨𝒖𝒕𝒐𝒍𝒊𝒌𝒆 𝒅𝒊𝒔𝒂𝒃𝒍𝒆𝒅...")
                              AM_SAKLAR['detect_tl']=False

                        elif cmd == "detect call on":
                            if AM_SAKLAR['detect_call'] == True:
                              vintemp(to,"𝑫𝒆𝒕𝒆𝒄𝒕 𝒄𝒂𝒍𝒍 𝒈𝒓𝒐𝒖𝒑 𝒆𝒏𝒂𝒃𝒍𝒆...")
                            else:
                              vintemp(to,"𝑫𝒆𝒕𝒆𝒄𝒕 𝒄𝒂𝒍𝒍 𝒈𝒓𝒐𝒖𝒑 𝒆𝒏𝒂𝒃𝒍𝒆...")
                              AM_SAKLAR['detect_call']=True

                        elif cmd == "detect call off":
                            if AM_SAKLAR['detect_call'] == False:
                              vintemp(to,"𝑫𝒆𝒕𝒆𝒄𝒕 𝒄𝒂𝒍𝒍 𝒈𝒓𝒐𝒖𝒑 𝒅𝒊𝒔𝒂𝒃𝒍𝒆𝒅...")
                            else:
                              vintemp(to,"𝑫𝒆𝒕𝒆𝒄𝒕 𝒄𝒂𝒍𝒍 𝒈𝒓𝒐𝒖𝒑 𝒅𝒊𝒔𝒂𝒃𝒍𝒆𝒅...")
                              AM_SAKLAR['detect_call']=False

               #     =======[ respon sticker ]

                        elif cmd == "addautoadd sticker" and sender == clientMID:
                            settings["messageSticker"]["addStatus"] = True
                            settings["messageSticker"]["addName"] = "addSticker"
                            vintemp(to,"Status: Send sticker")

                        elif cmd == "delautoadd sticker" and sender == clientMID:
                            settings["messageSticker"]["listSticker"]["addSticker"]["status"] = False
                            vintemp(to,"Status: Succes")

                        elif cmd == "addautorespon sticker":
                            if msg.to not in wait["GROUP"]['AR']['S']:
                                wait["GROUP"]['AR']['S'][msg.to] = {'AP':False,'Sticker':{}}
                            wait["GROUP"]['AR']['S'][msg.to]['AP'] = True
                            vintemp(to,"Status: Send sticker")

                        elif cmd == "delautorespon sticker":
                          if msg.to in wait['GROUP']['AR']['S']:
                              wait['GROUP']['AR']['S'] = {}
                              vintemp(to,"Status: delete sticker")

                        elif cmd == 'addleave sticker':
                            if msg.to not in wait["GROUP"]['LM']['S']:
                                wait["GROUP"]['LM']['S'][msg.to] = {'AP':False,'Sticker':{}}
                            wait["GROUP"]['LM']['S'][msg.to]['AP'] = True
                            vintemp(to,"Status: send sticker")

                        elif cmd == 'delleave sticker':
                            if msg.to in wait['GROUP']['LM']['S']:
                                wait['GROUP']['LM']['S'] = {}
                                vintemp(to,"Status: delete sticker")

                        elif cmd == 'addwelcome sticker':
                            if msg.to not in wait["GROUP"]['WM']['S']:
                                wait["GROUP"]['WM']['S'][msg.to] = {'AP':False,'Sticker':{}}
                            wait["GROUP"]['WM']['S'][msg.to]['AP'] = True
                            vintemp(to,"Status: send sticker")

                        elif cmd == 'delwelcome sticker':
                            if msg.to in wait['GROUP']['WM']['S']:
                                wait['GROUP']['WM']['S'] = {}
                                vintemp(to,"Status: delete sticker")
#=====================================================================

                        elif cmd.startswith('unsend '):
                            client.unsendMessage(msg.id)
                            j = int(msg.text.split(' ')[1])
                            a = [client.adityasplittext(msg.text,'s').replace('{} '.format(j),'')]*j
                            if len(msg.text.split(' ')) == 2:
                                h = wait['Unsend'][msg.to]['B']
                                n = len(wait['Unsend'][msg.to]['B'])
                                for b in h[:j]:
                                    try:
                                        client.unsendMessage(b)
                                        wait['Unsend'][msg.to]['B'].remove(b)
                                    except:pass
                                t = len(wait['Unsend'][msg.to]['B'])
                            if len(msg.text.split(' ')) >= 3:h = [client.unsendMessage(client.sendMessage(to,client.adityasplittext(msg.text,'s')).id) for b in a]
#=====================================================================
#=====================================================================
                        elif cmd == "friend":
                            ret = "╭───[ 𝑳𝒊𝒔𝒕 𝑪𝒐𝒏𝒕𝒂𝒄𝒕 ]\n"
                            ret += "├•Temanlist\n"
                            ret += "├•Infoteman「num」\n"
                            ret += "├───[ 𝑯𝒂𝒑𝒖𝒔 𝑻𝒆𝒎𝒂𝒏 ]\n"
                            ret += "├•Clearteman\n"
                            ret += "├•Delallcontact\n"
                            ret += "├•Delteman「@」\n"
                            ret += "├•Delteman「num」\n"
                            ret += "├───[ 𝑨𝒅𝒅 𝑻𝒆𝒎𝒂𝒏 ]\n"
                            ret += "├•Addteman「@」\n"
                            ret += "├•Block「@」\n"
                            ret += "╰───[ •𝖑𝖎𝖕𝖗𝖔®-𝜷??𝝉𝚜• ]"
                            hello = "{}".format(str(ret))
                            vintemp2(to, hello)

                        elif "scall" in msg.text.lower():
                            if msg.toType == 2:
                               sep = msg.text.split(" ")
                               resp = msg.text.replace(sep[0] + " ","")
                               num = int(resp)
                               try:
                                  vintemp(to,"𝙎𝙪𝙘𝙘𝙚𝙨 𝙈𝙚𝙣𝙜𝙞𝙧𝙞𝙢 {} 𝙐𝙣𝙙𝙖𝙣𝙜𝙖𝙣 𝘾𝙖𝙡𝙡 𝙂𝙧𝙤𝙪𝙥𝙨".format(str(num)))
                               except:
                                  pass
                               for var in range(num):
                                  group = client.getGroup(msg.to)
                                  members = [mem.mid for mem in group.members]
                                  client.acquireGroupCallRoute(msg.to)
                                  client.inviteIntoGroupCall(msg.to, contactIds=members)

                        elif cmd == 'temanlist':a = client.refreshContacts();client.datamention(msg.to,'[ Teman List ]',a)

                        elif cmd.startswith('getid'):
                            if 'MENTION' in msg.contentMetadata.keys()!=None:
                                key = eval(msg.contentMetadata["MENTION"])
                                key1 = key["MENTIONEES"][0]["M"]
                                client.getinformation(msg.to,key1,wait)
                            else:
                                if len(cmd.split(' ')) == 2:
                                    a = client.getGroupIdsJoined()
                                    client.getinformation(msg.to,a[int(cmd.split(' ')[1])-1],wait)
                                if cmd == 'getid':client.getinformation(msg.to,msg.to,wait)

                        elif cmd.startswith("infoteman "):
                            msg.text = msg.text = client.mycmd(msg.text,wait)
                            if len(msg.text.split(' ')) == 3:
                                b = client.refreshContacts()
                                client.getinformation(to,b[int(msg.text.split(' ')[2])-1],wait)

                        elif cmd == "clearteman":
                            n = len(client.getAllContactIds())
                            try:
                                client.clearContacts()
                            except: 
                                pass
                            t = len(client.getAllContactIds())
                            vintemp(to,"Type: Friendlist\n • Detail: Clear Contact\n • Before: %s Friendlist\n • After: %s Friendlist\n • Total removed: %s Friendlist\n • Status: Succes.."%(n,t,(n-t)))

                        elif cmd == "delallcontact":
                            n = len(client.getAllContactIds())
                            try:
                                client.deleteContact(to)
                            except:pass
                            t = len(client.getAllContactIds())
                            vintemp(to, "Type: Friendlist\n • Detail: Delete friend\n • Status: Succes..\n • Before: %s Friendlist\n • After: %s Friendlist"%(n,t))

                        elif cmd.startswith("delteman "):
                            if msg.contentMetadata is not None and 'MENTION' in msg.contentMetadata:
                                names = re.findall(r'@(\w+)', text)
                                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                mentionees = mention['MENTIONEES']
                                lists = []
                                for mention in mentionees:
                                    if mention["M"] not in lists:
                                        lists.append(mention["M"])
                                for ls in lists:
                                    contact = client.getContact(ls)
                                    n = len(client.getAllContactIds())
                                    try:
                                        client.deleteContact(ls)
                                    except:pass
                                    t = len(client.getAllContactIds())
                                    vintemp(to, "Type: Friendlist\n • Detail: Delete friend\n • Status: Succes..\n • Before: %s Friendlist\n • After: %s Friendlist"%(n,t))

                        elif cmd.startswith("addteman "):
                            if msg.contentMetadata is not None and 'MENTION' in msg.contentMetadata:
                                names = re.findall(r'@(\w+)', text)
                                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                mentionees = mention['MENTIONEES']
                                lists = []
                                for mention in mentionees:
                                    if mention["M"] not in lists:
                                        lists.append(mention["M"])
                                for ls in lists:
                                    contact = client.getContact(ls)
                                    client.findAndAddContactsByMid(ls)
                                vintemp(to,"Succes add {}".format(str(contact.displayName)))

                        elif cmd.startswith("block "):
                            if msg.contentMetadata is not None and 'MENTION' in msg.contentMetadata:
                                names = re.findall(r'@(\w+)', text)
                                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                mentionees = mention['MENTIONEES']
                                lists = []
                                for mention in mentionees:
                                    if mention["M"] not in lists:
                                        lists.append(mention["M"])
                                for ls in lists:
                                    contact = client.getContact(ls)
                                    client.blockContact(ls)
                                vintemp(to,"Succes block {}".format(str(contact.displayName)))

                        elif cmd.startswith("delteman "):
                            anu = client.refreshContacts()
                            client.deletefriendnum(to, wait, cmd)

                        elif cmd.startswith("hitungmundur "):
                           number = removeCmd("hitungmundur", text)
                           if len(number) > 0:
                               if number.isdigit():
                                   number = int(number)
                                   if number > 500:
                                    vinfooter(to,"kebanyakan woy")
                                   else:
                                       for i in range(0,number):
                                           client.sendMessage(to,str(number))
                                           number -= 1
                                           time.sleep(0.008)
                               else:
                                vinfooter(to,"Gunakan space yah")

                        elif cmd.startswith("hitung "):
                           number = removeCmd("hitung", text)
                           if len(number) > 0:
                               if number.isdigit():
                                   number = int(number)
                                   if number > 500:         
                                       vinfooter(to,"kebanyakan woy")
                                   else:
                                       for i in range(0,number):
                                           client.sendMessage(to,str(i+1))
                                           i += 1+1
                                           time.sleep(0.008)
                               else:
                                   vinfooter(to,"Masukan jumlahnya")
#=====================================================================
#=====================================================================
                        elif cmd == "mentionunsend":
                            client.unsendMessage(msg_id)
                            try:group = client.getGroup(msg.to);nama = [contact.mid for contact in group.members];nama.remove(client.getProfile().mid)
                            except:group = client.getRoom(msg.to);nama = [contact.mid for contact in group.contacts]
                            k = len(nama)//20
                            for a in range(k+1):
                                if a == 0:client.mentionmention(to=msg.to,wait=wait,text='',dataMid=nama[:20],pl=0,ps='╭「 Mention 」─',pg='MENTIONALLUNSED',pt=nama)
                                else:client.mentionmention(to=msg.to,wait=wait,text='',dataMid=nama[a*20 : (a+1)*20],pl=a*20,ps='├「 Mention 」─',pg='MENTIONALLUNSED',pt=nama)
                        elif cmd == AM_message["settag"]:
                            client.unsendMessage(msg_id)
                            group = client.getGroup(to);nama = [contact.mid for contact in group.members];nama.remove(client.getProfile().mid)
                            client.datamention(to,'Tag all',nama)
                   #         client.sendContact#(to, #AM_message["Zul"])
                            time.sleep(1)
                        elif cmd.startswith('mention '):
                            msg.text = client.mycmd(msg.text,wait)
                            if msg.toType == 0:
                                client.datamention(to,'Halo',[to]*int(cmd.split(" ")[1]))
                            elif msg.toType == 2:
                                gs = client.getGroup(to)
                                nama = [contact.mid for contact in gs.members]
                                try:
                                    if 'MENTION' in msg.contentMetadata.keys()!=None:client.datamention(to,'panggilan darurat',[eval(msg.contentMetadata["MENTION"])["MENTIONEES"][0]["M"]]*int(cmd.split(" ")[1]))
                                    else:texst = client.adityasplittext(cmd)
                                    gs = client.getGroup(to)
                                    nama = [contact.mid for contact in gs.members];nama.remove(client.getProfile().mid)
                                    c = ['{}:-:{}'.format(a.displayName,a.mid) for a in gs.members]
                                    c.sort()
                                    b = []
                                    for s in c:
                                        if len(texst) == 1:dd = s[len(texst)-1].lower()
                                        else:dd = s[:len(texst)].lower()
                                        if texst in dd:b.append(s.split(':-:')[1])
                                    client.datamention(to,'Mention By Abjad',b)
                                except:client.adityaarchi(wait,'Mention','',to,client.adityasplittext(msg.text),msg,'\n├Group: '+gs.name[:20],nama=nama)

                        elif cmd.startswith('mentionname '):
                            texst = client.adityasplittext(cmd)
                            gs = client.getGroup(to)
                            c = ['{}:-:{}'.format(a.displayName,a.mid) for a in gs.members]
                            c.sort()
                            b = []
                            for s in c:
                                if texst in s.split(':-:')[0].lower():b.append(s.split(':-:')[1])
                            client.datamention(to,'Mention By Name',b)

                        elif cmd == "check mention":
                            if to in wait['ROM']:
                                moneys = {}
                                msgas = ''
                                for a in wait['ROM'][to].items():
                                    moneys[a[0]] = [a[1]['msg.id'],a[1]['waktu']] if a[1] is not None else idnya
                                sort = sorted(moneys)
                                sort.reverse()
                                sort = sort[0:]
                                msgas = ' 「 Mention Me 」'
                                h = []
                                no = 0
                                for m in sort:
                                    has = ''
                                    nol = -1
                                    for kucing in moneys[m][0]:
                                        nol+=1
                                        has+= '\nline://nv/chatMsg?chatId={}&messageId={} {}'.format(to,kucing,humanize.naturaltime(datetime.fromtimestamp(moneys[m][1][nol]/1000)))
                                    h.append(m)
                                    no+=1
                                    if m == sort[0]:
                                        msgas+= '\n{}. @!{}x{}'.format(no,len(moneys[m][0]),has)
                                    else:
                                        msgas+= '\n\n{}. @!{}x{}'.format(no,len(moneys[m][0]),has)
                                mentions(to, msgas, h)
                                del wait['ROM'][to]
                            else:
                                try:
                                    mids = ["u43b69ac6edb98f1ac42bef8016535342"]
                                    msgas = 'Sorry @!In {} nothink get a mention'.format(client.getGroup(to).name)
                                    mentions(to, msgas, [clientMID])
                                except:
                                    mids = ["u43b69ac6edb98f1ac42bef8016535342"]
                                    msgas = 'Sorry @!In Chat @!nothink get a mention'
                                    mentions(to, msgas, [clientMID])

                        
                        
#==============================================================
                        elif cmd.startswith("ginfo "):
                            number = removeCmd("ginfo",text)
                            groups = client.getGroupIdsJoined()
                            ret_ = ""
                            try:
                                group = groups[int(number)-1]
                                G = client.getGroup(group)
                                path = "http://dl.profile.line-cdn.net/" + G.pictureStatus
                                try:
                                    gCreator = G.creator.displayName
                                except:
                                    gCreator = "Tidak ditemukan"
                                if G.invitee is None:
                                    gPending = "0"
                                else:
                                    gPending = str(len(G.invitee))
                                if G.preventedJoinByTicket == True:
                                    gQr = "Tertutup"
                                    gTicket = "Tidak ada"
                                else:
                                    gQr = "Terbuka"
                                    gTicket = "https://line.me/R/ti/g/{}".format(str(client.reissueGroupTicket(G.id)))
                                timeCreated = []
                                timeCreated.append(time.strftime("%d-%m-%Y [ %H:%M:%S ]", time.localtime(int(G.createdTime) / 1000)))
                                ret_ += "「 𝑮𝒓𝒐𝒖𝒑𝒔 𝑰𝒏𝒇?? 」\n"
                                ret_ += "\nNama Group : {}".format(G.name)
                                ret_ += "\nID Group : {}".format(G.id)
                                ret_ += "\nPembuat : {}".format(gCreator)
                                ret_ += "\nWaktu Dibuat : {}".format(str(timeCreated))
                                ret_ += "\nJumlah Member : {}".format(str(len(G.members)))
                                ret_ += "\nJumlah Pending : {}".format(gPending)
                                ret_ += "\nGroup Qr : {}".format(gQr)
                                ret_ += "\nGroup Ticket : {}".format(gTicket)
                                client.sendImageWithURL(to, path)
                                vinfooter(to,"{}".format(str(ret_)))
                                client.sendContact(to, G.creator.mid)
                            except:
                                pass

                        elif cmd.startswith("changegn"):
                            if msg.toType == 2:
                                X = client.getGroup(to)
                                X.name = removeCmd("changegn", text)
                                client.updateGroup(X)
                            
                        elif cmd.startswith("leave ") and sender == clientMID:
                            number = removeCmd("leave", text)
                            groups = client.getGroupIdsJoined()
                            try:
                                group = groups[int(number)-1]
                                G = client.getGroup(group)
                                try:
                                    client.leaveGroup(G.id)
                                except:
                                    client.leaveGroup(G.id)
                                client.sendMessage(to, "「Leave 」\n\nGroup : " + G.name)
                            except Exception as error:
                                client.sendMessage(to, str(error))
                                
                        elif cmd.startswith("accept ") and sender == clientMID:
                            number = removeCmd("accept", text)
                            groups = client.getGroupIdsJoined()
                            try:
                                group = groups[int(number)-1]
                                G = client.getGroup(group)
                                try:
                                    client.acceptGroup(G.id)
                                except:
                                    client.acceptGroup(G.id)
                                client.sendMessage(to, "「accept 」\n\nGroup : " + G.name)
                            except Exception as error:
                                client.sendMessage(to, str(error))

               #     =======[ Bagian add gambar ]
                        elif cmd == "gambar":
                            ret = "「 𝑪𝒐𝒎𝒎𝒂𝒏𝒅 𝑮𝒂𝒎𝒃𝒂𝒓 」\n\n"
                            ret += "• add pict|text\n"
                            ret += "• del pict|text\n"
                            ret += "• changepict |text\n"
                            ret += "• sendpict |text\n"
                            ret += "• list pict"
                            hello = "{}".format(str(ret))
                            vintemp2(to, hello)

                        elif cmd.startswith("add pict ") and sender == clientMID:
                            load()
                            name = removeCmd("add pict", text)
                            name = name.lower()
                            if name not in images:
                                settings["addImage"]["status"] = True
                                settings["addImage"]["name"] = str(name.lower())
                                images[str(name.lower())] = ""
                                f = codecs.open('Zul/image.json','w','utf-8')
                                json.dump(images, f, sort_keys=True, indent=4, ensure_ascii=False)
                                vintemp(to,"Status: send potonya")
                            else:
                              vintemp(to,"Status: name poto sudah ada")

                        elif cmd.startswith("del pict ") and sender == clientMID:
                            load()
                            name = removeCmd("del pict", text)
                            name = name.lower()
                            if name in images:
                                client.deleteFile(images[str(name.lower())])
                                del images[str(name.lower())]
                                f = codecs.open('Zul/image.json','w','utf-8')
                                json.dump(images, f, sort_keys=True, indent=4, ensure_ascii=False)
                                client.sendMessage(to, "Type: Picture\n • Detail: Delete list picture\n • Status: Succes delete Picture {}".format(str(name.lower())))
                            else:
                              vintemp(to,"Status: name pict tidak ada dalam list")

                        elif cmd.startswith("changepict ") and sender == clientMID:
                            load()
                            name = removeCmd("changepict", text)
                            name = name.lower()
                            if name in images:
                                settings["addImage"]["status"] = True
                                settings["addImage"]["name"] = str(name.lower())
                                images[str(name.lower())] = ""
                                f = codecs.open('Zul/image.json','w','utf-8')
                                json.dump(images, f, sort_keys=True, indent=4, ensure_ascii=False)
                                vintemp(to,"Status: Send pict...")
                            else:
                              vintemp(to,"Status: name pict tidak ada")

                        elif cmd == "list pict":
                            load()
                            no = 0
                            ret_ = "╭───────────────────"
                            for image in images:
                                no += 1
                                ret_ += "\n├➥{}. {}".format(int(no), image.title())
                            ret_ += "\n├───────────────────\n│    Total {} Picture\n╰───────────────────".format(str(len(images)))
                            hello = "{}".format(str(ret_))
                            vintemp2(to,"{}".format(str(ret_)))

                        elif cmd.startswith("sendpict ") and sender == clientMID:
                            load()
                            text = removeCmd("sendpict", text)
                            cond = text.split(" ")
                            jml = int(cond[0])
                            imagename = text.replace(cond[0] + " ","").lower()
                            if imagename in images:
                                imgURL = images[imagename]
                            else:
                              vintemp(to,"Picture name not in list...")
                              return
                            for x in range(jml):
                              client.sendImage(to, imgURL)


                        elif cmd == "stickers":
                            a = "For sticker biasa:\n"
                            a += "  - addsticker text\n"
                            a += "  - delsticker text\n"
                            a += "  - changesticker text\n"
                            a += "  - stickerlist\n"
                            a += "For sticker big nonanimation\n"
                            a += "  - Addtikel- text\n"
                            a += "  - Deltikel- text\n"
                            a += "  - Listtikel-\n"
                            a += "For sticker big Animation\n"
                            a += "  - Addtikel+ text\n"
                            a += "  - Deltikel+ text\n"
                            a += "  - Listtikel+\n\n"
                            a += "For cek your sticker\n"
                            a += "  - mysticker\n"
                            a += "  - sendsticker num\n"
                            a += "  - List tikel-"
                            vintemp2(to, a)
#=====================================================================
#=====================================================================
                        elif cmd.startswith("addtikel- ") and sender == clientMID:
                            load()
                            name = removeCmd("addtikel-", text)
                            name = name.lower()
                            if name not in stickers1:
                                nissa["addTikel2"]["status"] = True
                                nissa["addTikel2"]["name"] = name.lower()
                                stickers1[name.lower()] = {}
                                f = codecs.open('Zul/sticker1.json','w','utf-8')
                                json.dump(stickers1, f, sort_keys=True, indent=4, ensure_ascii=False)
                                vintemp(to, "sᴇɴᴅ sᴛɪᴄᴋᴇʀs ᴛᴏ sᴀᴠᴇ ᴀs {} ".format(name.lower()))
                            else:
                                vintemp(to, "sᴛɪᴄᴋᴇʀs {} sᴜᴅᴀʜ ᴀᴅᴀ ᴅᴀʟᴀᴍ ʟɪsᴛ".format(name.lower()))

                        elif cmd.startswith("deltikel- ") and sender == clientMID:
                            name = removeCmd("deltikel-", text)
                            name = name.lower()
                            if name in stickers1:
                                del stickers1[name.lower()]
                                f = codecs.open('Zul/sticker1.json','w','utf-8')
                                json.dump(stickers2, f, sort_keys=True, indent=4, ensure_ascii=False)
                                vintemp(to, "sᴜᴄᴄᴇss ᴅᴇʟᴇᴛᴇ sᴛɪᴄᴋᴇʀs {} ".format(name.lower()))
                            else:
                                vintemp(to, "sᴛɪᴄᴋᴇʀs {} sᴛɪᴄᴋᴇʀs ᴛɪᴅᴀᴋ ᴀᴅᴀ ᴅᴀʟᴀᴍ ʟɪsᴛ".format(name.lower()))

                        elif cmd.startswith("addtikel+ ") and sender == clientMID:
                            load()
                            name = removeCmd("addtikel+", text)
                            name = name.lower()
                            if name not in stickers2:
                                anyun["addTikel"]["status"] = True
                                anyun["addTikel"]["name"] = name.lower()
                                stickers2[name.lower()] = {}
                                f = codecs.open('Zul/sticker2.json','w','utf-8')
                                json.dump(stickers2, f, sort_keys=True, indent=4, ensure_ascii=False)
                                vintemp(to, "sᴇɴᴅ sᴛɪᴄᴋᴇʀs ᴛᴏ sᴀᴠᴇ ᴀs {} ".format(name.lower()))
                            else:
                                vintemp(to, "sᴛɪᴄᴋᴇʀs {} sᴜᴅᴀʜ ᴀᴅᴀ ᴅᴀʟᴀᴍ ʟɪsᴛ".format(name.lower()))

                        elif cmd.startswith("deltikel+ ") and sender == clientMID:
                            name = removeCmd("deltikel+", text)
                            name = name.lower()
                            if name in stickers2:
                                del stickers2[name.lower()]
                                f = codecs.open('Zul/sticker2.json','w','utf-8')
                                json.dump(stickers2, f, sort_keys=True, indent=4, ensure_ascii=False)
                                vintemp(to, "sᴜᴄᴄᴇss ᴅᴇʟᴇᴛᴇ sᴛɪᴄᴋᴇʀs {} ".format(name.lower()))
                            else:
                                vintemp(to, "sᴛɪᴄᴋᴇʀs {} sᴛɪᴄᴋᴇʀs ᴛɪᴅᴀᴋ ᴀᴅᴀ ᴅᴀʟᴀᴍ ʟɪsᴛ".format(name.lower()))

                        elif cmd.startswith("addsticker ") and sender == clientMID:
                            load()
                            name = removeCmd("addsticker", text)
                            name = name.lower()
                            if name not in stickers:
                                settings["addSticker"]["status"] = True
                                settings["addSticker"]["name"] = str(name.lower())
                                stickers[str(name.lower())] = {}
                                f = codecs.open('Zul/sticker.json','w','utf-8')
                                json.dump(stickers, f, sort_keys=True, indent=4, ensure_ascii=False)
                                vintemp(to,"Kirim stickerya...")
                            else:
                                vintemp(to,"Nama sticker sudah ada...")

                        elif cmd.startswith("delsticker ") and sender == clientMID:
                            load()
                            name = removeCmd("delsticker", text)
                            name = name.lower()
                            if name in stickers:
                                del stickers[str(name.lower())]
                                f = codecs.open('Zul/sticker.json','w','utf-8')
                                json.dump(stickers, f, sort_keys=True, indent=4, ensure_ascii=False)
                                vintemp(to,"sᴜᴄᴄᴇs ᴅᴇʟᴇᴛᴇ sᴛɪᴄᴋᴇʀ {}".format(str(name)))
                            else:
                                vintemp(to,"sᴛɪᴄᴋᴇʀs ᴛɪᴅᴀᴋ ᴀᴅᴀ ᴅᴀʟᴀᴍ ʟɪsᴛ")

                        elif cmd.startswith("changesticker ") and sender == clientMID:
                            load()
                            name = removeCmd("changesticker", text)
                            name = name.lower()
                            if name in stickers:
                                settings["addSticker"]["status"] = True
                                settings["addSticker"]["name"] = str(name.lower())
                                stickers[str(name.lower())] = ""
                                f = codecs.open('Zul/sticker.json','w','utf-8')
                                json.dump(stickers, f, sort_keys=True, indent=4, ensure_ascii=False)
                                vintemp(to,"sᴛᴀᴛᴜs: sᴇɴᴅ sᴛɪᴄᴋᴇʀ..")
                            else:
                                vintemp(to,"sᴛɪᴄᴋᴇʀ ɴᴏᴛ ɪɴ ʟɪsᴛ..")

                        elif cmd == "listtikel+":
                            load()
                            ret_ = "「 Stickers list + 」\n"
                            for sticker in stickers2:
                                ret_ += "\n" + sticker.title()
                            ret_ += "\n\nᴛᴏᴛᴀʟ : {} sᴛɪᴄᴋᴇʀs".format(str(len(stickers2)))
                            vintemp(to,"{}".format(str(ret_)))

                        elif cmd == "listtikel-":
                            load()
                            ret_ = "「 Stickers list - 」\n"
                            for sticker in stickers1:
                                ret_ += "\n" + sticker.title()
                            ret_ += "\n\nᴛᴏᴛᴀʟ : {} sᴛɪᴄᴋᴇʀs".format(str(len(stickers1)))
                            vintemp(to,"{}".format(str(ret_)))

                        elif cmd == "stickerlist":
                            load()
                            ret_ = "「 Stickers list 」\n"
                            for sticker in stickers:
                                ret_ += "\n" + sticker.title()
                            ret_ += "\n\nᴛᴏᴛᴀʟ : {} sᴛɪᴄᴋᴇʀs".format(str(len(stickers)))
                            vintemp(to,"{}".format(str(ret_)))

                        elif cmd.startswith("sendsticker ") and sender == clientMID:
                            load()
                            text = removeCmd("sendsticker", text)
                            cond = text.split(" ")
                            jml = int(cond[0])
                            stickername = text.replace(cond[0] + " ","").lower()
                            if stickername in stickers:
                                sid = stickers[stickername]["STKID"]
                                spkg = stickers[stickername]["STKPKGID"]
                                sver = stickers[stickername]["STKVER"]
                            else:
                                return
                            for x in range(jml):
                                sendStickers(to, sver, spkg, sid)

                        elif cmd == "mysticker":
                            a = client.shop.getActivePurchases(start=0, size=1000, language='ID', country='ID').productList
                            c = "「 My stickers list 」\n"
                            no = 0
                            for b in a:
                                no +=1
                                c += "\n"+str(no)+". "+b.title[:21]+" ID:"+str(b.packageId)
                            k = len(c)//10000
                            for aa in range(k+1):
                                vintemp(to,'{}'.format(c[aa*10000 : (aa+1)*10000]))

               #     ======[ Pengumuman ]==================================================================
                        elif cmd == "pengumuman":
                            a = "「 Pengumuman 」\n\n"
                            a += "cek pengumuman\n"
                            a += "cek pengumuman num\n"
                            a += "del pengumuman"
                            vintemp(to, a)

                        elif cmd == "cek pengumuman":
                            msg.text = client.mycmd(msg.text,wait)
                            to = msg.to
                            a = client.getChatRoomAnnouncements(msg.to)
                            if a == []:
                                client.sendMention(to, 'Maap @! di group {} tidak ada Pengumuman'.format(self.getGroup(to).name),' 「 Pengumuman 」\n', [self.getProfile().mid])
                                return
                            no = 0
                            c = ' 「 Pengumuman 」'
                            h = []
                            ds = [a[b].creatorMid for b in range(len(a)) if a[b].creatorMid not in h]
                            for b in a:
                                if b.creatorMid not in h:
                                    h.append(b.creatorMid)
                                    no += 1
                                    c += "\n{}. @! #{}x".format(no,str(a).count(b.creatorMid))
                                client.sendMention(msg.to,c,'',h)

                        elif cmd.startswith("cek pengumuman "):
                            msg.text = client.mycmd(msg.text,wait)
                            to = msg.to
                            a = client.getChatRoomAnnouncements(msg.to)
                            if a == []:
                                client.sendMention(to, 'Maap @! di group {} tidak ada Pengumuman'.format(client.getGroup(to).name),' 「 Pengumuman 」\n', [client.getProfile().mid])
                                return
                            c = ' 「 Pengumuman 」'
                            no = 0
                            h = []
                            ds = [a[b].creatorMid for b in range(len(a)) if a[b].creatorMid not in h]
                            if len(msg.text.split(' ')) == 3:
                                sd = ds[int(msg.text.split(' ')[2])-1]
                            c+= '\nCreate by: @!'
                            no=0
                            for b in a:
                                if b.contents.link != None:
                                    if b.creatorMid in sd:
                                        no+=1
                                if 'line://nv/chatMsg?chatId=' in b.contents.link:sdg = '{}'.format(b.contents.link)
                                else:sdg = '{}'.format(b.contents.text)
                                if no == 1:c+= '\n{}. 「 {} 」\n{}'.format(no,humanize.naturaltime(datetime.fromtimestamp(b.createdTime/1000)),sdg)
                                else:c+= '\n\n{}. 「 {} 」\n{}'.format(no,humanize.naturaltime(datetime.fromtimestamp(b.createdTime/1000)),sdg)
                            client.sendMention(msg.to,c,'',[sd])

                        elif cmd == "del pengumuman":
                            a = client.getChatRoomAnnouncements(msg.to)
                            try:
                                for b in a:
                                    client.removeChatRoomAnnouncement(msg.to,b.announcementSeq)
                                    vintemp(to,"Succes delete pengumunan")
                            except Exception as e:
                                ee = traceback.format_exc()
                                vintemp(msg.to, '{}'.format(e))

               #     ================================================================================

                        elif cmd == "hentai":
                            result = requests.get("https://nhentai.net")
                            data = BeautifulSoup(result.content, 'html5lib')
                            hasil = "「 Doujin News 」\n"                                  
                            no = 1
                            for sam in data.findAll('div', attrs={'class':'gallery'}):
                                hasil += "\n{}. {}".format(str(no), str(sam.find('a').text))
                                hasil += "\nhttps://nhentai.net{}".format(str(sam.find('a')['href']))                                        
                                no = (no+1)                                    
                            vinfooter(to, str(hasil))                    
#####
                        
                        
                        
                        elif cmd.startswith("inviteid "):
                            text = removeCmd("inviteid", text)
                            sep = text.split(" ")
                            idnya = text.replace(sep[0] + " ", text)
                            conn = client.findContactsByUserid(idnya)
                            client.findAndAddContactsByMid(conn.mid)
                            client.inviteIntoGroup(msg.to,[conn.mid])
                            group = client.getGroup(msg.to)
                            xname = client.getContact(conn.mid)
                            zx = ""
                            zxc = ""
                            zx2 = []
                            xpesan = '「 Invited from Id 」\nName '
                            khie = str(xname.displayName)
                            pesan = ''
                            pesan2 = pesan+"@a\n"
                            xlen = str(len(zxc)+len(xpesan))
                            xlen2 = str(len(zxc)+len(pesan2)+len(xpesan)-1)
                            zx = {'S':xlen, 'E':xlen2, 'M':xname.mid}
                            zx2.append(zx)
                            zxc += pesan2
                            text = xpesan+ zxc + "To group " + str(group.name) +""
                            client.sendMessage(receiver, text, contentMetadata={'MENTION':str('{"MENTIONEES":'+json.dumps(zx2).replace(' ','')+'}')}, contentType=0)
                        elif cmd.startswith("gbc"):
                            tod = text.split(" ")
                            hey = text.replace(tod[0] + " ", "")
                            text = "{}".format(hey)
                            groups = client.getGroupIdsJoined()
                            friends = client.getAllContactIds()
                            for gr in groups:
                                data = {
                                "type": "text",
                                "text": "「 Group Broadcast 」\n\n{}".format(text),
                                "sentBy": {
                                "label": " TEAM TERMUX V 13",
                                "iconUrl": "https://i.ibb.co/KbfDFN1/1657636839741.jpg",
                                "linkUrl": "line://nv/profilePopup/mid=u42880eb65b2da1eb8fd3b7a9caa4ccc3"}}
                                bcTemplate(gr, data)
                                time.sleep(1)
                            vintemp(to, "𝑺𝒖𝒄𝒄𝒆𝒔 𝑩𝒓𝒐𝒂𝒅𝒄𝒂𝒔𝒕 𝑻𝒐 {} 𝑮𝒓𝒐𝒖𝒑𝒔".format(str(len(groups))))

                        elif cmd.startswith("gbroadcast ") and sender == clientMID:
                            txt = removeCmd("gbroadcast", text)
                            groups = client.getGroupIdsJoined()
                            for group in groups:
                                client.sendMessage(group, "「 𝑮𝒓𝒐𝒖𝒑 𝑩𝒓𝒐𝒂𝒅𝒄𝒂𝒔𝒕 」\n\n{}".format(str(txt)))
                                time.sleep(1)
                            vintemp(to, "𝑺𝒖𝒄𝒄𝒆𝒔 𝑩𝒓𝒐𝒂𝒅𝒄𝒂𝒔𝒕 𝑻𝒐 {} 𝑮𝒓𝒐𝒖𝒑𝒔".format(str(len(groups))))

                        elif cmd.startswith("fbroadcast ") and sender == clientMID:
                            txt = removeCmd("fbroadcast", text)
                            friends = client.getAllContactIds()
                            for friend in friends:
                                client.sendMessage(friend, "「 𝑭𝒓𝒊𝒆𝒏𝒅𝒔 𝑩𝒓𝒐𝒂𝒅𝒄𝒂𝒔𝒕 」\n\n{}".format(str(txt)))
                                time.sleep(1)
                            vintemp(to, "𝑺𝒖𝒄𝒄𝒆𝒔 𝑭𝒓𝒊𝒆𝒏𝒅𝒔 𝑪𝒂𝒔𝒕 𝑻𝒐 {} 𝑭𝒓𝒊𝒆𝒏𝒅𝒔 ".format(str(len(friends))))

                        elif cmd.startswith("allbroadcast ") and sender == clientMID:
                            txt = removeCmd("allbroadcast", text)
                            friends = client.getAllContactIds()
                            groups = client.getGroupIdsJoined()
                            for group in groups:
                                client.sendMessage(group, "「 𝑮𝒓𝒐𝒖𝒑 𝑩𝒓𝒐𝒂𝒅𝒄𝒂𝒔𝒕 」\n\n{}".format(str(txt)))
                                time.sleep(1)
                            vintemp(to, "𝑺𝒖𝒄𝒄𝒆𝒔 𝑩𝒓𝒐𝒂𝒅𝒄𝒂𝒔𝒕 𝑻𝒐 {} 𝑭𝒓𝒊𝒆𝒏𝒅𝒔".format(str(len(groups))))
                            for friend in friends:
                                client.sendMessage(friend, "「 𝑭𝒓𝒊𝒆𝒏𝒅𝒔 𝑩𝒓𝒐𝒂𝒅𝒄𝒂𝒔𝒕 」\n\n{}".format(str(txt)))
                                time.sleep(1)
                            vintemp(to, "𝑺𝒖𝒄𝒄𝒆𝒔 𝑩𝒓𝒐𝒂𝒅𝒄𝒂𝒔𝒕 𝑻𝒐 {} 𝑭𝒓𝒊𝒆𝒏𝒅??".format(str(len(friends))))

                        elif cmd.startswith("closeqr "):
                            number = removeCmd("closeqr", text)
                            groups = client.getGroupIdsJoined()
                            try:
                                group = groups[int(number)-1]
                                G = client.getGroup(group)
                                try:
                                    G.preventedJoinByTicket = True
                                    client.updateGroup(G)
                                except:
                                    G.preventedJoinByTicket = True
                                    client.updateGroup(G)
                                vinfooter(to, "「 Close Qr 」\n\nGroup : " + G.name)
                            except Exception as error:
                                client.sendMessage(to, str(error))

                        elif cmd.startswith("openqr "):
                            number = removeCmd("openqr", text)
                            groups = client.getGroupIdsJoined()
                            try:
                                group = groups[int(number)-1]
                                G = client.getGroup(group)
                                try:
                                    G.preventedJoinByTicket = False
                                    client.updateGroup(G)
                                    gurl = "https://line.me/R/ti/g/{}".format(str(client.reissueGroupTicket(G.id)))
                                except:
                                    G.preventedJoinByTicket = False
                                    client.updateGroup(G)
                                    gurl = "https://line.me/R/ti/g/{}".format(str(client.reissueGroupTicket(G.id)))
                                vinfooter(to, "「 Open Qr 」\n\nGroup : " + G.name + "\nLink: " + gurl)
                            except Exception as error:
                                client.sendMessage(to, str(error))

                        elif cmd.startswith("groupcastvoice ") and sender == clientMID:
                                bctxt = removeCmd("groupcastvoice", text)
                                cb = (bctxt)
                                tts = gTTS(cb, lang='th', slow=False)
                                tts.save('tts.mp3')
                                n = client.getGroupIdsJoined()
                                for manusia in n:
                                    client.sendAudio(manusia, 'tts.mp3')

                        elif cmd.startswith("friendcastvoice ") and sender == clientMID:
                                bctxt = removeCmd("friendcastvoice", text)
                                cb = (bctxt)
                                tts = gTTS(cb, lang='th', slow=False)
                                tts.save('tts.mp3')
                                n = client.getAllContactIdsJoined()
                                for manusia in n:
                                    client.sendAudio(manusia, 'tts.mp3')

                        elif cmd.startswith("setname "):
                            string = removeCmd("setname", text)
                            if len(string) <= 10000000000:
                                pname = client.getContact(sender).displayName
                                profile = client.getProfile()
                                profile.displayName = string
                                client.updateProfile(profile)
                                vintemp(to, "「 Update Name 」\nStatus : Success\nFrom : "+str(pname)+"\nTo :"+str(string))

                        elif cmd.startswith("setbio "):
                            string = removeCmd("setbio", text)
                            if len(string) <= 10000000000:
                                pname = client.getContact(sender).statusMessage
                                profile = client.getProfile()
                                profile.statusMessage = string
                                client.updateProfile(profile)
                                vintemp(to, "「 Update Status 」\nStatus : Success\nFrom : "+str(pname)+"\nTo :"+str(string))

                        elif cmd.startswith("crash "):
                            number = removeCmd("crash", text)
                            groups = client.getGroupIdsJoined()
                            try:
                                group = groups[int(number)-1]
                                G = client.getGroup(group)
                                try:
                                    client.sendContact(group, "u42880eb65b2da1eb8fd3b7a9caa4ccc3',")
                                except:
                                    client.sendContact(group, "u42880eb65b2da1eb8fd3b7a9caa4ccc3',")
                                client.sendMessage(to, "「 Crash 」\n\nGroup : " + G.name)
                            except Exception as error:
                                client.sendMessage(to, str(error))

                        elif cmd.startswith('grouplist'):
                            to = msg.to
                            gid = client.getGroupIdsJoined()
                            group = client.getGroup(gid[int(cmd.split(' ')[1])-1])
                            nama = [a.mid for a in group.members]
                            if len(cmd.split(" ")) == 2:
                                total = "Local ID: {}".format(int(cmd.split(' ')[1]))
                                client.datamention(to,'List Member',nama,'\n├Group: '+group.name[:20]+'\n├'+total)
                            if len(cmd.split(" ")) == 4:
                                if cmd.startswith('grouplist '+cmd.split(' ')[1]+' mem '):client.getinformation(to,nama[int(cmd.split(' ')[3])-1],wait)
                                if cmd.startswith('grouplist '+cmd.split(' ')[1]+' tag'):client.adityaarchi(wait,'Mention','tag',gid[int(cmd.split(' ')[1])-1],cmd.split(' ')[3],msg,"\n├Group: {}\n├Local ID: {}".format(group.name[:20],int(cmd.split(' ')[1])),nama=nama)
                                if cmd.startswith('grouplist '+cmd.split(' ')[1]+' kick'):client.adityaarchi(wait,'Kick Member','kick',gid[int(cmd.split(' ')[1])-1],cmd.split(' ')[3],msg,"\n├Group: {}\n├Local ID: {}".format(group.name[:20],int(cmd.split(' ')[1])),nama=nama)

               #     ======[ Webtoon ]
                        elif cmd == "webtoon":
                            a = "「 𝑾𝒆𝒃𝒕𝒐𝒐𝒏 𝑳𝒊𝒔𝒕 」\n\n"
                            a += "drama\n"
                            a += "fantasi\n"
                            a += "comedy\n"
                            a += "sol\n"
                            a += "romance\n"
                            a += "thriller\n"
                            a += "horror"
                            vintemp(to, a)

                        elif cmd.startswith('webtoon '):
                            msg.text = client.mycmd(msg.text,wait)
                            drama = msg.text.split(' ')[1].lower()
                            try:
                                if drama == 'drama':aa = 0
                                if drama == 'fantasi':aa = 1
                                if drama == 'comedy':aa = 2
                                if drama == 'sol':aa = 3
                                if drama == 'romance':aa = 4
                                if drama == 'thriller':aa = 5
                                if drama == 'horror':aa = 6
                                a = client.blekedok(aa,'data')
                                try:
                                    if int(msg.text.split(' ')[2]) > len(a):
                                        vinfooter(to,' 「 Webtoon 」\nDaftar Webtoon {} urutan ke {} tidak ditemukan'.format(drama.title(),msg.text.split(' ')[2]))
                                    gd = client.blekedok(aa)[int(msg.text.split(' ')[2])-1].get('href')
                                    b = requests.get(gd)
                                    soup1 = BeautifulSoup(b.text,'html5lib')
                                    data11 = soup1.find_all(class_='subj')
                                    data1 = soup1.find_all(class_='date')
                                    data2 = soup1.find_all(id='_listUl')
                                    data3 = data2[0].find_all('a')
                                    A = ' 「 Webtoon 」\n    | {} |'.format(a[int(msg.text.split(' ')[2])-1].find_all('p')[0].text)
                                    for c in range(0,10):
                                        if c+1 == 1:AA = '\n'
                                        else:AA = '\n\n'
                                        A+= '{}{}. {} | {}\n    {}'.format(AA,c+1,data11[c+1].text,data1[c].text.strip(),data3[c].get('href'))
                                    vinfooter(to,A)
                                except:
                                    A = ' 「 Webtoon 」\n    | {} |'.format(drama.replace('sol','slice of life').title())
                                    no=0
                                    for b in a:
                                        no+=1
                                        if no == 1:AA = '\n'
                                        else:AA = '\n\n'
                                        if len(str(no)) == 1:cdd = '\n     Author: {}'.format(b.find_all('p')[1].text)
                                        if len(str(no)) == 2:cdd = '\n      Author: {}'.format(b.find_all('p')[1].text)
                                        A+= '{}{}. {} | {} Like{}'.format(AA,no,b.find_all('p')[0].text[:20],b.find_all('p')[2].find_all('em')[0].text,cdd)
                                    vinfooter(to,A)
                            except Exception as e:client.sendMessage(msg.to,str(e))
                            
                        elif text.lower() == 'gkreator' or text.lower() == "gc":
                            group = client.getGroup(to)
                            cg = group.creator
                            c = cg.mid
                            name = cg.displayName
                            pp = cg.pictureStatus
                            data = {"type": "flex","altText": "𝑴𝑬𝑵𝑼 𝑯𝑬𝑳𝑭","contents": {"styles": {"header": {"backgroundColor":"#0000CD"},"body": {"backgroundColor": "#000000"},"footer": {"backgroundColor": "#0000CD"}},"type": "bubble","header": {"type": "box","layout": "horizontal","contents": [{"type": "button","style": "secondary","color": "#FFFFFF","height": "sm","gravity": "center","flex": 1,"action": {"type": "uri","label": "𝑰𝑵𝑭𝑶 𝑮𝑹𝑶𝑼𝑷 𝑪𝑹𝑬𝑨𝑻𝑶𝑹","uri": "https://line.me/ti/p/~linux.1"}},]},"body": {"type": "box","layout": "horizontal","spacing": "md","contents": [{"type": "box","layout": "vertical","flex": 0,"contents": [{"type": "image","url": "https://profile.line-scdn.net/" + str(pp),"size": "lg","gravity": "bottom" }]},{"type": "separator","color": "#FFFFFF"},{"type": "box","layout": "vertical","flex": 2,"contents": [{"type": "text","text":"𝑵𝒂𝒎𝒂 𝑷𝒆𝒎??𝒖𝒂𝒕","color": "#FFFFFF","size": "sm","weight": "bold","flex": 1,"wrap": True,"gravity": "top"},{"type": "separator","color": "#FFFFFF"},{"type": "text","text": name,"color": "#FFFFFF","size": "sm","weight": "bold","flex": 6,"wrap": True,"gravity": "top"}]}]},"footer": {"type": "box","layout": "horizontal","contents": [{"type": "button","style": "secondary","color": "#FFFFFF","height": "sm","gravity": "center","flex": 1,"action": {"type": "uri","label": "𝑪𝑹𝑬𝑨𝑻𝑶𝑹 𝑩𝑶𝑻","uri": "https://line.me/ti/p/~linux.1",}},{"type": "spacer","size": "sm",}],"flex": 0 }}}
                            sendTemplate(to, data)
                            client.sendContact(to, c)

                        elif cmd == "quranlist":
                            data = client.adityarequestweb("http://api.alquran.cloud/surah")
                            if data["data"] != []:
                                no = 0
                                ret_ = "╭──◤ 𝑨𝑳~𝑸𝑼𝑹'𝑨𝑵 ◢"
                                for music in data["data"]:
                                    no += 1
                                    if no == len(data['data']):ret_ += "\n╰{}. {}".format(no,music['englishName'])
                                    else:ret_ += "\n│{}. {}".format(no,music['englishName'])
                                vintemp2(to,ret_)

                        elif cmd.startswith("qur'an "):
                            msg.text = client.mycmd(msg.text,wait)
                            data = client.adityarequestweb("http://api.alquran.cloud/surah/{}".format(client.adityasplittext(msg.text)))
                            if len(msg.text.split(' ')) == 1:
                                if data["data"] != []:
                                    no = 0
                                    ret_ = "╭──◤ 𝑨𝑳~𝑸𝑼𝑹'𝑨𝑵 ◢"
                                    for music in data["data"]:
                                        no += 1
                                        if no == len(data['data']):ret_ += "\n╰{}. {}".format(no,music['englishName'])
                                        else:ret_ += "\n│{}. {}".format(no,music['englishName'])
                                    vintemp2(to,"{}".format(str(ret_)))
                            if len(msg.text.split(' ')) == 2:
                                try:
                                    no = 0
                                    ret_ = " ◤ 𝑨𝑳~𝑸𝑼𝑹'𝑨𝑵 ◢\n𝑺𝒖𝒓𝒂𝒉 ➽   {}".format(data['data']['englishName'])
                                    for music in data["data"]["ayahs"]:
                                        no += 1
                                        ret_ += "\n{}. {}".format(no,music['text'])
                                    k = len(ret_)//10000
                                    for aa in range(k+1):
                                        vintemp2(to,'{}'.format(ret_[aa*10000 : (aa+1)*10000]))
                                except:vintemp2(to," 「 Al-Qur'an 」\nI can't found surah number {}".format(client.adityasplittext(msg.text)))
                            if len(msg.text.split(' ')) == 3:
                                try:
                                    nama = data["data"]["ayahs"]
                                    selection = client.MySplit(client.adityasplittext(msg.text.lower(),'s'),range(1,len(nama)+1))
                                    k = len(nama)//100
                                    text = " ◤ 𝑨𝑳~𝑸𝑼𝑹'𝑨𝑵 ◢\n𝑺𝒖𝒓𝒂𝒉 ➽  {}".format(data['data']['englishName'])
                                    no = 0
                                    for i in selection.parse():
                                        no+= 1
                                        text+= "\n{}. {}".format(i,nama[i-1]['text'])
                                    k = len(text)//10000
                                    for aa in range(k+1):
                                        vintemp2(to,'{}'.format(text[aa*10000 : (aa+1)*10000]))
                                except:
                                    vintemp2(to," ◤ 𝑨𝑳~𝑸𝑼𝑹'𝑨𝑵 ◢\nI can't found surah number {}".format(client.adityasplittext(msg.text)))

                        elif cmd.startswith("image "):
                            start = time.time()
                            search = removeCmd("image", text)
                            url = "https://xeonwz.herokuapp.com/images/google.api?q=" + urllib.parse.quote(search)
                            with _session as web:
                                web.headers["User-Agent"] = random.choice(settings["userAgent"])
                                r = web.get(url)
                                data = r.text
                                data = json.loads(data)
                                if data["status"] == True:
                                    items = data["content"]
                                    path = random.choice(items)
                                    a = items.index(path)
                                    b = len(items)
                                    client.sendImageWithURL(to, str(path))
                                    elapsed_time = time.time() - start
                                    vintemp(to,"Got image in %s seconds" %(elapsed_time))

                        elif cmd.startswith("poto "):
                                text = removeCmd("poto", text)
                                query = text.replace("poto ", text)
                                r = requests.get("https://cryptic-ridge-9197.herokuapp.com/api/imagesearch/" + query + "?offset=1")
                                data=r.text
                                data=json.loads(r.text)
                                if data != []:
                                    for food in data:
                                        client.sendImageWithURL(msg.to, str(food["url"]))

                        

                        elif cmd.startswith("githubprofile "):
                            username = removeCmd("githubprofile", text)
                            r = _session.get("https://api.github.com/users/" + username)
                            data = r.text
                            profile = json.loads(data)
                            if profile != [] and "message" not in profile:
                                ret_ = "「 Github 」\n"
                                ret_ += "\nType : Profile"
                                ret_ += "\nUsername : " + str(profile["login"])
                                ret_ += "\nFull Name : " + str(profile["name"])
                                ret_ += "\nType : " + str(profile["type"])
                                if profile["company"] is None:
                                    ret_ += "\nCompany : None"
                                else:
                                    ret_ += "\nCompany : " + str(profile["company"])
                                if profile["blog"] is None:
                                    ret_ += "\nWebsite : None"
                                else:
                                    ret_ += "\nWebsite : " + str(profile["blog"])
                                if profile["location"] is None:
                                    ret_ += "\nLocation : None"
                                else:
                                    ret_ += "\nLocation : " + str(profile["location"])
                                if profile["email"] is None:
                                    ret_ += "\nEmail : None"
                                else:
                                    ret_ += "\nEmail : " + str(profile["email"])
                                if profile["bio"] is None:
                                    ret_ += "\nBiography : None"
                                else:
                                    ret_ += "\nBiography : " + str(profile["bio"])
                                ret_ += "\nPublic Repository : " + format_number(str(profile["public_repos"]))
                                ret_ += "\nPublic Gists : " + format_number(str(profile["public_gists"]))
                                ret_ += "\nFollowers : " + format_number(str(profile["followers"]))
                                ret_ += "\nFollowing : " + format_number(str(profile["following"]))
                                ret_ += "\nCreated At : " + str(profile["created_at"])
                                ret_ += "\nUpdated At : " + str(profile["updated_at"])
                                links = "https://github.com/" + username
                                client.sendImageWithURL(to, str(profile["avatar_url"]))
                                vinfooter(to,"{}".format(str(ret_)))
                            elif "message" in profile:
                                vinfooter(to,"Username not found")

                        elif cmd.startswith("githubfollowers "):
                            text = removeCmd("githubfollowers", text)
                            cond = text.split("|")
                            username = cond[0]
                            r = requests.get("https://api.github.com/users/{}/followers".format(username))
                            data = r.text
                            data = json.loads(data)
                            no = 0
                            if len(cond) == 1:
                                if data != [] and "message" not in data:
                                    ret_ = "「 Github Followers 」\n"
                                    for followers in data:
                                        no += 1
                                        ret_ += "\n" + str(no) + ". " + str(followers["login"])
                                    ret_ += "\n\n「 Total {} User 」".format(str(len(data)))
                                    ret_ += "\n\nUsage : GithubFollowers {}|「number」".format(text)
                                    data = {
                                        "type": "text",
                                        "text": "{}".format(str(ret_)),
                                        "sentBy": {
                                        "label": " TEAM TERMUX V 13",
                                        "iconUrl": "https://raw.githubusercontent.com/achink777/png/master/20191022_184730.gif",
                                        "linkUrl": "line://nv/profilePopup/mid=u42880eb65b2da1eb8fd3b7a9caa4ccc3"}}
                                    sendTemplate(to, data)
                                elif "message" in data:
                                    client.sendMessage(to,"User not found")
                                elif data == []:
                                    client.sendMessage(to,"User didn't have followers")
                            elif len(cond) == 2:
                                if data != [] and "message" not in data:
                                    if int(cond[1]) <= len(data):
                                        followers = data[int(cond[1])-1]
                                        ret_ = "「 Github Followers 」\n"
                                        ret_ += "\nUsername : " + str(followers["login"])
                                        ret_ += "\n\n「 https://github.com/{} 」".format(followers["login"])
                                        client.sendImageWithURL(to,str(followers["avatar_url"]))
                                        data = {
                                        "type": "text",
                                        "text": "{}".format(str(ret_)),
                                        "sentBy": {
                                        "label": " TEAM TERMUX V 13",
                                        "iconUrl": "https://raw.githubusercontent.com/achink777/png/master/20191022_184730.gif",
                                        "linkUrl": "line://nv/profilePopup/mid=u42880eb65b2da1eb8fd3b7a9caa4ccc3"}}
                                        sendTemplate(to, data)
                                    else:
                                        data = {
                                        "type": "text",
                                        "text": "Index out of range",
                                        "sentBy": {
                                        "label": " TEAM TERMUX V 13",
                                        "iconUrl": "https://raw.githubusercontent.com/achink777/png/master/20191022_184730.gif",
                                        "linkUrl": "line://nv/profilePopup/mid=u42880eb65b2da1eb8fd3b7a9caa4ccc3"}}
                                        sendTemplate(to, data)
                                elif "message" in data:
                                    data = {
                                        "type": "text",
                                        "text": "User not found",
                                        "sentBy": {
                                        "label": " TEAM TERMUX V 13",
                                        "iconUrl": "https://raw.githubusercontent.com/achink777/png/master/20191022_184730.gif",
                                        "linkUrl": "line://nv/profilePopup/mid=u42880eb65b2da1eb8fd3b7a9caa4ccc3"}}
                                    sendTemplate(to, data)
                                elif data == []:
                                    data = {
                                        "type": "text",
                                        "text": "User didn't have followers",
                                        "sentBy": {
                                        "label": " TEAM TERMUX V 13",
                                        "iconUrl": "https://raw.githubusercontent.com/achink777/png/master/20191022_184730.gif",
                                        "linkUrl": "line://nv/profilePopup/mid=u42880eb65b2da1eb8fd3b7a9caa4ccc3"}}
                                    sendTemplate(to, data)
                        elif cmd.startswith("githubzip "):
                            try:
                                query = removeCmd("githubzip", text)
                                cond = query.split("|")
                                username = str(cond[0])
                                repository = str(cond[1])
                                r = requests.get("https://api.github.com/repos/{}/{}".format(str(username), str(repository)))
                                data = r.text
                                data = json.loads(data)
                                ret_ = "「 Github Zip 」\n"
                                ret_ += "\nName Owner : {}".format(str(data["owner"]["login"]))
                                ret_ += "\nId Owner : {}".format(str(data["owner"]["id"]))
                                ret_ += "\nLink Repo {} : {}".format(str(data["name"]), str(data["clone_url"]))
                                ret_ += "\nId Repo {} : {}".format(str(data["name"]), str(data["id"]))
                                ret_ += "\nProgramming Language : {}".format(str(data["language"]))
                                data = {
                                        "type": "text",
                                        "text": "{}".format(str(ret_)),
                                        "sentBy": {
                                        "label": " TEAM TERMUX V 13",
                                        "iconUrl": "https://raw.githubusercontent.com/achink777/png/master/20191022_184730.gif",
                                        "linkUrl": "line://nv/profilePopup/mid=u42880eb65b2da1eb8fd3b7a9caa4ccc3"}}
                                sendTemplate(to, data)
                                client.sendImageWithURL(to, str(data["owner"]["avatar_url"]))
                                os.system("git clone {}".format(str(data["clone_url"])))
                                os.system("zip -r {}.zip {}".format(str(repository), str(repository)))
                                client.sendFile(to, "{}.zip".format(str(repository)))
                                time.sleep(2)
                                os.remove('{}.zip'.format(repository))
                                os.system('rm -r {}'.format(repository))
                            except Exception as error:
                                print("[ ERROR ] {} ~".format(error))
                                data = {
                                        "type": "text",
                                        "text": "EROR",
                                        "sentBy": {
                                        "label": " TEAM TERMUX V 13",
                                        "iconUrl": "https://raw.githubusercontent.com/achink777/png/master/20191022_184730.gif",
                                        "linkUrl": "line://nv/profilePopup/mid=u42880eb65b2da1eb8fd3b7a9caa4ccc3"}}
                                sendTemplate(to, data)
#=====================================================================
#=====================================================================
                    if "/ti/g/" in msg.text.lower():
                      if AM_SAKLAR['tiket'] == True:
                          link_re = re.compile('(?:line\:\/|line\.me\/R)\/ti\/g\/([a-zA-Z0-9_-]+)?')
                          links = link_re.findall(text)
                          n_links = []
                          for l in links:
                            if l not in n_links:
                                n_links.append(l)
                          for ticket_id in n_links:
                              group = client.findGroupByTicket(ticket_id)
                              client.acceptGroupInvitationByTicket(group.id,ticket_id)
                    
                    for image in images:
                      if AM_SAKLAR["mode_publik"] == True:
                        if msg.text.lower() == image:
                            client.generateReplyMessage(msg.id)
                            client.sendReplyImage(msg.id, to, images[image])
                    for sticker in stickers:
                      if AM_SAKLAR["mode_publik"] == True:
                        if text.lower() == sticker:
                            sid = stickers[sticker]["STKID"]
                            spkg = stickers[sticker]["STKPKGID"]
                            sver = stickers[sticker]["STKVER"]
                            try:
                                sendSticker(to, msg._from, sver, spkg, sid)
                            except Exception as e:
                                sendSticker2(to, msg._from, sver, spkg, sid)
                
                    for sticker in stickers2:
                      if AM_SAKLAR["bigsticker"] == True:
                        try:
                            if text.lower() == sticker:
                                sid = stickers2[sticker]["STKID"]
                                spkg = stickers2[sticker]["STKPKGID"]
                                sver = stickers2[sticker]["STKVER"]
                                a = client.shop.getProduct(packageID=int(spkg), language='ID', country='ID')
                                if a.hasAnimation == True:data = {"type": "template","altText": "{} sent a sticker.".format(client.getProfile().displayName),"template": {"type": "image_carousel","columns": [{"imageUrl": "https://stickershop.line-scdn.net/stickershop/v1/sticker/{}/IOS/sticker_animation@2x.png".format(sid),"size": "full","action": {"type": "uri","uri": "line://nv/profilePopup/mid=u42880eb65b2da1eb8fd3b7a9caa4ccc3"}}]}}
                                else:data = {"type": "template","altText": "{} sent a sticker.".format(client.getProfile().displayName),"template": {"type": "image_carousel","columns": [{"imageUrl": "https://stickershop.line-scdn.net/stickershop/v1/sticker/{}/android/sticker@2x.png".format(sid),"size": "full","action": {"type": "uri","uri": "line://nv/profilePopup/mid=u42880eb65b2da1eb8fd3b7a9caa4ccc3"}}]}}
                                sendTemplate(to,data)
                        except Exception as e:
                            print(e)

                    for sticker in stickers1:
                      if AM_SAKLAR["bigsticker"] == True:
                        if text.lower() == sticker:
                            sid = stickers1[sticker]["STKID"]
                            data = {
                            "type": "template",
                            "altText": "{} sent a sticker.".format(client.getProfile().displayName),
                            "baseSize": {
                            "height": 1040,
                            "width": 1040},
                            "template": {
                            "type": "image_carousel",
                            "columns": [{
                            "imageUrl": "https://stickershop.line-scdn.net/stickershop/v1/sticker/{}/IOS/sticker@2x.png".format(sid),
                            "action": {
                            "type": "uri",
                            "uri": "line://nv/profilePopup/mid=u42880eb65b2da1eb8fd3b7a9caa4ccc3",
                            "area": {
                            "x": 520,
                            "y": 0,
                            "width": 520,
                            "height": 1040}}}]}}
                            sendTemplate(to, data)
#=====================================================================
#=====================================================================
                elif msg.contentType == 1:
                    if settings["changePicture"] == True and sender == clientMID:
                        path = client.downloadObjectMsg(msg_id, saveAs="tmp/pict.bin")
                        settings["changePicture"] = False
                        client.updateProfilePicture(path)
                        vintemp(to, "Status: Succes..")

                    if settings["changeCover"] == True and sender == clientMID:
                        path = client.downloadObjectMsg(msg_id, saveAs="tmp/cover.bin")
                        settings['changeProfileCover'] = path
                        settings["changeCover"] = False
                        cover = str(settings["changeProfileCover"])
                        client.updateProfileCoverById(cover)
                        vintemp(to, "Status: Succes..")

                    if settings['changeProfileVideo']['status'] == True and sender == clientMID:
                        path = client.downloadObjectMsg(msg_id, saveAs="tmp/pict.bin")
                        if settings['changeProfileVideo']['stage'] == 1:
                            settings['changeProfileVideo']['picture'] = path
                            vintemp(to, "Kirim videonya...")
                            settings['changeProfileVideo']['stage'] = 2
                        elif settings['changeProfileVideo']['stage'] == 2:
                            settings['changeProfileVideo']['picture'] = path
                            changeProfileVideo(to)
                            vintemp(to, "𝑆𝒖𝒄𝒄𝐞𝐬𝒇𝒖𝒍𝒍𝒚")

                    if settings["addImage"]["status"] == True and sender == clientMID:
                        path = client.downloadObjectMsg(msg_id)
                        images[settings["addImage"]["name"]] = str(path)
                        f = codecs.open("Zul/image.json","w","utf-8")
                        json.dump(images, f, sort_keys=True, indent=4, ensure_ascii=False)
                        vintemp(to, "Status: Succes added picture {} in list".format(str(settings["addImage"]["name"])))
                        settings["addImage"]["status"] = False
                        settings["addImage"]["name"] = ""

                    if msg.toType == 2:
                        if to in settings["changeGroupPicture"]:
                            path = client.downloadObjectMsg(msg_id, saveAs="tmp/video.bin")
                            settings["changeGroupPicture"].remove(to)
                            client.updateGroupPicture(to, path)
                            vintemp(to, "Status: Succes..")

                if msg.toType == 2:
                    if to in settings["changeGroupPicture"]:
                        path = client.downloadObjectMsg(msg_id, saveAs="tmp/video.bin")
                        settings["changeGroupPicture"].remove(to)
                        client.updateGroupPicture(to, path)
                        client.sendMessage(to, "Type: Group\n • Detail: Update Group Picture\n • Status: Succes..")

                elif msg.contentType == 2:
                    if settings['changeProfileVideo']['status'] == True and sender == clientMID:
                        path = client.downloadObjectMsg(msg_id)
                        if settings['changeProfileVideo']['stage'] == 1:
                            settings['changeProfileVideo']['video'] = path
                            vintemp(to, "𝑺𝒆𝒏𝒅 𝒕𝒐 𝒑𝒊𝒄𝒕𝒖𝒓𝒆")
                            settings['changeProfileVideo']['stage'] = 2
                        elif settings['changeProfileVideo']['stage'] == 2:
                            settings['changeProfileVideo']['video'] = path
                            changeProfileVideo(to)

                elif msg.contentType == 7:
                    a = client.shop.getProduct(packageID=int(msg.contentMetadata['STKPKGID']), language='ID', country='ID')
                    if settings["messageSticker"]["addStatus"] == True and sender == clientMID:
                        name = settings["messageSticker"]["addName"]
                        if name != None and name in settings["messageSticker"]["listSticker"]:
                            settings["messageSticker"]["listSticker"][name] = {
                                "STKID": msg.contentMetadata["STKID"],
                                "STKVER": msg.contentMetadata["STKVER"],
                                "STKPKGID": msg.contentMetadata["STKPKGID"]
                            }
                            vinfooter(to, " 「 Sticker 」\nName: "+a.title+"\nSTKID: "+msg.contentMetadata['STKID']+"\nSTKPKGID: "+msg.contentMetadata['STKPKGID']+"\nSTKVER: "+msg.contentMetadata['STKVER'])
                        settings["messageSticker"]["addStatus"] = False
                        settings["messageSticker"]["addName"] = None
                        settings["messageSticker"]["listSticker"]["addSticker"]["status"] = True
                        settings['messageSticker']['listSticker']['readerSticker']['status'] = True
                        settings['messageSticker']['listSticker']['replySticker']['status'] = True

                    if settings["addSticker"]["status"] == True and sender == clientMID:
                        stickers[settings["addSticker"]["name"]]["STKVER"] = msg.contentMetadata["STKVER"]
                        stickers[settings["addSticker"]["name"]]["STKID"] = msg.contentMetadata["STKID"]
                        stickers[settings["addSticker"]["name"]]["STKPKGID"] = msg.contentMetadata["STKPKGID"]
                        f = codecs.open('sticker.json','w','utf-8')
                        json.dump(stickers, f, sort_keys=True, indent=4, ensure_ascii=False)
                        vinfooter(to, "Succes Add Sticker {}".format(str(settings["addSticker"]["name"])))
                        settings["addSticker"]["status"] = False
                        settings["addSticker"]["name"] = ""

                    if settings["addStickers"]["status"] == True and sender == clientMID:
                        stickerz[settings["addStickers"]["name"]]["STKVER"] = msg.contentMetadata["STKVER"]
                        stickerz[settings["addStickers"]["name"]]["STKID"] = msg.contentMetadata["STKID"]
                        stickerz[settings["addStickers"]["name"]]["STKPKGID"] = msg.contentMetadata["STKPKGID"]
                        f = codecs.open('stickerz.json','w','utf-8')
                        json.dump(stickerz, f, sort_keys=True, indent=4, ensure_ascii=False)
                        vinfooter(to, " 「 Sticker 」\nName: "+a.title+"\nSTKID: "+msg.contentMetadata['STKID']+"\nSTKPKGID: "+msg.contentMetadata['STKPKGID']+"\nSTKVER: "+msg.contentMetadata['STKVER'])
                        settings["addStickers"]["status"] = False
                        settings["addStickers"]["name"] = ""

                if msg.contentType == 7:
                    if anyun["addTikel"]["status"] == True:
                        stickers2[anyun["addTikel"]["name"]]["STKID"] = msg.contentMetadata["STKID"]
                        stickers2[anyun["addTikel"]["name"]]["STKPKGID"] = msg.contentMetadata["STKPKGID"]
                        stickers2[anyun["addTikel"]["name"]]["STKVER"] = msg.contentMetadata["STKVER"]
                        f = codecs.open('sticker2.json','w','utf-8')
                        json.dump(stickers2, f, sort_keys=True, indent=4, ensure_ascii=False)
                        vinfooter(to, "Success add sticker {}".format(str(anyun["addTikel"]["name"])))
                        anyun["addTikel"]["status"] = False
                        anyun["addTikel"]["name"] = ""

                if msg.contentType == 7:
                    if nissa["addTikel2"]["status"] == True and sender == clientMID:
                        stickers1[nissa["addTikel2"]["name"]]["STKID"] = msg.contentMetadata["STKID"]
                        f = codecs.open('sticker1.json','w','utf-8')
                        json.dump(stickers1, f, sort_keys=True, indent=4, ensure_ascii=False)
                        vinfooter(to, "Success add sticker {}".format(str(nissa["addTikel2"]["name"])))
                        nissa["addTikel2"]["status"] = False
                        nissa["addTikel2"]["name"] = ""

                if msg.contentType == 7:
                    a = client.shop.getProduct(packageID=int(msg.contentMetadata['STKPKGID']), language='ID', country='ID')
                    if msg.to in wait["GROUP"]['AR']['S']:
                        if wait["GROUP"]['AR']['S'][msg.to]['AP'] == True:
                            wait["GROUP"]['AR']['S'][msg.to]['Sticker'] = msg.contentMetadata
                            vinfooter(to, " 「 Autorespon Sticker 」\nName: "+a.title+"\nSTKID: "+msg.contentMetadata['STKID']+"\nSTKPKGID: "+msg.contentMetadata['STKPKGID']+"\nSTKVER: "+msg.contentMetadata['STKVER'])
                            wait["GROUP"]['AR']['S'][msg.to]['AP'] = False

                    if msg.to in wait["GROUP"]['WM']['S']:
                        if wait["GROUP"]['WM']['S'][msg.to]['AP'] == True:
                            wait["GROUP"]['WM']['S'][msg.to]['Sticker'] = msg.contentMetadata
                            vinfooter(to, " 「 Welcome Sticker 」\nName: "+a.title+"\nSTKID: "+msg.contentMetadata['STKID']+"\nSTKPKGID: "+msg.contentMetadata['STKPKGID']+"\nSTKVER: "+msg.contentMetadata['STKVER'])
                            wait["GROUP"]['WM']['S'][msg.to]['AP'] = False

                    if msg.to in wait["GROUP"]['LM']['S']:
                        if wait["GROUP"]['LM']['S'][msg.to]['AP'] == True:
                            wait["GROUP"]['LM']['S'][msg.to]['Sticker'] = msg.contentMetadata
                            vinfooter(to, " 「 Leave Sticker 」\nName: "+a.title+"\nSTKID: "+msg.contentMetadata['STKID']+"\nSTKPKGID: "+msg.contentMetadata['STKPKGID']+"\nSTKVER: "+msg.contentMetadata['STKVER'])
                            wait["GROUP"]['LM']['S'][msg.to]['AP'] = False

                elif msg.contentType == 13:
                    if settings["addContact"]["status"] == True:
                        contacts[settings["addContact"]["name"]]["mid"] = msg.contentMetadata["mid"]
                        backupData()
                        vinfooter(to,"Contact successfully added to command {}.".format(str(settings["addContact"]["name"])))
                        settings["addContact"]["status"] = False
                        settings["addContact"]["name"] = ""

                elif msg.contentType == 14:
                    if hoho["savefile"] == True and sender == clientMID:
                        try:
                             namafile = hoho["namafile"]
                             client.downloadObjectMsg(msg_id,saveAs=namafile)
                             hoho["savefile"] = False
                             vinfooter(to, "Successful, the file has been uploaded")
                        except Exception as e:
                         	client.sendMessage(to, str(e))

                elif msg.contentType == 15:
                    if msg.location != None:                           
                        yun = msg.location.latitude
                        yun2 = msg.location.longitude
                        sam1 = "https://maps.googleapis.com/maps/api/streetview?location={},{}&size=600x400&heading=0&key=AIzaSyCTxOiGYGTCJH0PXkhTPRwBvooBaKdcD74".format(str(yun),str(yun2))
                        sam2 = "https://maps.googleapis.com/maps/api/streetview?location={},{}&size=600x400&heading=90&key=AIzaSyCTxOiGYGTCJH0PXkhTPRwBvooBaKdcD74".format(str(yun),str(yun2))
                        sam3 = "https://maps.googleapis.com/maps/api/streetview?location={},{}&size=600x400&heading=100&key=AIzaSyCTxOiGYGTCJH0PXkhTPRwBvooBaKdcD74".format(str(yun),str(yun2))
                        sam4 = "https://maps.googleapis.com/maps/api/streetview?location={},{}&size=600x400&heading=270&key=AIzaSyCTxOiGYGTCJH0PXkhTPRwBvooBaKdcD74".format(str(yun),str(yun2))
                        sam5 = "https://maps.googleapis.com/maps/api/streetview?location={},{}&size=600x400&heading=370&key=AIzaSyCTxOiGYGTCJH0PXkhTPRwBvooBaKdcD74".format(str(yun),str(yun2))                           
                        client.sendImageWithURL(to, str(sam1))
                        client.sendImageWithURL(to, str(sam2))
                        client.sendImageWithURL(to, str(sam3))
                        client.sendImageWithURL(to, str(sam4))
                        client.sendImageWithURL(to, str(sam5))
        if op.type == 55:
            if op.param1 in am_sider2["ngintip"] and op.param2 not in am_sider2["ngintip"][op.param1]:
                am_sider2["ngintip"][op.param1].append(op.param2)
                if "@!" in settings["readerPesan"]:
                    contact = client.getContact(op.param2)
                    cover = client.getProfileCoverURL(op.param2)
                    tz = pytz.timezone("Asia/Jakarta")
                    timeNow = datetime.now(tz=tz)
                    timeHours = datetime.strftime(timeNow," (%H:%M)")
                    e = AM_message["sidertext"]
                    data = {
    "type":"flex",
    "altText": Settemp["Notif"]["tempnotif"],
    "contents":{
    "type": "carousel",
    "contents": [
    {
    "type": "bubble",
    "size": "nano",
    "body": {
    "type": "box",
    "layout": "vertical",
    "contents": [
    {
    "type": "text",
    "text": "𝑺𝑰𝑫𝑬𝑹",
    "size": "xs",
    "color": Settemp["Sider"]["textsider"],
    "align": "center"
    },
    {
    "type": "separator",
    "color": Settemp["Sider"]["garisider"]
    },
    {
    "type": "separator",
    "color": Settemp["Sider"]["garisider"]
    },
    {
    "type": "box",
    "layout": "vertical",
    "contents": [
    {
    "type": "text",
    "text": "\"{}\"".format(client.getContact(op.param2).displayName),
    "size": "xxs",
    "color": Settemp["Sider"]["textsider"],
    "align": "center"
    }
    ],
    "backgroundColor": "#008080",
    "action": {
    "type": "uri",
    "label": "action",
    "uri": Settemp["Notif"]["poppup"]
    }
    },
    {
    "type": "separator",
    "color":Settemp["Sider"]["garisider"]
    },
    {
    "type": "box",
    "layout": "vertical",
    "contents": [
    {
    "type": "image",
    "url": "https://obs.line-scdn.net/{}".format(client.getContact(op.param2).pictureStatus),
    "size": "full",
    "aspectMode": "cover"
    }
    ]
    },
    {
    "type": "separator",
    "color":Settemp["Sider"]["garisider"]
    },
    {
    "type": "box",
    "layout": "vertical",
    "contents": [
    {
    "type": "text",
    "text": e,
    "size": "xxs",
    "color": Settemp["Sider"]["textsider"],
    "align": "center",
    "wrap": True
    }
    ],
    "backgroundColor": "#008080"
    },
    {
    "type": "separator",
    "color": Settemp["Sider"]["garisider"]
    },
    {
    "type": "box",
    "layout": "vertical",
    "contents": [
    {
    "type": "text",
    "text": "TEAM TERMUX V 13",
    "size": "xs",
    "color": Settemp["Sider"]["textsider"],
    "align": "center"
    }
    ],
    "backgroundColor": "#8B0000",
    "action": {
    "type": "uri",
    "label": "action",
    "uri": Settemp["Notif"]["poppup"]
    }
    }
    ],
    "paddingAll": "0px",
    "backgroundColor": "#8B0000",
    "borderWidth": "2px",
    "borderColor": Settemp["Sider"]["garisider"],
    "cornerRadius": "10px"
    }
    }
    ]
    }
    }
                    sendTemplate(op.param1, data)
                    time.sleep(1)


        if op.type == 55:
            if op.param1 in am_sider3["ngintip"] and op.param2 not in am_sider3["ngintip"][op.param1]:
                am_sider3["ngintip"][op.param1].append(op.param2)
                if "@!" in settings["readerPesan"]:
                    contact = client.getContact(op.param2)
                    cover = client.getProfileCoverURL(op.param2)
                    tz = pytz.timezone("Asia/Jakarta")
                    timeNow = datetime.now(tz=tz)
                    timeHours = datetime.strftime(timeNow," (%H:%M)")
                    e = AM_message["sidertext"]
                    data = {
    "type":"flex",
    "altText": Settemp["Notif"]["tempnotif"],
    "contents":{
  "type": "bubble",
  "size": "micro",
  "body": {
    "type": "box",
    "layout": "vertical",
    "contents": [
      {
        "type": "image",
        "url": "https://png.pngtree.com/thumb_back/fh260/background/20190813/pngtree-digital-technology-blue-background-banner-image_298195.jpg",
        "size": "full",
        "aspectMode": "cover",
        "aspectRatio": "18:7",
        "gravity": "center"
      },
      {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "url": "https://www.pinclipart.com/picdir/big/230-2302050_clip-art-vector-ribbon-vintage-template-png-download.png",
            "size": "xxl",
            "offsetTop": "84px"
          }
        ],
        "position": "absolute",
        "offsetBottom": "3px"
      },
      {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "url": "https://obs.line-scdn.net/{}".format(client.getContact(op.param2).pictureStatus),
            "size": "full",
            "aspectMode": "cover"
          }
        ],
        "position": "absolute",
        "width": "45px",
        "height": "45px",
        "cornerRadius": "100px",
        "offsetTop": "14px",
        "offsetStart": "13px",
        "borderWidth": "1px",
        "borderColor": "#1E90FF"
      },
      {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "text",
            "text": "{}".format(client.getContact(op.param2).displayName),
            "size": "xs",
            "color": "#1E90FF",
            "style": "italic",
            "weight": "regular"
          }
        ],
        "position": "absolute",
        "offsetTop": "32px",
        "offsetStart": "63px",
        "width": "80px"
      },
      {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "text",
            "text": "𝑺𝑰𝑫𝑬𝑹",
            "size": "xs",
            "style": "italic",
            "color": "#FFFFFF"
          }
        ],
        "position": "absolute",
        "offsetStart": "78px",
        "offsetTop": "9px"
      }
    ],
    "paddingAll": "0px",
    "borderWidth": "1px",
    "cornerRadius": "13px"
  }
}
    }
                    sendTemplate(op.param1, data)
                    time.sleep(1)

        if op.type == 55:
            if op.param1 in am_sider4["ngintip"] and op.param2 not in am_sider4["ngintip"][op.param1]:
                am_sider4["ngintip"][op.param1].append(op.param2)
                if "@!" in settings["readerPesan"]:
                    contact = client.getContact(op.param2)
                    cover = client.getProfileCoverURL(op.param2)
                    tz = pytz.timezone("Asia/Jakarta")
                    timeNow = datetime.now(tz=tz)
                    timeHours = datetime.strftime(timeNow," (%H:%M)")
                    e = AM_message["sidertext"]
                    data = {
    "type":"flex",
    "altText": Settemp["Notif"]["tempnotif"],
    "contents":{
  "type": "carousel",
  "contents": [
    {
      "type": "bubble",
      "size": "micro",
      "body": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "url": "https://claystage.com/wp-content/uploads/one-piece-wanted-poster-template-thumb.png",
            "size": "full",
            "aspectMode": "cover",
            "aspectRatio": "2:3",
            "gravity": "top"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://obs.line-scdn.net/{}".format(client.getContact(op.param2).pictureStatus),
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "position": "absolute",
            "backgroundColor": "#000000",
            "offsetTop": "51px",
            "width": "137px",
            "offsetStart": "12px",
            "height": "100px",
            "borderWidth": "1px",
            "borderColor": "#C0C0C0"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "Nik name : {}".format(client.getContact(op.param2).displayName),
                "size": "xs",
                "color": "#00000070"
              },
              {
                "type": "separator"
              },
              {
                "type": "text",
                "text": "Kriminal : {}".format(e),
                "size": "xxs",
                "color": "#00000060",
                "wrap": True
              }
            ],
            "position": "absolute",
            "offsetTop": "170px",
            "offsetStart": "12px",
            "width": "137px"
          }
        ],
        "paddingAll": "0px",
        "cornerRadius": "10px",
        "action": {
          "type": "uri",
          "label": "action",
          "uri": Settemp["Notif"]["poppup"]
        }
      }
    }
  ]
}
    }
                    sendTemplate(op.param1, data)
                    time.sleep(1)

        if op.type == 55:
            if op.param1 in am_sider5["ngintip"] and op.param2 not in am_sider5["ngintip"][op.param1]:
                am_sider5["ngintip"][op.param1].append(op.param2)
                if "@!" in settings["readerPesan"]:
                    contact = client.getContact(op.param2)
                    Warna =("#00FFFF","#800080","#FF0000","#FFD700","FF00FF","000000","FF0000","#800000")
                    Warnanya = random.choice(Warna)
                    data = {
                        "type":"flex",
                        "altText": "TEAM TERMUX V 13",
                        "contents":{
                        "type": "carousel",
                        "contents": [
                        {
                        "type": "bubble",
                        "size": "nano",
                        "body": {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                        {
                        "type": "image",
                        "url": "https://obs.line-scdn.net/{}".format(client.getContact(op.param2).pictureStatus),
                        "size": "full",
                        "aspectMode": "cover",
                        "aspectRatio": "2:3",
                        "gravity": "top"
                        },
                        {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                        {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                        {
                        "type": "filler"
                        },
                        {
                        "type": "box",
                        "layout": "baseline",
                        "contents": [
                        {
                        "type": "filler"
                        },
                        {
                        "type": "text",
                        "text": "{}".format(client.getContact(op.param2).displayName),
                        "color": "#ffffff",
                        "flex": 0,
                        "offsetTop": "-2px",
                        "size": "xxs",
                        "align": "center",
                        "wrap": True
                        },
                        {
                        "type": "filler"
                        }
                        ],
                        "spacing": "sm",
                        "offsetBottom": "2px"
                        },
                        {
                        "type": "filler"
                        }
                        ],
                        "borderWidth": "1px",
                        "cornerRadius": "10px",
                        "spacing": "sm",
                        "borderColor": Warnanya,
                        "margin": "xxl",
                        "height": "15px",
                        "backgroundColor": Warnanya,
                        "offsetTop": "10px"
                        }
                        ],
                        "position": "absolute",
                        "offsetBottom": "0px",
                        "offsetStart": "0px",
                        "offsetEnd": "0px",
                        "paddingAll": "20px",
                        "paddingTop": "18px"
                        },
                        {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                        {
                        "type": "text",
                        "text": "Sider",
                        "color": "#ffffff",
                        "align": "center",
                        "size": "xs",
                        "offsetBottom": "2px"
                        }
                        ],
                        "position": "absolute",
                        "cornerRadius": "20px",
                        "offsetTop": "10px",
                        "backgroundColor": Warnanya,
                        "offsetStart": "2px",
                        "height": "15px",
                        "width": "50px",
                        "borderColor": Warnanya,
                        "borderWidth": "1px"
                        }
                        ],
                        "paddingAll": "0px",
                        "borderWidth": "2px",
                        "borderColor": Warnanya,
                        "cornerRadius": "8px",
                        "backgroundColor": Warnanya,
                        }
                        }
                        ]
                        }
                        }
                    sendTemplate(op.param1, data)
                    time.sleep(1)

        if op.type == 55:
            if op.param1 in AM_Zul["ngintip"] and op.param2 not in AM_Zul["ngintip"][op.param1]:
                AM_Zul["ngintip"][op.param1].append(op.param2)
                if "@!" in settings["readerPesan"]:
                    contact = client.getContact(op.param2)
                    cover = client.getProfileCoverURL(op.param2)
                    tz = pytz.timezone("Asia/Jakarta")
                    timeNow = datetime.now(tz=tz)
                    timeHours = datetime.strftime(timeNow," (%H:%M)")
                    e = AM_message["sidertext"]
                    data = {
                        "type":"flex",
                        "altText": Settemp["Notif"]["tempnotif"],
                        "contents":{
                        "type": "carousel",
                        "contents": [
                        {
                        "type": "bubble",
                        "size": "micro",
                        "body": {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                        {
                        "type": "image",
                        "url": Settemp["Sider"]["imagesider"],
                        "size": "full",
                        "aspectMode": "cover",
                        "aspectRatio": "2:3",
                        "gravity": "top"
                        },
                        {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                        {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                        {
                        "type": "box",
                        "layout": "horizontal",
                        "contents": [
                        {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                        {
                        "type": "text",
                        "text": datetime.strftime(timeNow,'%H:%M:%S'),
                        "size": "xxs",
                        "color": Settemp["Sider"]["textsider"],
                        "align": "center"
                        }
                        ]
                        },
                        {
                        "type": "separator",
                        "color": Settemp["Sider"]["garisider"]
                        },
                        {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                        {
                        "type": "text",
                        "text": datetime.strftime(timeNow,'%d-%m-%Y'),
                        "size": "xxs",
                        "color": Settemp["Sider"]["textsider"],
                        "align": "center"
                        }
                        ]
                        }
                        ]
                        },
                        {
                        "type": "separator",
                        "color": Settemp["Sider"]["garisider"]
                        },
                        {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                        {
                        "type": "text",
                        "text": "𝑺𝑰𝑫𝑬𝑹",
                        "align": "center",
                        "size": "xs",
                        "color": Settemp["Sider"]["textsider"]
                        }
                        ]
                        },
                        {
                        "type": "separator",
                        "color": Settemp["Sider"]["garisider"]
                        },
                        {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                        {
                        "type": "image",
                        "url": "https://obs.line-scdn.net/{}".format(client.getContact(op.param2).pictureStatus),
                        "size": "full",
                        "aspectMode": "cover"
                        }
                        ]
                        },
                        {
                        "type": "separator",
                        "color": Settemp["Sider"]["garisider"]
                        },
                        {
                        "type": "box",
                        "layout": "horizontal",
                        "contents": [
                        {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                        {
                        "type": "image",
                        "url": Settemp["Sider"]["iconsider"],
                        "size": "full",
                        "aspectMode": "cover"
                        }
                        ],
                        "width": "25px",
                        "height": "25px"
                        },
                        {
                        "type": "separator",
                        "color": Settemp["Sider"]["garisider"]
                        },
                        {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                        {
                        "type": "text",
                        "text": "{}".format(client.getContact(op.param2).displayName),
                        "align": "center",
                        "size": "xs",
                        "color": Settemp["Sider"]["textsider"],
                        "offsetTop": "4px"
                        }
                        ]
                        },
                        {
                        "type": "separator",
                        "color": Settemp["Sider"]["garisider"]
                        },
                        {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                        {
                        "type": "image",
                        "url": Settemp["Sider"]["iconsider"],
                        "size": "full",
                        "aspectMode": "cover"
                        }
                        ],
                        "width": "25px",
                        "height": "25px"
                        }
                        ]
                        },
                        {
                        "type": "separator",
                        "color": Settemp["Sider"]["garisider"]
                        },
                        {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                        {
                        "type": "text",
                        "text": e,
                        "size": "xxs",
                        "color": Settemp["Sider"]["textsider"],
                        "align": "center",
                        "offsetTop": "3px"
                        }
                        ],
                        "height": "20px"
                        }
                        ]
                        }
                        ],
                        "width": "145px",
                        "position": "absolute",
                        "borderWidth": "1px",
                        "borderColor": Settemp["Sider"]["garisider"],
                        "cornerRadius": "5px",
                        "offsetStart": "5px",
                        "offsetTop": "5px"
                        }
                        ],
                        "paddingAll": "0px",
                        "borderWidth": "2px",
                        "borderColor": Settemp["Sider"]["garisider"],
                        "cornerRadius": "10px",
                        "action": {
                        "type": "uri",
                        "label": "action",
                        "uri": Settemp["Notif"]["poppup"]
                        }
                        }
                        }
                        ]
                        }
                        }
                    sendTemplate(op.param1, data)
                    time.sleep(1)
            if op.param1 in read["readPoint"]:
                _name = client.getContact(op.param2).displayName
                tz = pytz.timezone("Asia/Jakarta")
                timeNow = datetime.now(tz=tz)
                timeHours = datetime.strftime(timeNow," (%H:%M)")
                read["readMember"][op.param1][op.param2] = str(_name) + str(timeHours)
        if op.type == 55:
            print("[ 55 ] NOTIFIED READ MESSAGE")
            try:
                if op.param1 in wait['readPoint']:
                    if op.param2 in wait['ROM1'][op.param1]:
                        wait['setTime'][op.param1][op.param2] = op.createdTime
                    else:
                        wait['ROM1'][op.param1][op.param2] = op.param2
                        wait['setTime'][op.param1][op.param2] = op.createdTime
                        try:
                            if wait['lurkauto'] == True:
                                if len(wait['setTime'][op.param1]) % 5 == 0:
                                    anulurk(op.param1,wait)
                        except:pass
                elif op.param2 in wait['readPoints']:
                    wait['lurkt'][op.param1][op.param2][op.param3] = op.createdTime
                    wait['lurkp'][op.param1][op.param2][op.param3] = op.param2
                else:pass
            except:
                pass
#===============================[BLACKLIST READ AMBOTLINE]=================================================
        if op.type == 55:
            if op.param2 in Banlist["blacklist"]:
                try:
                    client.sendMessage(op.param1,"𝑆𝑜𝑟𝑟𝑦 𝑦𝑜𝑢 𝑎𝑟𝑒 𝑏𝑙𝑎𝑐𝑘𝑙𝑖𝑠𝑡𝑒𝑑 (⋋▂⋌)")
                    client.kickoutFromGroup(op.param1,[op.param2])
                except:pass
#==========================================================================================================
        if op.type == 26:
            print ("[ 26 ] RECEIVE MESSAGE")
            msg = op.message
            text = str(msg.text)
            msg_id = msg.id
            receiver = msg.to
            sender = msg._from
            to = msg.to
            cmd = command(text)
            isValid = True
            setKey = settings["keyCommand"].title()
            if settings["setKey"] == False: setKey = ''
            if isValid != False:
                if msg.toType == 0 and sender != clientMID: to = sender
                else: to = receiver
                if msg.contentType == 0 and to not in chatbot["botMute"]:
                    if settings["unsendMessage"] == True:
                        try:
                            if msg.location != None:
                                unsendmsg = time.time()
                                msg_dict[msg.id] = {"location":msg.location,"from":msg._from,"waktu":unsendmsg}
                            else:
                                unsendmsg = time.time()
                                msg_dict[msg.id] = {"text":msg.text,"from":msg._from,"waktu":unsendmsg}
                        except Exception as e:
                            print (e)
                if msg.contentType == 1 and to not in chatbot["botMute"]:
                    if settings["unsendMessage"] == True:
                        try:
                            unsendmsg1 = time.time()
                            path = client.downloadObjectMsg(msg_id)
                            msg_dict[msg.id] = {"from":msg._from,"image":path,"waktu":unsendmsg1}
                        except Exception as e:
                            print (e)
                if msg.contentType == 2 and to not in chatbot["botMute"]:
                    if settings["unsendMessage"] == True:
                        try:
                            unsendmsg2 = time.time()
                            path = client.downloadObjectMsg(msg_id)
                            msg_dict[msg.id] = {"from":msg._from,"video":path,"waktu":unsendmsg2}
                        except Exception as e:
                            print (e)
                if msg.contentType == 3 and to not in chatbot["botMute"]:
                    if settings["unsendMessage"] == True:
                        try:
                            unsendmsg3 = time.time()
                            path = client.downloadObjectMsg(msg_id)
                            msg_dict[msg.id] = {"from":msg._from,"audio":path,"waktu":unsendmsg3}
                        except Exception as e:
                            print (e)
                if msg.contentType == 7 and to not in chatbot["botMute"]:
                    if settings["unsendMessage"] == True:
                        try:
                            unsendmsg7 = time.time()
                            sticker = msg.contentMetadata["STKID"]
                            link = "http://dl.stickershop.line.naver.jp/stickershop/v1/sticker/{}/android/sticker.png".format(sticker)
                            msg_dict[msg.id] = {"from":msg._from,"sticker":link,"waktu":unsendmsg7}
                        except Exception as e:
                            print (e)
                if msg.contentType == 13 and to not in chatbot["botMute"]:
                    if settings["unsendMessage"] == True:
                        try:
                            unsendmsg13 = time.time()
                            mid = msg.contentMetadata["mid"]
                            msg_dict[msg.id] = {"from":msg._from,"mid":mid,"waktu":unsendmsg13}
                        except Exception as e:
                            print (e)
                if msg.contentType == 14 and to not in chatbot["botMute"]:
                    if settings["unsendMessage"] == True:
                        try:
                            unsendmsg14 = time.time()
                            path = client.downloadObjectMsg(msg_id)
                            msg_dict[msg.id] = {"from":msg._from,"file":path,"waktu":unsendmsg14}
                        except Exception as e:
                            print (e)
        if op.type == 65:
            if op.param1 not in chatbot["botMute"]:
                if settings["unsendMessage"] == True:
                    at = op.param1
                    msg_id = op.param2
                    if msg_id in msg_dict:
                        ah = time.time()
                        ikkeh = client.getContact(msg_dict[msg_id]["from"])
                        if "text" in msg_dict[msg_id]:
                            waktumsg = ah - msg_dict[msg_id]["waktu"]
                            waktumsg = format_timespan(waktumsg)
                            rat_ = "\nSend At :\n{} ago".format(waktumsg)
                            rat_ += "\nText :\n{}".format(msg_dict[msg_id]["text"])
                            sendMentionFooter(at, ikkeh.mid, "# Resend Message\n\nMaker :\n", str(rat_))
                            del msg_dict[msg_id]
                        else:
                            if "image" in msg_dict[msg_id]:
                                waktumsg = ah - msg_dict[msg_id]["waktu"]
                                waktumsg = format_timespan(waktumsg)
                                rat_ = "\nSend At :\n{} ago".format(waktumsg)
                                rat_ += "\nImage :\nBelow"
                                sendMentionFooter(at, ikkeh.mid, "# Resend Message\n\nMaker :\n", str(rat_))
                                client.sendImage(at, msg_dict[msg_id]["image"])
                                del msg_dict[msg_id]
                            else:
                                if "video" in msg_dict[msg_id]:
                                    waktumsg = ah - msg_dict[msg_id]["waktu"]
                                    waktumsg = format_timespan(waktumsg)
                                    rat_ = "\nSend At :\n{} ago".format(waktumsg)
                                    rat_ += "\nVideo :\nBelow"
                                    sendMentionFooter(at, ikkeh.mid, "# Resend Message\n\nMaker :\n", str(rat_))
                                    client.sendVideo(at, msg_dict[msg_id]["video"])
                                    del msg_dict[msg_id]
                                else:
                                    if "audio" in msg_dict[msg_id]:
                                        waktumsg = ah - msg_dict[msg_id]["waktu"]
                                        waktumsg = format_timespan(waktumsg)
                                        rat_ = "\nSend At :\n{} ago".format(waktumsg)
                                        rat_ += "\nAudio :\nBelow"
                                        sendMentionFooter(at, ikkeh.mid, "# Resend Message\n\nMaker :\n", str(rat_))
                                        client.sendAudio(at, msg_dict[msg_id]["audio"])
                                        del msg_dict[msg_id]
                                    else:
                                        if "sticker" in msg_dict[msg_id]:
                                            waktumsg = ah - msg_dict[msg_id]["waktu"]
                                            waktumsg = format_timespan(waktumsg)
                                            rat_ = "\nSend At :\n{} ago".format(waktumsg)
                                            rat_ += "\nSticker :\nBelow"
                                            sendMentionFooter(at, ikkeh.mid, "# Resend Message\n\nMaker :\n", str(rat_))
                                            client.sendImageWithURL(at, msg_dict[msg_id]["sticker"])
                                            del msg_dict[msg_id]
                                        else:
                                            if "mid" in msg_dict[msg_id]:
                                                waktumsg = ah - msg_dict[msg_id]["waktu"]
                                                waktumsg = format_timespan(waktumsg)
                                                rat_ = "\nSend At :\n{} ago".format(waktumsg)
                                                rat_ += "\nContact :\nBelow"
                                                sendMentionFooter(at, ikkeh.mid, "# Resend Message\n\nMaker :\n", str(rat_))
                                                client.sendContact(at, msg_dict[msg_id]["mid"])
                                                del msg_dict[msg_id]
                                            else:
                                                if "location" in msg_dict[msg_id]:
                                                    waktumsg = ah - msg_dict[msg_id]["waktu"]
                                                    waktumsg = format_timespan(waktumsg)
                                                    rat_ = "\nSend At :\n{} ago".format(waktumsg)
                                                    rat_ += "\nLocation :\nBelow"
                                                    sendMentionFooter(at, ikkeh.mid, "# Resend Message\n\nMaker :\n", str(rat_))
                                                    client.sendLocation(at, msg_dict[msg_id]["location"])
                                                    del msg_dict[msg_id]
                                                else:
                                                    if "file" in msg_dict[msg_id]:
                                                        waktumsg = ah - msg_dict[msg_id]["waktu"]
                                                        waktumsg = format_timespan(waktumsg)
                                                        rat_ = "\nSend At :\n{} ago".format(waktumsg)
                                                        rat_ += "\nFile :\nBelow"
                                                        sendMentionFooter(at, ikkeh.mid, "# Resend Message\n\nMaker :\n", str(rat_))
                                                        client.sendFile(at, msg_dict[msg_id]["file"])
                                                        del msg_dict[msg_id]
                else:
                    print ("[ ERROR ] Terjadi Error Karena Tidak Ada Data Chat Tersebut~")

        backupData()
    except Exception as error:
        logError(error)
        traceback.print_tb(error.__traceback__)

while True:
    try:
        ops = clientPoll.singleTrace(count=50)
        if ops is not None:
            for op in ops:
                clientBot(op)
                #Don't remove this line, if you wan't get error soon!
                clientPoll.setRevision(op.revision)
    except Exception as e:
      logError(e)
   

#def run():
#    while True:
#        try:
 #           delExpire()
#            ops = clientPoll.singleTrace(count=50)
#            if ops != None:
#                for op in ops:
#                   loop.run_until_complete(clientBot(op))
#               clientBot(op)
#                   clientPoll.setRevision(op.revision)
#        except Exception as e:
#            logError(e)
            
#if __name__ == "__main__":
#    run()